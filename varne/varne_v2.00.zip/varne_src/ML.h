#ifndef ML_H
#define ML_H

#include "Model.h"

#include "gsl/gsl_rng.h"
#include "nlopt.h"

typedef struct MLBuilder * MLBuilder_t;
typedef struct ML * ML_t;

/**
 * @param m On return d is set to NULL.
 * @param improveRelTolerance A small real number (e.g., 1e-15); used to decide whether a new search 
 *                 initilised using the outcome of the search immediately before results in significant 
 *                 improvements in the ln-likelihood.
 * @param numNoImprove A positive integer. If it is set to 1, then no improvement search is attempted. 
 *               Otherwise, improvement searches will be conducted until a nnoimp number of consecutive 
 *               improvement attempts lead to no significant improvement in the ln-likelihood, 
 *               as determined by imprftol.
 * @param maxNumImprove A positive integer. This is the maximum number of
 *               improvement searches attempted.
 * @return 
 */
MLBuilder_t MLBuilder_new(Model_t *m, int numSearches, double improveRelTolerance, int numNoImprove, int maxNumImprove, char **msg);

/**
 * @param relTolerance Set relative tolerance on optimization parameters: stop when an optimization step 
 *             (or an estimate of the optimum) changes every parameter by less than rtol 
 *             multiplied by the absolute value of the parameter.
 * @param maxNumOfFuncEvaluations Stop when the number of function evaluations exceeds maxeval.
 * @param maxExecutionTime Stop when the optimization time (in seconds) exceeds maxtime
 */
void MLBuilder_addAlgorithm(MLBuilder_t mb, const char * algorithmName, 
        double relTolerance, int maxNumOfFuncEvaluations, double maxExecutionTime, char **msg);

/**
 * On return mb is set to NULL.
 */
ML_t MLBuilder_build(MLBuilder_t *mb);

/**
 * On return ml is set to NULL.
 */
void ML_free(ML_t *ml);

/**
 * Either res_file OR log_file can be NULL, depending on what is needed to be recorded.
 * @param ml
 * @param res_file
 * @param log_file
 * @param rng
 * @param init Initial values. If this is NULL, then the built-in method is used to initialise the search. Otherwise
 *             the values in init are used. These values should be on the scale that the likelihood function expects.
 *             No check is carried out as to whether the values are valid.
 */
void ML_search(ML_t ml, FILE *res_file, FILE *log_file, gsl_rng *rng, double *init);

/**
 * With numSearches elements, this holds the likelihood obtained from the searches in reverse order.
 * The returned value should be freed by matrixalloc_1d_free
 */
double * ML_getLikelihoods(ML_t ml);

/**
 * A numSearches * Model_getNumParam() matrix, each row contains the MLEs associated with the corresponding element in ML_getLikelihoods().
 * The returned value should be freed by matrixalloc_2d_d_free
 */
double ** ML_getMLEs(ML_t ml);

/**
 * With numSearches elements, this holds the NLopt exit codes associated with the corresponding elements in ML_getLikelihoods().
 * The returned value should be freed by matrixalloc_1d_free
 */
nlopt_result * ML_getExitCodes(ML_t ml);

#endif /* ML_H */

