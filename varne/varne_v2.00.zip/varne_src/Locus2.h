/*
 * Created on 16 October 2018, 17:48
 */

#ifndef LOCUS2_H
#define LOCUS2_H

#include "Locus_def.h"

#include "LocusData2.h"

struct Locus2 {
    struct LocusData2 *data;
    /**
     * <ul>
     * <li> This is of the same length as data.len.
     * <li> id[i] stores the id of the Marth_t object in Locus2Executor for the sample size
     * <li> This is updated in LocusExecutor_new()
     * </ul>
     */
    int *id;
    
    int H;
    
    /**
     * 2 * H + 3 parameters: theta, f, g_1, ..., g_{H-1}, tau_1, ..., tau_{H-1}, err, c, t
     */
    int numParam;
    enum ParameterType *paramType;//parameter types under the full model, including theta
    char **paramName;//parameter names under the full model, including theta
};

#endif /* LOCUS2_H */

