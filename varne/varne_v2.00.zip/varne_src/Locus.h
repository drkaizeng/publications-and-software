#ifndef LOCUS_H
#define LOCUS_H

#include <stdbool.h>
#include <stdarg.h>
#include <stdio.h>

#include "ParameterType.h"

typedef struct LocusBuilder * LocusBuilder_t;
typedef struct Locus * Locus_t;
typedef struct LocusExecutor * LocusExecutor_t;

///////////////////////////////////////////////////////////////////////////////////////////////
//   Functions for locus_builder_t
///////////////////////////////////////////////////////////////////////////////////////////////

enum LocusType {
    LOCUS1, LOCUS2
};

/**
 * LOCUS1: stepwise population size change with polarisation error
 * <ul>
 * <li> ...: H and use_prof
 * <li> int H: This is 1 if the population size is constant
 * <li> bool use_prof: true if the profile likelihood is to be used
 * <li> full likelihood model 
 *      <ul>
 *      <li> parameters: theta, f, g_1, ..., g_{H-1}, tau_1, ..., tau_{H-1}, err 
 *      <li> If H = 1, parameters = theta, f, err for all loci.
 *      </ul>
 * <li> full profile likelihood
 *      <ul>
 *      <li> parameters: f, g_1, ..., g_{H-1}, tau_1, ..., tau_{H-1}, err
 *      <li> If H = 1, f, err are the only free parameter
 *      </ul>
 * </ul>
 * 
 * LOCUS2: stepwise population size change with polarisation error and divergence data
 * <ul>
 * <li> ...: int H
 * <li> Parameters: theta, f, g_1, ..., g_{H-1}, tau_1, ..., tau_{H-1}, err, c, t
 * </ul>
 * 
 * 
 * @param name The name of this dataset. This will be the prefix of all its parameter names. This is cloned.
 * @param msg If an error occurs, then msg[0] points to the error message. Otherwise msg[0] = NULL.
 */
LocusBuilder_t LocusBuilder_new(enum LocusType type, const char *name, char **msg, ...);

/**
 * LOCUS1
 * <ul>
 * <li> All input are cloned.
 * <li> int len: the number of sample sizes
 * <li> int *n: sample size
 * <li> double *m: number of sites with polymorphism data
 * <li> int *folded: 1 if SFS[i] is folded, 0 if unfolded
 * <li> double **sfs
 * </ul>
 *
 * LOCUS2
 * <ul>
 * <li> All input are cloned.
 * <li> int len: the number of sample sizes
 * <li> int *n: sample size
 * <li> double *m: number of sites with polymorphism data
 * <li> int *folded: 1 if SFS[i] is folded, 0 if unfolded
 * <li> double **sfs
 * <li> double md
 * <li> double sub
 * </ul> 
 * 
 */
void LocusBuilder_addData(LocusBuilder_t lb, char **msg, ...);

/**
 * On return lb points to NULL.
 */
Locus_t LocusBuilder_build(LocusBuilder_t *lb);



///////////////////////////////////////////////////////////////////////////////////////////////
//   Functions for locus_executor_t
///////////////////////////////////////////////////////////////////////////////////////////////



/**
 * This can be called multiple times.
 * 
 * LOCUS1 & LOCUS2
 * <ul>
 * <li> len: the total number of loci
 * <li> locus_t *loc: a list containing all the loci in the analysis
 * </ul>
 * 
 */
LocusExecutor_t LocusExecutor_new(enum LocusType type, char **msg, ...);

/**
 * On return, exec points to NULL.
 */
void LocusExecutor_free(LocusExecutor_t *exec);

LocusExecutor_t LocusExecutor_clone(LocusExecutor_t exec);

/**
 * @param grad The length is the same as x. It is assumed that all elements are 0 on entry
 * @param x On the original scale. Contains the parameters of the full likelihood or the profile likelihood model
 * @param derivative The length is the same as x. If derivative[j] = true, then the d(lnL)/d(param[j]) is stored in grad[j]
 * @param loc
 * @param exec
 */
double LocusExecutor_getLikelihood(double *grad, const double *x, const bool *derivative, Locus_t loc, LocusExecutor_t exec);


/**
 * For LOCUS_I
 * <ul>
 * <li> thetaMLE
 *      <ul>
 *      <li> If useProfile = false, then x[0] is returned.
 *      <li> The return value should be cast to (double *), which is of length 1. It contains the 
 *           MLE of theta.
 *      <li> ...: double *x (all the parameters in the model as defined by useProfile)
 *      </ul>
 * <li> fullLikelihood
 *      <ul>
 *      <li> ...: double *x (all the parameters in the model as defined by useProfile)
 *      <li> The return value should be cast to (double *), which is of length 1. It contains the 
 *           log likelihood calculated using the full likelihood function.
 *      </ul> 
 * </ul>
 * 
 */
void * LocusExecutor_extraFunction(const char *cmd, Locus_t loc, LocusExecutor_t exec, char **msg, ...);


///////////////////////////////////////////////////////////////////////////////////////////////
//  Functions for locus_t
///////////////////////////////////////////////////////////////////////////////////////////////

void Locus_free(Locus_t *loc);

enum LocusType Locus_getType(Locus_t loc);

/**
 * Return the name of the locus. The returned array should be freed.
 */
char * Locus_getName(Locus_t loc);

/**
 * The number of parameters. 
 */
int Locus_getNumParam(Locus_t loc);

/**
 * <ul>
 * <li> The returned array is of length locus_numParam() and should be freed (free(types)).
 * </ul>
 */
enum ParameterType * Locus_getParamTypes(Locus_t loc);

/**
 * <ul>
 * <li> The returned array is of length locus_numParam(). 
 * <li> The returned array should be freed (each element by free(names[i]) and then free(names)).
 * </ul>
 */
char ** Locus_getParamNames(Locus_t loc);

/**
 * LOCUS1 & LOCUS2
 * <ul>
 * <li> isAllSFSFolded
 *      <ul>
 *      <li> ...: no parameter needed
 *      <li> void * should be cast to bool *, which should be freed.
 *      <li> Return true if all SFS are folded
 *      </ul>
 * <li> sampleSizes
 *      <ul>
 *      <li> ...: no parameter needed
 *      <li> void * should be cast to void **
 *      <li> re[0]: int * of size 1. This is the number of sample sizes
 *      <li> re[1]: int * of size re[0][0]. The sample sizes
 *      <li> free(re[i]) and free(re)
 *      <li> 
 * </ul>
 */
void * Locus_extraFunction(const char *cmd, Locus_t loc, char **msg, ...);

#endif /* LOCUS_H */

