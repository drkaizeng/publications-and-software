/*
 * Created on 16 October 2018, 16:58
 */

#ifndef LOCUSDATA2_H
#define LOCUSDATA2_H

#include <stdbool.h>

struct LocusData2 {
    int len;
    int *n;//the sample size
    double *m;//length
    bool *folded;
    /*
     * For SNPs, either n/2 or n-1 elements, depending on whether it's folded or not. <br>
     */
    double **sfs;
    int *sfsLen;
    double numSeg;//the total number of segregating sites
    
    /** md=0 is allowed, in which case sub has to be 0. */
    double md;
    double sub;
};

/**
 * n, m, folded, sfs are cloned by this function
 */
struct LocusData2 * LocusData2_new(int len, int *n, double *m, int *folded, double **sfs, double md, double sub, char **msg);

/**
 */
void LocusData2_free(struct LocusData2 **data);

/**
 * Use void* to conform with <code>struct locus</code>
 * @return The number of alleles
 */
void LocusData2_getSampleSize(int *len, int **n, void *data);


#endif /* LOCUSDATA2_H */

