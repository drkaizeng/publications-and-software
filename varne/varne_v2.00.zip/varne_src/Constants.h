/*
 * Created on 16 October 2018, 14:47
 */

#ifndef CONSTANTS_H
#define CONSTANTS_H

#define REL_TOLERANCE 1e-8
#define CONSTRAINT_TOLERANCE 1e-8


#endif /* CONSTANTS_H */

