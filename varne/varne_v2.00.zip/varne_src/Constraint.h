/* 
 * Created on 21 February 2017, 12:33
 */

#ifndef CONSTRAINT_H
#    define CONSTRAINT_H

#include <stdbool.h>

/**
 * Constants should not be set by using this
 */
struct Constraint {
    /* the length of x in f(x) */
    int nx;
    double *x;//on the original scale; set to NULL if no used
    /* 
     * of length nx. <br>
     * These are the IDs of the parameters in the full model. <br>
     * None of the parameters involved should be a constant.
     * Set to NULL if no used
     */
    int *xi;
    double (* f)(const double *x, void *param);
    double (* df)(const double *x, int i, void *param); // d f(x) / dx[i]. The partial derivative of the i-th parameter (i in [0, nx-1]).
    /*
     * Additional parameters for f and df 
     */
    void *param;
    /*
     * This can be NULL if param is not used or is freed by some other methods (e.g., when param points to the current constraint_func object).
     * This is not for freeing x and xi.
     */
    void (* freeParam)(void *param);
};

/**
 * <ul>
 * <li> The parameters are not checked for their validity.
 * <li> x, xi, param: The memory of these must be dynamically allocated.
 * <li> x, xi, param: these are not cloned and the pointer is directly copied.
 * </ul>
 */
struct Constraint * Constraint_new(int nx, double *x, int *xi, 
        double (* f)(const double *x, void *param), double (* df)(const double *x, int i, void *param),
        void *param, void (* freeParam)(void *param));

/**
 * cf[0] will be freed. On return it will be set to NULL.
 */
void Constraint_free(struct Constraint **cf);

#endif /* CONSTRAINT_FUNC_H */

