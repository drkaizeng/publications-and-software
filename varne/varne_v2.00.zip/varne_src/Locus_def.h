#ifndef LOCUS_DEF_H
#define LOCUS_DEF_H

#include <stdarg.h>

#include "Locus.h"

struct LocusBuilder {
    /**
     * <ol>
     * <li> 0: no data. The object was just created by new()
     * <li> 1: data have been added
     * <li> build_executor can be called only when mode >= 1. 
     *      It does not change the code, because it can be called multiple times
     * </ol>
     */
    int mode;
    
    /* To be initialised in locus_builder_locus_i() etc */
    struct Locus *loc;
};

void Locus1Builder_new(LocusBuilder_t lb, const char *name, char **msg, va_list args);
LocusExecutor_t Locus1Executor_new(va_list args);


void Locus2Builder_new(LocusBuilder_t lb, const char *name, char **msg, va_list args);
LocusExecutor_t Locus2Executor_new(va_list args);

struct Locus {
    char *name;
    
    enum LocusType type;
    void *typeParam;
    void (* freeTypeParam)(void **type_param);
    
    void (* addData)(void *type_param, char **msg, va_list args);
    int (* getNumParam)(void *type_param);
    enum ParameterType * (* getParamTypes)(void *type_param);
    char ** (* getParamNames)(void *type_param);
    void * (* extraFunction)(const char *cmd, void *typeParam, char **msg, va_list args);
};

struct LocusExecutor {
    void *param;
    void (* freeParam)(void **param);
    void * (* clone)(void *param);
    double (* lnlike)(double *grad, const double *x, const bool *derivative, Locus_t loc, void *param);
    void * (* extraFunction)(const char *cmd, Locus_t loc, void *param, char **msg, va_list args);
};

#endif /* LOCUS_DEF_H */

