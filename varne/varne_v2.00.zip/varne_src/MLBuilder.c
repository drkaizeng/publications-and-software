#include "ML_def.h"

#include "PrintErrorMessage.h"
#include "Model.h"
#include "FindName.h"
#include "Constants.h"

#include "util/matrixalloc.h"
#include "util/error_msg.h"

/*
 * @since 2017.6.23 (copied from dfeml), 8.1
 */
MLBuilder_t MLBuilder_new(Model_t *m, int numSearches, double improveRelTolerance, int numNoImprove, int maxNumImprove, char **msg) {
    if (numSearches < 1) {
        PRINT_ERRMSG(msg, "num_searches < 1");
        return NULL;
    }
    if (improveRelTolerance <= 0 || improveRelTolerance >= 0.01) {
        PRINT_ERRMSG(msg, "imprftol <= 0 or imprftol >= 0.01");
        return NULL;
    }
    if (numNoImprove < 1) {
        PRINT_ERRMSG(msg, "nnoimp < 1\n");
        return NULL;
    }
    if (maxNumImprove < 1) {
        PRINT_ERRMSG(msg, "maximp < 1\n");
        return NULL;
    }
    if (Model_getNumParam(m[0]) == 0)
        ERROR_MSG_LMA("num_free_param == 0\n");
    
    MLBuilder_t mb = matrixalloc_1d(1, sizeof (*mb));
    mb->mode = 0;
    mb->m = m[0];
    m[0] = NULL;
    mb->numSearches = numSearches;
    mb->improveRelTolerance = improveRelTolerance;
    mb->numNoImprove = numNoImprove;
    mb->maxNumImprove = maxNumImprove;
    return mb;
}

static double nlopt_f(unsigned n, const double *x, double *grad, void *f_data) {
    return Model_getLikelihood(grad, x, f_data);
}

/*
 * @since 2017.6.23 (copied from dfeml), 8.1
 */
void MLBuilder_addAlgorithm(MLBuilder_t mb, const char * algstr, 
        double relTolerance, int maxNumOfFuncEvaluations, double maxExecutionTime, char **msg) {
    if (mb->mode != 0)
        ERROR_MSG_LMA("Failed\n");
    mb->mode = 1;
    
    int num_alg = 3;
    const char *alg_name[num_alg];
    nlopt_algorithm alg_type[num_alg]; 
    int cnt = 0;
    alg_name[cnt] = "NLOPT_LD_SLSQP"; 
    alg_type[cnt]  = NLOPT_LD_SLSQP; 
    cnt++;//1
    
    alg_name[cnt] = "NLOPT_LD_LBFGS";
    alg_type[cnt]  = NLOPT_LD_LBFGS;
    cnt++;//2
    
    alg_name[cnt] = "NLOPT_LD_TNEWTON_PRECOND_RESTART";  
    alg_type[cnt] =  NLOPT_LD_TNEWTON_PRECOND_RESTART; 
    cnt++;//3
    
    if (cnt != num_alg)
        ERROR_MSG_LMA("ERROR");
    
    int id = findName2(algstr, num_alg, alg_name);
    if (id < 0) {
        PRINT_ERRMSG(msg, "Unknown optimisation algorithm: %s", algstr);
        return;
    }
    
    if (relTolerance <= 0 || relTolerance >= 0.01) {
        PRINT_ERRMSG(msg, "rftol <= 0 or rftol >= 0.01\n");
        return;
    }
    if (maxNumOfFuncEvaluations < 1) {
        PRINT_ERRMSG(msg, "maxeval < 1\n");
        return;
    }
    if (maxExecutionTime <= 0) {
        PRINT_ERRMSG(msg, "maxtime <= 0\n");
        return;
    }
    mb->nloptAlgorithm = alg_type[id];
    mb->relTolerance = relTolerance;
    mb->maxNumOfFuncEvaluations = maxNumOfFuncEvaluations;
    mb->maxExecutionTime = maxExecutionTime;
}

/*
 * @since 2018.7.4, 7.5
 */
static nlopt_opt getNlopt(nlopt_algorithm nloptAlgorithm, unsigned numParam, 
        double relTolerance, int maxNumOfFuncEvaluations, double maxExecutionTime, Model_t m) {
    nlopt_opt re = nlopt_create(nloptAlgorithm, numParam);
    if (re == NULL) 
        ERROR_MSG_LMA("Failed\n");
    if (nlopt_set_ftol_rel(re, relTolerance) != NLOPT_SUCCESS) 
        ERROR_MSG_LMA("\n");
    if (nlopt_set_maxeval(re, maxNumOfFuncEvaluations) != NLOPT_SUCCESS) 
        ERROR_MSG_LMA("\n");
    if (nlopt_set_maxtime(re, maxExecutionTime) != NLOPT_SUCCESS) 
        ERROR_MSG_LMA("\n");
    if (nlopt_set_max_objective(re, nlopt_f, m) != NLOPT_SUCCESS)
        ERROR_MSG_LMA("\n");
    double **ranges = Model_getParamRanges(m);
    if (nlopt_set_lower_bounds(re, ranges[0]) != NLOPT_SUCCESS) 
        ERROR_MSG_LMA("\n");
    if (nlopt_set_upper_bounds(re, ranges[1]) != NLOPT_SUCCESS) 
        ERROR_MSG_LMA("\n");
    matrixalloc_2d_d_free(ranges);
    return re;
}

/*
 * @since 2017.6.23 (copied from dfeml), 8.1, 12.17 (only the new addition), 12.25 (only the new addition)
 *        2018.7.4 (added auglag), 7.5 (auglag)
 */
ML_t MLBuilder_build(MLBuilder_t *mb) {
    if (mb[0]->mode != 1)
        ERROR_MSG_LMA("Failed\n");
    
    ML_t ml = matrixalloc_1d(1, sizeof (*ml));
    ml->numSearches = mb[0]->numSearches;
    ml->improveRelTolerance = mb[0]->improveRelTolerance;
    ml->numNoImprove = mb[0]->numNoImprove;
    ml->maxNumImprove = mb[0]->maxNumImprove;
    ml->m = mb[0]->m;
    ml->numParam = Model_getNumParam(ml->m);
    ml->nlopt = NULL;
    if (Model_getNumNloptConstraints(ml->m) > 0) {
        ERROR_MSG_LMA("ERROR");
        ml->nlopt = getNlopt(NLOPT_AUGLAG, (unsigned) ml->numParam,
                mb[0]->relTolerance, mb[0]->maxNumOfFuncEvaluations, mb[0]->maxExecutionTime, ml->m);
        
        double constraintTol = CONSTRAINT_TOLERANCE;
        
        int num = Model_getNumNloptConstraints(ml->m);
        nlopt_func *constraints;
        bool *isEquality;
        void **constraintsData;
        M1D_NEW(constraints, num);
        M1D_NEW(isEquality, num);
        M1D_NEW(constraintsData, num);
        Model_getNloptConstraints(constraints, isEquality, constraintsData, ml->m);
        for (int i = 0; i < num; i++) {
            if (isEquality[i] == true) {
                if (nlopt_add_equality_constraint(ml->nlopt, constraints[i], constraintsData[i], constraintTol) != NLOPT_SUCCESS)
                    ERROR_MSG_LMA("\n");
            } else {
                if (nlopt_add_inequality_constraint(ml->nlopt, constraints[i], constraintsData[i], constraintTol) != NLOPT_SUCCESS)
                    ERROR_MSG_LMA("\n");
            }
        }
        M1D_FREE(constraints);
        M1D_FREE(isEquality);
        M1D_FREE(constraintsData);
        
        nlopt_opt tmp = getNlopt(mb[0]->nloptAlgorithm, (unsigned) ml->numParam,
                mb[0]->relTolerance, mb[0]->maxNumOfFuncEvaluations, mb[0]->maxExecutionTime, ml->m);
        if (nlopt_set_local_optimizer(ml->nlopt, tmp) != NLOPT_SUCCESS)
            ERROR_MSG_LMA("\n");
        nlopt_destroy(tmp);
    } else {
        ml->nlopt = getNlopt(mb[0]->nloptAlgorithm, (unsigned) ml->numParam,
                mb[0]->relTolerance, mb[0]->maxNumOfFuncEvaluations, mb[0]->maxExecutionTime, ml->m);
    }
    
    matrixalloc_1d_free(mb[0]);
    mb[0] = NULL;
    
    M1D_NEW(ml->x, ml->numParam);
    M1D_NEW(ml->likelihoods, ml->numSearches);
    ml->MLEs = matrixalloc_2d_d(ml->numSearches, ml->numParam);
    M1D_NEW(ml->runID, ml->numSearches);
    M1D_NEW(ml->improveID, ml->numSearches);
    M1D_NEW(ml->exitCodes, ml->numSearches);
    M1D_NEW(ml->re, ml->numParam);
    ml->numParamSize = (size_t) ml->numParam * sizeof (double);
    
    return ml;
}