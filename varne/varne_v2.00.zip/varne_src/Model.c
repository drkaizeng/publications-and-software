#include <string.h>
#include <math.h>

#include "Model_def.h"

#include "PrintErrorMessage.h"

#include "util/matrixalloc.h"

/**
 * @since 2018.10.15
 */
Model_t Model_new(enum ModelType type, file_reader_t *reader, int *line_id, char **msg, ...) {
    msg[0] = NULL;
    
    va_list args;
    va_start(args, msg);
    
    Model_t re;
    if (type == MODEL1) {
        re = Model1_new(reader, line_id, msg);
    } else if (type == MODEL2) {
        re = Model2_new(reader, line_id, msg);
    } else {
        PRINT_ERRMSG(msg, "Unknown model type.");
        return NULL;
    }
    
    va_end(args);
    
    return re;
}

/**
 * @since 2018.10.15
 */
void Model_free(Model_t *mod) {
    Model_t m = mod[0];
    mod[0] = NULL;
    m->freeParam(&m->param);
    M1D_FREE(m);
}

/**
 * @since 2018.10.15
 */
enum ModelType Model_getType(Model_t m) {
    return m->type;
}

/**
 * @since 2018.10.15
 */
int Model_getNumParam(Model_t m) {
    return m->getNumParam(m->param);
}

/**
 * @since 2018.10.15
 */
char ** Model_getParamNames(Model_t m) {
    return m->getParamNames(m->param);
}

/**
 * @since 2018.10.15
 */
enum ParameterType * Model_getParamTypes(Model_t m) {
    return m->getParamTypes(m->param);
}

/**
 * @since 2018.10.15
 */
void Model_getInitialValues(double *x, Model_t m, ...) {
    va_list args;
    va_start(args, m);
    
    m->getInitialValues(x, m->param, args);
    
    va_end(args);
}

/**
 * @since 2018.10.15
 */
double ** Model_getParamRanges(Model_t m) {
    return m->getParamRanges(m->param);
}

/**
 * @since 2018.10.15
 */
int Model_getNumNloptConstraints(Model_t m) {
    return m->getNumNloptConstraints(m->param);
}

/**
 * @since 2018
 */
void Model_getNloptConstraints(nlopt_func *constraint, bool *isEqualityConstraint, void **constraintData, Model_t m) {
    m->getNloptConstraints(constraint, isEqualityConstraint, constraintData, m->param);
}

/**
 * @since 2018.10.15 
 */
double Model_getLikelihood(double *grad, const double *x, Model_t m) {
    return m->getLikelihood(grad, x, m->param);
}

/**
 * @since 2018.10.15
 */
void Model_scaleParam(double *x2, double *x, Model_t m) {
    return m->scaleParam(x2, x, m->param);
}

/**
 * @since 2018.10.15
 */
void Model_unscaleParam(double *x2, double *x, Model_t m) {
    return m->unscaleParam(x2, x, m->param);
}

/**
 * @since 2018.10.15
 */
void * Model_extraFunction(const char *cmd, Model_t m, char **msg, ...) {
    va_list args;
    va_start(args, msg);
    
    void *re;
    re = m->extraFunction(cmd, m->param, msg, args);
    
    va_end(args);
    
    return re;
}







///**
// * @since 2018
// */
//int Model_getNumParamOfFullModel(Model_t m) {
//    return m->getNumParamOfFullModel(m->param);
//}
//
///**
// * @since 2018
// */
//char ** Model_getParamNamesOfFullModel(Model_t m) {
//    return m->getParamNamesOfFullModel(m->param);
//}
//
///**
// * @since 2018
// */
//void Model_toParamOfFullModel(double *allParam, const double *freeParam, Model_t m) {
//    m->toParamOfFullModel(allParam, freeParam, m->param);
//}
//
///**
// * @since 2018
// */
//void Model_toFreeParam(double *freeParam, const double *allParam, Model_t m) {
//    m->toFreeParam(freeParam, allParam, m->param);
//}
