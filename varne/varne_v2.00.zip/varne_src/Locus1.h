/*
 * Created on 16 May 2018, 16:16
 */

#ifndef LOCUS1_H
#define LOCUS1_H

#include "Locus_def.h"

#include "LocusData1.h"

struct Locus1 {
    struct LocusData1 *data;
    /**
     * <ul>
     * <li> This is of the same length as data.len.
     * <li> id[i] stores the id of the marth_t object in Locus1Executor for the sample size
     * <li> This is updated in LocusExecutor_new()
     * </ul>
     */
    int *id;
    
    int H;
    bool useProfile;//true if the profile likelihood is used
    
    /**
     * <ul>
     * <li> If useProfile = false, then 2 * H + 1 parameters: theta, f, g_1, ..., g_{H-1}, tau_1, ..., tau_{H-1}, err
     * <li> If useProfile = true, then 2 * H parameters: f, g_1, ..., g_{H-1}, tau_1, ..., tau_{H-1}, err
     * </ul>
     */
    int numParam;
    enum ParameterType *paramType;//parameter types under the full model, including theta
    char **paramName;//parameter names under the full model, including theta
};


#endif /* LOCUS_I_H */

