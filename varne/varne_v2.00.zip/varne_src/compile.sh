DIR=/home/libraries/
GSL=${DIR}/gsl-2.3
NLOPT=${DIR}/nlopt-2.4.2

# Enabling OpenMP support. Comment out and use the alternative below if this is not required.
CFLAG="-std=c99 -O3 -g -fopenmp"

# Comment out the version above and uncomment this version instead, if OpenMP is not needed.
#CFLAG="-std=c99 -O3 -g"



# No need to change the following

LIBRARY=./library
INCLUDE="-I${LIBRARY} -I${GSL}/include -I${NLOPT}/include"
LIB="-L${LIBRARY} -L${GSL}/lib -L${NLOPT}/lib"
LINK="-lnlopt -llibrary -lgsl -lgslcblas -lm"

cd library
make 
cd ..
gcc $CFLAG $INCLUDE $LIB  *.c -o varne $LINK
 

