/* 
 * Created on 15 February 2017, 12:24
 */

#ifndef FINDNAME_H
#    define FINDNAME_H

/**
 * Return the ID of name in the list. Return -1 if name is not in the list
 * @parma n Length of the list
 */
int findName(const char *name, int n, char **list);

int findName2(const char *name, int n, const char *list[n]);

#endif /* FIND_NAME_H */

