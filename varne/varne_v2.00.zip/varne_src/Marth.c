/*
 * Created on 01 October 2018, 17:43
 */
#include <limits.h>
#include <math.h>

#include "Marth.h"

#include "util/error_msg.h"
#include "util/matrixalloc.h"
#include "util/arrayutil.h"

struct Marth {
    int n;
    int H;//the total number of epochs. H=1 for a constant population
    
    int nx;//the number of parameters = 2H - 1
    
    double *choose2; //choose2[j-2] = j*(j-1)/2 for j=2..n
    
    /*
     * Of length n - 1. 
     * <p>
     * On return from stepwise_executor_lnlike <br>
     * Unfolded:
     * psi[i] = m theta phi[i] 
     */
//    double *phi;
    /**
     * Dimension: (2H - 1) * (n - 1)
     * <p> 
     * On return from stepwise_executor_lnlike <br>
     * Unfolded:
     * dphi[j][i] = d(phi[i])/d(param[j]). 
     * <p>
     * Folded: 
     * dphi[j][i] = d(Phi[i])/d(param[j]). 
     * <p>
     * The parameters are f, g_1, ..., g_{H-1}, tau_1, ..., tau_{H-1}
     * All elements should be set to zero on initialisation. 
     * This is because, for a given sfs[i], its derivative is non-zero wrt some of the parameters.
     * These are not calculated, but may be used in the calculation of the partial derivative of the likelihood function.
     */
//    double **dphi;
    
    /**
     * Dimension: (2H) * (n-1) <br>
     * part[0]: the phi's <br>
     * part[1..(2H-1)]: the same as dphi above
     */
    double **part;
    /**
     * <ul>
     * <li> (2H) * (n-1) elements
     * <li> part is initialised by M2D_NEW().
     * <li> To fill it with zero, memcpy(part[0], zero, size).
     * </ul>
     */
    double *zero;
    size_t zero_size;//size of zero
    /**
     * With 2H elements. Used to store the partial sums for calculating the elements in part
     */
    double *sum;
    size_t sum_size;
};

/**
 * @since 2018.10.3, 10.7
 */
void Marth_free(Marth_t *mm) {
    Marth_t m = mm[0];
    mm[0] = NULL;

    M1D_FREE(m->sum);
    M1D_FREE(m->zero);
    M2D_FREE(m->part);
    M1D_FREE(m->choose2);
    M1D_FREE(m);
}

/**
 * @since 2018.10.3
 */
struct Marth * Marth_clone(struct Marth *m) {
    struct Marth *re;
    M1D_NEW(re, 1);
    
    *re = *m;
    
    if (m->H > 1) {
        int n = m->n;
        M1D_NEW(re->choose2, n - 1);
        size_t choose2_size = (size_t) (n - 1) * sizeof(*re->choose2);
        memcpy(re->choose2, m->choose2, choose2_size);
        
        int H = m->H;
        int part_len = 2 * H;
        M2D_NEW(re->part, part_len, n - 1);
        memcpy(re->part[0], m->part[0], m->zero_size);
        
        int zero_len = part_len * (n - 1);
        M1D_NEW(re->zero, zero_len);
        memcpy(re->zero, m->zero, m->zero_size);
        
        M1D_NEW(re->sum, part_len);
        memcpy(re->sum, m->sum, m->sum_size);
    }
    
    return re;
}

/*
 * @param phi Of length n-1
 * @param dphi Of length nx * (n-1), where nx is the total number of parameters
 *             when the profile likelihood is used
 * @param nx The total number of parameters
 *             when the profile likelihood is used
 * @param xi Of the same length as nx. If xi[i] &lt; 0, then the parameter has no derivative.
 * @since 2017.7.4, 7.27, 2018 (moved to marth.c)
 */
static void get_folded(double *phi, double **dphi, int n, int nx, const bool *derivative) {
    int n2 = n / 2;
    for (int i = 1; i <= n2; i++) {
        if (i < n - i)
            phi[i - 1] += phi[n - i - 1];
    }
    if (dphi != NULL) {
        for (int j = 0; j < nx; j++) {
            if (derivative[j] == true) {
                for (int i = 1; i <= n2; i++) {
                    if (i < n - i)
                        dphi[j][i - 1] += dphi[j][n - i - 1];
                }
            }
        }
    }
}

/*
 * The order of the parameters x should be
 * <ol>
 * <li> f
 * <li> g_1, g_2, ..., g_{H-1}
 * <li> tau_1, ..., tau_{H-1}
 * </ol>
 * All on the original scale
 * <p>
 * @param xi Of the same length as x. If xi[i] = -1, then the corresponding parameter has no derivative.
 * @param phi
 * @param dphi If non-NULL, then the derivatives are calculated. 
 * @param x
 * @param s
 * @since 2018.10.3 (modified from varne/marth.c; checked), 10.7
 */
void Marth_get(double *phi, double **dphi, const double *x, const bool *derivative, bool folded, double **w, Marth_t se) {
    int nx = se->nx;
    int n = se->n;
    int H = se->H;
    if (H == 1) {//f is the only free parameter
        for (int i = 1, i1 = 0; i < n; i++, i1++)
            phi[i1] = x[0] / i;
        if (dphi != NULL) {
            for (int i = 1, i1 = 0; i < n; i++, i1++)
                dphi[0][i1] = 1.0 / i;
        }
    } else {
        /* The following is about an order of magnitude faster; complexity = 2(H-1)(n-1)^2 + 7(H-1)(n-1). complexity above = 4(H-1)(n-1)^2 + 6(H-1)(n-1) */
        double f = x[0];
        const double *g = x + 1;
        const double *tau = x + H;
        const bool *gDer;
        const bool *tauDer;
        if (dphi != NULL) {
            gDer = derivative + 1;
            tauDer = derivative + H;
        } else {
            gDer = NULL;
            tauDer = NULL;
        }
        
        double *choose2 = se->choose2;
        double *phi2 = se->part[0];
        double **dphi2 = se->part + 1;
        double *sum = se->sum;
        double sum_tfg2, exp1, diff_exp1, tmp;
        
        memcpy(se->part[0], se->zero, se->zero_size);
        
        for (int j = 2, j2 = 0; j <= n; j++, j2++) {
            sum_tfg2 = 0;//-sum_{l=1}^h tau_l/f g_{l})
            memcpy(sum, se->zero, se->sum_size);
            for (int h = 1, hm1 = 0, hp1 = 2; h < H; h++, hm1++, hp1++) {
                tmp = -tau[hm1] / (f * g[hm1]);//-tau_l/(f g_l)
                sum_tfg2 += tmp;
                
                exp1 = sum_tfg2 * choose2[j2];//-binom{j}{2} sum_{l=1}^h tau_l/f g_{l}
                exp1 = exp(exp1);
                
                if (hp1 == H)
                    diff_exp1 = 1;
                else
                    diff_exp1 = g[h];
                diff_exp1 -= g[hm1];
                diff_exp1 *= exp1;
                
                //A_i
                sum[0] += diff_exp1;
                
                if (dphi != NULL) {
                    if (derivative[0] == true) {//f d(Ai)/d(f)
                        tmp = diff_exp1 * sum_tfg2;
                        sum[1] -= tmp;
                    }
                    for (int a = 1, a1 = 0, gi = 2, tau_i = H + 1; a < H; a++, a1++, gi++, tau_i++) {
                        if (gDer[a1] == true) {// d(Ai)/d(g_a)
                            if (h == a1)
                                sum[gi] += exp1 / choose2[j2] / 2;
                            else if (h >= a) {
                                if (h == a) {
                                    sum[gi] -= exp1 / choose2[j2] / 2;
                                }
                                tmp = tau[a1] / pow(g[a1], 2) / f;
                                tmp *= diff_exp1 / 2;
                                sum[gi] += tmp;
                            }
                        }
                        if (tauDer[a1] == true && h >= a) {//-f g_a d(Ai)/d(tau_a)
                            sum[tau_i] += diff_exp1;
                        }
                    }
                }                
            }
            for (int i = 1, i1 = 0; i < n; i++, i1++) {
                /* Ai */
                phi2[i1] += w[i1][j2] * sum[0] / choose2[j2] / 2;
                if (dphi != NULL) {
                    //f d(Ai)/d(f)
                    dphi2[0][i1] += w[i1][j2] * sum[1] / 2;
                    for (int a = 1, a1 = 0, gi = 1, tau_i = H; a < H; a++, a1++, gi++, tau_i++) {
                        if (gDer[a1] == true) {// d(Ai)/d(g_a)
                            dphi2[gi][i1] += w[i1][j2] * sum[gi + 1];
                        }
                        if (tauDer[a1] == true) {//-f g_a d(Ai)/d(tau_a)
                            dphi2[tau_i][i1] += w[i1][j2] * sum[tau_i + 1] / 2;
                        }
                    }
                }
            }
        }
        for (int i = 1, i1 = 0; i < n; i++, i1++) {
            phi[i1] = f * (g[0] / i + phi2[i1]);
        }
        if (dphi != NULL) {
            if (derivative[0] == true) { //f
                for (int i = 1, i1 = 0; i < n; i++, i1++) {
                    dphi[0][i1] = g[0] / i + phi2[i1] + dphi2[0][i1];
                }
            }
            for (int a = 1, a1 = 0, gi = 1, tau_i = H; a < H; a++, a1++, gi++, tau_i++) {
                if (gDer[a1] == true) {
                    for (int i = 1, i1 = 0; i < n; i++, i1++) {
                        dphi[gi][i1] = f * dphi2[gi][i1];
                        if (a == 1)
                            dphi[gi][i1] += f / i;
                    }
                }
                if (tauDer[a1] == true) {
                    for (int i = 1, i1 = 0; i < n; i++, i1++) {
                        dphi[tau_i][i1] = -dphi2[tau_i][i1] / g[a1];
                    }
                }
            }
        }
    }
    if (folded) {
        get_folded(phi, dphi, n, nx, derivative);
    }
}

/*
 * @since 2018.10.3 (H >= 1), 10.7
 */
Marth_t Marth_new(int n, int H) {
    if (n < 2)
        ERROR_MSG_LMA("n < 2\n");
    if (n >= (int) sqrt(INT_MAX))
        ERROR_MSG_LMA("n >= %d\n", (int) sqrt(INT_MAX));
    if (H < 1)
        ERROR_MSG_LMA("H < 1\n");
    
    struct Marth *se;
    M1D_NEW(se, 1);
    
    se->n = n;
    se->H = H;
    
    se->nx = 2 * H - 1;
    
    if (H > 1) {
        M1D_NEW(se->choose2, n - 1);
        for (int j = 2, j2 = 0; j <= n; j++, j2++) 
            se->choose2[j2] = j * (j - 1) / 2;
        
        int part_len = 2 * H;
        M2D_NEW(se->part, part_len, n - 1);
        
        int zero_len = part_len * (n - 1);
        M1D_NEW(se->zero, zero_len);
        AU_FILL2(se->zero, 0, zero_len, 0);
        se->zero_size = (size_t) zero_len * sizeof(*se->zero);

        M1D_NEW(se->sum, part_len);
        se->sum_size = (size_t) part_len * sizeof(*se->sum);
    } else {
        se->choose2 = NULL;
        se->part = NULL;
        se->zero = NULL;
        se->zero_size = 0;
        se->sum = NULL;
        se->sum_size = 0;
    }
    
    return se;
}