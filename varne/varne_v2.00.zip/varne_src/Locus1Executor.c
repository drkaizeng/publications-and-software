#include <limits.h>
#include <math.h>
#include <string.h>
#include <stdint.h>

#include "Locus1.h"

#include "Marth.h"
#include "PrintErrorMessage.h"
#include "Coefficient.h"

#include "util/error_msg.h"
#include "util/matrixalloc.h"
#include "util/arrayutil.h"
#include "util/string_util.h"


struct Locus1Executor {
    int H;//the total number of epochs. H=1 for a constant population
    
    Coefficient_t co;
    int len;//the number of marth objects
    /**
     * <ul>
     * <li> each object is for a "unique" sample size
     * <li> marth[i] correspond to the i-th sample size in co. Thus, w_id = i
     * </ul>
     */
    Marth_t *marth;
    
    /**
     * Of length len * (n - 1). 
     * <p>
     * Unfolded:
     * psi[i] = m theta phi[i] 
     * <p>
     * Folded:
     * Psi[i] = m theta Phi[i]
     */
    double **phi;
    /**
     * Of length len * (n - 1)
     * <p>
     * This is for adding errors to the SFS
     */
    double **errArray;
    size_t *errArraySize;
    /**
     * <ul>
     * <li> The number of parameters in dPhi and dEta
     * <li> numParam = 2 * H (f, g_1, ..., g_{H-1}, tau_1, ..., tau_{H-1}, err)
     * </ul>
     */
    int Hx2;
    /**
     * Parameters: (f, g_1, ..., g_{H-1}, tau_1, ..., tau_{H-1}, err) <br>
     * Dimension: len * Hx2 * (n - 1)
     * <p> 
     * On return from stepwise_executor_lnlike <br>
     * Unfolded:
     * dphi[j][i] = d(phi[i])/d(param[j]). 
     * <p>
     * Folded: 
     * dphi[j][i] = d(Phi[i])/d(param[j]). 
     * <p>
     * All elements should be set to zero on initialisation. 
     * This is because, for a given sfs[i], its derivative is non-zero wrt some of the parameters.
     * These are not calculated, but may be used in the calculation of the partial derivative of the likelihood function.
     */
    double ***dPhi;
    /**
     * <ul>
     * <li> Dimension = Hx2
     * <li> dEta[i] = d(eta)/d(param[i])
     * </ul>
     */
    double *dEta;
    double *Hx2Zeros;//array with numParam zeros
    size_t Hx2ZerosSize;
};

/*
 * @since 2018.10.9
 */
static void freeParam(void **param) {
    struct Locus1Executor *se = (struct Locus1Executor *) param[0];
    param[0] = NULL;
    
    M1D_FREE(se->Hx2Zeros);
    M1D_FREE(se->dEta);
    for (int i = 0; i < se->len; i++) {
        M2D_FREE(se->dPhi[i]);
        M1D_FREE(se->errArray[i]);
        M1D_FREE(se->phi[i]);
        Marth_free(&(se->marth[i]));
    }
    M1D_FREE(se->dPhi);
    M1D_FREE(se->errArraySize);
    M1D_FREE(se->errArray);
    M1D_FREE(se->phi);
    M1D_FREE(se->marth);
    Coefficient_free(&(se->co));
    M1D_FREE(se);
}

/*
 * @since 2018.10.9
 */
static void * clone(void *param) {
    struct Locus1Executor *se = (struct Locus1Executor *) param;
    
    struct Locus1Executor *re;
    M1D_NEW(re, 1);
    
    *re = *se;
    
    int H = re->H;
    
    re->co = Coefficient_clone(se->co);
    
    int len = Coefficient_getSize(se->co);
    if (len <= 0)
        ERROR_MSG_LMA("ERROR");
    int n_lst[len];
    Coefficient_getSampleSizes(n_lst, se->co);
    M1D_NEW(re->marth, re->len);
    M1D_NEW(re->phi, re->len);
    M1D_NEW(re->errArray, re->len);
    M1D_CLONE(re->errArraySize, se->errArraySize, re->len);
    M1D_NEW(re->dPhi, re->len);
    for (int i = 0; i < re->len; i++) {
        re->marth[i] = Marth_clone(se->marth[i]);
        M1D_CLONE(re->phi[i], se->phi[i], n_lst[i] - 1);
        M1D_CLONE(re->errArray[i], se->errArray[i], n_lst[i] - 1);
        M2D_CLONE(re->dPhi[i], se->dPhi[i], 2 * H, n_lst[i] - 1);
    }
    M1D_CLONE(re->dEta, se->dEta, 2 * H);
    M1D_CLONE(re->Hx2Zeros, se->Hx2Zeros, 2 * H);
    
    return re;
}

/*
 * <ul>
 * <li> nx and xi in locus_i
 * <li> eta = sum_{j=1}^J m_j phi_j
 * <li> deta[i] = d(eta)/d(param[i])
 * </ul>
 * @since 2018.10.10, 10.17
 */
static double prof_like(double *grad, double *eta, double *dEta, double *phi, double **dphi, int sfs_len, double *sfs, 
        int nx, const bool *derivative, double m, int dPhiErrID) {
    double sum_phi;
    AU_SUM2(sum_phi, phi, 0, sfs_len);
    eta[0] += sum_phi * m;
    double re = 0;
    for (int i = 0; i < sfs_len; i++)
        re += sfs[i] * log(phi[i]);
    if (grad != NULL) {
        for (int j = 0; j < nx; j++) {
            if (derivative[j] == true) {
                if (j != dPhiErrID) {
                    double phi_x;
                    AU_SUM2(phi_x, dphi[j], 0, sfs_len);
                    dEta[j] += phi_x * m;
                }
                for (int i = 0; i < sfs_len; i++)
                    grad[j] += sfs[i] * dphi[j][i] / phi[i];
            } 
        }
    }
    return re;
}

/*
 * nx is the length of grad and x and derivative
 * @since 2018.10.8, 10.9
 */
static double full_like(double *grad, double *phi, double **dphi, int sfs_len, double *sfs, int nx, const bool *derivative, double theta, double m, bool folded) {
    double lnlike = 0;
    for (int i = 0; i < sfs_len; i++) {
        double psi = theta * phi[i];
        lnlike += -psi + sfs[i] * log(psi);
    }
    if (grad != NULL) {
        int lastParam = (folded == true ? nx - 1 : nx);//if folded, then this doesn't contribute to d(L)/d(err)
        for (int i = 0; i < sfs_len; i++) {
            double psi = theta * phi[i];
            psi = (-1 + sfs[i] / psi);
            for (int j = 0; j < lastParam; j++) {
                if (derivative[j] == true) { 
                    double dpsi;
                    if (j == 0) {//theta
                        dpsi = m * phi[i];
                    } else {
                        dpsi = theta * dphi[j - 1][i];
                    }
                    grad[j] += psi * dpsi;
                } 
            }
        }
    }
    return lnlike;
}

/**
 * re[i] = (1 - err) * re[i] + err * re[len - i]
 * @since 2018.10.9, 10.17
 */
static void addErrorWork(int n, double *re, double err, double *arr, size_t arrSize) {
    double noErr = 1 - err;
    for (int i = 1, i1 = 0, ni1 = n - 2; i < n; i++, i1++, ni1--)
        arr[i1] = noErr * re[i1] + err * re[ni1];
    memcpy(re, arr, arrSize);
}

/*
 * <ul>
 * <li> err_id: id of err in dphi, which does not contain theta
 * <li> der2 does not consider theta
 * </ul>
 * @since 2018.10.9, 10.17 (added test for err>0)
 */
static void addError(double *phi, double **dphi, int n, double err, int dPhiErrID, const bool *der2, double *arr, size_t arrSize) {
    if (dphi != NULL) {
        if (err > 0) {
            for (int j = 0; j < dPhiErrID; j++) {
                if (der2[j] == true)
                    addErrorWork(n, dphi[j], err, arr, arrSize);
            }
        }
        if (der2[dPhiErrID] == true) {
            for (int i = 1, i1 = 0, ni1 = n - 2; i < n; i++, i1++, ni1--) {
                dphi[dPhiErrID][i1] = -phi[i1] + phi[ni1];
            }
        }
    }
    /* phi */
    if (err > 0) {
        addErrorWork(n, phi, err, arr, arrSize);
    }
}

/*
 * @since 2018.10.9, 10.17 (corrected err=0 and der[err]=true)
 */
static double lnlike(double *grad, const double *x, const bool *derivative, Locus_t loc, void *param) {
    struct Locus1Executor *se = (struct Locus1Executor *) param;
    struct Locus1 *sl = (struct Locus1 *) loc->typeParam;
    
    struct LocusData1 *data = sl->data;
    int *id = sl->id;
    
    double re = 0;

    const double *x2 = x;//f, g_1, ..., g_{H-1}, tau_1, ..., tau_{H-1}, err
    const bool *der2 = derivative;
    double eta = 0, *dEta = NULL;
    int nx = se->Hx2;//the length of x and derivative
    if (sl->useProfile == false) {
        x2++;
        if (grad != NULL) {
            der2++;
        }
        nx++;
    } else {
        if (grad != NULL) {
            dEta = se->dEta;
            memcpy(dEta, se->Hx2Zeros, se->Hx2ZerosSize);
        }
    }
        
    int dPhiErrID = se->Hx2 - 1; //id of err in x2 and der2
    double err = x2[dPhiErrID];

    for (int k = 0; k < data->len; k++) {
        double *phi = se->phi[id[k]];
        double **dphi = (grad == NULL ? NULL : se->dPhi[id[k]]);
        double m = data->m[k];
        int sfsLen = data->sfsLen[k];
        double *sfs = data->sfs[k];
        bool folded = data->folded[k];
        double **w = Coefficient_getW(id[k], se->co);
        Marth_get(phi, dphi, x2, der2, folded, w, se->marth[id[k]]);
        if (folded == false) {
            addError(phi, dphi, data->n[k], err, dPhiErrID, der2, se->errArray[id[k]], se->errArraySize[id[k]]);
        }
        if (sl->useProfile)
            re += prof_like(grad, &eta, dEta, phi, dphi, sfsLen, sfs, nx, derivative, m, dPhiErrID);
        else {
            double theta = data->m[k] * x[0];
            re += full_like(grad, phi, dphi, sfsLen, sfs, nx, derivative, theta, m, folded);
        }
    }
    if (sl->useProfile) {
        re -= log(eta) * data->numSeg;
        if (grad != NULL) {
            double tmp = data->numSeg / eta;
            for (int j = 0; j < nx; j++) {
                if (derivative[j] == true) {//free param
                    grad[j] -= tmp * dEta[j];
                }
            }
        }
    }
    
    return re;
}

/**
 * @param x This is defined by useProfile
 * @since 2018.10.10
 */
static void * getThetaMLE(Locus_t loc, void *param, double *x) {
    struct Locus1 *sl = (struct Locus1 *) loc->typeParam;
    
    double *re;
    M1D_NEW(re, 1);
    
    if (sl->useProfile == false) {
        re[0] = x[0];
    } else {
        struct Locus1Executor *se = (struct Locus1Executor *) param;
        struct LocusData1 *data = sl->data;
        int *id = sl->id;

        double eta = 0;

        for (int k = 0; k < data->len; k++) {
            double *phi = se->phi[id[k]];
            int n = data->n[k];
            double m = data->m[k];
            double **w = Coefficient_getW(id[k], se->co);
            Marth_get(phi, NULL, x, NULL, false, w, se->marth[id[k]]);
            double tmp;
            AU_SUM2(tmp, phi, 0, n - 1);
            tmp *= m;
            eta += tmp;
        }

        re[0] = data->numSeg / eta;
    }
    
    return re;
}

/**
 * @param x This is defined by useProfile
 * @since 2018.10.10
 */
static void * getFullLikelihood(Locus_t loc, void *param, double *x) {
    struct Locus1 *sl = (struct Locus1 *) loc->typeParam;

    int numParam = 2 * sl->H + 1;//theta, f, g_1, ..., g_{H-1}, tau_1, ..., tau_{H-1}, err
    double x2[numParam];
    {
        if (sl->useProfile == true) {
            double *tmp = getThetaMLE(loc, param, x);
            x2[0] = tmp[0];
            M1D_FREE(tmp);
            memcpy(x2 + 1, x, (size_t) sl->numParam * sizeof(*x));
        } else {
            memcpy(x2, x, (size_t) sl->numParam * sizeof(*x));
        }
    }
    
    double *re;
    M1D_NEW(re, 1);
    
    double err = x2[numParam - 1];
    
    struct LocusData1 *data = sl->data;
    struct Locus1Executor *se = (struct Locus1Executor *) param;
    int *id = sl->id;
    
    re[0] = 0;
    for (int k = 0; k < data->len; k++) {
        double *phi = se->phi[id[k]];
        int sfs_len = data->sfsLen[k];
        double *sfs = data->sfs[k];
        bool folded = data->folded[k];
        double **w = Coefficient_getW(id[k], se->co);
        Marth_get(phi, NULL, x2 + 1, NULL, folded, w, se->marth[id[k]]);
        if (err >= 0 && folded == false) {
            addError(phi, NULL, data->n[k], err, -1, NULL, se->errArray[id[k]], se->errArraySize[id[k]]); //errID is not needed
        }
        double theta = data->m[k] * x2[0];
        re[0] += full_like(NULL, phi, NULL, sfs_len, sfs, numParam, NULL, theta, data->m[k], folded);
    }
    
    return re;
}

/*
 * @since 2018.10.9
 */
static void * extraFunction(const char *cmd, Locus_t loc, void *param, char **msg, va_list args) {
    msg[0] = NULL;
    
    if (string_util_equal(cmd, "thetaMLE")) {
        double *x = va_arg(args, double *);
        return getThetaMLE(loc, param, x);
    } else if (string_util_equal(cmd, "fullLikelihood")) {
        double *x = va_arg(args, double *);
        return getFullLikelihood(loc, param, x);
    } else {
        PRINT_ERRMSG(msg, "Unknown command = %s\n", cmd);
        return NULL;
    }
}

/*
 * Parameter: int len, locus_t *loc
 * @since 2018.10.9 (numLoc >= 1)
 */
LocusExecutor_t Locus1Executor_new(va_list args) {
    int numLoc = va_arg(args, int);
    if (numLoc <= 0)
        ERROR_MSG_LMA("ERROR");
    Locus_t *loc = va_arg(args, Locus_t *);
    
    int H = ((struct Locus1 *) loc[0]->typeParam)->H;
    
    struct Locus1Executor *se;
    M1D_NEW(se, 1);
    
    se->H = H;
    
    se->co = Coefficient_new();
    for (int i = 0; i < numLoc; i++) {
        char *msg;
        void **data = Locus_extraFunction("sampleSizes", loc[i], &msg);
        if (msg != NULL)
            ERROR_MSG_LMA("ERROR");
        int num = ((int *) data[0])[0];
        M1D_FREE(data[0]);
        int *n = data[1];
        M1D_FREE(data);
        for (int j = 0; j < num; j++)
            Coefficient_add(n[j], se->co);
        M1D_FREE(n);
    }
    
    se->len = Coefficient_getSize(se->co);
    if (se->len == 0)
        ERROR_MSG_LMA("ERROR");
    int n_lst[se->len];
    Coefficient_getSampleSizes(n_lst, se->co);
    M1D_NEW(se->marth, se->len);
    M1D_NEW(se->phi, se->len);
    M1D_NEW(se->errArray, se->len);
    M1D_NEW(se->errArraySize, se->len);
    se->Hx2 = 2 * H;
    M1D_NEW(se->dPhi, se->len);
    for (int i = 0; i < se->len; i++) {
        se->marth[i] = Marth_new(n_lst[i], H);
        M1D_NEW(se->phi[i], n_lst[i] - 1);
        M1D_NEW(se->errArray[i], n_lst[i] - 1);
        se->errArraySize[i] = (size_t) (n_lst[i] - 1) * sizeof(*se->errArray[i]);
        M2D_NEW(se->dPhi[i], se->Hx2, n_lst[i] - 1);
        int cnt = se->Hx2 * (n_lst[i] - 1);
        AU_FILL2(se->dPhi[i][0], 0, cnt, 0);
    }
    
    for (int i = 0; i < numLoc; i++) {
        struct Locus1 *sl = (struct Locus1 *) loc[i]->typeParam;
        struct LocusData1 *data = sl->data;
        for (int j = 0; j < data->len; j++) {
            sl->id[j] = Coefficient_getID(data->n[j], se->co);
        }
    }
    
    M1D_NEW(se->dEta, se->Hx2);
    M1D_NEW(se->Hx2Zeros, se->Hx2);
    AU_FILL2(se->Hx2Zeros, 0, se->Hx2, 0);
    se->Hx2ZerosSize = (size_t) se->Hx2 * sizeof(*se->Hx2Zeros);
    
    struct LocusExecutor *exec;
    M1D_NEW(exec, 1);
    
    exec->param = se;
    exec->freeParam = freeParam;
    exec->clone = clone;
    exec->lnlike = lnlike;
    exec->extraFunction = extraFunction;
    
    return exec;
}