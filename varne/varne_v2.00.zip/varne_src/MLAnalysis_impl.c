/*
 * Created on 13 October 2017, 20:04
 */
#include <string.h>

#include "MLAnalysis_def.h"

#include "VarneIO.h"
#include "Constants.h"

#include "util/error_msg.h"
#include "util/matrixalloc.h"

/**
 * @since 2017.12.4, 12.15, 12.25, 2018.3.30
 */
struct MLAnalysis * MLAnalysis_new(void) {
    struct MLAnalysis *alg = matrixalloc_1d(1, sizeof (*alg));
    alg->algorithmName = NULL;
    alg->numNoImprove = 1;
    alg->maxNumImprove = 1;
    return alg;
}

/**
 * @since 2017.8.1, 9.20, 12.4, 2018.3.30
 */
static void getOptional(struct MLAnalysis *alg, bool optional, file_reader_t *reader, int *line_id, char **msg) {
    alg->relTolerance = REL_TOLERANCE;
    
    if (optional) {
        int numParam = 1;
        int paramID = 0;
        const char *names[numParam];
        names[paramID++] = "relTolerance:";
        if (paramID != numParam)
            ERROR_MSG_LMA("Error");
        
        char par[numParam][BUFFER_SIZE];
        VarneIO_readControlParam(numParam, par, names, reader, line_id, msg);
        if (msg[0] != NULL)
            return;
        
        paramID = 0;
        
        alg->relTolerance = VarneIO_getDouble(par[paramID], "Failed to parse relTolerance at line %i.\n",
                line_id[0] - numParam + paramID + 1);
        paramID++;
    }
}

/**
 * @since 2017.8.1, 9.20, 12.4, 2018.3.30
 */
void MLAnalysis_readControlFile(struct MLAnalysis *mla, file_reader_t *reader, int *line_id, char **msg) {
    /* control parameters */
    const int numParam = 6;
    int param_id = 0;
    const char *param_names[numParam];
    param_names[param_id++] = "[algorithm]";
    param_names[param_id++] = "algorithmName:";
    param_names[param_id++] = "numSearches:";
    param_names[param_id++] = "maxNumOfFuncEvaluations:";
    param_names[param_id++] = "maxExecutionTime:";
    param_names[param_id++] = "optional:";
    if (param_id != numParam)
        ERROR_MSG_LMA("par_id != num_ctlp\n");
    
    char param[numParam][BUFFER_SIZE];
    VarneIO_readControlParam(numParam, param, param_names, reader, line_id, msg);
    if (msg[0] != NULL)
        return;
    
    param_id = 1;//skip [algorithm]
    
    const char *search_algorithm = param[param_id];
    mla->algorithmName = matrixalloc_1d_clone(search_algorithm, (int) strlen(search_algorithm) + 1, sizeof (char));
    param_id++;
    
    mla->numSearches = VarneIO_getInt(param[param_id], "Failed to parse numSearches at line %i.\n", 
            line_id[0] - numParam + param_id + 1);
    param_id++;
    
    mla->maxNumOfFuncEvaluations = VarneIO_getInt(param[param_id], "Failed to parse maxNumOfFuncEvaluations at line %i.\n", 
            line_id[0] - numParam + param_id + 1);
    param_id++;
    
    mla->maxExecutionTime = VarneIO_getDouble(param[param_id], "Failed to parse maxExecutionTime at line %i.\n", 
            line_id[0] - numParam + param_id + 1);
    param_id++;
    
    bool optional = VarneIO_getBool(param[param_id], "Failed to parse optional at line %i.\n", 
            line_id[0] - numParam + param_id + 1);
    param_id++;
    
    getOptional(mla, optional, reader, line_id, msg);
}

/**
 * @since 2017.12.18, 12.25
 */
void MLAnalysis_free(struct MLAnalysis **ptr) {
    struct MLAnalysis *alg = ptr[0];
    matrixalloc_1d_free(alg->algorithmName);
    matrixalloc_1d_free(alg);
    ptr[0] = NULL;
}