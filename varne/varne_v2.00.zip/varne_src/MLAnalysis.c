/*
 * Created on 31 July 2017, 17:17
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "MLAnalysis.h"

#include "VarneIO.h"
#include "ML.h"
#include "Model.h"
#include "PrintErrorMessage.h"
#include "MLAnalysis_def.h"

#include "io/file_reader.h"
#include "util/error_msg.h"
#include "util/string_util.h"

/**
 * @since 2017.8.1, 9.20
 */
static void noFreeParam(Model_t model, FILE *resultFile) {
    char *msg;
    void **data = Model_extraFunction("fullLikelihood_noConstraint", model, &msg, NULL);
    if (msg != NULL) {
        ERROR_MSG_LMA("ERROR");
    }
    int num = ((int *) data[0])[0];
    M1D_FREE(data[0]);
    char **names = data[1];
    double *mle = data[2];
    double lnlike = ((double *) data[3])[0];
    M1D_FREE(data[3]);
    M1D_FREE(data);
    fprintf(resultFile, "All parameters of the equilibrium model and the full likelihood:\n");
    for (int i = 0; i < num; i++) {
        fprintf(resultFile, "%s = %.15g\n", names[i], mle[i]);
        M1D_FREE(names[i]);
    }
    M1D_FREE(names);
    M1D_FREE(mle);
    fprintf(resultFile, "lnlike = %.15g\n", lnlike);
}

/**
 * @since 2017.8.1, 9.20
 */
static ML_t getML(struct MLAnalysis *mla, FILE *result_file, file_reader_t *reader, int *line_id, char **msg) {
    int numParam = 2;
    int paramID = 0;
    const char *names[numParam];
    names[paramID++] = "[model]";
    names[paramID++] = "modelName:";
    if (paramID != numParam)
        ERROR_MSG_LMA("Error");
    
    char param[numParam][BUFFER_SIZE];
    VarneIO_readControlParam(numParam, param, names, reader, line_id, msg);
    if (msg[0] != NULL)
        return NULL;

    paramID = 1; //skip [model_commands]

    Model_t model;

    if (string_util_equal(param[paramID], "MODEL1")) {
        model = Model_new(MODEL1, reader, line_id, msg);
    } else if (string_util_equal(param[paramID], "MODEL2")) {
        model = Model_new(MODEL2, reader, line_id, msg);
    } else {
        PRINT_ERRMSG(msg, "Unknown modelName = %s\n", param[paramID]);
        return NULL;
    }
    if (msg[0] != NULL)
        return NULL;
    paramID++;

    mla->numParam = Model_getNumParam(model);
    if (mla->numParam == 0) {
        noFreeParam(model, result_file);
        Model_free(&model);
        return NULL;
    } else {
        char **paramNames = Model_getParamNames(model);
        fprintf(result_file, "List of free parameters:");
        for (int i = 0; i < mla->numParam; i++) {
            fprintf(result_file, "   %s", paramNames[i]);
            matrixalloc_1d_free(paramNames[i]);
        }
        matrixalloc_1d_free(paramNames);
        fprintf(result_file, "\n\n");
        fflush(result_file);

        MLBuilder_t mb = MLBuilder_new(&model, mla->numSearches, mla->relTolerance, mla->numNoImprove, mla->maxNumImprove, msg);
        if (msg[0] != NULL)
            return NULL;

        MLBuilder_addAlgorithm(mb, mla->algorithmName, mla->relTolerance, mla->maxNumOfFuncEvaluations, mla->maxExecutionTime, msg);
        if (msg[0] != NULL)
            return NULL;

        return MLBuilder_build(&mb);
    }
}

/*
 * @since 2017.8.1, 9.20
 */
void doMLAnalysis(char** argv, unsigned long seed) {
    file_reader_t *reader;
    {
        file_reader_state_t state;
        reader = file_reader_new(argv[3], BUFFER_SIZE, &state);
        if (state != file_reader_state_success) {
            fprintf(stderr, "Error: failed to open the following file: %s\n", argv[3]);
            exit(EXIT_FAILURE);
        } 
    }
    
    FILE *resultFile = VarneIO_newFile(argv[4]);
    fprintf(resultFile, "Control file: %s\n", argv[3]);
    fprintf(resultFile, "Seed = %lu\n\n", seed);
    fflush(resultFile);
    
    FILE *logFile = VarneIO_newFile(argv[5]);

    int line_id = 0;
    char *msg;
    
    struct MLAnalysis *mla = MLAnalysis_new();
    
    MLAnalysis_readControlFile(mla, reader, &line_id, &msg);
    if (msg != NULL)
        ERROR_MSG_LMA("%s\n", msg);
    
    ML_t ml = getML(mla, resultFile, reader, &line_id, &msg);
    if (msg != NULL)
        ERROR_MSG_LMA("%s\n", msg);
    
    if (mla->numParam != 0) {
        gsl_rng *rng = gsl_rng_alloc(gsl_rng_mt19937);
        gsl_rng_set(rng, seed);

        ML_search(ml, resultFile, logFile, rng, NULL);

        gsl_rng_free(rng);
        ML_free(&ml);
    }

    MLAnalysis_free(&mla);
    fclose(logFile);
    fclose(resultFile);
    {
        file_reader_state_t s;
        file_reader_free(reader, &s, NULL);
    }
}