/*
 * Created on 05 July 2017, 08:41
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "VarneIO.h"

#include "PrintErrorMessage.h"

#include "util/string_util.h"
#include "util/error_msg.h"
#include "util/matrixalloc.h"


/**
 * @since 2016.9.27, 9.28, 2017.2.26
 */
FILE * VarneIO_newFile(const char *path) {
//    FILE *re = fopen(path, "r");
//    if (re != NULL) {//TODO
//        fprintf(stderr, "Error: output file exists!\n");
//        abort();
//    }
//    re = fopen(path, "w");
    
    FILE *re = fopen(path, "w");
    if (re == NULL) {
        fprintf(stderr, "Error: cannot open output file!\n");
        abort();
    }
    return re;
}

/*
 * @since 2017.7.28, 9.12
 */
void VarneIO_toEOF(file_reader_t *reader, int *line_id, char **msg) {
    msg[0] = NULL;
    
    char buffer[BUFFER_SIZE];
    file_reader_state_t state;
    while (true) {
        line_id[0]++;
        file_reader_read_line_buffer(BUFFER_SIZE, buffer, reader, &state);
        if (state == file_reader_state_eof)
            return;
        else if (state == file_reader_state_success) {
            char *buff = string_util_trim(buffer);
            if (strlen(buff) == 0 || buff[0] == '#')
                continue;
            else {
                PRINT_ERRMSG(msg, "Unexpected text at line %d = %s", *line_id, buffer);
                return;
            }
        } else {
            PRINT_ERRMSG(msg, "Unexpected error at line %d", *line_id);
            return;
        }
    }
}

/*
 * @since 2016.10.26, 10.29, 2017.4.14
 */
void VarneIO_skipLines(char buffer[BUFFER_SIZE], file_reader_t *reader, int *line_id, char **msg) {
    msg[0] = NULL;
    file_reader_state_t state;
    while (true) {
        line_id[0]++;
        file_reader_read_line_buffer(BUFFER_SIZE, buffer, reader, &state);
        if (state != file_reader_state_success) {
            PRINT_ERRMSG(msg, "Error reading the control file! Bad format, corrupted file, or "
                    "line width greater than %i.\n", BUFFER_SIZE);
            return;
        }
        char *buff = string_util_trim(buffer);
        if (strlen(buff) == 0) 
            continue;
        else if (string_util_starts_with(buff, "#"))
            continue;
        else 
            break;
    }
}

/**
 * @since 2017.2.24, 2.26, 4.12
 */
void VarneIO_readControlParam(int num_param, char param[num_param][BUFFER_SIZE], 
        const char *param_name[num_param], file_reader_t *reader, int *line_id, char **msg) {
    msg[0] = NULL;
    char *buff;
    char buffer[BUFFER_SIZE];
    
    for (int i = 0; i < num_param; i++) {
        VarneIO_skipLines(buffer, reader, line_id, msg);
        if (msg[0] != NULL) {
            return;
        }
        buff = string_util_trim(buffer);
        if (string_util_starts_with(buff, param_name[i]) == false) {
            PRINT_ERRMSG(msg, "Failed to find %s at line %i in the control file.\n", param_name[i], line_id[0]);
            return;
        }
        buff += strlen(param_name[i]);
        buff = string_util_trim(buff);
        strcpy(param[i], buff);
    }
}

/*
 * @since 2017.2.24, 2.26, 4.14
 */
int VarneIO_getInt(const char *valstr, const char *format, ...) {
    string_util_parse_state_t state;
    char *endptr;
    int re = string_util_parse_int(valstr, &endptr, 10, &state);
    if (state != string_util_parse_state_success) {
        va_list args;
        va_start(args, format);
        vfprintf(stderr, format, args);
        va_end(args);
        ERROR_MSG_LMA("\n");
    }
    return re;
}

/*
 * @since 2017.8.10, 9.12
 */
intmax_t VarneIO_getIntmax(const char *valstr, const char *format, ...) {
    string_util_parse_state_t state;
    char *endptr;
    intmax_t re = string_util_parse_intmax(valstr, &endptr, 10, &state);
    if (state != string_util_parse_state_success) {
        va_list args;
        va_start(args, format);
        vfprintf(stderr, format, args);
        va_end(args);
        ERROR_MSG_ME("\n");
    }
    return re;
}

/*
 * @since 2017.2.26, 4.14
 */
static double vget_double(const char *valstr, const char *format, va_list args) {
    string_util_parse_state_t state;
    char *endptr;
    double re = string_util_parse_double(valstr, &endptr, &state);
    if (state != string_util_parse_state_success) {
        vfprintf(stderr, format, args);
        ERROR_MSG_LMA("\n");
    }
    return re;
}

/*
 * @since 2017.2.26, 4.14
 */
double VarneIO_getDouble(const char *valstr, const char *format, ...) {
    va_list args;
    va_start(args, format);
    double re = vget_double(valstr, format, args);
    va_end(args);
    return re;
}

///**
// * Process a, b, c
// * @param len The number of elements
// * @since 2017.2.26, 4.14
// */
//void VarneIO_getDoubleArray1(int len, double result[len], char *valstr, const char *format, ...) {
//    va_list args;
//    va_start(args, format);
//    int cn;
//    char **sarr = string_util_split(valstr, ",", &cn);
//    if (cn != len) {
//        vfprintf(stderr, format, args);
//        ERROR_MSG_LMA("\n");
//    }
//    for (int i = 0; i < cn; i++)
//        result[i] = vget_double(sarr[i], format, args);
//    va_end(args);
//    matrixalloc_1d_free(sarr);
//}

/**
 * Process a b c
 * @param len The number of elements
 * @since 2017.2.26, 4.14
 */
void VarneIO_getDoubleArray1(int len, double result[len], char *valstr, const char *format, ...) {
    va_list args;
    va_start(args, format);
    if (strlen(valstr) == 0) {
        vfprintf(stderr, format, args);
        ERROR_MSG_LMA("\n");
    }
    int cn;
    char **sarr = string_util_split(valstr, "\\s+", &cn);
    if (cn != len) {
        vfprintf(stderr, format, args);
        ERROR_MSG_LMA("\n");
    }
    for (int i = 0; i < cn; i++)
        result[i] = vget_double(sarr[i], format, args);
    va_end(args);
    matrixalloc_1d_free(sarr);
}

/**
 * Process a b c
 * @since 2018.4.14, 4.16, 5.27
 */
double * VarneIO_getDoubleArray2(int *cn, char *valstr, const char *format, ...) {
    va_list args;
    va_start(args, format);
    char **sarr = string_util_split(valstr, "\\s+", cn);
    double *re = matrixalloc_1d(cn[0], sizeof(*re));
    for (int i = 0; i < cn[0]; i++)
        re[i] = vget_double(sarr[i], format, args);
    va_end(args);
    matrixalloc_1d_free(sarr);
    return re;
}

///**
// * Process a, b, c
// * @since 2018.5.29
// */
//double * VarneIO_getDoubleArray2(int *cn, char *valstr, const char *format, ...) {
//    va_list args;
//    va_start(args, format);
//    char **sarr = string_util_split(valstr, ",", cn);
//    double *re;
//    M1D_NEW(re, cn[0]);
//    for (int i = 0; i < cn[0]; i++)
//        re[i] = vget_double(sarr[i], format, args);
//    va_end(args);
//    M1D_FREE(sarr);
//    return re;
//}

/*
 * @since 2017.2.24, 2.26, 4.14
 */
bool VarneIO_getBool(const char *valstr, const char *format, ...) {
    string_util_parse_state_t state;
    bool re = string_util_parse_bool(valstr, &state);
    if (state != string_util_parse_state_success) {
        va_list args;
        va_start(args, format);
        vfprintf(stderr, format, args);
        va_end(args);
        ERROR_MSG_LMA("\n");
    }
    return re;
}

/*
 * @since 2018.1.31, 2.2, 11.9
 */
char * VarneIO_removeSquareBrackets(const char *src, char **msg) {
    msg[0] = NULL;

    if ((string_util_starts_with(src, "[") && string_util_ends_with(src, "]")) == false) {
        PRINT_ERRMSG(msg, "%s is not flanked by square brackets.", src);
        return NULL;
    }
    
    char *re;
    size_t len = strlen(src + 1);
    if (len > BUFFER_SIZE) {
        PRINT_ERRMSG(msg, "Overflow.");
        return NULL;
    }
    M1D_CLONE(re, src + 1, (int) len);
    re[len - 1] = '\0';
    return re;
}

/*
 * @since 2018.5.27, 5.30, 11.9
 */
void VarneIO_getValuesInSquareBrackets(int *n, double **v, const char *src, char **msg) {
    msg[0] = NULL;
    
    char *tmp = memchr(src, '[', strlen(src));
    if (tmp == NULL) {
        PRINT_ERRMSG(msg, "Failed to find '[' in %s.", src);
        return;
    }
    tmp = VarneIO_removeSquareBrackets(tmp, msg);
    if (msg[0] != NULL) {
        return;
    }
    char *tmp2 = tmp;
    v[0] = VarneIO_getDoubleArray2(n, tmp2, "Failed to parse values in %s.", src);
    M1D_FREE(tmp);
}

