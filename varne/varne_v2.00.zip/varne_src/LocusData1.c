/*
 * Created on 24 June 2018, 07:56
 */

#include "LocusData1.h"

#include "PrintErrorMessage.h"

#include "util/matrixalloc.h"

/*
 * @since 2018.10.8, 10.9
 */
struct LocusData1 * LocusData1_new(int len, int *n, double *m, int *folded, double **sfs, char **msg) {
    if (len < 1) {
        PRINT_ERRMSG(msg, "len < 1\n");
        return NULL;
    }
    
    struct LocusData1 *data;
    M1D_NEW(data, 1);
    data->len = len;
    M1D_NEW(data->n, len);
    M1D_NEW(data->m, len);
    M1D_NEW(data->folded, len);
    M1D_NEW(data->sfs, len);
    M1D_NEW(data->sfsLen, len);
    data->numSeg = 0;
    
    for (int i = 0; i < len; i++) {
        if (m[i] <= 0) {
            PRINT_ERRMSG(msg, "m <= 0\n");
            return NULL;
        }
        if (n[i] < 2) {
            PRINT_ERRMSG(msg, "n < 2\n");
            return NULL;
        }
        data->n[i] = n[i];
        data->m[i] = m[i];
        data->folded[i] = (bool) folded[i];
        data->sfsLen[i] = (data->folded[i] ? n[i] / 2 : n[i] - 1);
        for (int k = 0; k < data->sfsLen[i]; k++) {
            if (sfs[i][k] < 0) {
                PRINT_ERRMSG(msg, "sfs[%i] < 0\n", i + 1);
                return NULL;
            }
            data->numSeg += sfs[i][k];
        }
        M1D_CLONE(data->sfs[i], sfs[i], data->sfsLen[i]);
    }
    
    return data;
}

/*
 * @since 2018.10.9
 */
void LocusData1_free(struct LocusData1 **data) {
    struct LocusData1 *d = data[0];
    data[0] = NULL;
    M1D_FREE(d->sfsLen);
    for (int i = 0; i < d->len; i++)
        M1D_FREE(d->sfs[i]);
    M1D_FREE(d->sfs);
    M1D_FREE(d->folded);
    M1D_FREE(d->m);
    M1D_FREE(d->n);
    M1D_FREE(d);
}

/*
 * @since 2018.10.8, 10.9
 */
void LocusData1_getSampleSize(int *len, int **n, void *data) {
    struct LocusData1 *d = (struct LocusData1 *) data;
    len[0] = d->len;
    M1D_CLONE(n[0], d->n, d->len);
}