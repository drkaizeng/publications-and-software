#include <stdlib.h>

#include "Locus_def.h"

#include "PrintErrorMessage.h"

#include "util/matrixalloc.h"

/*
 * @since 2018.10.8
 */
LocusExecutor_t LocusExecutor_new(enum LocusType type, char **msg, ...) {
    LocusExecutor_t re;
    
    va_list args;
    va_start(args, msg);
    
    msg[0] = NULL;
    if (type == LOCUS1) {
        re = Locus1Executor_new(args);
    } else if (type == LOCUS2) {
        re = Locus2Executor_new(args);
    } else {
        PRINT_ERRMSG(msg, "Unknown locus type.");
        return NULL;
    }
    
    va_end(args);
    
    return re;
}

/*
 * @since 2017.6.30, 7.4, 7.28, 2018.5.17
 */
void LocusExecutor_free(LocusExecutor_t *exec) {
    LocusExecutor_t e = exec[0];
    exec[0] = NULL;
    
    e->freeParam(&(e->param));
    matrixalloc_1d_free(e);
}

/*
 * @since 2017.7.7, 7.28
 */
LocusExecutor_t LocusExecutor_clone(LocusExecutor_t exec) {
    LocusExecutor_t re = matrixalloc_1d(1, sizeof (*re));
    *re = *exec;
    re->param = exec->clone(exec->param);
    return re;
}

/*
 * @since 2017.6.30, 7.27
 */
double LocusExecutor_getLikelihood(double *grad, const double *x, const bool *derivative, Locus_t loc, LocusExecutor_t exec) {
    return exec->lnlike(grad, x, derivative, loc, exec->param);
}

/*
 * @since 2018.10.9
 */
void * LocusExecutor_extraFunction(const char *cmd, Locus_t loc, LocusExecutor_t exec, char **msg, ...) {
    va_list args;
    va_start(args, msg);
    
    void *re = exec->extraFunction(cmd, loc, exec->param, msg, args);
    
    va_end(args);
    
    return re;
}
