/* 
 * Created on 23 February 2017, 10:57
 */

#ifndef GETNAME_H
#    define GETNAME_H

/**
 * Return name_index.
 * The returned object should be freed by free() or matrixalloc_1d_free.
 */
char * getName(const char *name, int index);

/**
 * The returned object should be freed by free() or matrixalloc_1d_free.
 */
char * getName2(const char *format, ...);

#endif /* GET_NAME_H */

