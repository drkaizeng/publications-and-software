/*
 * Created on 16 October 2018, 15:12
 */
#include <time.h>
#include <stdio.h>
#include <stdlib.h>

#include "MLAnalysis.h"

#include "util/error_msg.h"
#include "util/string_util.h"

/*
 * @since 2017.8.15, 9.12
 */
static unsigned long getSeed(const char *method) {
    unsigned long seed;
    if (string_util_equal(method, "current_time")) {
        seed = (unsigned long) time(NULL);
    } else {
        string_util_parse_state_t status;
        char *endptr;
        seed = string_util_parse_ulong(method, &endptr, 10, &status);
        if (status != string_util_parse_state_success) {
            ERROR_MSG_ME("Failed to parse seed = %s\n", method);
        }
    }
    return seed;
}

int main(int argc, char** argv) {
    if (argc != 6) {
        ERROR_MSG_ME("Usage:\n"
                "varne ml seed control_file result_file log_file\n"
                );
    }
    
    if (string_util_equal(argv[1], "ml")) {
        if (argc != 6) {
            ERROR_MSG_ME("Usage:\n"
                "varne ml seed control_file result_file log_file\n");
        }
        unsigned long seed = getSeed(argv[2]);
        doMLAnalysis(argv, seed);
    } else {
        ERROR_MSG_ME("Unknown command-line option!\n"
                "Usage:\n"
                "varne ml seed control_file result_file log_file\n"
                );
    }
        
    return (EXIT_SUCCESS);
}

