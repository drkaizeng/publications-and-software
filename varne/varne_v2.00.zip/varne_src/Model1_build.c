/*
 * Created on 14 October 2018, 12:10
 */

#include "Model.h"
#include "Model1_def.h"

#include "GetName.h"
#include "FindName.h"
#include "PrintErrorMessage.h"
#include "VarneIO.h"

#include "util/matrixalloc.h"
#include "util/error_msg.h"
#include "util/arrayutil.h"
#include "util/string_util.h"


/**
 * Initialise everything assuming no constraints
 * @param inputParamRanges On the original scale. Parameters ordered as getParamTypeID
 * @since 2018.10.15
 */
static void initialise(struct Model1 *re, char **msg) {
    msg[0] = NULL;
    
    re->nx = 0;
    for (int i = 0; i < re->numLoci; i++) {
        re->nx += Locus_getNumParam(re->loci[i]);
    }
    
    M1D_NEW(re->x, re->nx);
    
    M1D_NEW(re->xi, re->nx);
    for (int i = 0; i < re->nx; i++) {
        re->xi[i] = i;
    }
    
    M1D_NEW(re->derivative, re->nx);
    AU_FILL2(re->derivative, 0, re->nx, true);
    
    M1D_NEW(re->dx, re->nx);
    M1D_NEW(re->nxZeros, re->nx);
    AU_FILL2(re->nxZeros, 0, re->nx, 0);
    re->nxZerosSize = (size_t) re->nx * sizeof(*re->nxZeros);
    
    M1D_NEW(re->offset, re->numLoci);
    re->offset[0] = 0;
    for (int i = 1; i < re->numLoci; i++) {
        re->offset[i] = re->offset[i - 1] + Locus_getNumParam(re->loci[i - 1]);
    }
    
    M1D_NEW(re->constraints, re->nx);
    AU_FILL2(re->constraints, 0, re->nx, NULL);
    
    re->numParam = re->nx;
    M1D_NEW(re->paramTypes, re->numParam);
    M1D_NEW(re->paramNames, re->numParam);
    M2D_NEW(re->paramRanges, 2, re->numParam);
    for (int i = 0; i < re->numLoci; i++) {
        int num = (size_t) Locus_getNumParam(re->loci[i]);
        
        int offset = re->offset[i];
        
        enum ParameterType *types = Locus_getParamTypes(re->loci[i]);
        memcpy(re->paramTypes + offset, types, (size_t) num * sizeof(*types));
        for (int j = 0, indx = offset; j < num; j++, indx++) {
            double lo, hi;
            Model1InputParamRanges_get(&lo, &hi, types[j], re->inputRanges);
            lo = Model1_scaleParam(types[j], lo);
            hi = Model1_scaleParam(types[j], hi);
            re->paramRanges[0][indx] = lo;
            re->paramRanges[1][indx] = hi;
        }
        M1D_FREE(types);
        
        char **names = Locus_getParamNames(re->loci[i]);
        memcpy(re->paramNames + offset, names, (size_t) num * sizeof(*names));
        M1D_FREE(names);
        
    }
    
    re->numParamZerosSize = (size_t) re->numParam * sizeof(double);
    
    re->numNloptConstraints = 0;
    re->isEqualityConstraint = NULL;
    re->nloptConstraints = NULL;
    re->nloptConstraintsData = NULL;
    re->freeNloptConstraintData = NULL;
    
    M1D_NEW(re->exec, re->numThreads);
    re->exec[0] = LocusExecutor_new(LOCUS1, msg, re->numLoci, re->loci);
    if (msg[0] != NULL) {
        ERROR_MSG_LMA("ERROR");
    }
    for (int i = 1; i < re->numThreads; i++) {
        re->exec[i] = LocusExecutor_clone(re->exec[0]);
    }
    
    re->initMethod = 0;
    re->givenInitValues = NULL;
}

/**
 * @since 2017.7.7, 7.31
 */
static double equal_f(const double *x, void *param) {
    return x[0];
}

/**
 * @since 2017.5.22, 7.31
 */
static double equal_df(const double *x, int i, void *param) {
    return 1;
}

/* 
 * See also Model1_build.c
 * @since 2018.10.15
 */
static int getParamTypeCount(Locus_t loc, enum ParameterType type) {
    int nx = Locus_getNumParam(loc);
    enum ParameterType *types = Locus_getParamTypes(loc);
    int num = 0;
    for (int i = 0; i < nx; i++) {
        if (types[i] == type) {
            num++;
        }
    }
    M1D_FREE(types);
    return num;
}

/*
 * @since 2018.10.15, 11.9
 */
static void setTauGEqual(struct Model1 *re, enum ParameterType type) {
    char *typeName = ParameterType_toString(type);
    int cnt = getParamTypeCount(re->loci[0], type);
    if (cnt == 0) 
        ERROR_MSG_LMA("error\n");
    int paramID[re->numLoci];
    for (int i = 0; i < cnt; i++) {
        for (int j = 0; j < re->numLoci; j++) {
            char *locName = Locus_getName(re->loci[j]);
            if (getParamTypeCount(re->loci[j], type) != cnt) {
                ERROR_MSG_LMA("ERROR");
            }
            char *name = getName2("%s%s_%d", locName, typeName, (i + 1));
            paramID[j] = findName(name, re->numParam, re->paramNames);
            if (paramID[j] < 0)
                ERROR_MSG_LMA("error\n");
            M1D_FREE(name);
            M1D_FREE(locName);
        }
        for (int j = 1; j < re->numLoci; j++) {
            re->xi[paramID[j]] = -2;
            int nx = 1;//for the constraint
            double *x;
            int *xi2;
            M1D_NEW(x, nx);
            M1D_NEW(xi2, nx);
            xi2[0] = paramID[0];
            re->constraints[paramID[j]] = Constraint_new(nx, x, xi2, equal_f, equal_df, NULL, NULL);
        }
    }
    M1D_FREE(typeName);
}

/*
 * See also setConstant in Model2_build.c.
 * @since 2018.10.15 
 */
static void setConstant(struct Model1 *re, int locID, int locParamID, enum ParameterType type, double v) {
    if (locID < 0 || locID >= re->numLoci) {
        ERROR_MSG_LMA("ERROR");
    }
    
    if (locParamID < 0 || locParamID >= Locus_getNumParam(re->loci[locID])) {
        ERROR_MSG_LMA("ERROR");
    }
    
    char *typeName = ParameterType_toString(type);
    
    enum ParameterType *types = Locus_getParamTypes(re->loci[locID]);
    if (types[locParamID] != type) {
        ERROR_MSG_LMA("ERROR");
    }
    
    int id;
    {
        char *locName = Locus_getName(re->loci[locID]);
        char *name;
        if (type == G || type == TAU) {
            int cnt = 1; ERROR_MSG_LMA("ERROR");
            for (int j = locParamID - 1; j >= 0; j--) {
                if (types[j] == type) {
                    cnt++;
                } else
                    break;
            }
            name = getName2("%s%s_%d", locName, typeName, cnt);
        } else {
            name = getName2("%s%s", locName, typeName);
        }
        id = findName(name, re->numParam, re->paramNames);
        if (id < 0) {
            ERROR_MSG_LMA("error.");
        }
        M1D_FREE(name);
        M1D_FREE(locName);
    }
    if (re->xi[id] < 0) {
        ERROR_MSG_LMA("ERROR");
    }

    re->xi[id] = -1;
    re->x[id] = v; 
    re->derivative[id] = false;
    
    M1D_FREE(types);
    M1D_FREE(typeName);
}

/*
 * @since 2018.10.15
 */
static void setErrorConstant(struct Model1 *re, double v) {
    int errID = 2 * re->H;
    if (re->useProfile)
        errID--;
    for (int k = 0; k < re->numLoci; k++) {
        setConstant(re, k, errID, ERROR, v);
    }
}

/*
 * @since 2018.10.15, 11.9
 */
static void setFConstant(struct Model1 *re, double v) {
    int fID = (re->useProfile ? 0 : 1);
    for (int k = 0; k < re->numLoci; k++) {
        setConstant(re, k, fID, F, v);
    }
}

/*
 * This is for parameter that appears exactly once at each locus. <br>
 * Set all theta/error to be equal l1_theta/l1_error
 * @since 2018.11.9
 */
static void setThetaErrorEqual(struct Model1 *re, enum ParameterType type) {
    char *typeName = ParameterType_toString(type);
    int cnt = getParamTypeCount(re->loci[0], type);
    if (cnt != 1) 
        ERROR_MSG_LMA("error\n");
    int paramID[re->numLoci];
    for (int i = 0; i < cnt; i++) {
        for (int j = 0; j < re->numLoci; j++) {
            char *locName = Locus_getName(re->loci[j]);
            if (getParamTypeCount(re->loci[j], type) != cnt) {
                ERROR_MSG_LMA("ERROR");
            }
            char *name = getName2("%s%s", locName, typeName);
            paramID[j] = findName(name, re->numParam, re->paramNames);
            if (paramID[j] < 0)
                ERROR_MSG_LMA("error\n");
            M1D_FREE(name);
            M1D_FREE(locName);
        }
        for (int j = 1; j < re->numLoci; j++) {
            re->xi[paramID[j]] = -2;
            int nx = 1;//for the constraint
            double *x;
            int *xi2;
            M1D_NEW(x, nx);
            M1D_NEW(xi2, nx);
            xi2[0] = paramID[0];
            re->constraints[paramID[j]] = Constraint_new(nx, x, xi2, equal_f, equal_df, NULL, NULL);
        }
    }
    M1D_FREE(typeName);
}

/*
 * Fix error to 0 at loci with only folded sfs
 * @since 2018.11.9 (Extracted from general and simplified)
 */
static void detectFoldedSFSOnlyLoci(struct Model1 *re) {
    char *msg;
    int errID = 2 * re->H;
    if (re->useProfile) {
        errID--;
    }
    for (int i = 0; i < re->numLoci; i++) {
        bool *isAllFolded = Locus_extraFunction("isAllSFSFolded", re->loci[i], &msg);
        if (msg != NULL) {
            ERROR_MSG_LMA("ERROR");
        }
        if (isAllFolded[0]) {
            setConstant(re, i, errID, ERROR, 0);
        }
        M1D_FREE(isAllFolded);
    }
}

/*
 * non-free parameters has been marked by setting xi to -1 and x[xi] to the constant, or xi to -2 and cf to non-NULL.
 * <li> But the other numbers in xi have not been changed (e.g., 0, -1, 2 rather than 0, -1, 1)
 * 
 * @since 2018.10.15
 */
static void removeParam(struct Model1 *re) {
    for (int i = 0, cnt = 0; i < re->nx; i++) {
        if (re->xi[i] >= 0) {
            cnt++;
            continue;
        } 
        for (int j = i + 1; j < re->nx; j++) {
            if (re->xi[j] >= 0)
                re->xi[j]--;
        }
        M1D_FREE(re->paramNames[cnt]);
        int num = re->numParam - cnt - 1;
        memmove(re->paramTypes + cnt, re->paramTypes + cnt + 1, (size_t) num * sizeof(*re->paramTypes));
        memmove(re->paramNames + cnt, re->paramNames + cnt + 1, (size_t) num * sizeof(*re->paramNames));
        memmove(re->paramRanges[0] + cnt, re->paramRanges[0] + cnt + 1, (size_t) num * sizeof(*re->paramRanges[0]));
        memmove(re->paramRanges[1] + cnt, re->paramRanges[1] + cnt + 1, (size_t) num * sizeof(*re->paramRanges[1]));
        re->numParam--;
        re->numParamZerosSize -= sizeof(double);
    }
    if (re->numParam == 0) {
        M1D_FREE(re->paramTypes); re->paramTypes = NULL;
        M1D_FREE(re->paramNames); re->paramNames = NULL;
        M2D_FREE(re->paramRanges); re->paramRanges = NULL;
    } else {
        double **ranges = matrixalloc_2d_d(2, re->numParam);
        for (int i = 0; i < 2; i++)
            memcpy(ranges[i], re->paramRanges[i], (size_t) re->numParam * sizeof (*ranges[i]));
        M2D_FREE(re->paramRanges);
        re->paramRanges = ranges;
    }
}

/*
 * @since 2018.10.16
 */
static void general(struct Model1 *re, bool withError) {
    if (re->H == 1) {
        setFConstant(re, 1);
    } else {
        int fID = (re->useProfile ? 0 : 1);
        setConstant(re, 0, fID, F, 1); //f_1 = 1
        setTauGEqual(re, TAU);
    }
    if (withError) {
        detectFoldedSFSOnlyLoci(re);
    } else {
        setErrorConstant(re, 0);
    }
    removeParam(re);
}

/*
 * @since 2018.11.9
 */
static void simplified(struct Model1 *re, bool withError) {
    if (re->H == 1) {
        setFConstant(re, 1);
    } else {
        int fID = (re->useProfile ? 0 : 1);
        setConstant(re, 0, fID, F, 1); //f_1 = 1
        setTauGEqual(re, TAU);
        setTauGEqual(re, G);
    }
    if (withError) {
        detectFoldedSFSOnlyLoci(re);
    } else {
        setErrorConstant(re, 0);
    }
    removeParam(re);
}

/*
 * @since 2018.11.9
 */
static double getNeRatio(char *constraintName, char **msg) {
    msg[0] = NULL;
    double v;
    {
        int n;
        double *tmp;
        VarneIO_getValuesInSquareBrackets(&n, &tmp, constraintName, msg);
        if (msg[0] != NULL) {
            return -1;
        }
        if (n != 1) {
            PRINT_ERRMSG(msg, "Unknown constraint = %s.", constraintName);
            return -1;
        }
        v = tmp[0];
        if (v <= 0) {
            PRINT_ERRMSG(msg, "Ne ratio <= 0 in constraint = %s.", constraintName);
            return -1;
        }
        M1D_FREE(tmp);
    }
    return v;
}

/*
 * @since 2018.11.9
 */
static void twoLoci_fixedNeRatio(struct Model1 *re, bool withError, char **msg) {
    msg[0] = NULL;
    if (re->numLoci != 2) {
        PRINT_ERRMSG(msg, "The number of loci must be 2 when twoLoci_fixedNeRatio[val] is used.");
        return;
    }
    if (re->H == 1) {
        PRINT_ERRMSG(msg, "H should be at least 2 when twoLoci_fixedNeRatio[val] is used.");
        return;
    }
    double v = getNeRatio(re->constraintName, msg);
    if (msg[0] != NULL) {
        return;
    }
    int fID = re->useProfile ? 0 : 1;
    /* fix f for locus 1 to 1 */
    setConstant(re, 0, fID, F, 1);
    //This fixes f for locus 2 to 1/v.
    setConstant(re, 1, fID, F, 1 / v);
    setTauGEqual(re, TAU);
    setTauGEqual(re, G);
    if (withError) {
        detectFoldedSFSOnlyLoci(re);
    } else {
        setErrorConstant(re, 0);
    }
    removeParam(re);
}

/*
 * @since 2018.11.9
 */
static void general_equalMutationRate(struct Model1 *re, bool withError, char** msg) {
    msg[0] = NULL;
    if (re->useProfile) {
        PRINT_ERRMSG(msg, "useProfile must be set to false when general_equalMutationRate is used.");
        return;
    }
    setThetaErrorEqual(re, THETA);
    if (re->H == 1) {
        setFConstant(re, 1);
    } else {
        int fID = (re->useProfile ? 0 : 1);
        setConstant(re, 0, fID, F, 1); //f_1 = 1
        setTauGEqual(re, TAU);
    }
    if (withError) {
        detectFoldedSFSOnlyLoci(re);
    } else {
        setErrorConstant(re, 0);
    }
    removeParam(re);
}

/*
 * @since 2018.10.15
 */
void Model1_build(struct Model1 *re, char **msg) {
    msg[0] = NULL;
    
    initialise(re, msg);
    if (msg[0] != NULL) {
        return;
    }
    
    if (string_util_equal(re->constraintName, "general_noError")) {
        general(re, false);
    } else if (string_util_equal(re->constraintName, "general")) {
        general(re, true);
    } else if (string_util_equal(re->constraintName, "simplified_noError")) {
        simplified(re, false);
    } else if (string_util_equal(re->constraintName, "simplified")) {
        simplified(re, true);
    } else if (string_util_starts_with(re->constraintName, "twoLoci_noError_fixedNeRatio")) {
        twoLoci_fixedNeRatio(re, false, msg);
        if (msg[0] != NULL) {
            return;
        }
    } else if (string_util_starts_with(re->constraintName, "twoLoci_fixedNeRatio")) {
        twoLoci_fixedNeRatio(re, true, msg);
        if (msg[0] != NULL) {
            return;
        }
    } else if (string_util_equal(re->constraintName, "general_equalMutationRate")) {
        general_equalMutationRate(re, true, msg);
        if (msg[0] != NULL) {
            return;
        }
    } else if (string_util_equal(re->constraintName, "general_equalMutationRate_noError")) {
        general_equalMutationRate(re, false, msg);
        if (msg[0] != NULL) {
            return;
        }
    } else {
        PRINT_ERRMSG(msg, "Unknown constraint = %s", re->constraintName);
    }

    if (string_util_equal(re->initMethodName, "random")) {
        re->initMethod = 0;
        re->givenInitValues = NULL;
    } else if (string_util_starts_with(re->initMethodName, "given[") && string_util_ends_with(re->initMethodName, "]")) {
        re->initMethod = 1;
        int n;
        double *arr;
        VarneIO_getValuesInSquareBrackets(&n, &arr, re->initMethodName, msg);
        if (msg[0] != NULL) {
            return;
        }
        if (n != re->numParam) {
            PRINT_ERRMSG(msg, "Invalid number of parameters in %s.", re->initMethodName);
            return;
        }
        for (int i = 0; i < re->numParam; i++) {
            arr[i] = Model1_scaleParam(re->paramTypes[i], arr[i]);
            if (arr[i] < re->paramRanges[0][i] || arr[i] > re->paramRanges[1][i]) {
                PRINT_ERRMSG(msg, "Parameter %i in %s out of range.", i + 1, re->initMethodName);
                return;
            }
        }
        re->givenInitValues = arr;
    } else {
        ERROR_MSG_LMA("ERROR");
    }
    
}