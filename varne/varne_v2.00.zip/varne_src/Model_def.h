#ifndef MODEL_DEF_H
#define MODEL_DEF_H

#include "Model.h"

#include "Constraint.h"

struct Model {
    enum ModelType type;
    
    void *param;
    void (* freeParam)(void **param);
    
    int (* getNumParam)(void *param);
    char ** (* getParamNames)(void *param);
    enum ParameterType * (* getParamTypes)(void *param);
    void (* getInitialValues)(double *x, void *param, va_list args);
    double ** (* getParamRanges)(void *param);
    int (* getNumNloptConstraints)(void *param);
    void (* getNloptConstraints)(nlopt_func *constraint, bool *isEqualityConstraint, void **constraintData, void *param);
    double (* getLikelihood)(double *grad, const double *x, void *param);
    void (* scaleParam)(double *x2, double *x, void *param);
    void (* unscaleParam)(double *x2, double *x, void *param);
    void * (* extraFunction)(const char *cmd, void * param, char **msg, va_list args);
    
    
//    int (* getNumParamOfFullModel)(void *param);
//    char ** (* getParamNamesOfFullModel)(void *param);
//    void (* toParamOfFullModel)(double *allParam, const double *freeParam, void *param);
//    void (* toFreeParam)(double *free_param, const double *all_param, void *param);
};

Model_t Model1_new(file_reader_t *reader, int *line_id, char **msg);


Model_t Model2_new(file_reader_t *reader, int *line_id, char **msg);


#endif /* MODEL_DEF_H */

