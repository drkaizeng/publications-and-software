#include <float.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "nr_dfridr.h"
#include "../util/matrixalloc.h"


struct nr_dfridr_tag {
    int ntab;    
    double **a;
    int state;
};


/*
 * @since 2013.04.06, 2014.04.28
 */
nr_dfridr_t *nr_dfridr_new(int ntab) {
    if (ntab <= 0) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort(); 
    }
    
    nr_dfridr_t *re = matrixalloc_1d(1, sizeof(nr_dfridr_t));
    re->ntab = ntab;
    re->a = matrixalloc_2d_d(ntab, ntab);
    
    return re;
}


/*
 * @since
 */
void nr_dfridr_free(nr_dfridr_t *ptr) {
    if (ptr == NULL)
        return;
    matrixalloc_2d_d_free(ptr->a);
    matrixalloc_1d_free(ptr);
}


static const double CON = 1.4;
static const double CON2 = 1.4 * 1.4;
static const double SAFE = 2.0;

/*
 * @since 2014.04.06, 2014.04.25 (added void * to func and parameter list)
 */
static inline double central(double (*func)(double, void *), double x, void *data, double hh) {
        return ((*func)(x + hh, data) - (*func)(x - hh, data)) / (2.0 * hh);
}

/*
 * @since
 */
static inline double forward(double (*func)(double, void *), double x, void *data, double hh) {
    return ((*func)(x + hh, data) - (*func)(x + hh / 2, data)) / (hh / 2);
}


/*
 * @since
 */
static inline double backward(double (*func)(double, void *), double x, void *data, double hh) {
    return ((*func)(x - hh / 2, data) - (*func)(x - hh, data)) / (hh / 2);
}

/*
 * @since 2014.04.06, 2014.04.25 (added void * to func and parameter list), 2014.04.30
 */
static inline double work(double (*func)(double, void *), double x, void *data, double h, double *err, nr_dfridr_t *ptr, double (*diff)(double (*func)(double, void *), double x, void *data, double hh)) {
    if (h <= 0.0) {
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }

    const int NTAB = ptr->ntab;
    int i, j;
    double errt, fac, hh, ans;
    double **a = ptr->a;
    hh = h;
    a[0][0] = diff(func, x, data, hh);
    *err = DBL_MAX;
    ptr->state = 1;
    for (i = 1; i < NTAB; i++) {
        hh /= CON;
        a[0][i] = diff(func, x, data, hh);
        fac = CON2;
        for (j = 1; j <= i; j++) {
            a[j][i] = (a[j - 1][i] * fac - a[j - 1][i - 1]) / (fac - 1.0);
            fac = CON2*fac;
            errt = fmax(fabs(a[j][i] - a[j - 1][i]), fabs(a[j][i] - a[j - 1][i - 1]));
            if (errt <= *err) {
                *err = errt;
                ans = a[j][i];
            }
        }
        if (fabs(a[i][i] - a[i - 1][i - 1]) >= SAFE * (*err)) {
            ptr->state = 0;
            break;
        }
    }
    return ans;
}


/*
 * @since 2014.04.06, 2014.04.25 (added void * to func and parameter list)
 */
double nr_dfridr_central(double (*func)(double, void *), double x, void *data, double h, double *err, nr_dfridr_t *ptr) {    
    return work(func, x, data, h, err, ptr, central);
}


/*
 * @since
 */
double nr_dfridr_forward(double (*func)(double, void *), double x, void *data, double h, double *err, nr_dfridr_t *ptr) {
    return work(func, x, data, h, err, ptr, forward);
}


/*
 * @since
 */
double nr_dfridr_backward(double (*func)(double, void *), double x, void *data, double h, double *err, nr_dfridr_t *ptr) {
    return work(func, x, data, h, err, ptr, backward);
}

/*
 * @since 2014.04.28
 */
int nr_dfridr_state(nr_dfridr_t *ptr) {
    return ptr->state;    
}