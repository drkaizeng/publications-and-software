#include <stdio.h>
#include <string.h>

#include "my_string.h"

#include "../util/matrixalloc.h"

struct my_string_tag {
    const char *value;
    size_t length;
    size_t mem_size;
};

/*
 * @since
 */
my_string_t * my_string_new(const char *original) {
    size_t length = strlen(original);
    my_string_t *re = matrixalloc_1d(1, sizeof (my_string_t));
    re->mem_size = (length + 1) * sizeof (char);
    char *value = matrixalloc_1d(1, re->mem_size);
    memcpy(value, original, re->mem_size);
    re->value = value;
    re->length = length;
    return re;
}