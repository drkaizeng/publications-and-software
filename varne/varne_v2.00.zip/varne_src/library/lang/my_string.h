/* 
 * File:   my_string.h
 * Author: Kai
 *
 * Created on 02 February 2015, 17:07
 */

#ifndef MY_STRING_H
#define	MY_STRING_H

typedef struct my_string_tag my_string_t;

/**
 * 
 * @param original A null terminated string. A defensive copy is made, so that
 *                 the returned object is independent of original.
 */
my_string_t * my_string_new(const char *original);

#endif	/* STRING_H */

