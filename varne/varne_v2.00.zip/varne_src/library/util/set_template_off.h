/* 
 * Created on 14 September 2016, 13:57
 */

#undef DATA_TYPE
#undef ABBR

/* Generic part */
#undef CONCAT2x
#undef CONCAT2
#undef CONCAT3x
#undef CONCAT3

#undef SET_TYPE
#undef SET_NEW
#undef SET_FREE
#undef SET_CONTAINS
#undef SET_ADD
#undef SET_REMOVE
#undef SET_SIZE
#undef SET_GET
#undef BIN_SEARCH


