#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <inttypes.h>

#include "string_util.h"

#include "matrixalloc.h"
#include "error_msg.h"

/*
 * @since 2018.2.2
 */
char * string_util_make(const char *format, ...) {
    int buffer_size = 1000;
    char *re;
    while (true) {
        char buffer[buffer_size];
        va_list args;
        va_start(args, format);
        int cn = vsnprintf(buffer, (size_t) buffer_size, format, args);
        va_end(args);
        if (cn < 0)
            ERROR_MSG_LMA("Unknown error.");
        if (cn >= buffer_size) {
            buffer_size = cn + 1;
        } else {
            M1D_CLONE(re, buffer, cn + 1);
            break;
        }
    }
    return re;
}

/*
 * @since 2015.02.06, 2.17, 11.12, 11.16
 */
bool string_util_equal(const char *s1, const char *s2) {
    size_t len = strlen(s1);
    if (strlen(s2) != len) {
        return false;
    } else {
        int re = memcmp(s1, s2, len);
        if (re == 0)
            return true;
        else
            return false;
    }
}

/*
 * @since 2015.02.06, 2.17, 11.12
 */
char * string_util_clone(const char *s) {
    size_t len = strlen(s) + 1;
    if (len > INT_MAX) {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
    return matrixalloc_1d_clone(s, (int) len, sizeof (char));
}

/*
 * @since 2015.02.06, 2.17, 11.12
 */
char * string_util_trim(char *s) {
    size_t len = strlen(s);
    if (len >= INT_MAX) {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
    int cn = (int) len - 1;
    while (cn >= 0) {
        if (isspace(s[cn]) == 0)
            break;
        s[cn] = '\0';
        cn--;
    }
    if (cn == -1) {//len = cn + 1
        return s;
    } else {
        cn = 0;
        while (true) {
            if (isspace(*(s + cn)))
                cn++;
            else
                return s + cn;
        }
//        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
//        abort();
    }
}

/*
 * @since 2017.11.28
 */
static char ** string_util_split_space(char *s1, size_t s1_len, int *cn) {
    typedef struct ptr_list_tag {
        char *ptr;
        struct ptr_list_tag *next;
    } ptr_list_t;
    
    cn[0] = 0;
    ptr_list_t *head = NULL;
    ptr_list_t *this;
    
    for (size_t i = 0, in = 0; i < s1_len; i++) {//in = 0 if not in non-space
        if (isspace(s1[i])) {
            if (in == 1) 
                s1[i] = '\0';
            in = 0;
        } else {
            if (in == 0) {
                cn[0]++;
                ptr_list_t *new = matrixalloc_1d(1, sizeof (*new));
                new->ptr = s1 + i;
                new->next = NULL;
                if (cn[0] == 1) {
                    head = this = new;
                } else {
                    this->next = new;
                    this = new;
                }
            }
            in = 1;
        }
    }
    if ((*cn) == 0) {
        return NULL;
    } else {
        char **re = matrixalloc_1d((*cn), sizeof (char *));
        for (int i = 0; i < (*cn); i++) {
            re[i] = head->ptr;
            this = head->next;
            matrixalloc_1d_free(head);
            head = this;
        }
        return re;
    }
}

/*
 * @since 2015.02.04, 2.6, 2.17, 11.12; 2017.11.28
 */
char ** string_util_split(char *s1, const char *s2, int *cn) {
    typedef struct ptr_list_tag {
        char *ptr;
        struct ptr_list_tag *next;
    } ptr_list_t;

    size_t s1_len = strlen(s1);
    size_t s2_len = strlen(s2);
    if (s1_len == 0 || s2_len == 0) {
        ERROR_MSG_ME("Either s1 or s2 is empty.\n");
    } else if (string_util_equal(s2, "\\s+")) {
        return string_util_split_space(s1, s1_len, cn);
    } else {
        (*cn) = 0;
        char *s1_end = s1 + s1_len;
        ptr_list_t *head = NULL;
        ptr_list_t *this;
        do {
            char *tmp = strstr(s1, s2);
            if (tmp == NULL) {
                if ((*cn) == 0) {
                    (*cn) = 1;
                    char **re = matrixalloc_1d((*cn), sizeof (char *));
                    re[0] = s1;
                    return re;
                } else {
                    ptr_list_t *new = matrixalloc_1d(1, sizeof (ptr_list_t));
                    this->next = new;
                    new->ptr = s1;
                    new->next = NULL;
                    (*cn)++;
                    s1 = s1_end;
                }
            } else if (tmp == s1) { /* If tmp = s1, then s2 starts from the very beginning. No new segment is added. */
                s1 = tmp + s2_len;
            } else {
                if ((*cn) == 0) {
                    head = matrixalloc_1d(1, sizeof (ptr_list_t));
                    head->ptr = s1;
                    head->next = NULL;
                    this = head;
                } else {
                    ptr_list_t *new = matrixalloc_1d(1, sizeof (ptr_list_t));
                    this->next = new;
                    new->ptr = s1;
                    new->next = NULL;
                    this = new;
                }
                *tmp = '\0';
                (*cn)++;
                s1 = tmp + s2_len;
            }
        } while (s1 < s1_end);
        if ((*cn) == 0) {
            return NULL;
        } else {
            char **re = matrixalloc_1d((*cn), sizeof (char *));
            for (int i = 0; i < (*cn); i++) {
                re[i] = head->ptr;
                this = head->next;
                matrixalloc_1d_free(head);
                head = this;
            }
            return re;
        }
    }
}

/*
 * @since 2015.02.06, 2.17, 11.12
 */
int string_util_parse_int(const char *nptr, char **endptr, int base, string_util_parse_state_t *state) {
    if (! ((base == 0) || (base >= 2 && base <= 36))) {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
//7.5.3 The value of errno is zero at program startup, but is never set to zero by any library function.
    errno = 0;
    long tmp = strtol(nptr, endptr, base);
    if (endptr != NULL && nptr == endptr[0]) {
        (*state) = string_util_parse_state_bad_format;
        return 0;
    } else if (errno == ERANGE || tmp >= INT_MAX || tmp <= INT_MIN) {
        (*state) = string_util_parse_state_erange;
        return 0;
    } else {
        (*state) = string_util_parse_state_success;
        return (int) tmp;
    }
}

/*
 * @since 2015.6.11, 2017.9.12
 */
unsigned long int string_util_parse_ulong(const char *nptr, char **endptr, int base, string_util_parse_state_t *state) {
    if (! ((base == 0) || (base >= 2 && base <= 36))) {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
    errno = 0;
    unsigned long tmp = strtoul(nptr, endptr, base);
    if (endptr != NULL && nptr == endptr[0]) {
        (*state) = string_util_parse_state_bad_format;
        return 0;
    } else if (errno == ERANGE) {
        (*state) = string_util_parse_state_erange;
        return 0;
    } else {
        (*state) = string_util_parse_state_success;
        return tmp;
    }
}

/*
 * @since 2017.8.10, 9.12
 */
intmax_t string_util_parse_intmax(const char *nptr, char **endptr, int base, string_util_parse_state_t *state) {
    if (! ((base == 0) || (base >= 2 && base <= 36))) {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
    errno = 0;
    intmax_t tmp = strtoimax(nptr, endptr, base);
    if (endptr != NULL && nptr == endptr[0]) {
        (*state) = string_util_parse_state_bad_format;
        return 0;
    } else if (errno == ERANGE) {
        (*state) = string_util_parse_state_erange;
        return 0;
    } else {
        (*state) = string_util_parse_state_success;
        return tmp;
    }
}

/*
 * @since 2015.2.6, 2.17
 */
double string_util_parse_double(const char *nptr, char **endptr, string_util_parse_state_t *state) {
    errno = 0;
    double tmp = strtod(nptr, endptr);
    if (endptr != NULL && nptr == endptr[0]) {
        (*state) = string_util_parse_state_bad_format;
        return 0;
    } else if (errno == ERANGE) {
        (*state) = string_util_parse_state_erange;
        return 0;
    } else {
        (*state) = string_util_parse_state_success;
        return tmp;
    }
}

/*
 * @since 2016.10.26, 10.29
 */
bool string_util_parse_bool(const char *nptr, string_util_parse_state_t *state) {
    if (string_util_equal(nptr, "true")) {
        state[0] = string_util_parse_state_success;
        return true;
    } else if (string_util_equal(nptr, "false")) {
        state[0] = string_util_parse_state_success;
        return false;
    } else {
        state[0] = string_util_parse_state_bad_format;
        return false;
    }
}

/*
 * @since 2015.2.6, 2.17, 11.16
 */
bool string_util_starts_with(const char *s1, const char *s2) {
    size_t len_s2 = strlen(s2);
    if (len_s2 == 0) {
        return true;
    } else if (strlen(s1) < len_s2) {
        return false;
    } else {
        int re = memcmp(s1, s2, len_s2);
        if (re == 0)
            return true;
        else
            return false;
    }
}

/*
 * @since 2015.2.6, 2.17
 */
bool string_util_ends_with(const char *s1, const char *s2) {
    size_t len_s2 = strlen(s2);
    if (len_s2 == 0) {
        return true;
    } else {
        size_t len_s1 = strlen(s1);
        if (len_s1 < len_s2) {
            return false;
        } else {
            int re = memcmp(s1 + len_s1 - len_s2, s2, len_s2);
            if (re == 0)
                return true;
            else
                return false;
        }
    }
}