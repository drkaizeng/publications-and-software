/*
 * Created on 03 October 2018, 18:37
 */

#ifndef ORDERED_LIST_H
#define ORDERED_LIST_H

#include <stdbool.h>

typedef struct ordered_list_i * ordered_list_i_t;

ordered_list_i_t ordered_list_i_new(int init_cap);

void ordered_list_i_free(ordered_list_i_t *lst);

/**
 * Add d to the list. If d is already in lst, false is returned. Otherwise true is returned.
 */
bool ordered_list_i_add(int d, ordered_list_i_t lst);

/**
 * Remove d from lst. If d is in lst, its index is returned (0-base). 
 * Otherwise -(insertion point - 1) is returned and lst is not affected.
 */
int ordered_list_i_rm(int d, ordered_list_i_t lst);

/**
 * Returns the id (0-based) of d in lst. If d is not in lst, -(insertion point - 1) is returned.
 */
int ordered_list_i_id(int d, ordered_list_i_t lst);

/**
 * On return
 * <ul>
 * <li> If true is returned, then d[0] stores the value of the id-th element
 * <li> If false is returned, id &lt; 0 or id &ge; lst.size and d[0] is undefined. 
 * </ul>
 */
bool ordered_list_i_get(int *d, int id, ordered_list_i_t lst);

int ordered_list_i_size(ordered_list_i_t lst);

/**
 * <ul>
 * <li> arr is an int array of size given by ordered_list_i_size(). 
 * <li> The user must allocate the memory.
 * <li> if size = 0, arr is ignored and the function does nothing.
 * </ul>
 */
void ordered_list_i_arr(int *arr, ordered_list_i_t lst);

/**
 * Set the size of the list to 0.
 */
void ordered_list_i_clear(ordered_list_i_t lst);





typedef struct ordered_list_d * ordered_list_d_t;
ordered_list_d_t ordered_list_d_new(int init_size);
void ordered_list_d_free(ordered_list_d_t *lst);
bool ordered_list_d_add(double d, ordered_list_d_t lst);
int ordered_list_d_rm(double d, ordered_list_d_t lst);
int ordered_list_d_id(double d, ordered_list_d_t lst);
bool ordered_list_d_get(double *d, int id, ordered_list_d_t lst);
int ordered_list_d_size(ordered_list_d_t lst);
void ordered_list_d_arr(double *arr, ordered_list_d_t lst);
void ordered_list_d_clear(ordered_list_d_t lst);

#endif /* ORDERED_LIST_H */

