/* 
 * File:   string_util.h
 * Author: Kai
 *
 * Created on 03 February 2015, 13:20
 */

#ifndef STRING_UTIL_H
#define	STRING_UTIL_H

#include <stdbool.h>
#include <stdint.h>
#include <stdarg.h>

/**
 * This function returns a string, which should be freed by matrixalloc_1d_free or M1D_FREE
 */
char * string_util_make(const char *format, ...);

/**
 * @return true only if s1 and s2 have exactly the same same of characters in their entire range.
 */
bool string_util_equal(const char *s1, const char *s2);

/**
 * @return A clone of the string pointed to by s. The returned string should be freed
 * by either free or matrixalloc_1d_free.
 */
char * string_util_clone(const char *s);

/**
 * Remove leading and trailing space characters, as defined by isspace, pointed to by s.
 * This is achieved by returning a pointer pointing to the first non-space character in s, and by
 * replacing all trailing space characters is by the NULL character.
 * <p>
 * <b>Important:</b> The input pointer should be retained, so that the memory can be released later.
 * @return An empty string (i.e., nothing precedes the NULL character) is returned if s points to a string consisted of space characters only.
 */
char * string_util_trim(char *s);

/**
 * <b>Important:</b> Because s1 will be affected by this function and also any operations made via the returned char ** array,
 * it is important that a pointer to the beginning of s1 is retained before calling this function, so that memory can be
 * released accurately.
 * <p>
 * Split the null-terminated string pointed to by s1 by the null-terminated string pointed to by s2. 
 * This is achieved by searching for the presence of s2 (excluding the terminating null character) in s1 using 
 * strstr. 
 * <p>
 * On return, for each occurrence of s2 in s1, the first character of that s2 instance in s1 is replaced by a NULL character.
 * <ul>
 * <li> Neither s1 or s2 should be an empty string.
 * <li> *cn gives the number of segments that result from the split.
 * <li> The returned char ** array of length *cn contains pointed to the beginning of each substring. The characters
 *      in s1 are not copied. Instead, the each element of the array simply points to relevant positions in s1.
 *      Therefore, any changes made via the returned array will affect s1. However, 
 * <li> If s2 is not in s1, *cn is 1, and a pointer to the input is returned.
 * <li> The returned array should be freed by free or matrixalloc_1d_free.
 * <li> If s2 starts from the beginning, then the first segment starts from the first character in s1 after s2.
 * <li> If s1 ends with s2, then the last segment ends with the first character before the last occurrence of s2 in s1.
 * <li> If s1 = s2, then NULL is return and cn = 0.
 * <li> If s2 points to "\\s+", then s1 will be split by one or more space characters, as defined by isspace(). That is, 
 *      each continuous stretch of space characters is treated as one separator. 
 * </ul>
 */
char ** string_util_split(char *s1, const char *s2, int *cn);

typedef enum {
    string_util_parse_state_init,
    string_util_parse_state_success,
    /** The number is not representable by the data type given */
    string_util_parse_state_erange,
    /** If the subject sequence is empty or does not have the expected form, no conversion is performed */        
    string_util_parse_state_bad_format        
} string_util_parse_state_t;

/**
 * <ul>
 * <li> If the value of base is zero, the expected form of the subject sequence is that of an
 *        integer constant as described in 6.4.4.1, optionally preceded by a plus or minus sign, but
 *        not including an integer suffix. If the value of base is between 2 and 36 (inclusive), the
 *        expected form of the subject sequence is a sequence of letters and digits representing an
 *        integer with the radix specified by base, optionally preceded by a plus or minus sign,
 *        but not including an integer suffix. The letters from a (or A) through z (or Z) are
 *        ascribed the values 10 through 35; only letters and digits whose ascribed values are less
 *        than that of base are permitted. If the value of base is 16, the characters 0x or 0X may
 *        optionally precede the sequence of letters and digits, following the sign if present.
 * <li> If the subject sequence is empty or does not have the expected form, no conversion is
 *        performed; the value of nptr is stored in the object pointed to by endptr, provided
 *        that endptr is not a null pointer.
 * <li> In cases where s2 = "aa", s1 = "bbaaaacc", arr[0] = "bb", arr[1] = "cc"
 * <li> If no conversion could be performed, zero is returned.
 * </ul>
 * @param nptr
 * @param endptr On return, endptr[0] should point to the first character after the double value.
 *               If this information is unwanted, then supply NULL in the invocation. But it is
 *               best to supply such a pointer, because the function requires it being non-NULL to
 *               return string_util_parse_state_bad_format.
 * @param state
 * @return Zero is returned whenever state &ne; string_util_parse_success.
 */
int string_util_parse_int(const char *nptr, char **endptr, int base, string_util_parse_state_t *state);
/**
 * See string_util_parse_int
 * <p>
 * If the subject sequence begins with a minus sign, the value resulting from the conversion 
 * is negated (in the return type).
 * <p>
 * If the new type is unsigned, the value is converted by repeatedly adding or 
 * subtracting one more than the maximum value that can be represented in the new 
 * type until the value is in the range of the new type.
 * <p>
 * Therefore, if the string represents a negative number x, strtoul returns UINT_MAX + 1 + x.
 */
unsigned long int string_util_parse_ulong(const char *nptr, char **endptr, int base, string_util_parse_state_t *state);

/**
 * This is similar to string_util_parse_int. Although endptr can be NULL, but it is best to provide a non-NULL value,
 * so that bad format can be detected and reported.
 */
intmax_t string_util_parse_intmax(const char *nptr, char **endptr, int base, string_util_parse_state_t *state);

/**
 * <ul>
 * <li> A nonempty sequence of decimal digits optionally containing a decimal-point 
 *      character, then an optional exponent part as defined in 6.4.4.2
 * <li> A 0x or 0X, then a nonempty sequence of hexadecimal digits optionally containing a
 *        decimal-point character, then an optional binary exponent part as defined in 6.4.4.2
 * <li> INF or INFINITY, ignoring case
 * <li> NAN, ignoring case
 * <li> If the subject sequence is empty or does not have the expected form, no conversion is
 *        performed; the value of nptr is stored in the object pointed to by endptr, provided
 *        that endptr is not a null pointer.
 * </ul>
 * @param nptr
 * @param endptr On return, endptr[0] should point to the first character after the double value.
 *               If this information is unwanted, then supply NULL in the invocation. But it is
 *               best to supply such a pointer, because the function requires it being non-NULL to
 *               return string_util_parse_state_bad_format.
 * @param state
 * @return Zero is returned whenevern state &ne; string_util_parse_success.
 */
double string_util_parse_double(const char *nptr, char **endptr, string_util_parse_state_t *state);

/**
 * @return true if the string nptr points to is exactly "true", and false if it is "false".
 * In either cases, state is set to success. In all other cases, state is set to bad_format
 * and false is returned.
 */
bool string_util_parse_bool(const char *nptr, string_util_parse_state_t *state);

/**
 * @return <code>true</code> if the string pointed to by s2 is a 
 * prefix of the string pointed to by s1 this string; <code>false</code> otherwise. 
 * Note also that <code>true</code> will be returned if s2 is an empty string 
 * or is equal to s1 as determined by the memcmp method.
 */
bool string_util_starts_with(const char *s1, const char *s2);

/**
 * @return <code>true</code> if the string pointed to by s2 is a 
 * suffix of the string pointed to by s1; <code>false</code> otherwise. 
 * Note that the result will be true if s2 is an empty string 
 * or is equal to s1 as determined by the memcmp method.
 */
bool string_util_ends_with(const char *s1, const char *s2);

#endif	/* STRING_UTIL_H */

