/* 
 * File:   arrayutil_quick_sort_template_off.h
 * Author: Kai
 *
 * Created on 06 February 2015, 18:29
 */


#undef DATA_TYPE
#undef ABBR

#undef CONCAT2x
#undef CONCAT2

#undef PARTITION
#undef QUICK_SORT_WORK
#undef QUICK_SORT
