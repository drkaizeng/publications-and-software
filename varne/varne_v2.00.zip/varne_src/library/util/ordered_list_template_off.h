/*
 * Created on 04 October 2018, 10:52
 */

#undef DATA_TYPE
#undef ABBR

#undef CONCAT2x
#undef CONCAT2

#undef CONCAT3x
#undef CONCAT3

#undef STRUCT_NAME
#undef NEW
#undef FREE
#undef ADD
#undef BSEARCH
#undef ENSURE_CAPACITY
#undef RM 
#undef ID   
#undef GET
#undef SIZE
#undef ARR        
#undef CLEAR        
        
