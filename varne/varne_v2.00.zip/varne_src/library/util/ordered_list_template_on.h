/*
 * Created on 04 October 2018, 10:52
 */
#ifdef INT
#define DATA_TYPE int
#define ABBR i
#endif


#ifdef DOUBLE
#define DATA_TYPE double
#define ABBR d
#endif


#define CONCAT2x(a, b) a ## _ ## b
#define CONCAT2(a, b) CONCAT2x(a, b)

#define CONCAT3x(a, b, c) a ## _ ## b ## _ ## c
#define CONCAT3(a, b, c) CONCAT3x(a, b, c)


#define STRUCT_NAME CONCAT2(ordered_list, ABBR)
#define NEW CONCAT3(ordered_list, ABBR, new)
#define FREE CONCAT3(ordered_list, ABBR, free)
#define ADD CONCAT3(ordered_list, ABBR, add)
#define BSEARCH CONCAT2(arrayutil_binary_search, ABBR)
#define ENSURE_CAPACITY CONCAT2(ensure_capacity, ABBR)
#define RM CONCAT3(ordered_list, ABBR, rm) 
#define ID CONCAT3(ordered_list, ABBR, id) 
#define GET CONCAT3(ordered_list, ABBR, get) 
#define SIZE CONCAT3(ordered_list, ABBR, size) 
#define ARR CONCAT3(ordered_list, ABBR, arr) 
#define CLEAR CONCAT3(ordered_list, ABBR, clear) 


