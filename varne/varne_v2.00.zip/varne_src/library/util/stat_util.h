/* 
 * File:   stat_util.h
 * Author: Kai
 *
 * Created on 06 February 2015, 15:33
 */

#ifndef STAT_UTIL_H
#define	STAT_UTIL_H

double stat_util_mean_d_d(const double *a, int n);

double stat_util_var_d_d(const double *a, int n, double mean);

#endif	/* STAT_UTIL_H */

