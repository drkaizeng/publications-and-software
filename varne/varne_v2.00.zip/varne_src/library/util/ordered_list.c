/*
 * Created on 04 October 2018, 09:48
 */
#include <string.h>

#include "error_msg.h"
#include "matrixalloc.h"
#include "arrayutil.h"

struct STRUCT_NAME {
    DATA_TYPE *arr;
    int size;
    int capacity;
};

/*
 * @since 2018.10.7
 */
struct STRUCT_NAME * NEW(int init_cap) {
    if (init_cap <= 0)
        ERROR_MSG_LMA("init_cap <= 0\n");
    
    struct STRUCT_NAME *re;
    M1D_NEW(re, 1);
    M1D_NEW(re->arr, init_cap);
    re->size = 0;
    re->capacity = init_cap;
    
    return re;
}

/*
 * @since 2018.10.7
 */
void FREE(struct STRUCT_NAME **in) {
    struct STRUCT_NAME *lst = in[0];
    in[0] = NULL;
    M1D_FREE(lst->arr);
    M1D_FREE(lst);
}

/*
 * @since 2018.10.7
 */
static void ENSURE_CAPACITY(int min_cap, struct STRUCT_NAME *lst) {
    int old = lst->capacity;
    if (min_cap > old) {
        int new = (old * 3) / 2 + 1;
        if (new < min_cap)
            new = min_cap;
        M1D_REALLOC(lst->arr, new);
        lst->capacity = new;
    }
}

/*
 * @since 2018.10.7
 */
bool ADD(DATA_TYPE d, struct STRUCT_NAME *lst) {
    bool re;
    int id = BSEARCH(lst->arr, 0, lst->size, d);
    if (id >= 0) {
        re = false;
    } else {
        ENSURE_CAPACITY(lst->size + 1, lst);
        re = true;
        id = -id - 1;
        size_t n = (size_t) (lst->size - id);
        memmove(lst->arr + id + 1, lst->arr + id, n * sizeof(DATA_TYPE));
        lst->arr[id] = d;
        lst->size++;
    }
    return re;
}

/*
 * @since
 */
int RM(DATA_TYPE d, struct STRUCT_NAME *lst) {
    int id = BSEARCH(lst->arr, 0, lst->size, d);
    if (id >= 0) {
        size_t n = (size_t) (lst->size - (id + 1));
        memmove(lst->arr + id, lst->arr + id + 1, n * sizeof(DATA_TYPE));
        lst->size--;
    }
    return id;
}

/*
 * @since 2018.10.7
 */
int ID(DATA_TYPE d, struct STRUCT_NAME *lst) {
    return BSEARCH(lst->arr, 0, lst->size, d);
}

/*
 * @since 2018.10.7
 */
bool GET(DATA_TYPE *d, int id, struct STRUCT_NAME *lst) {
    if (id < 0 || id >= lst->size)
        return false;
    else {
        d[0] = lst->arr[id];
        return true;
    }
}

/*
 * @since
 */
int SIZE(struct STRUCT_NAME *lst) {
    return lst->size;
}

/*
 * @since 2018.10.7
 */
void ARR(DATA_TYPE *arr, struct STRUCT_NAME *lst) {
    if (lst->size > 0) {
        memcpy(arr, lst->arr, (size_t) lst->size * sizeof(DATA_TYPE));
    }
}

/*
 * @since
 */
void CLEAR(struct STRUCT_NAME *lst) {
    lst->size = 0;
}