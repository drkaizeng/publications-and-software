/* 
 * File:   matrixalloc.h
 * Author: Kai
 *
 * Created on 28 February 2013, 17:11
 */

#ifndef MATRIXALLOC_H
#define	MATRIXALLOC_H

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "error_msg.h"

/**
 * Use to construct arrays of given length.
 * @param n The number of elements
 * @param styp The size of each element
 */
void * matrixalloc_1d(const int n, const size_t styp);

/**
 * Use to construct arrays of given length with all elements initialised to zero.
 * @param n
 * @param styp
 */
void * matrixalloc_1d_init(const int n, const size_t styp);

/**
 * Make a clone of the src array
 * @param src The source array, which was created by matrixalloc_1d or matrixalloc_1d_init.
 * @param n The number of elements
 * @param styp The size of each element
 */
void * matrixalloc_1d_clone(const void *src, const int n, const size_t styp);

/**
 * @param a Pointer to an array built by matrixalloc_1d, matrixalloc_1d_init, or matrixalloc_1d_clone.
 * @param n New size of the array
 * @param styp
 */
void * matrixalloc_1d_realloc(void *a, int n, size_t styp);
/**
 * Copy the contents of src to des. 
 * @param des The target array, which was created by matrixalloc_1d or matrixalloc_1d_init.
 * @param src The source array, which was created by matrixalloc_1d or matrixalloc_1d_init.
 * @param n The number of elements
 * @param styp The size of each element
 */
void   matrixalloc_1d_cpy1(void *des, const void *src, const int n, const size_t styp);
void   matrixalloc_1d_cpy2(void *des, const void *src, const size_t total_size);
void   matrixalloc_1d_free(void *);

/**
 * ptr has to be declared before calling this macro.
 */
#define M1D_NEW(ptr, n) \
        do { \
            (ptr) = matrixalloc_1d((n), sizeof(*(ptr))); \
        } while(0)

/**
 * ptr has to be declared before calling this macro.
 */
#define M1D_INIT(ptr, n) \
        do { \
            (ptr) = matrixalloc_1d_init((n), sizeof(*(ptr))); \
        } while(0)

/**
 * ptr has to be declared and memory dynamically allocated.
 */
#define M1D_REALLOC(ptr, n) \
        do { \
            (ptr) = matrixalloc_1d_realloc((ptr), n, sizeof(*(ptr))); \
        } while(0)

/**
 * result has to be declared before calling this macro. 
 * <p>
 * src should be created to either M1D_NEW or M1D_INIT
 */
#define M1D_CLONE(result, src, n) \
        do { \
            (result) = matrixalloc_1d_clone((src), (n), sizeof(*(src))); \
        } while(0)

/**
 * Clone the string including the terminating null character.
 * <p>
 * Both <code>result</code> and <code>src</code> must be of type <code>char *</code>
 * <p>
 * <code>result</code> has to be declared before calling this macro. 
 * <p>
 * This does not perform any checks and uses matrixalloc_1d_clone
 */
#define M1D_CLONE_STR2(result, src) \
        do { \
            (result) = matrixalloc_1d_clone((src), (int) strlen(src) + 1, sizeof(char)); \
        } while(0)

/**
 * Free the memory and set ptr to NULL.
 */
#define M1D_FREE(ptr) \
        do { \
            matrixalloc_1d_free(ptr); \
            (ptr) = NULL; \
        } while(0)

/**
 * <ul>
 * <li> re must be defined beforehand in the form "double **re".
 * <li> Invalid to use the following with this macro: void **re
 * </ul>
 * @since 2018.5.15
 */
#define M2D_NEW(re, nr, nc) \
        do { \
            if ((nr) <= 0 || (nc) <= 0) { \
                ERROR_MSG_LMA("Invalid nr or nc in M2D_NEW().\n"); \
            } \
            if ((uintmax_t) (nr) >= (uintmax_t) SIZE_MAX || (uintmax_t) (nc) >= (uintmax_t) SIZE_MAX) { \
                ERROR_MSG_LMA("Invalid nr or nc in M2D_NEW().\n"); \
            } \
            size_t ___NR_ = (size_t) (nr); \
            size_t ___NC_ = (size_t) (nc); \
            size_t ___SIZE_ = sizeof(*(re)); \
            size_t ___MAX_ = SIZE_MAX / ___SIZE_; \
            if (___NR_ >= ___MAX_) { \
                ERROR_MSG_LMA("Insufficient memory in M2D_NEW().\n"); \
            } \
            (re) = malloc( ___NR_ * ___SIZE_ ); \
            if ((re) == NULL) { \
                ERROR_MSG_LMA("M2D_NEW() failed to allocate memory.\n"); \
            } \
            ___SIZE_ = sizeof(**(re)); \
            ___MAX_ = SIZE_MAX / ___SIZE_ / ___NC_; \
            if (___NR_ >= ___MAX_) { \
                ERROR_MSG_LMA("Insufficient memory in M2D_NEW().\n"); \
            } \
            (re)[0] = malloc(___NR_ * ___NC_ * ___SIZE_); \
            if ((re)[0] == NULL) { \
                ERROR_MSG_LMA("M2D_NEW() failed to allocate memory.\n"); \
            } \
            for (size_t ___I_ = 1; ___I_ < ___NR_; ___I_++) { \
                (re)[___I_] = (re)[___I_ - 1] + ___NC_; \
            } \
        } while(0)

/**
 * <ul>
 * <li> re must be initialised using M2D_NEW or matrixalloc_2d_? or matrixalloc_2d_?_init
 * <li> Invalid to use the following with this macro: void **re
 * </ul>
 */
#define M2D_FILL(re, nr, nc, v) \
        do { \
            size_t ___LEN_ = (size_t) (nr) * (size_t) (nc); \
            for (size_t ___I_ = 0; ___I_ < ___LEN_; ___I_++) { \
                (re)[___I_] = (v); \
            } \
        } while(0)
            


/**
 * <ul>
 * <li> re must be declared first.
 * <li> src must be initialised by M2D_NEW or matrixalloc_2d_? or matrixalloc_2d_?_init
 * <li> The parameters src, nr and nc are not checked
 * </ul> 
 * @since 2018.5.15
 */
#define M2D_CLONE(re, src, nr, nc) \
        do { \
            size_t ___NR_ = (size_t) (nr); \
            size_t ___NC_ = (size_t) (nc); \
            size_t ___SIZE_ = sizeof(*(re)); \
            if ( ___SIZE_ != sizeof(*(src)) ) { \
                ERROR_MSG_LMA("Incompatible data types in M2D_CLONE.\n"); \
            } \
            (re) = malloc(___NR_ * ___SIZE_); \
            if ((re) == NULL) { \
                ERROR_MSG_LMA("M2D_CLONE() failed to allocate memory.\n"); \
            } \
            ___SIZE_ = sizeof(**(re)); \
            if ( ___SIZE_ != sizeof(**(src)) ) { \
                ERROR_MSG_LMA("Incompatible data types in M2D_CLONE.\n"); \
            } \
            ___SIZE_ = ___NR_ * ___NC_ * ___SIZE_; \
            (re)[0] = malloc(___SIZE_); \
            if ((re)[0] == NULL) { \
                ERROR_MSG_LMA("M2D_CLONE() failed to allocate memory.\n"); \
            } \
            memcpy((re)[0], (src)[0], ___SIZE_); \
            for (size_t ___I_ = 1; ___I_ < ___NR_; ___I_++) { \
                (re)[___I_] = (re)[___I_ - 1] + ___NC_; \
            } \
        } while(0)

       

/**
 * <ul>
 * <li> re must be initialised by M2D_NEW or matrixalloc_2d_? or matrixalloc_2d_?_init
 * <li> re is set to NULL
 * </ul>
 * @since 2018.5.15, 10.3 (added test for whether re is NULL)
 */
#define M2D_FREE(re) \
        do { \
            if ((re) != NULL) { \
                free((re)[0]); \
                free((re)); \
                (re) = NULL; \
            } \
        } while(0)

            

/**
 * Use malloc to construct a 2D matrix for double-precision numbers.
 * @param nrow number of rows
 * @param ncol number of columns
 */
double ** matrixalloc_2d_d(const int nrow, const int ncol);
double ** matrixalloc_2d_d_init(const int nrow, const int ncol);
/**
 * @param src This must be created by matrixalloc_2d_d or matrixalloc_2d_d_init; otherwise the result is undefined.
 */
double ** matrixalloc_2d_d_clone(double **src, const int nrow, const int ncol);
void      matrixalloc_2d_d_cpy(double **des, double **src, const int nrow, const int ncol);
void      matrixalloc_2d_d_free(double **);

long double ** matrixalloc_2d_ld(const int nrow, const int ncol);
long double ** matrixalloc_2d_ld_init(const int nrow, const int ncol);
long double ** matrixalloc_2d_ld_clone(long double **src, const int nrow, const int ncol);
void     matrixalloc_2d_ld_cpy(long double **des, long double **src, const int nrow, const int ncol);
void     matrixalloc_2d_ld_free(long double **);

int ** matrixalloc_2d_i(const int nrow, const int ncol);
int ** matrixalloc_2d_i_init(const int nrow, const int ncol);
int ** matrixalloc_2d_i_clone(int **src, const int nrow, const int ncol);
void   matrixalloc_2d_i_cpy(int **des, int **src, const int nrow, const int ncol);
void   matrixalloc_2d_i_free(int **);

bool ** matrixalloc_2d_b(const int nrow, const int ncol);
bool ** matrixalloc_2d_b_init(const int nrow, const int ncol);
bool ** matrixalloc_2d_b_clone(bool **src, const int nrow, const int ncol);
void    matrixalloc_2d_b_cpy(bool **des, bool **src, const int nrow, const int ncol);
void    matrixalloc_2d_b_free(bool **);

char ** matrixalloc_2d_c(const int nrow, const int ncol);
char ** matrixalloc_2d_c_init(const int nrow, const int ncol);
char ** matrixalloc_2d_c_clone(char **src, const int nrow, const int ncol);
void    matrixalloc_2d_c_cpy(char **des, char **src, const int nrow, const int ncol);
void    matrixalloc_2d_c_free(char **);

#endif	/* MATRIXALLOC_H */

