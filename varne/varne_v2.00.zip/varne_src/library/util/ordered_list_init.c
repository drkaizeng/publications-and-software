/*
 * Created on 04 October 2018, 10:52
 */
#include "ordered_list.h"

#define INT
#include "ordered_list_template_on.h"
#include "ordered_list.c"
#include "ordered_list_template_off.h"
#undef INT

#define DOUBLE
#include "ordered_list_template_on.h"
#include "ordered_list.c"
#include "ordered_list_template_off.h"
#undef DOUBLE