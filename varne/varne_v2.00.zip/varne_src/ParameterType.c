/*
 * Created on 26 May 2018, 07:50
 */

#include "ParameterType.h"
#include "GetName.h"

#include "util/error_msg.h"

/*
 * @since 2018.5.27
 */
char * ParameterType_toString(enum ParameterType type) {
    char *re;
    if (type == THETA) {
        re = getName2("theta");
    } else if (type == F) {
        re = getName2("f");
    } else if (type == G) {
        re = getName2("g");
    } else if (type == TAU) {
        re = getName2("tau");
    } else if (type == ERROR) {
        re = getName2("error");
    } else if (type == C) {
        re = getName2("c");
    } else if (type == T) {
        re = getName2("t");
    } else {
        ERROR_MSG_LMA("error");
    }
    return re;
}