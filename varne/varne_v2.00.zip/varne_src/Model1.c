/*
 * Created on 10 October 2018, 18:49
 */
#include "Model_def.h"
#include "Model1_def.h"

#include "PrintErrorMessage.h"
#include "VarneIO.h"
#include "GetName.h"

#include "util/matrixalloc.h"
#include "util/error_msg.h"
#include "util/arrayutil.h"
#include "util/string_util.h"

#include "gsl/gsl_rng.h"

#ifdef _OPENMP
#include "omp.h"
#endif

/*
 * @since 2018.10.15
 */
static void freeParam(void **param) {
    struct Model1 *m = param[0];
    param[0] = NULL;
    
    M1D_FREE(m->givenInitValues);
    
    for (int i = 0; i < m->numThreads; i++) {
        LocusExecutor_free(m->exec + i);
    }
    M1D_FREE(m->exec);
    
    for (int i = 0; i < m->numNloptConstraints; i++) {
        m->freeNloptConstraintData[i](m->nloptConstraintsData + i);
    }
    M1D_FREE(m->freeNloptConstraintData);
    M1D_FREE(m->nloptConstraintsData);
    M1D_FREE(m->nloptConstraints);
    M1D_FREE(m->isEqualityConstraint);
    
    M2D_FREE(m->paramRanges);
    for (int i = 0; i < m->numParam; i++) {
        M1D_FREE(m->paramNames[i]);
    }
    M1D_FREE(m->paramNames);
    M1D_FREE(m->paramTypes);
    
    for (int i = 0; i < m->nx; i++) {
        if (m->constraints[i] != NULL) {
            Constraint_free(m->constraints + i);
        }
    }
    M1D_FREE(m->constraints);
    M1D_FREE(m->offset);
    M1D_FREE(m->nxZeros);
    M1D_FREE(m->dx);
    M1D_FREE(m->derivative);
    M1D_FREE(m->xi);
    M1D_FREE(m->x);
    
    for (int i = 0; i < m->numLoci; i++) {
        Locus_free(m->loci + i);
    }
    M1D_FREE(m->loci);
    
    M1D_FREE(m->initMethodName);
    M1D_FREE(m->constraintName);
    Model1InputParamRanges_free(&(m->inputRanges));
    
    M1D_FREE(m);
}

/*
 * @since 2018.10.15
 */
static int getNumParam(void *param) {
    struct Model1 *m = (struct Model1 *) param;
    return m->numParam;
}

/*
 * @since 2018.10.15
 */
static char ** getParamNames(void *param) {
    struct Model1 *m = (struct Model1 *) param;
    char **re = NULL;
    if (m->numParam > 0) {
        M1D_NEW(re, m->numParam);
        for (int i = 0; i < m->numParam; i++) {
            int n = (int) strlen(m->paramNames[i]) + 1;
            M1D_CLONE(re[i], m->paramNames[i], n);
        }
    }
    return re;
}

/*
 * @since 2018.10.15
 */
static enum ParameterType * getParamTypes(void *param) {
    struct Model1 *m = (struct Model1 *) param;
    enum ParameterType *re = NULL;
    if (m->numParam > 0) {
        M1D_CLONE(re, m->paramTypes, m->numParam);
    }
    return re;
}

/*
 * @since 2018.10.15
 */
static void getInitialValues(double *x, void *param, va_list args) {
    struct Model1 *m = (struct Model1 *) param;
    if (m->initMethod == 0) {
        gsl_rng *rng = va_arg(args, gsl_rng *);
        double **ranges = m->paramRanges;
        for (int i = 0; i < m->numParam; i++) {
            double tmp = gsl_rng_uniform(rng);
            x[i] = tmp * (ranges[1][i] - ranges[0][i]) + ranges[0][i];
        }
    } else if (m->initMethod == 1) {
        memcpy(x, m->givenInitValues, (size_t) m->numParam * sizeof(*x));
    } else 
        ERROR_MSG_LMA("ERROR");
}

/*
 * @since 2018.10.15
 */
static double ** getParamRanges(void *param) {
    struct Model1 *m = (struct Model1 *) param;
    if (m->numParam > 0) {
        return matrixalloc_2d_d_clone(m->paramRanges, 2, m->numParam);
    } else
        return NULL;
}

/*
 * @since 2018.10.15
 */
static int getNumNloptConstraints(void *param) {
    struct Model1 *m = (struct Model1 *) param;
    return m->numNloptConstraints;
}

/*
 * @since
 */
static void getNloptConstraints(nlopt_func *constraints, bool *isEqualityConstraint, void **constraintData, void *param) {
    struct Model1 *m = (struct Model1 *) param;
    memcpy(constraints, m->nloptConstraints, (size_t) m->numNloptConstraints * sizeof(*constraints));
    memcpy(isEqualityConstraint, m->isEqualityConstraint, (size_t) m->numNloptConstraints * sizeof(*isEqualityConstraint));
    memcpy(constraintData, m->nloptConstraintsData, (size_t) m->numNloptConstraints * sizeof(*constraintData));
}

/*
 * @since 2018.10.15
 */
static void toAllParam(const double *freeParam, struct Model1 *m) {
    int nx = m->nx;
    double *x = m->x;
    int *xi = m->xi;
    for (int i = 0; i < nx; i++) {
        if (xi[i] >= 0)
            x[i] = Model1_unscaleParam(m->paramTypes[xi[i]], freeParam[xi[i]]);
    }
    for (int i = 0; i < nx; i++) {
        struct Constraint *c = m->constraints[i];
        if (c != NULL) {
            for (int j = 0; j < c->nx; j++) 
                c->x[j] = x[c->xi[j]];
                
            x[i] = c->f(c->x, c->param);
        }
    }
}

/*
 * @since 2018.10.15
 */
static double getLikelihood(double *grad, const double *freeParam, void *param) {
    struct Model1 *m = (struct Model1 *) param;
    toAllParam(freeParam, m);
    
    int numLoci = m->numLoci;
    Locus_t *loci = m->loci;
    LocusExecutor_t *exec = m->exec;
    int *offset = m->offset;
    double *x = m->x;
    
    double lnlike = 0;
    
    if (grad == NULL) {
#ifdef _OPENMP
#pragma omp parallel default(none) shared(numLoci, loci, exec, offset, x) reduction(+:lnlike)
#endif
        {
            int tid = 0;
#ifdef _OPENMP
            tid = omp_get_thread_num();
#pragma omp for schedule(runtime)
#endif
            for (int i = 0; i < numLoci; i++) {
                lnlike += LocusExecutor_getLikelihood(NULL, x + offset[i], NULL, loci[i], exec[tid]);
            }
        }
    } else {
        memcpy(grad, m->nxZeros, m->numParamZerosSize);
        bool *derivative = m->derivative;
        double *dx = m->dx;
        memcpy(dx, m->nxZeros, m->nxZerosSize);
#ifdef _OPENMP
#pragma omp parallel default(none) shared(numLoci, loci, exec, offset, x, grad, derivative, dx) reduction(+:lnlike)
#endif
        {
            int tid = 0;
            
#ifdef _OPENMP
            tid = omp_get_thread_num();
#pragma omp for schedule(runtime)
#endif
            for (int i = 0; i < numLoci; i++) {
                lnlike += LocusExecutor_getLikelihood(dx + offset[i], x + offset[i], derivative + offset[i], loci[i], exec[tid]);
            }
        }
        
        int *xi = m->xi;
        
        for (int i = 0; i < m->nx; i++) {
            if (m->xi[i] >= 0)
                grad[xi[i]] += dx[i];
            else if (m->xi[i] == -2) {
                struct Constraint *c = m->constraints[i];
                for (int j = 0; j < c->nx; j++) {
                    double tmp = c->df(c->x, j, c->param);
                    grad[xi[c->xi[j]]] += tmp * dx[i];
                }
            }
        }
        for (int i = 0; i < m->numParam; i++) {
            grad[i] *= Model1_getJacobian(m->paramTypes[i], freeParam[i]);
        }
    }
    return lnlike;
}

/*
 * @since 2018.10.15
 */
static void scaleParam(double *x2, double *x, void *param) {
    struct Model1 *m = (struct Model1 *) param;
    for (int i = 0; i < m->numParam; i++) {
        x2[i] = Model1_scaleParam(m->paramTypes[i], x[i]);
    }
}

/*
 * @since 2018.10.15
 */
static void unscaleParam(double *x2, double *x, void *param) {
    struct Model1 *m = (struct Model1 *) param;
    for (int i = 0; i < m->numParam; i++) {
        x2[i] = Model1_unscaleParam(m->paramTypes[i], x[i]);
    }
}

/*
 * @since 2018.10.15
 */
static void * get_fullLikelihood_noConstraint(void *param, va_list args) {
    struct Model1 *m = (struct Model1 *) param;
    double *freeParam = va_arg(args, double *);
    toAllParam(freeParam, m);
    
    int *numParam;
    M1D_NEW(numParam, 1);
    numParam[0] = m->nx;
    if (m->useProfile) {
        numParam[0] += m->numLoci;
    }
    
    char **paramNames;
    M1D_NEW(paramNames, numParam[0]);
    for (int i = 0, cnt = 0; i < m->numLoci; i++) {
        char **names = Locus_getParamNames(m->loci[i]);
        int n = Locus_getNumParam(m->loci[i]);
        if (m->useProfile) {
            char *locName = Locus_getName(m->loci[i]);
            char *typeName = ParameterType_toString(THETA);
            paramNames[cnt] = getName2("%s%s", locName, typeName);
            M1D_FREE(locName);
            M1D_FREE(typeName);
            memcpy(paramNames + cnt + 1, names, (size_t) n * sizeof (*paramNames));
            cnt += n + 1;
        } else {
            memcpy(paramNames + cnt, names, (size_t) n * sizeof (*paramNames));
            cnt += n;
        }
        M1D_FREE(names);
    }
    
    double *mle;
    M1D_NEW(mle, numParam[0]);
    double *lnlike;
    M1D_NEW(lnlike, 1);
    lnlike[0] = 0;
    if (m->useProfile) {
        for (int i = 0, cnt = 0; i < m->numLoci; i++) {
            char *msg;
            void *tmp = LocusExecutor_extraFunction("thetaMLE", m->loci[i], m->exec[0], &msg, m->x + m->offset[i]);
            if (msg != NULL) {
                ERROR_MSG_LMA("ERROR");
            }
            mle[cnt] = ((double *) tmp)[0];
            M1D_FREE(tmp);
            int n = Locus_getNumParam(m->loci[i]);
            memcpy(mle + cnt + 1, m->x + m->offset[i], (size_t) n * sizeof(*mle));
            tmp = LocusExecutor_extraFunction("fullLikelihood", m->loci[i], m->exec[0], &msg, m->x + m->offset[i]);
            if (msg != NULL) {
                ERROR_MSG_LMA("ERROR");
            }
            lnlike[0] += ((double *) tmp)[0];
            M1D_FREE(tmp);
            cnt += n + 1;
        }
    } else {
        memcpy(mle, m->x, (size_t) m->nx * sizeof(*mle));
        lnlike[0] = getLikelihood(NULL, freeParam, param);
    }
    
    void **re;
    M1D_NEW(re, 4);
    re[0] = numParam;
    re[1] = paramNames;
    re[2] = mle;
    re[3] = lnlike;
    return re;
}

/*
 * @since 2018.10.15 
 */
static void * extraFunction(const char *cmd, void *param, char **msg, va_list args) {
    msg[0] = NULL;

    if (string_util_equal(cmd, "fullLikelihood_noConstraint")) {
        return get_fullLikelihood_noConstraint(param, args);
    } else {
        ERROR_MSG_LMA("ERROR");
    }
}

/*
 * @since 2018.10.15
 */
Model_t Model1_new(file_reader_t *reader, int *lineID, char **msg) {
    msg[0] = NULL;
    
    struct Model1 *m;
    M1D_NEW(m, 1);
    
    Model1_readControlFile(m, reader, lineID, msg);
    if (msg[0] != NULL) {
        return NULL;
    }
    
    Model1_build(m, msg);
    if (msg[0] != NULL) {
        return NULL;
    }
    
    Model_t re;
    M1D_NEW(re, 1);
    re->type = MODEL1;
    re->param = m;
    re->freeParam = freeParam;
    re->getNumParam = getNumParam;
    re->getParamNames = getParamNames;
    re->getParamTypes = getParamTypes;
    re->getInitialValues = getInitialValues;
    re->getParamRanges = getParamRanges;
    re->getNumNloptConstraints = getNumNloptConstraints;
    re->getNloptConstraints = getNloptConstraints;
    re->getLikelihood = getLikelihood;
    re->scaleParam = scaleParam;
    re->unscaleParam = unscaleParam;
    re->extraFunction = extraFunction;
    
    return re;
}