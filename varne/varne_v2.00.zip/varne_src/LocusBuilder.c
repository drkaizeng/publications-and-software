/*
 * Created on 16 May 2018, 17:52
 */

#include "Locus_def.h"
#include "PrintErrorMessage.h"

#include "util/matrixalloc.h"

/* 
 * @since 2018.10.8 (LOCUS_I), 10.9 (LOCUS_I)
 */
LocusBuilder_t LocusBuilder_new(enum LocusType type, const char *name, char **msg, ...) {
    msg[0] = NULL;
    
    struct LocusBuilder *re;
    M1D_NEW(re, 1);
    
    re->mode = 0;
    
    va_list args;
    va_start(args, msg);
    
    if (type == LOCUS1) {
        Locus1Builder_new(re, name, msg, args);
    } else if (type == LOCUS2) {
        Locus2Builder_new(re, name, msg, args);
    } else {
        PRINT_ERRMSG(msg, "Unknown locus type.");
        return NULL;
    }
    
    va_end(args);
    
    return re;
}

/*
 * @since 2018.10.8, 10.9
 */
void LocusBuilder_addData(LocusBuilder_t lb, char **msg, ...) {
    if (lb->mode != 0) 
        ERROR_MSG_LMA("mode != 0\n");
    lb->mode = 1;
    
    va_list args;
    va_start(args, msg);
    
    lb->loc->addData(lb->loc->typeParam, msg, args);
    
    va_end(args);
}

/*
 * @since 2018.10.8, 10.9
 */
Locus_t LocusBuilder_build(LocusBuilder_t *builder) {
    LocusBuilder_t lb = builder[0];
    builder[0] = NULL;
    
    if (lb->mode < 1)//at least data have been added; constraints are optional
        ERROR_MSG_LMA("mode < 1\n");

    Locus_t re = lb->loc;
    M1D_FREE(lb);
    return re;
}