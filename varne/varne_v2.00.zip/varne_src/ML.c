#include <string.h>
#include <stdarg.h>
#include <math.h>

#include "ML_def.h"

#include "util/matrixalloc.h"
#include "util/error_msg.h"
#include "util/arrayutil.h"

/*
 * @since 2017.2.23, 8.1
 */
void ML_free(ML_t *ml) {
    matrixalloc_1d_free(ml[0]->re);
    matrixalloc_1d_free(ml[0]->exitCodes);
    matrixalloc_1d_free(ml[0]->improveID);
    matrixalloc_1d_free(ml[0]->runID);
    matrixalloc_2d_d_free(ml[0]->MLEs);
    matrixalloc_1d_free(ml[0]->likelihoods);
    matrixalloc_1d_free(ml[0]->x);
    nlopt_destroy(ml[0]->nlopt);
    Model_free(&(ml[0]->m));
    matrixalloc_1d_free(ml[0]);
    ml[0] = NULL;
}

/*
 * @since 2017.4.16
 */
static void write(FILE *f, const char *name, const char *format, ...) {
    va_list args;
    va_start(args, format);
    int write_log = vfprintf(f, format, args);
    if (write_log < 0)
        ERROR_MSG_ME("Failed to write to %s\n", name);
    va_end(args);
}

/**
 * @param mle The MLEs of the parameters on return
 * @param lnl The ln-likelihood at the MLE
 * @param imp_id The ID of the improvement round when the search stops
 * @param init Initial values for the search
 * @param run_id
 * 
 * @since 2017.2.23, 4.16, 8.1
 */
static void runNlopt(double *mle, double *lnl, int *imp_id, nlopt_result *exit_code, 
        double *init, int run_id, ML_t ml, FILE *log_file) {
    int nnoimp = 1;
    double fold, fnow;
    size_t mem = ml->numParamSize; 
    for (int i = 1; i <= ml->maxNumImprove; i++) {
        nlopt_result code = nlopt_optimize(ml->nlopt, init, &fnow);
        if (log_file != NULL) {
            write(log_file, "log file", "%i\t%i\t%i", run_id, i, code);
            for (int j = 0; j < ml->numParam; j++)
                write(log_file, "log file", "\t%.15g", init[j]);
            write(log_file, "log file", "\t%.15g\n", fnow);
            fflush(log_file);
        }
        if (i == 1) {
            lnl[0] = fnow;
            memcpy(mle, init, mem);
            imp_id[0] = i;
            exit_code[0] = code;
        } else {
            double tmp = fabs(fnow - fold);
            if (tmp <= ml->improveRelTolerance * 0.5 * (fabs(fnow) + fabs(fold)))
                nnoimp++;
            else
                nnoimp = 1;
            if (lnl[0] < fnow) {
                lnl[0] = fnow;
                memcpy(mle, init, mem);
                imp_id[0] = i;
                exit_code[0] = code;
            }
        }
        fold = fnow;
        if (nnoimp >= ml->numNoImprove)
            break;
    }
}

/*
 * @since 2017.2.23, 4.16, 8.1, 12.17 (added init, allowed res_file, log_file and rng to be NULL)
 *        12.25 (added init, allowed res_file, log_file and rng to be NULL)
 */
void ML_search(ML_t ml, FILE *resultFile, FILE *logFile, gsl_rng *rng, double *init) {
    if (resultFile != NULL) {
        char **paramNames = Model_getParamNames(ml->m);
        write(resultFile, "result file", "run\timp\texit_code");
        for (int i = 0; i < ml->numParam; i++) {
            write(resultFile, "result file", "\t%s", paramNames[i]);
            matrixalloc_1d_free(paramNames[i]);
        }
        write(resultFile, "result file", "\tlnL\n");
        fflush(resultFile);
        matrixalloc_1d_free(paramNames);
    }
    
    double *x = ml->x;
    double *likelihoods = ml->likelihoods;
    double **MLEs = ml->MLEs;
    int *runID = ml->runID;
    int *improveID = ml->improveID;
    nlopt_result *exitCodes = ml->exitCodes;
    double *re = ml->re;
    size_t numParamSize = ml->numParamSize;
    for (int i = 0; i < ml->numSearches; i++) {
        if (init == NULL)
            Model_getInitialValues(x, ml->m, rng);
        else
            memcpy(x, init, numParamSize);
        double v;
        int imp;
        nlopt_result code;
        runNlopt(re, &v, &imp, &code, x, i + 1, ml, logFile);
        int indx = arrayutil_binary_search_d(likelihoods, 0, i, -v);
        if (indx < 0)
            indx = -indx - 1;
        for (int j = i; i > 0 && i > indx && j > indx; j--) {
            likelihoods[j] = likelihoods[j - 1];
            memcpy(MLEs[j], MLEs[j - 1], numParamSize);
            runID[j] = runID[j - 1];
            improveID[j] = improveID[j - 1];
            exitCodes[j] = exitCodes[j - 1];
        }
        likelihoods[indx] = -v;
        memcpy(MLEs[indx], re, numParamSize);
        runID[indx] = i + 1;
        improveID[indx] = imp;
        exitCodes[indx] = code;
    }
    if (resultFile != NULL) {
        for (int i = 0; i < ml->numSearches; i++) {
            write(resultFile, "result file", "%i\t%i\t%i", runID[i], improveID[i], exitCodes[i]);
            Model_unscaleParam(MLEs[i], MLEs[i], ml->m);
            for (int j = 0; j < ml->numParam; j++)
                write(resultFile, "result file", "\t%.15g", MLEs[i][j]);
            write(resultFile, "result file", "\t%.15g\n", -likelihoods[i]);
            fflush(resultFile);
        }
        write(resultFile, "result file", "\n\nAll parameters (including non-free parameters) and the full likelihood:\n");
        Model_scaleParam(MLEs[0], MLEs[0], ml->m);
        char *msg;
        void **data = Model_extraFunction("fullLikelihood_noConstraint", ml->m, &msg, MLEs[0]);
        int num = ((int *) data[0])[0];
        M1D_FREE(data[0]);
        char **names = data[1];
        double *mle = data[2];
        double lnlike = ((double *) data[3])[0];
        M1D_FREE(data[3]);
        M1D_FREE(data);
        for (int i = 0; i < num; i++) {
            write(resultFile, "result file", "%s = %.15g\n", names[i], mle[i]);
            M1D_FREE(names[i]);
        }
        M1D_FREE(names);
        M1D_FREE(mle);
        write(resultFile, "result file", "lnlike = %.15g\n", lnlike);
        fflush(resultFile);
    }
}

/*
 * @since 2017.12.17, 12.25
 */
double * ML_getLikelihoods(ML_t ml) {
    double *re;
    M1D_CLONE(re, ml->likelihoods, ml->numSearches);
    for (int i = 0; i < ml->numSearches; i++)
        re[i] = -re[i];
    return re;
}

/*
 * @since 2017.12.17, 12.25
 */
double ** ML_getMLEs(ML_t ml) {
   return matrixalloc_2d_d_clone(ml->MLEs, ml->numSearches, ml->numParam); 
}

/*
 * @since 2017.12.17, 12.25
 */
nlopt_result * ML_getExitCodes(ML_t ml) {
    nlopt_result *re;
    M1D_CLONE(re, ml->exitCodes, ml->numSearches);
    return re;
}