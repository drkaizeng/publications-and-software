/* 
 * Created on 23 February 2017, 10:57
 */
#include <string.h>
#include <stdarg.h>

#include "GetName.h"

#include "util/error_msg.h"
#include "util/matrixalloc.h"

#define BUFFER_SIZE 5000

/*
 * The returned object should be freed by free() or matrixalloc_1d_free
 * @since 2017.2.16, 2.19
 */
char * getName(const char *name, int index) {
    char buffer[BUFFER_SIZE];
    int cn = snprintf(buffer, BUFFER_SIZE, "%s_%d", name, index);
    if (cn < 0 || cn >= BUFFER_SIZE)
        ERROR_MSG_LMA("Failed!\n");
    char *str = matrixalloc_1d(cn + 1, sizeof (char));
    strcpy(str, buffer);
    return str;
}

/*
 * The returned object should be freed by free() or matrixalloc_1d_free
 * @since 2017.2.24, 2.26
 */
char * getName2(const char *format, ...) {
    char buffer[BUFFER_SIZE];
    
    va_list args;
    va_start(args, format);
    int cn = vsnprintf(buffer, BUFFER_SIZE, format, args);
    va_end(args);
    
    if (cn < 0 || cn >= BUFFER_SIZE)
        ERROR_MSG_LMA("Failed!\n");
    char *str = matrixalloc_1d(cn + 1, sizeof (char));
    strcpy(str, buffer);
    return str;
}