/* 
 * Created on 04 November 2016, 20:57
 */

#ifndef PARAMETERTYPE_H
#    define PARAMETERTYPE_H

enum ParameterType {
    THETA, F, G, TAU, ERROR, C, T
};

/**
 * The returned array must be freed using M1D_FREE
 */
char * ParameterType_toString(enum ParameterType type);

#endif /* PARAM_H */

