#ifndef ML_DEF_H
#define ML_DEF_H

#include "ML.h"

struct MLBuilder {
    /**
     * 0: A newly created object
     * 1: Algorithm has been added
     */
    int mode;
    Model_t m;
    int numSearches;
    double improveRelTolerance; 
    int numNoImprove;
    int maxNumImprove;
    
    nlopt_algorithm nloptAlgorithm;
    double relTolerance; 
    int maxNumOfFuncEvaluations;
    double maxExecutionTime;
};

struct ML {
    int numSearches;
    double improveRelTolerance; 
    int numNoImprove;
    int maxNumImprove;
    Model_t m;
    int numParam;
    nlopt_opt nlopt;
    
    double *x;//With numParam elements, this holds the initial value. 
    double *likelihoods;//With numSearches elements, this holds the log likelihood obtained from the searches in reverse order.
    double **MLEs;//A numSearches * numParam matrix, each row contains the MLEs associated with the corresponding element in lnl.
    int *runID;//With numSearches elements, runID[i] gives the index of the search that gives rise to lnl[i] and mle[i].
    int *improveID;//With numSearches elements, improveID[i] gives the index of the improvement search with the i-th run that gives rise to lnl[i] and mle[i].
    nlopt_result *exitCodes;//With numSearches elements, exit_code[i] gives the NLopt exit code for the search that gives rise to lnl[i] and mle[i].
    double *re;//With numParam elements, this is used to hold intermediate values of the free parameters.
    size_t numParamSize;//numParam * sizeof (double);
};


#endif /* ML_DEF_H */

