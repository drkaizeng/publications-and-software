/* 
 * Created on 23 February 2017, 12:43
 */

#ifndef PRINTERRORMESSAGE_H
#    define PRINTERRORMESSAGE_H

#include "util/matrixalloc.h"
#include "util/error_msg.h"

#define PRINT_ERRMSG(MSG, ...) \
        do { \
            int ___ERRMSG_BUFFER_ = 5000; \
            char ___ERRMSG_[___ERRMSG_BUFFER_]; \
            int ___CN_ = snprintf(___ERRMSG_, (size_t) ___ERRMSG_BUFFER_, __VA_ARGS__); \
            if (___CN_ < 0 || ___CN_ >= ___ERRMSG_BUFFER_) \
                ERROR_MSG_LMA("Failed\n"); \
            else {\
                char *___STR_ = matrixalloc_1d_clone(___ERRMSG_, ___CN_ + 1, sizeof(char)); \
                MSG[0] = ___STR_; \
            } \
        } while (0)


#endif /* PRINT_ERRMSG_H */

