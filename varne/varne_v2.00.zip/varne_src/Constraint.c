#include "Constraint.h"

#include "util/matrixalloc.h"

/*
 * @since 2018.10.15, 11.8
 */
struct Constraint * Constraint_new(int nx, double *x, int *xi, 
        double (* f)(const double *x, void *param), double (* df)(const double *x, int i, void *param),
        void *param, void (* freeParam)(void *param)) {
    struct Constraint *re;
    M1D_NEW(re, 1);
    
    re->nx = nx;
    re->x = x;
    re->xi = xi;
    re->f = f;
    re->df = df;
    re->param = param;
    re->freeParam = freeParam;
    
    return re;
}

/*
 * @since 2017.5.10, 5.22
 */
void Constraint_free(struct Constraint **cf) {
    if (cf[0]->freeParam != NULL)
        cf[0]->freeParam(cf[0]->param);
    matrixalloc_1d_free(cf[0]->xi);
    matrixalloc_1d_free(cf[0]->x);
    matrixalloc_1d_free(cf[0]);
    cf[0] = NULL;
}