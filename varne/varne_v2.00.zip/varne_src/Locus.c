#include <string.h>

#include "Locus_def.h"

#include "PrintErrorMessage.h"

#include "util/matrixalloc.h"
#include "util/arrayutil.h"

/*
 * @since 2017.6.30, 7.28, 2018.5.13 (added free_data; both free functions used void **), 5.17, 5.20
 */
void Locus_free(Locus_t *loc) {
    Locus_t l = loc[0];
    loc[0] = NULL;
    l->freeTypeParam(&(l->typeParam));
    matrixalloc_1d_free(l->name);
    matrixalloc_1d_free(l);
}

/*
 * @since 2018.5.17
 */
enum LocusType Locus_getType(Locus_t loc) {
    return loc->type;
}

/*
 * @since 2017.7.6, 7.27
 */
char * Locus_getName(Locus_t loc) {
    return matrixalloc_1d_clone(loc->name, (int) strlen(loc->name) + 1, sizeof (*loc->name));
}

/*
 * @since 2018.10.9
 */
int Locus_getNumParam(Locus_t loc) {
    return loc->getNumParam(loc->typeParam);
}

/*
 * @since 2018.10.8, 10.9
 */
enum ParameterType * Locus_getParamTypes(Locus_t loc) {
    return loc->getParamTypes(loc->typeParam);
}

/*
 * @since 2018.10.9
 */
char ** Locus_getParamNames(Locus_t loc) {
    return loc->getParamNames(loc->typeParam);
}

/*
 * @since 2018.10.16, 11.8
 */
void * Locus_extraFunction(const char *cmd, Locus_t loc, char **msg, ...) {
    va_list args;
    va_start(args, msg);
    
    void *re = loc->extraFunction(cmd, loc->typeParam, msg, args);
    
    va_end(args);
    
    return re;
}
