/*
 * Created on 30 September 2018, 19:17
 */
#include <math.h>

#include "Coefficient.h"

#include "util/matrixalloc.h"
#include "util/error_msg.h"
#include "util/ordered_list.h"

struct Coefficient {
    int len;//the number of sample sizes
    ordered_list_i_t n_lst;//the sample sizes
    double ***w;//w[id] is W_i(j) for the id-th element in n_lst
};

/*
 * @since 2018.10.1, 10.7 (n_lst from int* to ordered_list)
 */
Coefficient_t Coefficient_new(void) {
    struct Coefficient *re;
    M1D_NEW(re, 1);
    
    re->len = 0;
    re->n_lst = ordered_list_i_new(10);
    re->w = NULL;
    
    return re;
}

/*
 * @since 2018.10.7
 */
Coefficient_t Coefficient_clone(Coefficient_t co) {
    Coefficient_t re;
    M1D_NEW(re, 1);
    
    *re = *co;
    
    re->n_lst = ordered_list_i_new(1);
    M1D_NEW(re->w, re->len);
    for (int k = 0, n; k < re->len; k++) {
        ordered_list_i_get(&n, k, co->n_lst);
        ordered_list_i_add(n, re->n_lst);
        M2D_NEW(re->w[k], n - 1, n - 1);
        size_t s = (size_t) (n - 1) * sizeof(double);
        for (int i = 1, i1 = 0; i < n; i++, i1++) {
            memcpy(re->w[k][i1], co->w[k][i1], s);
        }
    }
    
    return re;
}

/*
 * @since 2018.10.1, 10.7 (n_lst from int* to ordered_list)
 */
void Coefficient_free(Coefficient_t *co) {
    struct Coefficient *c = co[0];
    co[0] = NULL;
    for (int id = 0; id < c->len; id++) {
        M2D_FREE(c->w[id]);
    }
    M1D_FREE(c->w);
    ordered_list_i_free(&(c->n_lst));
    M1D_FREE(c);
}

/**
 * <ul>
 * <li> b[id] is B_i(j) for sample size n[id]
 * <li> b[i-1][j-2] is the B_i(j). i=1..(n-1); j=2..n
 * </ul>
 * @since 2018.10.1 (n=2,3,4,5), 10.7 (by eye)
 */
static void cal(int n, int id, struct Coefficient *co) {
    double **w;
    M2D_NEW(w, n - 1, n - 1);
    co->w[id] = w;
    
    if (n == 2) {//i=1, j=2
        w[0][0] = 2;
    } else {
        double tmp;
        double first = 6.0 / (n + 1);//W_i(2)
        double second = exp(log(30) - log(n + 1) - log(n + 2));//part of W_i(3)
        double *c1 = NULL, *c2 = NULL;
        if (n >= 4) {
            M1D_NEW(c1, n - 3);
            M1D_NEW(c2, n - 3);
            for (int j = 2, j2 = j - 2; j <= n - 2; j++, j2++) {
                c1[j2] = log(j + 1) + log(2 * j + 3) + log(n - j) 
                        - log(j) - log(2 * j - 1) - log(n + j + 1);
                c1[j2] = -exp(c1[j2]);
                c2[j2] = log(2 * j + 3) - log(j) - log(n + j + 1);
                c2[j2] = exp(c2[j2]);
            }
        }
        for (int i = 1, i1 = 0; i < n; i++, i1++) {
            w[i1][0] = first;//W_i(2)
            tmp = n - 2 * i;
            w[i1][1] = second * tmp;//W_i(3)
            for (int j = 2, j2 = j - 2; j <= n - 2; j++, j2++) {
                w[i1][j] = c1[j2] * w[i1][j2] + c2[j2] * tmp * w[i1][j - 1];
            }
        }
        M1D_FREE(c1);
        M1D_FREE(c2);
    }
}

/**
 * <ul>
 * <li> Return true if n has been added to co. 
 * <li> When false is returned, it means n is already in co.
 * </ul>
 * @since 2018.10.1, 10.7 (n_lst from int* to ordered_list)
 */
static bool add_n(int n, struct Coefficient *co) {
    int id = ordered_list_i_id(n, co->n_lst);
    if (id >= 0) {
        return false;
    } else {
        id = -id - 1;
        ordered_list_i_add(n, co->n_lst);
        M1D_REALLOC(co->w, co->len + 1);
        size_t num = (size_t) (co->len - id);
        memmove(co->w + id + 1, co->w + id, num * sizeof(*(co->w)));
        cal(n, id, co);
        co->len++;
        return true;
    }
}

/*
 * @since 2018.10.1, 10.7
 */
bool Coefficient_add(int n, struct Coefficient *co) {
    if (n < 2)
        return false;
    if (co == NULL)
        ERROR_MSG_LMA("ERROR");
    return add_n(n, co);
}

/*
 * @since 2018.10.1, 10.7 (n_lst from int* to ordered_list)
 */
int Coefficient_getID(int n, Coefficient_t co) {
    return ordered_list_i_id(n, co->n_lst);
}

/*
 * @since 2018.10.1, 10.7
 */
double ** Coefficient_getW(int id, Coefficient_t co) {
    if (id < 0 || id >= co->len)
        ERROR_MSG_LMA("ERROR");
    return co->w[id];
}

/*
 * @since 2018.10.7
 */
int Coefficient_getSize(Coefficient_t co) {
    return co->len;
}

/*
 * @since 2018.10.7
 */
void Coefficient_getSampleSizes(int *n, Coefficient_t co) {
    if (co->len > 0) {
        ordered_list_i_arr(n, co->n_lst);
    }
}