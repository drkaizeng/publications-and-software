/*
 * Created on 05 July 2017, 08:41
 */

#ifndef VARNEIO_H
#define VARNEIO_H

#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>

#define BUFFER_SIZE 32767

#include "io/file_reader.h"

FILE * VarneIO_newFile(const char *path);

/*
 * On return, if msg[0] = NULL, then nothing has been read until EOF. Otherwise, unexpected text has been found.
 */
void VarneIO_toEOF(file_reader_t *reader, int *line_id, char **msg);

/**
 * Return the next line that is non-empty or not starting with # (after trimming)
 * @line_id The first line has ID 1. This variable should be initialised to 0.
 * @param msg If no error is detected, then msg[0] points to NULL, otherwise it contains an error message.
 */
void VarneIO_skipLines(char buffer[BUFFER_SIZE], file_reader_t *reader, int *line_id, char **msg);

/**
 * Read the parameters (param_name) and store them in param.
 * @line_id The first line has ID 1. This variable should be initialised to 0.
 * @param msg If no error is detected, then msg[0] points to NULL, otherwise it contains an error message.
 */
void VarneIO_readControlParam(int num_param, char param[num_param][BUFFER_SIZE], 
        const char *param_name[num_param], file_reader_t *reader, int *line_id, char **msg);

int VarneIO_getInt(const char *valstr, const char *format, ...);

intmax_t VarneIO_getIntmax(const char *valstr, const char *format, ...);

double VarneIO_getDouble(const char *valstr, const char *format, ...);

///**
// * Process a, b, c
// * @param len The number of elements
// * @param valstr This will be changed. So a copy of the pointer should be stored before
// *               calling the function to ensure proper release of memory.
// */
//void VarneIO_getDoubleArray1(int len, double result[len], char *valstr, const char *format, ...);
//
///**
// * Process a, b, c
// * @param cn On return, this stores the number of elements in the array
// * @param valstr This will be changed. So a copy of the pointer should be stored before
// *               calling the function to ensure proper release of memory.
// * @return The returned array should be freed by M1D_FREE
// */
//double * VarneIO_getDoubleArray2(int *cn, char *valstr, const char *format, ...);

/**
 * Process a b c
 * @param len The number of elements
 * @param valstr This will be changed. So a copy of the pointer should be stored before
 *               calling the function to ensure proper release of memory.
 */
void VarneIO_getDoubleArray1(int len, double result[len], char *valstr, const char *format, ...);

/**
 * Process a b c
 * @param cn On return, this stores the number of elements in the array
 * @param valstr This will be changed. So a copy of the pointer should be stored before
 *               calling the function to ensure proper release of memory.
 * @return The returned array should be freed by M1D_FREE
 */
double * VarneIO_getDoubleArray2(int *cn, char *valstr, const char *format, ...);

bool VarneIO_getBool(const char *valstr, const char *format, ...);

/**
 * @param msg On return, msg[0] should point to NULL if everything is fine. Otherwise, it contains an error message
 * @return A cloned version of the string. This should be freed by M1D_FREE() or matrixalloc_1d_free
 */
char * VarneIO_removeSquareBrackets(const char *src, char **msg);

/**
 * On return
 * <ul>
 * <li> n[0]: the length of v
 * <li> v[0]: A double array storing x y z. The returned array must be freed by M1D_FREE.
 * </ul>
 * @param src param_name[x y z], where x y z are separated by space characters. 
 */
void VarneIO_getValuesInSquareBrackets(int *n, double **v, const char *src, char **msg);

#endif /* VARNE_IO_H */

