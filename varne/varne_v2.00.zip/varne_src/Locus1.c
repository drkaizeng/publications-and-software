/*
 * Created on 12 May 2018, 13:21
 */
#include <string.h>
#include <limits.h>

#include "Locus1.h"

#include "PrintErrorMessage.h"
#include "GetName.h"

#include "util/error_msg.h"
#include "util/matrixalloc.h"
#include "util/arrayutil.h"
#include "util/string_util.h"


/*
 * @since 2018.10.9
 */
static void freeTypeParam(void **type_param) {
    struct Locus1 *sl = (struct Locus1 *) type_param[0];
    type_param[0] = NULL;
    for (int i = 0; i < sl->numParam; i++)
        matrixalloc_1d_free(sl->paramName[i]);
    matrixalloc_1d_free(sl->paramName);
    matrixalloc_1d_free(sl->paramType);
    M1D_FREE(sl->id);
    LocusData1_free(&(sl->data));
    matrixalloc_1d_free(sl);
}

/*
 * @since 2018.10.9
 */
static int getNumParam(void *model_param) {
    struct Locus1 *sl = (struct Locus1 *) model_param;
    return sl->numParam;
}

/*
 * @since 2018.10.8, 10.9
 */
static enum ParameterType * getParamTypes(void *model_param) {
    struct Locus1 *sl = (struct Locus1 *) model_param;
    return matrixalloc_1d_clone(sl->paramType, sl->numParam, sizeof(*sl->paramType));
}

/*
 * @since 2018.10.9
 */
static char ** getParamNames(void *model_param) {
    struct Locus1 *sl = (struct Locus1 *) model_param;
    char **re = matrixalloc_1d(sl->numParam, sizeof(*re));
    for (int i = 0; i < sl->numParam; i++)
        re[i] = matrixalloc_1d_clone(sl->paramName[i], (int) strlen(sl->paramName[i]) + 1, sizeof(*re[i]));
    return re;
}

/*
 * @since 2018.10.16, 11.9
 */
static void * isAllSFSFolded(void *typeParam) {
    struct Locus1 *sl = (struct Locus1 *) typeParam;
    bool *re;
    M1D_NEW(re, 1);
    re[0] = true;
    for (int i = 0; i < sl->data->len; i++) {
        re[0] = re[0] && sl->data->folded[i];
    }
    return re;
}

/*
 * @since 2018.10.16
 */
static void * getSampleSizes(void *typeParam) {
    struct Locus1 *sl = (struct Locus1 *) typeParam;
    int *len;
    M1D_NEW(len, 1);
    int *n;
    LocusData1_getSampleSize(len, &n, sl->data);
    void **re;
    M1D_NEW(re, 2);
    re[0] = len;
    re[1] = n;
    return re;
}

/*
 * @since 2018.10.16
 */
static void * extraFunction(const char *cmd, void *typeParam, char **msg, va_list args) {
    msg[0] = NULL;
    
    if (string_util_equal(cmd, "isAllSFSFolded")) {
        return isAllSFSFolded(typeParam);
    } else if (string_util_equal(cmd, "sampleSizes")) {
        return getSampleSizes(typeParam);
    } else {
        PRINT_ERRMSG(msg, "Unknown command = %s\n", cmd);
        return NULL;
    }
}

/*
 * @since 2018.10.8, 10.9
 */
static void addData(void *type_param, char **msg, va_list args) {
    struct Locus1 *sl = (struct Locus1 *) type_param;
    
    int len = va_arg(args, int);
    int *n = va_arg(args, int *);
    double *m = va_arg(args, double *);
    int *folded = va_arg(args, int *);
    double **sfs = va_arg(args, double **);
    
    sl->data = LocusData1_new(len, n, m, folded, sfs, msg);
    M1D_NEW(sl->id, len);
}

/*
 * @since 2018.10.15
 */
static char * getParamName2(enum ParameterType type, const char *locName, int indx) {
    char *typeName = ParameterType_toString(type);
    char *re;
    if (indx < 0) {
        re = getName2("%s%s", locName, typeName);
    } else if (indx > 0) {
        re = getName2("%s%s_%d", locName, typeName, indx);
    } else {
        ERROR_MSG_LMA("ERROR");
    }
    M1D_FREE(typeName);
    return re;
}


/*
 * Parameters: int H, bool use_prof
 * @since 2018.10.9
 */
void Locus1Builder_new(LocusBuilder_t lb, const char *name, char **msg, va_list args) {
    msg[0] = NULL;
    
    int H = va_arg(args, int);
    bool useProfile = va_arg(args, int);
    
    if (H < 1) {
        PRINT_ERRMSG(msg, "H < 1");
        return;
    }
    
    struct Locus *loc;
    M1D_NEW(loc, 1);
    lb->loc = loc;
    
    if (strlen(name) >= INT_MAX/2) {
        PRINT_ERRMSG(msg, "Locus name too long. name = %s.", name);
        return;
    }
    M1D_CLONE(loc->name, name, (int) (strlen(name) + 1));
    
    loc->type = LOCUS1;
    
    struct Locus1 *sl;
    M1D_NEW(sl, 1);
    loc->typeParam = sl;
    
    loc->freeTypeParam = freeTypeParam;
    loc->addData = addData;
    loc->getNumParam = getNumParam;
    loc->getParamTypes = getParamTypes;
    loc->getParamNames = getParamNames;
    loc->extraFunction = extraFunction;
    
    sl->H = H;
    sl->useProfile = useProfile;
    
    sl->numParam = (useProfile ? 2 * H : 2 * H + 1);
    M1D_NEW(sl->paramType, sl->numParam);
    M1D_NEW(sl->paramName, sl->numParam);
    {
        int indx = 0;
        if (useProfile == false) {
            sl->paramType[indx] = THETA;
            sl->paramName[indx] = getParamName2(sl->paramType[indx], loc->name, -1);
            indx++;
        }
        sl->paramType[indx] = F;
        sl->paramName[indx] = getParamName2(sl->paramType[indx], loc->name, -1);
        indx++;
        for (int h = 1, id = indx, hm1 = H - 1; h < H; h++, id++) {
            sl->paramType[id] = G;
            sl->paramName[id] = getParamName2(sl->paramType[id], loc->name, h);
            sl->paramType[id + hm1] = TAU;
            sl->paramName[id + hm1] = getParamName2(sl->paramType[id + hm1], loc->name, h);
            indx = id + H;
        }
        sl->paramType[indx] = ERROR;
        sl->paramName[indx] = getParamName2(sl->paramType[indx], loc->name, -1);
    }
}