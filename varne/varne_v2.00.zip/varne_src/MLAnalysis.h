/*
 * Created on 31 July 2017, 17:19
 */

#ifndef MLANALYSIS_H
#define MLANALYSIS_H

void doMLAnalysis(char** argv, unsigned long seed);

#endif /* ML_ANALYSIS_H */

