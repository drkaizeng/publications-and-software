#ifndef MODEL_H
#define MODEL_H

#include <stdbool.h>
#include <stdarg.h>

#include "Locus.h"
#include "ParameterType.h"

#include "io/file_reader.h"

#include "nlopt.h"

typedef struct Model * Model_t;

enum ModelType {
    MODEL1, MODEL2
};

////////////////////////////////////////////////////////////////////////////////////////////////
//  The ML models
////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * MODEL1
 * <ul>
 * <li> ...: none
 * <li> This is the general model without divergence described in the paper.
 * <li> In the most general case, each locus has its own theta, f, and g (with f = 1 at locus 1).
 *      The tau parameters are shared across loci.
 * <li> The format of the control file is as described in the manual.
 * <li> The parameters are ordered according to the order in which the loci are listed in the control file.
 *      Within each locus, the parameters are ordered as 
 *      <ul>
 *      <li> useProfile = false: theta, f, g_1, ..., g_{H-1}, tau_1, ..., tau_{H-1}, err
 *      <li> useProfile = true:         f, g_1, ..., g_{H-1}, tau_1, ..., tau_{H-1}, err
 *      </ul>
 * </ul>
 * 
 * MODEL2
 * <ul>
 * <li> ...: none
 * <li> This is the general model with divergence described in the paper.
 * <li> In the most general case, each locus has its own theta, f, g, and err (with f = 1 at locus 1).
 *      The tau, c, t parameters are shared across loci.
 * <li> The format of the control file is as described in the manual.
 * <li> The parameters are ordered according to the order in which the loci are listed in the control file.
 *      Within each locus, the parameters are ordered as <br>
 *      theta, f, g_1, ..., g_{H-1}, tau_1, ..., tau_{H-1}, err, c, t
 * <li> When H = 1, c is fixed at 1.
 * </ul>
 */
Model_t Model_new(enum ModelType type, file_reader_t *reader, int *line_id, char **msg, ...);


/**
 * On return m is set to NULL.
 */
void Model_free(Model_t *m);

enum ModelType Model_getType(Model_t m);

/**
 * The number of free parameters to be optimised by the search algorithm.
 */
int Model_getNumParam(Model_t m);

/**
 * The names of the free parameters to be optimised by the search algorithm.
 * <p>
 * The returned array should be freed as follows: free(re[i]), free(re).
 */
char ** Model_getParamNames(Model_t m);

/**
 * The types of the free parameters to be optimised by the search algorithm.
 */
enum ParameterType * Model_getParamTypes(Model_t m);

/**
 * Generate a starting point for ML searches.
 * <ul>
 * <li> The input array x should have Model_getNumParam elements. 
 * <li> The scale of value are the same as that defined in Model_getLikelihood().
 * </ul>
 * <p>
 * MODEL1
 * <ul>
 * <li> If random, then ... = gsl_rng *rng
 * <li> If given, then no extra param is needed.
 * </ul>
 */
void Model_getInitialValues(double *x, Model_t m, ...);

/**
 * The returned array contains the ranges for the Model_getNumParam() free parameters. 
 * <ul>
 * <li> re[0][i] is the lower bound for parameter i; and re[1][i] is the upper bound.
 * <li> The scale of the values is as defined in Model_getLikelihood().
 * <li> The returned matrix should be freed by matrixalloc_2d_d_free
 * </ul>
 */
double ** Model_getParamRanges(Model_t m);

/**
 * The number of equality/inequality constraints on the free parameters to be optimised by the search algorithm.
 * <p>
 * A non-positive returned value means no constraint exists.
 */
int Model_getNumNloptConstraints(Model_t m);

/**
 * This should be used only if Model_getNumConstraints returns a positive value. 
 * <ul>
 * <li> The caller needs to allocate memory.
 * <li> constraint[0]: of size Model_getNumConstraints().
 * <li> isEqualityConstraint[0]: of size Model_getNumConstraints().
 * <li> constraintData[0]: 
 *      <ul>
 *      <li> Of size Model_getNumConstraints(). 
 *      <li> On return, constraintData[0][i] contains the data for the i-th constraint.
 *      <li> Note that this function doesn't clone constraintData[0][i], but merely copies its reference.
 *      </ul>
 * </ul>
 */
void Model_getNloptConstraints(nlopt_func *constraint, bool *isEqualityConstraint, void **constraintData, Model_t m);


/**
 * <b>Note:</b> This function should not be called when there are no free parameters
 * <ul>
 * <li> grad and x: of size Model_getNumParam().
 * <li> MODEL1 & MODEL2
 *      <ul>
 *      <li> ERR is transferred to ln(ERR + 1)
 *      <li> All the other parameters are on the natural-log scale.
 *      </ul>
 * </ul>
 */
double Model_getLikelihood(double *grad, const double *x, Model_t m);

/**
 * 
 * @param x2 Of the same length as x, but the scales are the same as those defined in Model_getLikelihood()
 * @param x  Of the same length as x in Model_getLikelihood(), but the values are on the original scale.
 * @param m
 */
void Model_scaleParam(double *x2, double *x, Model_t m);

/**
 * 
 * @param x2 Of the same length as x, but values are on the original scale
 * @param x  Of the same length and on the same scale as x in Model_getLikelihood()
 * @param m
 */
void Model_unscaleParam(double *x2, double *x, Model_t m);

/**
 * MODEL1 & MODEL2
 * <ul>
 * <li> fullLikelihood_noConstraint
 *      <ul>
 *      <li> ...: the MLEs of the parameters optimised by the search algorithm. 
 *                  The scales are defined in Model_getLikelihood().
 *                  If m->numParam = 0, then supply NULL.
 *      <li> re should be cast to void **.
 *      <li> re[0]: int *; re[0][0] is the number of parameters; free(re[0])
 *      <li> re[1]: char **; the names of the parameters; free(re[1][i]), then free(re[1])
 *      <li> re[2]: double *; the MLEs of the parameters; free(re[2])
 *      <li> re[3]: double *; the full likelihood; free(re[3])
 *      <li> free(re)
 *      </ul>
 * </ul>
 */
void * Model_extraFunction(const char *cmd, Model_t m, char **msg, ...);







///**
// * <ul>
// * <li> MODEL_I: The number of all the parameters in the likelihood model without any constraints 
// *              (i.e., including theta and f=1 at locus 1).
// * </ul>
// */
//int Model_getNumParamOfFullModel(Model_t m);
//
///**
// * <ul>
// * <li> MODEL_I: The number of all the parameters in the likelihood model without any constraints 
// *              (i.e., including theta and f=1 at locus 1).
// * </ul>
// * <p>
// * The returned array should be freed as follows: free(re[i]), free(re).
// */
//char ** Model_getParamNamesOfFullModel(Model_t m);
//
///**
// * Convert the array composed of free parameters (see Model_getNumParam()) to 
// * one composed of all the parameters under the likelihood model without constraints (see Model_getNumParamFullModel())
// * <ul>
// * <li> freeParam: see Model_getLikelihood() for the scale.
// * <li> allParam: These are on the original scale.
// * </ul>
// */
//void Model_toParamOfFullModel(double *allParam, const double *freeParam, Model_t m);
//
///**
// * Convert the array composed of all the parameters under the likelihood model without constraints (see Model_getNumParamFullModel())
// * to the free parameters to be optimised by the search algorithm.
// * <ul>
// * <li> freeParam: see Model_getLikelihood() for the scale.
// * <li> allParam: These are on the original scale.
// * </ul>
// */
//void Model_toFreeParam(double *free_param, const double *all_param, Model_t m);



#endif /* MODEL_H */

