/*
 * Created on 13 October 2018, 08:20
 */
#include <math.h>

#include "Model1_def.h"

#include "PrintErrorMessage.h"
#include "VarneIO.h"
#include "GetName.h"

#include "util/matrixalloc.h"
#include "util/error_msg.h"
#include "util/string_util.h"

#ifdef _OPENMP
#include "omp.h"
#endif


/**
 * @since 2018.10.15, 11.8
 */
struct Model1InputParamRanges * Model1InputParamRanges_new(void) {
    struct Model1InputParamRanges *re;
    M1D_NEW(re, 1);
    re->len = 5;
    enum ParameterType types[5] = { THETA, F, G, TAU, ERROR };
    memcpy(re->types, types, 5 * sizeof(*re->types));
    return re;
}

/**
 * @since 2018.10.15
 */
void Model1InputParamRanges_free(struct Model1InputParamRanges **inputRanges) {
    struct Model1InputParamRanges *re = inputRanges[0];
    inputRanges[0] = NULL;
    M1D_FREE(re);
}

/**
 * @since 2018.10.15, 11.9
 */
void Model1InputParamRanges_add(int id, double lo, double hi, char **msg, struct Model1InputParamRanges *inputRanges) {
    msg[0] = NULL;
    
    if (id < 0 || id >= inputRanges->len) {
        ERROR_MSG_LMA("ERROR");
    }

    enum ParameterType type = inputRanges->types[id];
    if (lo >= hi || 
            (type != ERROR && lo <= 0) || 
            (type == ERROR && (lo < 0 || hi > 1))
            ) {
        PRINT_ERRMSG(msg, "Invalid range: low = %g, high = %g", lo, hi);
        return;
    }
    
    inputRanges->ranges[0][id] = lo;
    inputRanges->ranges[1][id] = hi;
}

/**
 * @since 2018.10.15
 */
void Model1InputParamRanges_get(double *lo, double *hi, enum ParameterType type, struct Model1InputParamRanges *inputRanges) {
    int id = -1;
    for (int i = 0; i < inputRanges->len; i++) {
        if (type == inputRanges->types[i]) {
            id = i;
            break;
        }
    }
    if (id < 0)
        ERROR_MSG_LMA("ERROR");
    
    lo[0] = inputRanges->ranges[0][id];
    hi[0] = inputRanges->ranges[1][id];
}


/**
 * @since 2018.10.15
 */
double Model1_scaleParam(enum ParameterType type, double v) {
    if (type != ERROR) {
        return log(v);
    } else {
        v += 1;
        return log(v);
    }
}

/**
 * @since
 */
double Model1_getJacobian(enum ParameterType type, double v) {
    return exp(v);
}

/**
 * @since 2018.10.15
 */
double Model1_unscaleParam(enum ParameterType type, double v) {
    if (type != ERROR) {
        return exp(v);
    } else {
        v = exp(v);
        v -= 1;
        return v;
    }
}

/**
 * @since 2018.10.15
 */
static void getLocusData(int *n, double *m, int *folded, double **sfs, file_reader_t *reader, int *lineID, char **msg) {
    msg[0] = NULL;
    int numParam = 4;
    int paramID = 0;
    const char *names[numParam];
    names[paramID++] = "n:";
    names[paramID++] = "m:";
    names[paramID++] = "folded:";
    names[paramID++] = "sfs:";
    if (paramID != numParam)
        ERROR_MSG_LMA("error");

    char param[numParam][BUFFER_SIZE];
    VarneIO_readControlParam(numParam, param, names, reader, lineID, msg);
    if (msg[0] != NULL)
        return;

    paramID = 0;
    
    n[0] = VarneIO_getInt(param[paramID], "Failed to parse n at line %i.\n",
                lineID[0] - numParam + paramID + 1);
    if (n[0] < 2) {
        PRINT_ERRMSG(msg, "n < 2 at line %i", lineID[0] - numParam + paramID + 1);
        return;
    }
    paramID++;
    
    m[0] = VarneIO_getDouble(param[paramID], "Failed to parse m at line %i.\n",
                lineID[0] - numParam + paramID + 1);
    if (m[0] <= 0) {
        PRINT_ERRMSG(msg, "m <= 0 at line %i", lineID[0] - numParam + paramID + 1);
        return;
    }
    paramID++;
    
    bool folded2 = VarneIO_getBool(param[paramID], "Failed to parse folded at line %i.\n",
                lineID[0] - numParam + paramID + 1);
    folded[0] = (folded2 == true ? 1 : 0);
    paramID++;
    
    int sfsLen;
    sfs[0] = VarneIO_getDoubleArray2(&sfsLen, param[paramID], "Failed to parse sfs at line %i.\n",
                lineID[0] - numParam + paramID + 1);
    if ( (folded2 && (sfsLen != n[0] / 2)) || 
            (folded2 == false && (sfsLen != n[0] - 1)) ) {
        PRINT_ERRMSG(msg, "Length of sfs at line %i in consistent with n and folded.", lineID[0] - numParam + paramID + 1);
        return;
    }
}

/**
 * @since 2018.10.15
 */
static int getNumSampleSizes(file_reader_t *reader, int *lineID, char **msg) {
    msg[0] = NULL;
    int numParam = 2;
    int paramID = 0;
    const char *names[numParam];
    names[paramID++] = "<locus>";
    names[paramID++] = "numSampleSizes:";
    if (paramID != numParam)
        ERROR_MSG_LMA("error");

    char param[numParam][BUFFER_SIZE];
    VarneIO_readControlParam(numParam, param, names, reader, lineID, msg);
    if (msg[0] != NULL)
        return -1;

    paramID = 1;
    int numSampleSizes = VarneIO_getInt(param[paramID], "Failed to parse numSampleSizes at line %i.\n",
                lineID[0] - numParam + paramID + 1);
    return numSampleSizes;
}

/**
 * @since 2018.10.15
 */
static Locus_t getLocus(int H, bool useProfile, int locusID, file_reader_t *reader, int *lineID, char **msg) {
    msg[0] = NULL;
    int len = getNumSampleSizes(reader, lineID, msg);
    if (len <= 0) {
        PRINT_ERRMSG(msg, "Invalid numSampleSizes at line %i", lineID[0]);
        return NULL;
    }
    int *n;
    double *m;
    int *folded;
    double **sfs;
    M1D_NEW(n, len);
    M1D_NEW(m, len);
    M1D_NEW(folded, len);
    M1D_NEW(sfs, len);
    for (int i = 0; i < len; i++) {
        getLocusData(n + i, m + i, folded + i, sfs + i, reader, lineID, msg);
        if (msg[0] != NULL)
            return NULL;
    }
    
    char *name = getName2("l%d_", locusID);
    LocusBuilder_t lb = LocusBuilder_new(LOCUS1, name, msg, H, useProfile);
    M1D_FREE(name);
    
    LocusBuilder_addData(lb, msg, len, n, m, folded, sfs);
    if (msg[0] != NULL)
        return NULL;
    
    for (int i = 0; i < len; i++) {
        M1D_FREE(sfs[i]);
    }
    M1D_FREE(n);
    M1D_FREE(m);
    M1D_FREE(folded);
    M1D_FREE(sfs);
    
    return LocusBuilder_build(&lb);
}

/**
 * @since 2018.10.15 (false), 11.9 (true with OpenMP)
 */
static void getOptional(struct Model1 *re, bool optional, file_reader_t *reader, int *lineID, char **msg) {
    msg[0] = NULL;
    
    if (optional == false) {/* Default values */
        re->initMethodName = getName2("random");
        re->numThreads = 1;
        re->sched = 1;
        re->chunkSize = 1;
    } else {
        int numParam = 4;
        int paramID = 0;
        const char *names[numParam];
        names[paramID++] = "initMethod:";
        names[paramID++] = "numThreads:";
        names[paramID++] = "sched:";
        names[paramID++] = "chunkSize:";
        if (paramID != numParam)
            ERROR_MSG_LMA("error");

        char param[numParam][BUFFER_SIZE];
        VarneIO_readControlParam(numParam, param, names, reader, lineID, msg);
        if (msg[0] != NULL)
            return;

        paramID = 0;

        {
            int s = (int) strlen(param[paramID]);
            M1D_NEW(re->initMethodName, s + 1);
            strcpy(re->initMethodName, param[paramID]);
        }
        if (string_util_equal(param[paramID], "random")) {
        } else if (string_util_starts_with(param[paramID], "given[") && string_util_ends_with(param[paramID], "]")) {
        } else {
            PRINT_ERRMSG(msg, "Unknown initMethod = %s", param[paramID]);
            return;
        }
        paramID++;

#ifndef _OPENMP
        re->numThreads = 1;
        re->sched = 1;
        re->chunkSize = 1;
#else
        re->numThreads = VarneIO_getInt(param[paramID], "Failed to parse numThreads at line %i.\n",
                lineID[0] - numParam + paramID + 1);
        paramID++;
        
        re->sched = VarneIO_getInt(param[paramID], "Failed to parse sched at line %i.\n",
                lineID[0] - numParam + paramID + 1);
        paramID++;
        
        re->chunkSize = VarneIO_getInt(param[paramID], "Failed to parse chunkSize at line %i.\n",
                lineID[0] - numParam + paramID + 1);
        paramID++;
        
        if (re->numThreads < 1) {
            PRINT_ERRMSG(msg, "numThreads < 1");
            return;
        }
        if (re->sched < 1 || re->sched > 4) {
            PRINT_ERRMSG(msg, "sched < 1 || sched > 4");
            return;
        }
        if (re->chunkSize < 1) {
            PRINT_ERRMSG(msg, "chunkSize < 1");
            return;
        }
        omp_set_num_threads(re->numThreads);
        omp_set_dynamic(false);
        omp_set_schedule(re->sched, re->chunkSize);
#endif
    }
}

/*
 * @since 2018.10.15
 */
void Model1_readControlFile(struct Model1 *re, file_reader_t *reader, int *lineID, char **msg) {
    msg[0] = NULL;
    
    int numParam = 10;
    int paramID = 0;
    const char *paramNames[numParam];
    paramNames[paramID++] = "H:";
    paramNames[paramID++] = "useProfile:";
    paramNames[paramID++] = "numLoci:";
    paramNames[paramID++] = "thetaRange:";
    paramNames[paramID++] = "fRange:";
    paramNames[paramID++] = "gRange:";
    paramNames[paramID++] = "tauRange:";
    paramNames[paramID++] = "errRange:";
    paramNames[paramID++] = "constraints:";
    paramNames[paramID++] = "optional:";
    if (paramID != numParam)
        ERROR_MSG_LMA("error\n");
    
    char param[numParam][BUFFER_SIZE];
    VarneIO_readControlParam(numParam, param, paramNames, reader, lineID, msg);
    if (msg[0] != NULL)
        return;
    
    paramID = 0;
    re->H = VarneIO_getInt(param[paramID], "Failed to parse H at line %i.\n", 
            lineID[0] - numParam + paramID + 1);
    if (re->H < 1) {
        PRINT_ERRMSG(msg, "H < 1");
        return;
    }
    paramID++;
    
    re->useProfile = VarneIO_getBool(param[paramID], "Failed to parse useProfile at line %i.\n", 
            lineID[0] - numParam + paramID + 1);
    paramID++;
    
    re->numLoci = VarneIO_getInt(param[paramID], "Failed to parse numLoci at line %i.\n", 
            lineID[0] - numParam + paramID + 1);
    if (re->numLoci < 1) {
        PRINT_ERRMSG(msg, "numLoci < 1");
        return;
    }
    paramID++;
    
    re->inputRanges = Model1InputParamRanges_new();
    for (int i = 0; i < 5; i++) {
        double rr[2];  
        VarneIO_getDoubleArray1(2, rr, param[paramID], "Failed to parse %s at line %i.\n", 
            paramNames[paramID], lineID[0] - numParam + paramID + 1);
        Model1InputParamRanges_add(i, rr[0], rr[1], msg, re->inputRanges);
        if (msg[0] != NULL) {
            return;
        }
        paramID++;
    }
    
    re->constraintName = matrixalloc_1d_clone(param[paramID], (int) strlen(param[paramID]) + 1, sizeof (char));
    paramID++;
    
    bool optional = VarneIO_getBool(param[paramID], "Failed to parse optional at line %i.\n",
            lineID[0] - numParam + paramID + 1);
    getOptional(re, optional, reader, lineID, msg);
    paramID++;
    
    M1D_NEW(re->loci, re->numLoci);
    for (int i = 0; i < re->numLoci; i++) {
        re->loci[i] = getLocus(re->H, re->useProfile, i + 1, reader, lineID, msg);
        if (msg[0] != NULL)
            return;
    }
}