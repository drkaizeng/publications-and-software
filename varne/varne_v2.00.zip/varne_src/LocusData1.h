/*
 * Created on 24 June 2018, 07:54
 */

#ifndef LOCUSDATA1_H
#define LOCUSDATA1_H

#include <stdbool.h>

struct LocusData1 {
    int len;
    int *n;//the sample size
    double *m;//length
    bool *folded;
    /*
     * For SNPs, either n/2 or n-1 elements, depending on whether it's folded or not. <br>
     */
    double **sfs;
    int *sfsLen;
    double numSeg;//the total number of segregating sites
};

/**
 * n, m, folded, sfs are cloned by this function
 */
struct LocusData1 * LocusData1_new(int len, int *n, double *m, int *folded, double **sfs, char **msg);

/**
 */
void LocusData1_free(struct LocusData1 **data);

/**
 * Use void* to conform with <code>struct locus</code>
 * @return The number of alleles
 */
void LocusData1_getSampleSize(int *len, int **n, void *data);

#endif /* LOCUS_DATA_I_H */

