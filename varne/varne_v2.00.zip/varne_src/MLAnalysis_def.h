/*
 * Created on 13 October 2017, 20:02
 */

#ifndef MLANALYSIS_DEF_H
#define MLANALYSIS_DEF_H

#include <stdbool.h>

#include "io/file_reader.h"

struct MLAnalysis {
    char *algorithmName;//this needs to be freed by matrixalloc_1d_free
    int numSearches;
    int maxNumOfFuncEvaluations;
    double maxExecutionTime;
    
    int numNoImprove;
    int maxNumImprove;
    
    double relTolerance;
    
    int numParam;
};

struct MLAnalysis * MLAnalysis_new(void);

void MLAnalysis_readControlFile(struct MLAnalysis *mla, file_reader_t *reader, int *line_id, char **msg);

/**
 * This must be called after ml_analysis_impl_get_ml_param(). On return ptr[0] is set to NULL.
 */
void MLAnalysis_free(struct MLAnalysis **ptr);

#endif /* ML_ANALYSIS_IMPL_H */

