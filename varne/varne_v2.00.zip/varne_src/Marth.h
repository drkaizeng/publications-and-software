/*
 * Created on 30 September 2018, 19:02
 */

#ifndef MARTH_H
#define MARTH_H

#include "Coefficient.h"

typedef struct Marth * Marth_t;

/**
 * <ul>
 * <li> n >= 2
 * <li> H = 1 is the equilibrium model. In this case co is not affected
 * <li> co does not have to contain n.
 * <\ul>
 * @return 
 */
Marth_t Marth_new(int n, int H);

Marth_t Marth_clone(Marth_t m);

/**
 * If H > 1, this function also runs coeff_delref(m->co).
 */
void Marth_free(Marth_t *m);

/**
 * If H = 1, phi[i] = f/(i+1) and dphi[0][i] = 1/(i+1)
 * 
 * @param phi Of size n - 1. The mean length of branches of size i.  <br>
 *            If folded, then only the first n/2 elements should be used on return.
 * @param dphi Dimension: (2H - 1) * (n - 1). dphi[j][i] = d(phi[i])/d(param[j]). <br>
 *             If the derivatives are not needed, supply NULL. <br>
 *             If folded, then only the first n/2 elements in each row should be used on return.
 * @param x Of size 2H - 1. Parameters should be ordered as: f, g_1, ..., g_{H-1}, tau_1, ..., tau_{H-1}. <br>
 *          When H = 1, f is the only parameter.
 * @param derivative Of size 2H - 1. If getDerivative[j] = true, then dphi[j] is calculated. This is not used when dphi = NULL.
 * @param m
 */
void Marth_get(double *phi, double **dphi, const double *x, const bool *derivative, bool folded, double **w, Marth_t m);

#endif /* MARTH_H */

