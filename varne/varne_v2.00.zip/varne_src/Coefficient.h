/*
 * Created on 30 September 2018, 18:16
 */

#ifndef COEFFICIENT_H
#define COEFFICIENT_H

#include <stdbool.h>

/**
 * This is for calculating W_i(j) = j(j-1)B_i(j) using recursion.
 */

typedef struct Coefficient * Coefficient_t;

/**
 * This creates an empty object.
 */
Coefficient_t Coefficient_new(void);

Coefficient_t Coefficient_clone(Coefficient_t co);

/**
 * On return, co points to NULL.
 */
void Coefficient_free(Coefficient_t *co);

/**
 * Add a new sample size to this object.
 * <p>
 * Return false if
 * <ul>
 * <li> n &lt; 2
 * <li> n is already in the object
 * </ul>
 * Otherwise true is returned
 */
bool Coefficient_add(int n, Coefficient_t co);

/**
 * <ul>
 * <li> If n is in the object, then the returned id is the order in which the sample
 * size was added (0-based).
 * <li> Otherwise, -(insertion point - 1) is returned.
 * </ul>
 */
int Coefficient_getID(int n, Coefficient_t co);

/**
 * w[i-1][j-2] is the W_i(j). i=1..(n-1); j=2..n. W_i(j) = j(j-1)B_i(j)
 * <p>
 * <b>Important:</b> The returned value should be strictly read-only.
 * 
 * @param id See coeff_id() for definition
 */
double ** Coefficient_getW(int id, Coefficient_t co);

int Coefficient_getSize(Coefficient_t co);

/**
 * All the sample sizes.
 * <ul>
 * <li> n should be of size coeff_size
 * <li> if coeff_size = 0, n is ignored and the function does nothing.
 * </ul>
 */
void Coefficient_getSampleSizes(int *n, Coefficient_t co);


#endif /* COEFFICIENT_H */

