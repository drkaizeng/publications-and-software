/*
 * Created on 16 October 2018, 17:59
 */
#include <limits.h>
#include <math.h>
#include <string.h>
#include <stdint.h>

#include "Locus2.h"

#include "Marth.h"
#include "PrintErrorMessage.h"
#include "Coefficient.h"

#include "util/error_msg.h"
#include "util/matrixalloc.h"
#include "util/arrayutil.h"
#include "util/string_util.h"

struct Locus2Executor {
    int H;//the total number of epochs. H=1 for a constant population
    
    Coefficient_t co;
    int len;//the number of marth objects
    /**
     * <ul>
     * <li> each object is for a "unique" sample size
     * <li> marth[i] correspond to the i-th sample size in co. Thus, w_id = i
     * </ul>
     */
    Marth_t *marth;
    
    /**
     * Of length len * (n - 1). 
     * <p>
     * Unfolded:
     * psi[i] = m theta phi[i] 
     * <p>
     * Folded:
     * Psi[i] = m theta Phi[i]
     */
    double **phi;
    /**
     * Of length len * (n - 1)
     * <p>
     * This is for adding errors to the SFS
     */
    double **errArray;
    size_t *errArraySize;
    /**
     * <ul>
     * <li> The number of parameters in dPhi and dEta
     * <li> numParam = 2 * H (f, g_1, ..., g_{H-1}, tau_1, ..., tau_{H-1}, err)
     * </ul>
     */
    int Hx2;
    /**
     * Parameters: (f, g_1, ..., g_{H-1}, tau_1, ..., tau_{H-1}, err) <br>
     * Dimension: len * Hx2 * (n - 1)
     * <p> 
     * Unfolded:
     * dphi[j][i] = d(phi[i])/d(param[j]). 
     * <p>
     * Folded: 
     * dphi[j][i] = d(Phi[i])/d(param[j]). 
     * <p>
     * All elements should be set to zero on initialisation. 
     * This is because, for a given sfs[i], its derivative is non-zero wrt some of the parameters.
     * These are not calculated, but may be used in the calculation of the partial derivative of the likelihood function.
     */
    double ***dPhi;
    /**
     * 2H <br>
     * The ID of ERROR in x and grad supplied
     */
    int errID;
    /**
     * 2H-1 <br>
     * The ID of ERROR in dPhi
     */
    int dPhiErrID;
    int cID;
    int tID;
};

/*
 * @since 2018.10.17
 */
static void freeParam(void **param) {
    struct Locus2Executor *se = (struct Locus2Executor *) param[0];
    param[0] = NULL;
    
    for (int i = 0; i < se->len; i++) {
        M2D_FREE(se->dPhi[i]);
        M1D_FREE(se->errArray[i]);
        M1D_FREE(se->phi[i]);
        Marth_free(&(se->marth[i]));
    }
    M1D_FREE(se->dPhi);
    M1D_FREE(se->errArraySize);
    M1D_FREE(se->errArray);
    M1D_FREE(se->phi);
    M1D_FREE(se->marth);
    Coefficient_free(&(se->co));
    M1D_FREE(se);
}

/*
 * @since 2018.10.17
 */
static void * clone(void *param) {
    struct Locus2Executor *se = (struct Locus2Executor *) param;
    
    struct Locus2Executor *re;
    M1D_NEW(re, 1);
    
    *re = *se;
    
    int H = re->H;
    
    re->co = Coefficient_clone(se->co);
    
    int len = Coefficient_getSize(se->co);
    if (len <= 0)
        ERROR_MSG_LMA("ERROR");
    int n_lst[len];
    Coefficient_getSampleSizes(n_lst, se->co);
    M1D_NEW(re->marth, re->len);
    M1D_NEW(re->phi, re->len);
    M1D_NEW(re->errArray, re->len);
    M1D_CLONE(re->errArraySize, se->errArraySize, re->len);
    M1D_NEW(re->dPhi, re->len);
    for (int i = 0; i < re->len; i++) {
        re->marth[i] = Marth_clone(se->marth[i]);
        M1D_CLONE(re->phi[i], se->phi[i], n_lst[i] - 1);
        M1D_CLONE(re->errArray[i], se->errArray[i], n_lst[i] - 1);
        M2D_CLONE(re->dPhi[i], se->dPhi[i], 2 * H, n_lst[i] - 1);
    }
    
    return re;
}

/*
 * nx is the length of grad and x and derivative
 * @since 2018.10.17
 */
static double full_like(double *grad, double *phi, double **dphi, int sfsLen, double *sfs, int errID, const bool *derivative, double theta, double m, bool folded) {
    double lnlike = 0;
    for (int i = 0; i < sfsLen; i++) {
        double psi = theta * phi[i];
        lnlike += -psi + sfs[i] * log(psi);
    }
    if (grad != NULL) {
        int lastParam = (folded == true ? errID : errID + 1);//if folded, then this doesn't contribute to d(L)/d(err)
        for (int i = 0; i < sfsLen; i++) {
            double psi = theta * phi[i];
            psi = (-1 + sfs[i] / psi);
            for (int j = 0; j < lastParam; j++) {
                if (derivative[j] == true) { 
                    double dpsi;
                    if (j == 0) {//theta
                        dpsi = m * phi[i];
                    } else {
                        dpsi = theta * dphi[j - 1][i];
                    }
                    grad[j] += psi * dpsi;
                } 
            }
        }
    }
    return lnlike;
}


/**
 * re[i] = (1 - err) * re[i] + err * re[len - i]
 * @since 2018.10.9, 10.17, 10.17 (copied from Locus1Executor; checked)
 */
static void addErrorWork(int n, double *re, double err, double *arr, size_t arrSize) {
    double noErr = 1 - err;
    for (int i = 1, i1 = 0, ni1 = n - 2; i < n; i++, i1++, ni1--)
        arr[i1] = noErr * re[i1] + err * re[ni1];
    memcpy(re, arr, arrSize);
}

/*
 * <ul>
 * <li> err_id: id of err in dphi, which does not contain theta
 * <li> der2 does not consider theta
 * </ul>
 * @since 2018.10.9, 10.17 (added test for err>0), 10.17 (copied from Locus1Executor; checked)
 */
static void addError(double *phi, double **dphi, int n, double err, int dPhiErrID, const bool *der2, double *arr, size_t arrSize) {
    if (dphi != NULL) {
        if (err > 0) {
            for (int j = 0; j < dPhiErrID; j++) {
                if (der2[j] == true)
                    addErrorWork(n, dphi[j], err, arr, arrSize);
            }
        }
        if (der2[dPhiErrID] == true) {
            for (int i = 1, i1 = 0, ni1 = n - 2; i < n; i++, i1++, ni1--) {
                dphi[dPhiErrID][i1] = -phi[i1] + phi[ni1];
            }
        }
    }
    /* phi */
    if (err > 0) {
        addErrorWork(n, phi, err, arr, arrSize);
    }
}

/*
 * @since 2018.10.17
 */
static double lnlike(double *grad, const double *x, const bool *derivative, Locus_t loc, void *param) {
    struct Locus2Executor *se = (struct Locus2Executor *) param;
    struct Locus2 *sl = (struct Locus2 *) loc->typeParam;
    
    struct LocusData2 *data = sl->data;
    int *id = sl->id;
    
    double re = 0;

    const double *x2 = x + 1;//f, g_1, ..., g_{H-1}, tau_1, ..., tau_{H-1}, err
    const bool *der2 = derivative + 1;
        
    double err = x[se->errID];

    for (int k = 0; k < data->len; k++) {
        double *phi = se->phi[id[k]];
        double **dphi = (grad == NULL ? NULL : se->dPhi[id[k]]);
        double m = data->m[k];
        int sfsLen = data->sfsLen[k];
        double *sfs = data->sfs[k];
        bool folded = data->folded[k];
        double **w = Coefficient_getW(id[k], se->co);
        Marth_get(phi, dphi, x2, der2, folded, w, se->marth[id[k]]);
        if (folded == false) {
            addError(phi, dphi, data->n[k], err, se->dPhiErrID, der2, se->errArray[id[k]], se->errArraySize[id[k]]);
        }
        double theta = data->m[k] * x[0];
        re += full_like(grad, phi, dphi, sfsLen, sfs, se->errID, derivative, theta, m, folded);
    }
    
    if (data->md > 0) {
        double f = x[1];
        double c = x[se->cID];
        double t = x[se->tID];
        
        double theta = data->md * x[0];
        double lambda = theta * (c * f + t);
        
        re += -lambda + data->sub * log(lambda);
        
        if (grad != NULL) {
            double tmp = -1 + data->sub / lambda;
            if (derivative[0] == true) {//theta
                grad[0] += tmp * lambda / x[0];
            }
            if (derivative[1] == true) {//f
                grad[1] += tmp * theta * c;
            }
            if (derivative[se->cID] == true) {
                grad[se->cID] += tmp * theta * f;
            }
            if (derivative[se->tID] == true) {
                grad[se->tID] += tmp * theta;
            }
        }
    }
    return re;
}

/*
 * @since 2018.10.
 */
static void * extraFunction(const char *cmd, Locus_t loc, void *param, char **msg, va_list args) {
    msg[0] = NULL;

    PRINT_ERRMSG(msg, "Unknown command = %s\n", cmd);
    return NULL;
}


/*
 * Parameter: int len, locus_t *loc
 * @since 2018.10.17
 */
LocusExecutor_t Locus2Executor_new(va_list args) {
    int numLoc = va_arg(args, int);
    if (numLoc <= 0)
        ERROR_MSG_LMA("ERROR");
    Locus_t *loc = va_arg(args, Locus_t *);
    
    int H = ((struct Locus2 *) loc[0]->typeParam)->H;
    
    struct Locus2Executor *se;
    M1D_NEW(se, 1);
    
    se->H = H;
    
    se->co = Coefficient_new();
    for (int i = 0; i < numLoc; i++) {
        char *msg;
        void **data = Locus_extraFunction("sampleSizes", loc[i], &msg);
        if (msg != NULL)
            ERROR_MSG_LMA("ERROR");
        int num = ((int *) data[0])[0];
        M1D_FREE(data[0]);
        int *n = data[1];
        M1D_FREE(data);
        for (int j = 0; j < num; j++)
            Coefficient_add(n[j], se->co);
        M1D_FREE(n);
    }
    
    se->len = Coefficient_getSize(se->co);
    if (se->len == 0)
        ERROR_MSG_LMA("ERROR");
    int n_lst[se->len];
    Coefficient_getSampleSizes(n_lst, se->co);
    M1D_NEW(se->marth, se->len);
    M1D_NEW(se->phi, se->len);
    M1D_NEW(se->errArray, se->len);
    M1D_NEW(se->errArraySize, se->len);
    se->Hx2 = 2 * H;
    M1D_NEW(se->dPhi, se->len);
    for (int i = 0; i < se->len; i++) {
        se->marth[i] = Marth_new(n_lst[i], H);
        M1D_NEW(se->phi[i], n_lst[i] - 1);
        M1D_NEW(se->errArray[i], n_lst[i] - 1);
        se->errArraySize[i] = (size_t) (n_lst[i] - 1) * sizeof(*se->errArray[i]);
        M2D_NEW(se->dPhi[i], se->Hx2, n_lst[i] - 1);
        int cnt = se->Hx2 * (n_lst[i] - 1);
        AU_FILL2(se->dPhi[i][0], 0, cnt, 0);
    }
    se->errID = 2 * H;
    se->dPhiErrID = 2 * H - 1;
    se->cID = 2 * H + 1;
    se->tID = 2 * H + 2;
    
    for (int i = 0; i < numLoc; i++) {
        struct Locus2 *sl = (struct Locus2 *) loc[i]->typeParam;
        struct LocusData2 *data = sl->data;
        for (int j = 0; j < data->len; j++) {
            sl->id[j] = Coefficient_getID(data->n[j], se->co);
        }
    }
    
    struct LocusExecutor *exec;
    M1D_NEW(exec, 1);
    
    exec->param = se;
    exec->freeParam = freeParam;
    exec->clone = clone;
    exec->lnlike = lnlike;
    exec->extraFunction = extraFunction;
    
    return exec;
}