/*
 * Created on 17 October 2018, 14:04
 */

#ifndef MODEL2_DEF_H
#define MODEL2_DEF_H

#include "Locus.h"
#include "Constraint.h"

#include "io/file_reader.h"

#include "nlopt.h"

typedef void (* freeNloptConstraintsData_f)(void **);

struct Model2InputParamRanges {
    int len;//7
    /** THETA, F, G, TAU, ERROR, C, T */
    enum ParameterType types[7];
    /** THETA, F, G, TAU, ERROR, C, T; on the original scale */
    double ranges[2][7];
};

struct Model2 {
    /* The following are updated by readControlFile() */
    int H;
    int numLoci;
    struct Model2InputParamRanges *inputRanges;
    char *constraintName;
    /**
     * The default is "random"
     */
    char *initMethodName;
    int numThreads;
    int sched;//default value = 1
    int chunkSize;//default value = 1
    
    Locus_t *loci;
    /* End updated by readControlFile() */
    
    
    /**
     * The total number of parameters without any constraints. 
     */
    int nx;
    /**
     * Of length nx. On the original scale. 
     */
    double *x;
    /**
     * Of length nx. The indices of the parameters in x in the input array supplied to lnlike.
     * This is for setting constraints. If xi[i] = -1, the corresponding parameter
     * is a constant. If xi[i] = -2, the corresponding parameter is a function specified by constraints below.
     */
    int *xi;
    /**
     * Of length nx. If derivative[i] = true, then derivative is calculated.
     */
    bool *derivative;
    /**
     * Of length nx. This should be set to 0 before calculating the likelihood
     */
    double *dx;
    /**
     * Of length nx.
     */
    double *nxZeros;
    size_t nxZerosSize;
    /**
     * Of length numLoci. offset[i] gives the index of the first parameter for locus i in x, xi, etc.
     */
    int *offset;
    /**
     * There are nx elements. These are for setting non-constant value constraints.
     * cf[j] is the constraint functions x[j] = cf(cf->x). The parameters are defined on the original scale.
     * The xi's in cf are defined wrt x here. This is the full model in the current case.
     */
    struct Constraint **constraints;
    
    /**
     * The number of parameters to be optimised
     */
    int numParam;
    enum ParameterType *paramTypes;
    char **paramNames;
    /**
     * <ul>
     * <li> The scale of the values are as described in Model_getLikelihood()
     * <li> paramRanges[0]: the lower bounds
     * <li> paramRanges[1]: the upper bounds
     * </ul>
     */
    double **paramRanges;
    /*
     * The size of numParam double zeros
     */
    size_t numParamZerosSize;
    
    int numNloptConstraints;
    /**
     * If true, then the corresponding constraint in nloptConstraints is an equality constraint
     */
    bool *isEqualityConstraint;
    nlopt_func *nloptConstraints;
    void **nloptConstraintsData;
    freeNloptConstraintsData_f *freeNloptConstraintData;
    
    /**
     * An array of size numThreads
     */
    LocusExecutor_t *exec;
    
    int initMethod;//0=random; 1=given
    /**
     * Not NULL if, initMethod=1. There should be numParam elements and the scale is defined as Model_getLikelihood().
     */
    double *givenInitValues;
};

/**
 */
void Model2_readControlFile(struct Model2 *re, file_reader_t *reader, int *lineID, char **msg);
void Model2_build(struct Model2 *re, char **msg);



struct Model2InputParamRanges * Model2InputParamRanges_new(void);
void Model2InputParamRanges_free(struct Model2InputParamRanges **inputRanges);


/**
 * lo and hi are on the original scale.
 */
void Model2InputParamRanges_add(int id, double lo, double hi, char **msg, struct Model2InputParamRanges *inputRanges);
/**
 * lo and hi are on the original scale.
 */
void Model2InputParamRanges_get(double *lo, double *hi, enum ParameterType type, struct Model2InputParamRanges *inputRanges);



double Model2_scaleParam(enum ParameterType type, double v);
double Model2_getJacobian(enum ParameterType type, double v);
double Model2_unscaleParam(enum ParameterType type, double v);

#endif /* MODEL2_DEF_H */

