#include <stdlib.h>
#include <stdio.h>

#include "event.h"

#include "util/matrixalloc.h"

struct event_tag {
    event_name_t name;
    /**
     * Time, in units of the reference haploid population size, to the present
     */
    double time;
    void *param;
    event_t *next;
};

static const event_t EVENT_INIT = {
    .name = event_name_init, 
    .time = -1, 
    .param = NULL, 
    .next = NULL
};

struct event_list_tag {
    /**
     * Points to the head of the list. For an empty list, head = NULL. For a list
     * with only one event, header holds its info.
     */
    event_t *head;
    /**
     * Points to the event that are being dealt with. For an empty list, iterator = NULL.
     */
    event_t *iterator;
    /**
     * Points to the last event. For any empty list, end = NULL.
     */
    event_t *end;
};

static const event_list_t LIST_INIT = {
    .head = NULL,
    .iterator = NULL,
    .end = NULL
};

typedef struct {
    int pop1;
    int pop2;
} pop_merger_param_t;

typedef struct {
    /**
     * Index of the population whose size is to be changed [0, npop-1]
     * If pop = -1, then all existing subpopulations' sizes are changed to new_size
     */
    int pop;
    /**
     * Expressed relative to the reference haploid size.
     */
    double new_size;
} pop_size_change_param_t;

/**
 * @since 2015.2.8, 2.11
 */
static event_t * event_new(void) {
    event_t *re = matrixalloc_1d(1, sizeof (event_t));
    (*re) = EVENT_INIT;
    return re;
}

#define CLONE_PARAM(PARAM_TYPE) \
        { \
            PARAM_TYPE *p1 = matrixalloc_1d(1, sizeof (PARAM_TYPE)); \
            PARAM_TYPE *p2 = (PARAM_TYPE *) src->param; \
            (*p1) = (*p2); \
            re->param = p1; \
        }

/**
 * This clones the name, time, and param, and set next to NULL.
 * @since 2015.2.11
 */
static event_t * event_clone(const event_t *src) {
    event_t *re = event_new();
    re->name = src->name;
    re->time = src->time;
    if (src->name == event_name_pop_merger) {
        CLONE_PARAM(pop_merger_param_t);
    } else if (src->name == event_name_pop_size_change) {
        CLONE_PARAM(pop_size_change_param_t);
    } else {
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    return re;
}

/*
 * @since 2015.2.12
 */
static void event_free(event_t *e) {
    matrixalloc_1d_free(e->param);
    matrixalloc_1d_free(e);
}

/*
 * @since 2015.2.8, 2.11
 */
event_list_t * event_list_new(void) {
    event_list_t *re = matrixalloc_1d(1, sizeof (event_list_t));
    (*re) = LIST_INIT;
    return re;
}

/*
 * @since 2015.2.12
 */
void event_list_free(event_list_t *list) {
    if (list != NULL) {
        event_list_iterator_reset(list);
        event_t *e;
        while ((e = event_list_iterator_next(list)) != NULL) {
            event_free(e);
        }
        matrixalloc_1d_free(list);
    }
}

/**
 * Append a new event to the end of the list. It is assume that event->next
 * has an undetermined value. The parameter is used without defensive copying.
 * @since 2015.2.11
 */
static void event_list_append(event_list_t *list, event_t *event) {
    if (list->head == NULL) {
        if (event->time < 0) {
            fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
            abort();
        }
        list->head = event;
        list->head->next = NULL;
        list->iterator = list->head;
        list->end = list->head;
    } else {
        if (event->time < list->end->time) {
            fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
            abort();
        }
        list->end->next = event;
        list->end = event;
        list->end->next = NULL;
    }
}

/*
 * @since 2015.2.11
 */
event_list_t * event_list_clone(const event_list_t *src) {
    event_list_t *re = NULL;
    if (src != NULL) {
        re = event_list_new();
        event_t *e = src->head;
        while (e != NULL) {
            event_t *next = event_clone(e);
            event_list_append(re, next);
            e = e->next;
        }
    }
    return re;
}

/*
 * @since 2015.2.11
 */
void event_list_iterator_reset(event_list_t *list) {
    if (list != NULL) {
        list->iterator = list->head;
    }
}

/*
 * @since 2015.2.11
 */
event_t * event_list_iterator_next(event_list_t *list) {
    if (list == NULL || list->iterator == NULL) {
        return NULL;
    } else {
        event_t *re = list->iterator;
        list->iterator = list->iterator->next;
        return re;
    }
}

/*
 * @since 2015.2.12
 */
event_name_t event_get_name(const event_t *e) {
    return e->name;
}

/*
 * @since 2015.2.11
 */
double event_get_time(const event_t *e) {
    return e->time;
}

/*
 * @since 2015.2.11
 */
void event_list_add_pop_merger(event_list_t *list, double time, int pop1, int pop2) {
    if (pop1 < 0 || pop2 <= pop1) {
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    event_t *e = event_new();
    e->name = event_name_pop_merger;
    e->time = time;
    pop_merger_param_t *param = matrixalloc_1d(1, sizeof (pop_merger_param_t));
    param->pop1 = pop1;
    param->pop2 = pop2;
    e->param = param;
    event_list_append(list, e);
}

/*
 * @since 2015.2.12
 */
void event_get_param_pop_merger(const event_t *e, int *pop1, int *pop2) {
    pop_merger_param_t * param = (pop_merger_param_t *) e->param;
    (*pop1) = param->pop1;
    (*pop2) = param->pop2;
}

/*
 * @since 2015.2.11, 6.11
 */
void event_list_add_pop_size_change(event_list_t *list, double time, int pop, double new_size) {
    if (pop < -1 || new_size <= 0) {
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    event_t *e = event_new();
    e->name = event_name_pop_size_change;
    e->time = time;
    pop_size_change_param_t *param = matrixalloc_1d(1, sizeof (pop_size_change_param_t));
    param->pop = pop;
    param->new_size = new_size;
    e->param = param;
    event_list_append(list, e);
}

/*
 * @since 2015.2.12
 */
void event_get_param_pop_size_change(const event_t *e, int *pop, double *new_size) {
    pop_size_change_param_t * param = (pop_size_change_param_t *) e->param;
    (*pop) = param->pop;
    (*new_size) = param->new_size;
}

/*
 * @since 2015.6.11 (size change)
 */
bool event_list_check_pop_indx(const event_list_t *list, int init_npop, event_name_t *name, 
        double *time, int *pop) {
    int npop = init_npop;
    const event_t *e = list->head;
    while (e != NULL) {
        event_name_t n = event_get_name(e);
        if (n == event_name_pop_merger) {
            int pop1, pop2;
            event_get_param_pop_merger(e, &pop1, &pop2);
            if (pop2 >= npop) {
                (*name) = event_name_pop_merger;
                (*time) = event_get_time(e);
                (*pop) = pop2;
                return true;
            }
            npop--;
        } else if (n == event_name_pop_size_change) {
            int p;
            double new_size;
            event_get_param_pop_size_change(e, &p, &new_size);
            if (p >= npop) {
                (*name) = event_name_pop_size_change;
                (*time) = event_get_time(e);
                (*pop) = p;
                return true;
            }
        } else {
            fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
            abort();
        }
        e = e->next;
    }
    return false;
}