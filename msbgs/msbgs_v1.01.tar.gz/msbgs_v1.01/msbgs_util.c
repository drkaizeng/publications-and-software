#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#include "msbgs_util.h"

#include "node.h"
#include "frag.h"
#include "msbgs_def.h"

#include "util/matrixalloc.h"
#include "util/arrayutil.h"

#include "gsl/gsl_randist.h"

struct msbgs_util_site_data_tag {
    /**
     * The site under consideration. [0, leng-1]
     */
    int site;
    /**
     * Sample size used in the simulation
     */
    int nsam;
    int max_nnodes;
    size_t tree_mem_size;
    /**
     * The tree at the site.
     */
    node_t *tree;
    /**
     * This equals to the number of true's in in_subtree;
     */
    int subtree_nsam;
    int subtree_max_nnodes;
    node_t *subtree;
};

/*
 * @since 2015.2.8, 2.17
 */
msbgs_util_site_data_t * msbgs_util_site_data_new(const msbgs_t *msb, int site) {
    if (frag_list_size(msb->frag_list) <= 0) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    if (site < 0 || site >= msb->leng) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    
    msbgs_util_site_data_t *re = matrixalloc_1d_init(1, sizeof (msbgs_util_site_data_t));
    re->site = site;
    re->nsam = msb->nsam;
    re->max_nnodes = msb->nsam * 2 - 2;
    frag_t *f = frag_list_find(msb->frag_list, site);
    re->tree_mem_size = (size_t) (re->max_nnodes + 1) * sizeof (node_t);
    re->tree = frag_clone_tree(f);
    re->subtree = NULL;
    return re;
}

/*
 * @since 2015.2.8, 2.17
 */
void msbgs_util_site_data_free(msbgs_util_site_data_t *sd) {
    matrixalloc_1d_free(sd->tree);
    matrixalloc_1d_free(sd->subtree);
    matrixalloc_1d_free(sd);
}

/**
 * @param tree An node_t array of size 2 * nsam - 1
 * @param nsam Sample size
 * @param max_nnodes 2 * nsam - 2
 * @return Total tree length
 * @since 2015.2.8 (n=2)
 */
static double site_tree_length(const node_t *tree, int nsam, int max_nnodes) {
    double t = (tree + max_nnodes)->time;
    for (int i = nsam; i <= max_nnodes; i++)
        t += tree[i].time;
    return t;
}

/**
 * @return The sum of all external branches.
 * @since 2015.4.1
 */
static double site_tree_ext_length(const node_t *tree, int nsam) {
    double sum = 0;
    for (int i = 0; i < nsam; i++) {
        sum += tree[tree[i].abv].time;
    }
    return sum;
}

/*
 * @since 
 */
double msbgs_util_site_tree_length(const msbgs_util_site_data_t *sd) {
    return site_tree_length(sd->tree, sd->nsam, sd->max_nnodes);
}

/*
 * @since 
 */
double msbgs_util_site_tree_tmrca(const msbgs_util_site_data_t *sd) {
    return (sd->tree + sd->max_nnodes)->time;
}

/*
 * @since 2015.4.1
 */
double msbgs_util_site_tree_ext_length(const msbgs_util_site_data_t *sd) {
    return site_tree_ext_length(sd->tree, sd->nsam);
}

/*
 * @since 2015.3.6
 */
static void site_sfs(const node_t *tree, int nsam, int max_nnodes, double *sfs) {
    int cn[max_nnodes + 1];
    arrayutil_fill_i(cn, 0, max_nnodes + 1, 0);
    for (int i = 0; i < nsam; i++) {
        int des = i;
        int abv = tree[des].abv;
        do {
            if (abv < 0 || abv > max_nnodes) {
                fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
                abort();
            }
            cn[des]++;
            if (abv == max_nnodes) {
                cn[max_nnodes]++;
                break;
            } else {
                des = abv;
                abv = tree[des].abv;
            }
        } while (true);
    }
    if (cn[max_nnodes] != nsam) {
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    arrayutil_fill_d(sfs, 0, nsam - 1, 0);
    for (int i = 0; i < max_nnodes; i++) {
        sfs[cn[i] - 1] += (tree[tree[i].abv].time - tree[i].time);
    }
}

/*
 * @since 2015.3.6
 */
void msbgs_util_site_tree_sfs(msbgs_util_site_data_t *sd, double *sfs) {
    site_sfs(sd->tree, sd->nsam, sd->max_nnodes, sfs);
}

/** 
 * @since 2015.2.17, 3.27
 */
void msbgs_util_site_subtree(msbgs_util_site_data_t *sd, bool *in_subtree) {
    typedef struct {
        /**
         * id of active node in the old tree
         */
        int old_node_id;
        /**
         * id of the node in the subtree. id = -1 if this node is not in the subtree.
         */
        int new_node_id;
    } node_id_t;
    
    sd->subtree_nsam = 0;
    for (int i = 0; i < sd->nsam; i++) {
        if (in_subtree[i] == true) {
            sd->subtree_nsam++;
        }
    }
    if (sd->subtree_nsam < 2) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    sd->subtree_max_nnodes = sd->subtree_nsam * 2 - 2;
    if (sd->subtree == NULL) {
        sd->subtree = matrixalloc_1d(1, sd->tree_mem_size);
    }
    if (sd->subtree_nsam == sd->nsam) {
        matrixalloc_1d_cpy2(sd->subtree, sd->tree, sd->tree_mem_size);
    } else {
        /* the active nodes in the new tree */
        int active[sd->subtree_nsam];
        int active_leng = sd->subtree_nsam;
        for (int i = 0; i < sd->subtree_nsam; i++) {
            active[i] = i;
            sd->subtree[i].time = 0;
        }
        sd->subtree[sd->subtree_max_nnodes].abv = -1;
        int abv_ptr = sd->subtree_nsam;
        node_id_t node_id[sd->nsam];
        int node_id_leng = sd->nsam;
        for (int i = 0, j = 0; i < sd->nsam; i++) {
            node_id[i].old_node_id = i;
            if (in_subtree[i] == true) {
                node_id[i].new_node_id = j;
                j++;
            } else {
                node_id[i].new_node_id = -1;
            }
        }
        int arr[2];
        for (int i = sd->nsam; i <= sd->max_nnodes; i++) {//the first CA node is stored in the max-th element, the second is in the (max+1)-th, etc
            int ptr = 0;
            for (int j = 0; j < node_id_leng; j++) {
                if (sd->tree[node_id[j].old_node_id].abv == i) {
                    if (ptr >= 2) {
                        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
                        abort();
                    }
                    arr[ptr] = j;
                    ptr++;
                }
            }
            if (ptr != 2) {
                fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
                abort();
            }
            int m0 = node_id[arr[0]].new_node_id;
            int m1 = node_id[arr[1]].new_node_id;
            /* move last element to arr[0] */
            node_id_leng--;
            node_id[arr[0]] = node_id[node_id_leng];
            if (arr[1] == node_id_leng) {
                arr[1] = arr[0];
            }
            /* move last element to arr[1] */
            node_id_leng--;
            node_id[arr[1]] = node_id[node_id_leng];
            if (m0 >= 0 && m1 >= 0) {// a coalescent in the sub-tree
                sd->subtree[m0].abv = abv_ptr;
                sd->subtree[m1].abv = abv_ptr;
                sd->subtree[abv_ptr].time = sd->tree[i].time;
                ptr = 0;
                for (int j = 0; j < active_leng; j++) {
                    if (active[j] == m0 || active[j] == m1) {
                        if (ptr >= 2) {
                            fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
                            abort();
                        }
                        arr[ptr] = j;
                        ptr++;
                    }
                }
                if (ptr != 2) {
                    fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
                    abort();
                }
                active_leng--;
                active[arr[0]] = active[active_leng];
                if (arr[1] == active_leng) {
                    arr[1] = arr[0];
                }
                active_leng--;
                active[arr[1]] = active[active_leng];
                if (active_leng == 0) {
                    break;
                } else {
                    active[active_leng] = abv_ptr;
                    active_leng++;
                    node_id[node_id_leng].old_node_id = i;
                    node_id[node_id_leng].new_node_id = abv_ptr;
                    node_id_leng++;
                    abv_ptr++;
                }
            } else {
                node_id[node_id_leng].old_node_id = i;
                if (m0 >= 0) {
                    node_id[node_id_leng].new_node_id = m0;
                } else if (m1 >= 0) {
                    node_id[node_id_leng].new_node_id = m1;
                } else {
                    node_id[node_id_leng].new_node_id = -1;
                }
                node_id_leng++;
            }
        }
    }
}

/*
 * @since 2015.2.8 (n=2)
 */
double msbgs_util_site_subtree_length(const msbgs_util_site_data_t *sd) {
    if (sd->subtree == NULL) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    return site_tree_length(sd->subtree, sd->subtree_nsam, sd->subtree_max_nnodes);
}

/*
 * @since 2015.2.8 (n=2), 2.17
 */
double msbgs_util_site_subtree_tmrca(const msbgs_util_site_data_t *sd) {
    if (sd->subtree == NULL) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    return (sd->subtree + sd->subtree_max_nnodes)->time;
}

/*
 * @since 
 */
void msbgs_util_site_subtree_sfs(msbgs_util_site_data_t *sd, double *sfs) {
    if (sd->subtree == NULL) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    site_sfs(sd->subtree, sd->subtree_nsam, sd->subtree_max_nnodes, sfs);
}




struct msbgs_util_seq_tag {
    /** 
     * Size of the entire simulated region
     */
    int leng;
    int nsam;
    int max_nnodes;//nsam * 2 - 2
    /**
     * see msbgs_param_t->thpns
     */
    double thpns;
    /**
     * cumm_neu[i] = the total number of neutral sites from site 0 to site i 
     * (i from 0 to leng-1, where leng is the size of the entire simulated region)
     */
    int *cumm_neu;
    /**
     * cumm_bl[i] = the total length of all branches up to the node with index i
     */
    double *cumm_bl;
    /**
     * This is an array with cumm_neu[leng-1] elements.
     * pos_neu[i] = position_of_neutral_site_i / leng; position starts from 0 to leng-1
     */
    double *pos_neu;
    /**
     * seq[i] points to the i-th sequence
     */
    char **seq;
    /**
     * The number of sites stored in each array in seq.
     */
    int seq_leng;
    /**
     * Maximum sequence length
     */
    int seq_capacity;
    /**
     * Positions in [0, 1] of the neutral variants. [0, 1] defines the entire simulated region.
     */
    double *pos;
};

/*
 * @since 2015.6.11, 6.14
 */
msbgs_util_seq_t * msbgs_util_seq_new(const msbgs_param_t *param, double thpns, int init_capacity) {
    if (param->nsam < 2 || init_capacity < 1 || thpns <= 0) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort(); 
    }
    msbgs_util_seq_t *re = matrixalloc_1d(1, sizeof (msbgs_util_seq_t));
    
    re->leng = param->leng;
    re->nsam = param->nsam;
    re->max_nnodes = param->nsam * 2 - 2;
    re->thpns = thpns;
    re->cumm_neu = matrixalloc_1d(param->leng, sizeof (int));
    re->cumm_bl = matrixalloc_1d(re->max_nnodes, sizeof (double));
    int cn = 0;
    for (int i = 0; i < param->leng; i++) {
        if (param->state[i] == -1) {
            cn++;
        }
        re->cumm_neu[i] = cn;
    }
    if (cn <= 0) {
        fprintf (stderr, "Error: %s:%d\nNo neutral sites found!\n", __FILE__, __LINE__);
        abort();
    }
    re->pos_neu = matrixalloc_1d(cn, sizeof (double));
    for (int i = 0, j = 0; i < param->leng; i++) {
        if (param->state[i] == -1) {
            re->pos_neu[j] = (double) i / param->leng;
            j++;
        }
    }
    re->seq = matrixalloc_1d(re->nsam, sizeof (char *));
    re->seq_leng = 0;
    re->seq_capacity = init_capacity;
    for (int i = 0; i < re->nsam; i++) {
        re->seq[i] = matrixalloc_1d(re->seq_capacity, sizeof (char));
    }
    re->pos = matrixalloc_1d(re->seq_capacity, sizeof (double));
    
    return re;
}

/*
 * @since 2015.6.11, 6.14
 */
void msbgs_util_seq_free(msbgs_util_seq_t *seq) {
    matrixalloc_1d_free(seq->pos);
    for (int i = 0; i < seq->nsam; i++) {
        matrixalloc_1d_free(seq->seq[i]);
    }
    matrixalloc_1d_free(seq->seq);
    matrixalloc_1d_free(seq->pos_neu);
    matrixalloc_1d_free(seq->cumm_bl);
    matrixalloc_1d_free(seq->cumm_neu);
    matrixalloc_1d_free(seq);
}

/*
 * Increase the capacity of seq and pos
 * @since 2015.6.11, 6.14
 */
static void seq_ensure_capacity(msbgs_util_seq_t *seq, int new_size) {
    if (new_size > seq->seq_capacity) {
        static const int LIMIT = INT_MAX / 2;
        if (new_size >= LIMIT) {
            fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
            abort();
        }
        seq->seq_capacity = new_size * 2;
        size_t mem_size = (size_t) seq->seq_capacity * sizeof (char);
        for (int i = 0; i < seq->nsam; i++) {
            seq->seq[i] = realloc(seq->seq[i], mem_size);
            if (seq->seq[i] == NULL) {
                fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
                abort();
            }
        }
        seq->pos = matrixalloc_1d_realloc(seq->pos, seq->seq_capacity, sizeof (double));
    } else if (new_size <= 0) {
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
}

/*
 * @return total branch length
 * @since 2015.6.11, 6.14
 */
static double seq_cumm_bl(const node_t *tree, int max_nnodes, double *cumm_bl) {
    double sum = 0;
    for (int i = 0; i < max_nnodes; i++) {
        sum += tree[tree[i].abv].time - tree[i].time;
        cumm_bl[i] = sum;
    }
    return sum;
}

/**
 * @return true if tip is a descendant of node
 * @since 2015.6.11, 6.14
 */
static bool is_des(const node_t *tree, int node, int tip) {
    int k;
    for (k = tip; k < node; k = (tree + k)->abv)
        ;
    if (k == node) 
        return true;
    else 
        return false;
}

/*
 * @since 2015.6.11, 6.14
 */
void msbgs_util_seq_gen(const msbgs_t *msb, msbgs_util_seq_t *seq) {
    if (msb->nsam != seq->nsam) {
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    if (frag_list_size(msb->frag_list) <= 0) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    
    frag_list_iterator_reset(msb->frag_list);
    const frag_t *f;
    int beg, end;
    int indx = 0;//points to the column where the first new segsite should be added
    const double sw = 1.0 / seq->leng;//the weight of each site in [0, 1]
    while ((f = frag_list_iterator_next(msb->frag_list)) != NULL) {
        frag_get_limits(f, &beg, &end);
        int ns = seq->cumm_neu[end];
        int indx_neu = 0;//the index of the first neutral site in this fragment. Neutral sites are index wrt the entired simulated region.
        if (beg > 0) {
            indx_neu = seq->cumm_neu[beg - 1];
            ns -= indx_neu;
        } else if (beg < 0) {
            fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
            abort();
        }
        if (ns == 0) {
            continue;
        } 
        const node_t *tree = frag_get_tree(f);
        double ttleng = seq_cumm_bl(tree, seq->max_nnodes, seq->cumm_bl);
        double thn = ttleng * seq->thpns * ns;//total neutral mutation rate
        int nmut = (int) gsl_ran_poisson(msb->ran, thn);
        if (nmut == 0) {
            continue;
        }
        seq_ensure_capacity(seq, indx + nmut);
        for (int i = 0, j = indx, k; i < nmut; i++, j++) {
            k = (int) gsl_rng_uniform_int(msb->ran, (unsigned long) ns);
            seq->pos[j] = seq->pos_neu[indx_neu + k] + gsl_rng_uniform(msb->ran) * sw;
        }
        for (int i = 0; i < nmut; i++) {
            double tmp = gsl_rng_uniform(msb->ran) * ttleng;
            int bi = arrayutil_binary_search_d(seq->cumm_bl, 0, seq->max_nnodes, tmp);
            if (bi < 0) {
                bi = -bi - 1;
            } 
            for (int j = 0; j < seq->nsam; j++) {
                if (is_des(tree, bi, j)) {
                    seq->seq[j][indx] = 1;
                } else {
                    seq->seq[j][indx] = 0;
                }
            }
            indx++;
        }
    }
    seq->seq_leng = indx;
    arrayutil_quick_sort_d(seq->pos, 0, seq->seq_leng);
}

/*
 * @since 2015.6.11
 */
void msbgs_util_seq_print_to_screen(const msbgs_util_seq_t *seq) {
    printf("segsites: %d\n", seq->seq_leng);
    printf("positions:");
    for (int i = 0; i < seq->seq_leng; i++) {
        printf(" %.9f", seq->pos[i]);
    }
    printf("\n");
    for (int i = 0; i < seq->nsam; i++) {
        for (int j = 0; j < seq->seq_leng; j++) {
            printf("%i", seq->seq[i][j]);
        }
        printf("\n");
    }
}

/*
 * @since 2015.6.11
 */
double msbgs_util_get_mean_coal_rate(const msbgs_t *msb) {
    return msb->mean_coal_rate;
}