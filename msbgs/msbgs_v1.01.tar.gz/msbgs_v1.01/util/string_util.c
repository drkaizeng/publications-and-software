#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>

#include "string_util.h"

#include "matrixalloc.h"

/*
 * @since 2015.02.06, 2.17
 */
bool string_util_equal(const char *s1, const char *s2) {
    size_t len = strlen(s1);
    if (strlen(s2) != len) {
        return false;
    } else {
        int re = memcmp(s1, s2, len);
        if (re == 0)
            return true;
        else
            return false;
    }
}

/*
 * @since 2015.02.06, 2.17
 */
char * string_util_clone(const char *s) {
    size_t len = strlen(s) + 1;
    if (len > INT_MAX) {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
    return matrixalloc_1d_clone(s, (int) len, sizeof (char));
}

/*
 * @since 2015.02.06, 2.17
 */
char * string_util_trim(char *s) {
    size_t len = strlen(s);
    if (len >= INT_MAX) {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
    int cn = (int) len - 1;
    while (cn >= 0) {
        if (isspace(s[cn]) == 0)
            break;
        s[cn] = '\0';
        cn--;
    }
    if (cn == -1) {//len = cn + 1
        return s;
    } else {
        cn = 0;
        while (true) {
            if (isspace(*(s + cn)))
                cn++;
            else
                return s + cn;
        }
//        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
//        abort();
    }
}

/*
 * @since 2015.02.04, 2.6, 2.17
 */
char ** string_util_split(char *s1, const char *s2, int *cn) {
    typedef struct ptr_list_tag {
        char *ptr;
        struct ptr_list_tag *next;
    } ptr_list_t;

    size_t s2_len = strlen(s2);
    if (s2_len == 0) {
        (*cn) = 1;
        char **re = matrixalloc_1d((*cn), sizeof (char *));
        re[0] = s1;
        return re;
    } else {
        (*cn) = 0;
        size_t s1_len = strlen(s1);
        char *s1_end = s1 + s1_len;
        ptr_list_t *head = NULL;
        ptr_list_t *this;
        do {
            char *tmp = strstr(s1, s2);
            if (tmp == NULL) {
                if ((*cn) == 0) {
                    (*cn) = 1;
                    char **re = matrixalloc_1d((*cn), sizeof (char *));
                    re[0] = s1;
                    return re;
                } else {
                    ptr_list_t *new = matrixalloc_1d(1, sizeof (ptr_list_t));
                    this->next = new;
                    new->ptr = s1;
                    new->next = NULL;
                    (*cn)++;
                    s1 = s1_end;
                }
            } else if (tmp == s1) { /* if tmp = s1, then s2 starts from the very beginning. No new segment is added. */
                s1 = tmp + s2_len;
            } else {
                if ((*cn) == 0) {
                    head = matrixalloc_1d(1, sizeof (ptr_list_t));
                    head->ptr = s1;
                    head->next = NULL;
                    this = head;
                } else {
                    ptr_list_t *new = matrixalloc_1d(1, sizeof (ptr_list_t));
                    this->next = new;
                    new->ptr = s1;
                    new->next = NULL;
                    this = new;
                }
                tmp[0] = '\0';
                (*cn)++;
                s1 = tmp + s2_len;
            }
        } while (s1 < s1_end);
        char **re = matrixalloc_1d((*cn), sizeof (char *));
        for (int i = 0; i < (*cn); i++) {
            re[i] = head->ptr;
            this = head->next;
            matrixalloc_1d_free(head);
            head = this;
        }
        return re;
    }
}

/*
 * @since 2015.02.06, 2.17
 */
int string_util_parse_int(const char *nptr, char **endptr, int base, string_util_parse_state_t *state) {
    if (! ((base == 0) || (base >= 2 && base <= 36))) {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
//7.5.3 The value of errno is zero at program startup, but is never set to zero by any library function.
    errno = 0;
    long tmp = strtol(nptr, endptr, base);
    if (endptr != NULL && nptr == endptr[0]) {
        (*state) = string_util_parse_state_bad_format;
        return 0;
    } else if (errno == ERANGE || tmp >= INT_MAX || tmp <= INT_MIN) {
        (*state) = string_util_parse_state_erange;
        return 0;
    } else {
        (*state) = string_util_parse_state_success;
        return (int) tmp;
    }
}

/*
 * @since 2015.6.11
 */
unsigned long int string_util_parse_ulong(const char *nptr, char **endptr, int base, string_util_parse_state_t *state) {
    if (! ((base == 0) || (base >= 2 && base <= 36))) {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
    errno = 0;
    unsigned long tmp = strtoul(nptr, endptr, base);
    if (endptr != NULL && nptr == endptr[0]) {
        (*state) = string_util_parse_state_bad_format;
        return 0;
    } else if (errno == ERANGE) {
        (*state) = string_util_parse_state_erange;
        return 0;
    } else {
        (*state) = string_util_parse_state_success;
        return tmp;
    }
}

/*
 * @since 2015.2.6, 2.17
 */
double string_util_parse_double(const char *nptr, char **endptr, string_util_parse_state_t *state) {
    errno = 0;
    double tmp = strtod(nptr, endptr);
    if (endptr != NULL && nptr == endptr[0]) {
        (*state) = string_util_parse_state_bad_format;
        return 0;
    } else if (errno == ERANGE) {
        (*state) = string_util_parse_state_erange;
        return 0;
    } else {
        (*state) = string_util_parse_state_success;
        return tmp;
    }
}

/*
 * @since 2015.2.6, 2.17
 */
bool string_util_starts_with(const char *s1, const char *s2) {
    size_t len_s2 = strlen(s2);
    if (len_s2 == 0) {
        return true;
    } else if (strlen(s1) < len_s2) {
        return false;
    } else {
        int re = memcmp(s1, s2, len_s2);
        if (re == 0)
            return true;
        else
            return false;
    }
}

/*
 * @since 2015.2.6, 2.17
 */
bool string_util_ends_with(const char *s1, const char *s2) {
    size_t len_s2 = strlen(s2);
    if (len_s2 == 0) {
        return true;
    } else {
        size_t len_s1 = strlen(s1);
        if (len_s1 < len_s2) {
            return false;
        } else {
            int re = memcmp(s1 + len_s1 - len_s2, s2, len_s2);
            if (re == 0)
                return true;
            else
                return false;
        }
    }
}