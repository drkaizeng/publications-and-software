#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

/**
 * @since 2013.08.11, 2013.08.12, 2013.09.11
 */
MATRIXALLOC_TYPE **MATRIXALLOC_2D(const int nrow, const int ncol) {
    /* type dependent variables */
    static const size_t sptr = sizeof (MATRIXALLOC_TYPE *);
    static const size_t styp = sizeof (MATRIXALLOC_TYPE);
    static const size_t lim1 = SIZE_MAX / sizeof (MATRIXALLOC_TYPE *);
    static const size_t lim2 = SIZE_MAX / sizeof (MATRIXALLOC_TYPE);
    MATRIXALLOC_TYPE **re;
    
    /* type independent part */
    if (nrow <= 0) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();        
    }
    if (ncol <= 0) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();        
    }
    size_t nr = (size_t) (nrow);
    size_t nc = (size_t) (ncol);
    if (nr >= lim1) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();        
    }
    if (nc >= lim2 / nr) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();        
    }
    re = malloc(nr * sptr);
    if (re == NULL) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();        
    }
    re[0] = malloc(nr * nc * styp);
    if (re[0] == NULL) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();        
    }
    for (size_t i = 1; i < nr; i++)
        re[i] = re[i - 1] + nc;
    return re;
}

/**
 * @since 2015.01.29
 */
MATRIXALLOC_TYPE ** MATRIXALLOC_2D_INIT(const int nrow, const int ncol) {
    /* type dependent variables */
    static const size_t sptr = sizeof (MATRIXALLOC_TYPE *);
    static const size_t styp = sizeof (MATRIXALLOC_TYPE);
    static const size_t lim1 = SIZE_MAX / sizeof (MATRIXALLOC_TYPE *);
    static const size_t lim2 = SIZE_MAX / sizeof (MATRIXALLOC_TYPE);
    MATRIXALLOC_TYPE **re;

    /* type independent part */
    if (nrow <= 0) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();        
    }
    if (ncol <= 0) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();        
    }
    size_t nr = (size_t) (nrow);
    size_t nc = (size_t) (ncol);
    if (nr >= lim1) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();        
    }
    if (nc >= lim2 / nr) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();        
    }
    re = malloc(nr * sptr);
    if (re == NULL) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();        
    }
    re[0] = calloc(nr * nc, styp);
    if (re[0] == NULL) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();        
    }
    for (size_t i = 1; i < nr; i++)
        re[i] = re[i - 1] + nc;
    return re;
}

/**
 * @since 2015.01.29, 2.8
 */
MATRIXALLOC_TYPE ** MATRIXALLOC_2D_CLONE(MATRIXALLOC_TYPE **src, const int nrow, const int ncol) {
    /* type dependent variables */
    static const size_t sptr = sizeof (MATRIXALLOC_TYPE *);
    static const size_t styp = sizeof (MATRIXALLOC_TYPE);
    MATRIXALLOC_TYPE **re;
    size_t nr = (size_t) (nrow);
    size_t nc = (size_t) (ncol);
    re = malloc(nr * sptr);
    if (re == NULL) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();        
    }
    size_t memsize = nr * nc * styp;
    re[0] = malloc(memsize);
    if (re[0] == NULL) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();        
    }
    for (size_t i = 1; i < nr; i++)
        re[i] = re[i - 1] + nc;
    memcpy(re[0], src[0], memsize);
    return re;
}

/**
 * @since 2015.01.29, 2.8
 */
void MATRIXALLOC_2D_CPY(MATRIXALLOC_TYPE **des, MATRIXALLOC_TYPE **src, const int nrow, const int ncol) {
    /* type dependent variables */
    static const size_t styp = sizeof (MATRIXALLOC_TYPE);
    size_t nr = (size_t) (nrow);
    size_t nc = (size_t) (ncol);
    size_t memsize = nr * nc * styp;
    memcpy(des[0], src[0], memsize);
}

/**
 * @since 2013.08.11, 2013.09.11
 */
void MATRIXALLOC_2D_FREE(MATRIXALLOC_TYPE **ptr) {
    if (ptr == NULL) {
        return;
    }
    free(ptr[0]);
    free(ptr);
}

/**
 * @since
 */
//double **matrixalloc_2d_d(const int nrow, const int ncol) {
//    /* type dependent variables */
//    static const size_t sptr = sizeof (double *);
//    static const size_t styp = sizeof (double);
//    static const size_t lim1 = SIZE_MAX / sizeof (double *);
//    static const size_t lim2 = SIZE_MAX / sizeof (double);
//    double **re;
//
//    /* type independent part */
//    if (nrow <= 0)
//        gsl_error("", __FILE__, __LINE__, GSL_EINVAL);
//    if (ncol <= 0)
//        gsl_error("", __FILE__, __LINE__, GSL_EINVAL);
//    size_t nr = (size_t) (nrow);
//    size_t nc = (size_t) (ncol);
//    if (nr >= lim1) {
//        gsl_error("", __FILE__, __LINE__, GSL_ENOMEM);
//    }
//    if (nc >= lim2 / nr) {
//        gsl_error("", __FILE__, __LINE__, GSL_ENOMEM);
//    }
//    re = malloc(nr * sptr);
//    if (re == NULL) {
//        gsl_error("", __FILE__, __LINE__, GSL_ENOMEM);
//    }
//    re[0] = malloc(nr * nc * styp);
//    if (re[0] == NULL) {
//        gsl_error("", __FILE__, __LINE__, GSL_ENOMEM);
//    }
//    for (size_t i = 1; i < nr; i++)
//        re[i] = re[i - 1] + nc;
//    return re;
//}
//
///**
// * @since
// */
//double **matrixalloc_2d_d_init(const int nrow, const int ncol) {
//    /* type dependent variables */
//    static const size_t sptr = sizeof (double *);
//    static const size_t styp = sizeof (double);
//    static const size_t lim1 = SIZE_MAX / sizeof (double *);
//    static const size_t lim2 = SIZE_MAX / sizeof (double);
//    double **re;
//
//    /* type independent part */
//    if (nrow <= 0)
//        gsl_error("", __FILE__, __LINE__, GSL_EINVAL);
//    if (ncol <= 0)
//        gsl_error("", __FILE__, __LINE__, GSL_EINVAL);
//    size_t nr = (size_t) (nrow);
//    size_t nc = (size_t) (ncol);
//    if (nr >= lim1) {
//        gsl_error("", __FILE__, __LINE__, GSL_ENOMEM);
//    }
//    if (nc >= lim2 / nr) {
//        gsl_error("", __FILE__, __LINE__, GSL_ENOMEM);
//    }
//    re = malloc(nr * sptr);
//    if (re == NULL) {
//        gsl_error("", __FILE__, __LINE__, GSL_ENOMEM);
//    }
//    re[0] = calloc(nr * nc, styp);
//    if (re[0] == NULL) {
//        gsl_error("", __FILE__, __LINE__, GSL_ENOMEM);
//    }
//    for (size_t i = 1; i < nr; i++)
//        re[i] = re[i - 1] + nc;
//    return re;
//}
//
///**
// * @since
// */
//double **matrixalloc_2d_d_clone(double **src, const int nrow, const int ncol) {
//    /* type dependent variables */
//    static const size_t sptr = sizeof (double *);
//    static const size_t styp = sizeof (double);
//    static const size_t lim1 = SIZE_MAX / sizeof (double *);
//    static const size_t lim2 = SIZE_MAX / sizeof (double);
//    double **re;
//
//    /* type independent part */
//    if (nrow <= 0)
//        gsl_error("", __FILE__, __LINE__, GSL_EINVAL);
//    if (ncol <= 0)
//        gsl_error("", __FILE__, __LINE__, GSL_EINVAL);
//    size_t nr = (size_t) (nrow);
//    size_t nc = (size_t) (ncol);
//    if (nr >= lim1) {
//        gsl_error("", __FILE__, __LINE__, GSL_ENOMEM);
//    }
//    if (nc >= lim2 / nr) {
//        gsl_error("", __FILE__, __LINE__, GSL_ENOMEM);
//    }
//    re = malloc(nr * sptr);
//    if (re == NULL) {
//        gsl_error("", __FILE__, __LINE__, GSL_ENOMEM);
//    }
//    size_t memsize = nr * nc * styp;
//    re[0] = malloc(memsize);
//    if (re[0] == NULL) {
//        gsl_error("", __FILE__, __LINE__, GSL_ENOMEM);
//    }
//    for (size_t i = 1; i < nr; i++)
//        re[i] = re[i - 1] + nc;
//    memcpy(re, src[0], memsize);
//    return re;
//}
//
///**
// * @since
// */
//void matrixalloc_2d_d_free(double **ptr) {
//    free(ptr[0]);
//    free(ptr);
//}
//
///**
// * @since
// */
//int **matrixalloc_2d_i(const int nrow, const int ncol) {
//    /* type dependent variables */
//    static const size_t sptr = sizeof (int *);
//    static const size_t styp = sizeof (int);
//    static const size_t lim1 = SIZE_MAX / sizeof (int *);
//    static const size_t lim2 = SIZE_MAX / sizeof (int);
//    int **re;
//
//    /* type independent part */
//    if (nrow <= 0)
//        gsl_error("", __FILE__, __LINE__, GSL_EINVAL);
//    if (ncol <= 0)
//        gsl_error("", __FILE__, __LINE__, GSL_EINVAL);
//    size_t nr = (size_t) (nrow);
//    size_t nc = (size_t) (ncol);
//    if (nr >= lim1) {
//        gsl_error("", __FILE__, __LINE__, GSL_ENOMEM);
//    }
//    if (nc >= lim2 / nr) {
//        gsl_error("", __FILE__, __LINE__, GSL_ENOMEM);
//    }
//    re = malloc(nr * sptr);
//    if (re == NULL) {
//        gsl_error("", __FILE__, __LINE__, GSL_ENOMEM);
//    }
//    re[0] = malloc(nr * nc * styp);
//    if (re[0] == NULL) {
//        gsl_error("", __FILE__, __LINE__, GSL_ENOMEM);
//    }
//    for (size_t i = 1; i < nr; i++)
//        re[i] = re[i - 1] + nc;
//    return re;
//}
//
///**
// * @since
// */
//void matrixalloc_2d_i_free(int **ptr) {
//    free(ptr[0]);
//    free(ptr);
//}
//
///**
// * @since
// */
//bool **matrixalloc_2d_b(const int nrow, const int ncol) {
//    /* type dependent variables */
//    static const size_t sptr = sizeof (bool *);
//    static const size_t styp = sizeof (bool);
//    static const size_t lim1 = SIZE_MAX / sizeof (bool *);
//    static const size_t lim2 = SIZE_MAX / sizeof (bool);
//    bool **re;
//
//    /* type independent part */
//    if (nrow <= 0)
//        gsl_error("", __FILE__, __LINE__, GSL_EINVAL);
//    if (ncol <= 0)
//        gsl_error("", __FILE__, __LINE__, GSL_EINVAL);
//    size_t nr = (size_t) (nrow);
//    size_t nc = (size_t) (ncol);
//    if (nr >= lim1) {
//        gsl_error("", __FILE__, __LINE__, GSL_ENOMEM);
//    }
//    if (nc >= lim2 / nr) {
//        gsl_error("", __FILE__, __LINE__, GSL_ENOMEM);
//    }
//    re = malloc(nr * sptr);
//    if (re == NULL) {
//        gsl_error("", __FILE__, __LINE__, GSL_ENOMEM);
//    }
//    re[0] = malloc(nr * nc * styp);
//    if (re[0] == NULL) {
//        gsl_error("", __FILE__, __LINE__, GSL_ENOMEM);
//    }
//    for (size_t i = 1; i < nr; i++)
//        re[i] = re[i - 1] + nc;
//    return re;
//}
//
///**
// * @since
// */
//void matrixalloc_2d_b_free(bool **ptr) {
//    free(ptr[0]);
//    free(ptr);
//}