/*
 * @since 2013.02.18, 2013.02.22, 2015.01.19
 */
int FUNCTION_NAME(const DATA_TYPE *a, int fromIndex, int toIndex, DATA_TYPE key) {   
#ifdef ARRAYUTIL_CHECK
    if (fromIndex < 0)
        abort();
    if (fromIndex >= toIndex)
        abort();
#endif
    
    int low = fromIndex;
    int high = toIndex - 1;
    
    int mid;
    DATA_TYPE midVal;
    while (low <= high) {
        
#ifdef ARRAYUTIL_CHECK
        if (low < 0)
            abort();
#endif
        
        mid = (low + high) >> 1;//if high>low, then mid<high; if high=low, then mid=high; c99 6.5.7.5
        midVal = a[mid];

        if (midVal < key)
            low = mid + 1;
        else if (midVal > key)
            high = mid - 1;
        else
            return mid; // key found
    }
    return -(low + 1); // key not found.
    /**
     * If key is less than a[fromIndex], then high decreases until it becomes one smaller than low, when the
     * while-loop is exited.
     * If key is larger than a[toIndex], then low increases until it becomes one larger than high, when
     * the while-loop is exited.
     * If key is in between a[fromIndex] and a[toIndex], but is not in the array, then as the length of the
     * array is halved in each step, there must be an occasion when key is outside the interval a[low] and a[high]. 
     * When this happens, the reasoning above suggests that
     * the return value is the desired result. Otherwise, since the distance between low and high is
     * halved every time, the interval between a[low] and a[high] will eventually becomes a single point, 
     * contradicting the assumption that key is not in the array.
     * Note that because the right shift is equivalent to an integer division by 2, mid = low when high - low <= 1.
     */
}