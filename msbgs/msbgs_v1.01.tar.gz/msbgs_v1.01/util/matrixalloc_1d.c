#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <limits.h>

#include "matrixalloc.h"

#if INT_MAX >= SIZE_MAX
#error INT_MAX >= SIZE_MAX
#endif

/**
 * @since 2013.07.30, 2013.08.01, 2014.01.22
 */
void *matrixalloc_1d(const int n, const size_t styp) {
    if (n < 1) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();        
    }
    if (styp == 0) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();        
    }
    if ((size_t) n >= SIZE_MAX / styp) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    
    size_t memsize = (size_t) n * styp;
    void *re = malloc(memsize);
    if (re == NULL) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    return re;
}

/**
 * @since 2015.01.29, 2.6
 */
void *matrixalloc_1d_init(const int n, const size_t s) {
    if (n < 1) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();        
    }
    if (s == 0) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();        
    }
    if ((size_t) n >= SIZE_MAX / s) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    
    void *re = calloc((size_t) n, s);
    if (re == NULL) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    return re;
}

/**
 * @since 2015.01.29, 2.6
 */
void * matrixalloc_1d_clone(const void *src, const int n, const size_t styp) {
    if (n < 1) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();        
    }
    if (styp == 0) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();        
    }
    if ((size_t) n >= SIZE_MAX / styp) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    
    size_t memsize = (size_t) n * styp;
    void *re = malloc(memsize);
    if (re == NULL) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    memcpy(re, src, memsize);
    return re;
}

/*
 * @since 2015.2.8, 2.19
 */
void * matrixalloc_1d_realloc(void *a, int n, size_t styp) {
    /*
     * c99 7.3.20
     * For malloc, calloc and realloc, if the size of the space requested is zero, the behavior is implementation-defined. 
     */
    if (n < 1) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();        
    }
    if (styp == 0) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();        
    }
    if ((size_t) n >= SIZE_MAX / styp) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    
    size_t memsize = (size_t) n * styp;
    void *re = realloc(a, memsize);
    if (re == NULL) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    return re;
}

/*
 * @since
 */
void   matrixalloc_1d_cpy1(void *des, const void *src, const int n, const size_t styp) {
    size_t memsize = (size_t) n * styp;
    memcpy(des, src, memsize);
}

/*
 * @since
 */
void   matrixalloc_1d_cpy2(void *des, const void *src, size_t total_size) {
    memcpy(des, src, total_size);
}

/**
 * @since
 */
void  matrixalloc_1d_free(void *a) {
    free(a);
}


