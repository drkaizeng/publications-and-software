/* 
 * File:   arrayutil.h
 * Author: Kai
 *
 * Created on 08 February 2013, 13:42
 */

#ifndef ARRAYUTIL_H
#define	ARRAYUTIL_H

#include <stdbool.h>

/**
 * @param a pointer to an array
 * @param fromIndex (inclusive)
 * @param toIndex (exclusive)
 * @return the sum of a[i] for i = 0, ..., (n-1)
 */
int arrayutil_sum_i_i(const int *a, int fromIndex, int toIndex);
double arrayutil_sum_i_d(const int *a, int fromIndex, int toIndex);
double arrayutil_sum_d_d(const double *a, int fromIndex, int toIndex);


/**
 * @param a a pointer to an integer array. The elements must be sorted into ascending order beforehand. 
 *    Otherwise the result is undefined. If the range contains
 *    multiple elements with the specified value, there is no guarantee which
 *    one will be found.
 * @param fromIndex the index of the first element (inclusive) to be searched; [0, n-1], where n is the length of a.
 * @param toIndex the index of the last element (exclusive) to be searched; [fromIndex+1, n];
 * @param key the value to be searched from in the range
 * @return index of the search key, if it is contained in the array;
 *         otherwise, <tt>(-(<i>insertion point</i>) - 1)</tt>.  The
 *         <i>insertion point</i> is defined as the point at which the
 *         key would be inserted into the array: the index of the first
 *         element greater than the key, or <tt>a.length</tt> if all
 *         elements in the array are less than the specified key.  Note
 *         that this guarantees that the return value will be &gt;= 0 if
 *         and only if the key is found.
 */
int arrayutil_binary_search_i(const int *a, int fromIndex, int toIndex, int key);
int arrayutil_binary_search_d(const double *a, int fromIndex, int toIndex, double key);

/**
 * Sort the array into ascending order. 
 */
/**
 * Sort the array into ascending order. If fromIndex &ge; toIndex, nothing is done.
 * @param fromIndex the index of the first element, inclusive, to be sorted
 * @param toIndex the index of the last element, exclusive, to be sorted
 */
void arrayutil_quick_sort_i(int *a, int fromIndex, int toIndex);
void arrayutil_quick_sort_d(double *a, int fromIndex, int toIndex);
void arrayutil_quick_sort_set_seed(unsigned int seed);


/**
 * Assigns the specified int value to each element of the specified
 * range of the specified array of shorts.  The range to be filled
 * extends from index <tt>fromIndex</tt>, inclusive, to index
 * <tt>toIndex</tt>, exclusive.  (If <tt>fromIndex==toIndex</tt>, the
 * range to be filled is empty.)
 *
 * @param a the array to be filled
 * @param fromIndex the index of the first element (inclusive) to be
 *        filled with the specified value
 * @param toIndex the index of the last element (exclusive) to be
 *        filled with the specified value
 * @param val the value to be stored in all elements of the array
 * 
 * NO RANGE CHECK IS PERFORMED.
 */
void arrayutil_fill_i(int *a, int fromIndex, int toIndex, int val);
void arrayutil_fill_d(double *a, int fromIndex, int toIndex, double val);
void arrayutil_fill_b(bool *a, int fromIndex, int toIndex, bool val);

#endif	

