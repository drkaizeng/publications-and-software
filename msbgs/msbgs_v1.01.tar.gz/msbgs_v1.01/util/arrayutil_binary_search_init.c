#include "arrayutil.h"

#define DATA_TYPE_INT
#include "arrayutil_binary_search_template_on.h"
#include "arrayutil_binary_search.c"
#include "arrayutil_binary_search_template_off.h"
#undef DATA_TYPE_INT

#define DATA_TYPE_DOUBLE
#include "arrayutil_binary_search_template_on.h"
#include "arrayutil_binary_search.c"
#include "arrayutil_binary_search_template_off.h"
#undef DATA_TYPE_DOUBLE
