#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#define SWAP(a, b, tmp) {(tmp) = (a); (a) = (b); (b) = (tmp);}

/*
 * @since 2015.2.9, 2.17
 */
static int PARTITION(DATA_TYPE *a, int p, int r) {
    if (set_seed == false) {
        set_seed = true;
        srand((unsigned int) time(NULL));
    }
    DATA_TYPE sw;
    {
        double tmp = 1.0;
        do {
            tmp = (double) rand() / RAND_MAX;
        } while (tmp == 1.0);
        tmp *= (r - p + 1);
        int i = (int) tmp;
        i += p;
        SWAP(a[r], a[i], sw);
    }
    DATA_TYPE x = a[r];
    int i = p - 1;
    for (int j = p; j < r; j++) {
        if (a[j] <= x) {
            i++;
            SWAP(a[i], a[j], sw);
        }
    }
    i++;
    SWAP(a[i], a[r], sw);
    return i;
}

/*
 * @since 2015.2.9, 2.17
 */
static void QUICK_SORT_WORK(DATA_TYPE *a, int p, int r) {
    if (p < r) {
        int q = PARTITION(a, p, r);
        QUICK_SORT_WORK(a, p, q - 1);
        QUICK_SORT_WORK(a, q + 1, r);
    }
}

/*
 * @since 2015.2.9, 2.17
 */
void QUICK_SORT(DATA_TYPE *a, int fromIndex, int toIndex) {
    if (toIndex >= RAND_MAX) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    QUICK_SORT_WORK(a, fromIndex, toIndex - 1);
}