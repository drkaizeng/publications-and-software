#include "arrayutil.h"

#define DATA_INT_RETURN_INT
#include "arrayutil_sum_template_on.h"
#include "arrayutil_sum.c"
#include "arrayutil_sum_template_off.h"
#undef DATA_INT_RETURN_INT

#define DATA_INT_RETURN_DOUBLE
#include "arrayutil_sum_template_on.h"
#include "arrayutil_sum.c"
#include "arrayutil_sum_template_off.h"
#undef DATA_INT_RETURN_DOUBLE

#define DATA_DOUBLE_RETURN_DOUBLE
#include "arrayutil_sum_template_on.h"
#include "arrayutil_sum.c"
#include "arrayutil_sum_template_off.h"
#undef DATA_DOUBLE_RETURN_DOUBLE