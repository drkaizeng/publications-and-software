/* 
 * File:   stack.h
 * Author: kai
 *
 * Created on 10 January 2015, 09:27
 */

#ifndef MY_STACK_H
#define	MY_STACK_H


typedef struct my_stack_tag my_stack_t;

/**
 * Construct an empty stack.
 * @param init_size  The initial size (&gt;0) of the stack.
 * @param inc_size The amount by which the size (&ge;0) is increased when the stack overflows. <br>
 *                 If zero is given, then the size will be doubled every time as in Vector.java
 *                 in the Java standard library.
 */
my_stack_t * my_stack_new(int init_size, int inc_size);

/**
 * Release the memory pointed to by an object created by stack_new().
 * <p>
 * Note that a stack can be freed only when it contains no data.
 */
void my_stack_free(my_stack_t *stack);

/**
 * @return The size of the current stack
 */
int my_stack_size(my_stack_t *stack);

/**
 * Pushes an item onto the top of this stack.
 */
void my_stack_push(my_stack_t * stack, void * item);

/**
 * Removes the object at the top of this stack and returns that
 * object as the value of this function.
 * @return NULL is returned if the stack is empty.
 */
void * my_stack_pop(my_stack_t * stack);

/**
 * Remove all items from the stack. The memory pointed to by the points in
 * the stack is not released.
 */
void my_stack_clear(my_stack_t * stack);

/**
 * Remove all items from the stack. The memory pointed to by the points in
 * the stack is released by the function in the argument.
 */
void my_stack_clear_free(my_stack_t * stack, void (*f)(void *));

/**
 * Display the contents of the stack on screen where the function provided
 * in the argument controls how each item is printed.
 */
void my_stack_print_to_screen(my_stack_t * stack, void (*f)(void *));



#endif	/* STACK_H */

