/* 
 * File:   arrayutil_sum_template_off.h
 * Author: kai
 *
 * Created on 18 January 2015, 22:52
 */

#undef DATA_TYPE
#undef RETURN_TYPE
#undef ABBR

#undef CONCAT2x
#undef CONCAT2

#undef FUNCTION_NAME
