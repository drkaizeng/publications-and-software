/**
 * @since 2013.07.21, 2015.01.19, 01.29
 */
void FUNCTION_NAME(DATA_TYPE *a, int fromIndex, int toIndex, DATA_TYPE val) {
    for (int i = fromIndex; i < toIndex; i++)
        a[i] = val;
}
