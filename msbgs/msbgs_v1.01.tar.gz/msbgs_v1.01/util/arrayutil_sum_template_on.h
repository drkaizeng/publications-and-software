/* 
 * File:   arrayutil_sum_template_on.h
 * Author: kai
 *
 * Created on 18 January 2015, 21:41
 */

#ifdef DATA_INT_RETURN_INT
#    define DATA_TYPE int
#    define RETURN_TYPE int
#    define ABBR i_i
#endif

#ifdef DATA_INT_RETURN_DOUBLE
#    define DATA_TYPE int
#    define RETURN_TYPE double
#    define ABBR i_d
#endif

#ifdef DATA_DOUBLE_RETURN_DOUBLE
#    define DATA_TYPE double
#    define RETURN_TYPE double
#    define ABBR d_d
#endif

#define CONCAT2x(a,b) a ## _ ## b
#define CONCAT2(a,b) CONCAT2x(a,b)

#define FUNCTION_NAME CONCAT2(arrayutil_sum, ABBR)
