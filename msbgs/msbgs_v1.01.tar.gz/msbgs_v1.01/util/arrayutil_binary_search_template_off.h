/* 
 * File:   arrayutil_binary_search_template_off.h
 * Author: kai
 *
 * Created on 18 January 2015, 20:47
 */

#undef DATA_TYPE
#undef ABBR

#undef CONCAT2x
#undef CONCAT2

#undef FUNCTION_NAME

