#include "arrayutil.h"

#define DATA_TYPE_INT
#include "arrayutil_fill_template_on.h"
#include "arrayutil_fill.c"
#include "arrayutil_fill_template_off.h"
#undef DATA_TYPE_INT

#define DATA_TYPE_DOUBLE
#include "arrayutil_fill_template_on.h"
#include "arrayutil_fill.c"
#include "arrayutil_fill_template_off.h"
#undef DATA_TYPE_DOUBLE

#define DATA_TYPE_BOOL
#include "arrayutil_fill_template_on.h"
#include "arrayutil_fill.c"
#include "arrayutil_fill_template_off.h"
#undef DATA_TYPE_BOOL
