#include <limits.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "frag.h"

#include "util/matrixalloc.h"
#include "util/my_stack.h"


struct frag_tag {
    /**
     * The beginning base pair (inclusive) of this fragment; indexed from 0 to (nsites-1)
     */
    int beg;
    /**
     * The ending base pair (inclusive) of this fragment; indexed from 0 to (nsites-1)
     */
    int end;
    /**
     * The genealogy of this fragment
     */
    node_t *tree;
    /**
     * (nnodes+1) is the number of nodes in tree (i.e., nnodes is the ID of the last node added to the tree).
     */
    int nnodes;
    int max_nnodes;
    /**
     * The index of the next segment in the frag_t list that follows current object; -1 indicates the end of list
     */
    int next;
};

struct frag_list_tag {
    int nsam;
    int leng;
    int leng_m1;
    size_t tree_mem_size;
    int max_nnodes;
    /**
     * This is an array containing nsam nodes, such that each node as abv=-1, time=0 and ndes=1.
     */
    node_t *leaves;
    size_t leaves_mem_size;
    frag_t **ppfrag;
    /**
     * The maximum number of elements can be held in ppfrag
     */        
    int ppfrag_capacity;
    /**
     * The current size of ppfrag. All elements indices in the range
     * between ppfrag_leng (inclusive) and ppfrag_capacity-1 (inclusive)
     * are undefined.
     */
    int ppfrag_leng;
    int iterator;
    my_stack_t *stack;
};

/*
 * @since 2015.2.11, 2.15
 */
frag_list_t * frag_list_new(int nsam, int leng, int init_stack_size) {
    frag_list_t *re = matrixalloc_1d(1, sizeof (frag_list_t));
    re->nsam = nsam;
    re->leng = leng;
    re->leng_m1 = leng - 1;
    re->tree_mem_size = (size_t) (2 * nsam - 1) * sizeof(node_t);
    re->max_nnodes = 2 * nsam - 2;
    re->leaves = matrixalloc_1d(nsam, sizeof (node_t));
    for (int i = 0; i < nsam; i++) {
        re->leaves[i].abv = -1;
        re->leaves[i].time = 0;
    }
    re->leaves_mem_size = (size_t) nsam * sizeof (node_t);
    re->ppfrag = matrixalloc_1d(init_stack_size, sizeof (frag_t *));
    re->ppfrag_capacity = init_stack_size;
    re->ppfrag_leng = 0;
    re->iterator = -1;
    re->stack = my_stack_new(init_stack_size, 0);
    return re;
}

/*
 * @since 2015.2.12
 */
static void frag_free(void *src) {
    frag_t *f = (frag_t *) src;
    matrixalloc_1d_free(f->tree);
    matrixalloc_1d_free(f);
}

/*
 * @since 2015.2.15
 */
void frag_list_free(frag_list_t *list) {
    if (list->ppfrag_leng > 0) {
        for (int i = 0; i < list->ppfrag_leng; i++) {
            my_stack_push(list->stack, list->ppfrag[i]);
            list->ppfrag[i] = NULL;
        }
    }
    my_stack_clear_free(list->stack, frag_free);
    my_stack_free(list->stack);
    matrixalloc_1d_free(list->ppfrag);
    matrixalloc_1d_free(list->leaves);
    matrixalloc_1d_free(list);
}

/**
 * max_nnodes is set to 2*nsam-2 and next is set to -1. <br>
 * The memory for tree is allocated, but no initialisation is done.
 * @since 2015.2.11, 2.15
 */
static frag_t * frag_new(frag_list_t *list) {
    frag_t *re = my_stack_pop(list->stack);
    if (re == NULL) {
        re = matrixalloc_1d(1, sizeof(frag_t));
        re->tree = matrixalloc_1d(1, list->tree_mem_size);
    } 
    re->max_nnodes = list->max_nnodes;
    re->next = -1;
    return re;
}

/*
 * @since 2015.2.11, 2.15
 */
void frag_list_init(frag_list_t *list) {
    if (list->ppfrag_leng > 0) {
        for (int i = 0; i < list->ppfrag_leng; i++) {
            my_stack_push(list->stack, list->ppfrag[i]);
            list->ppfrag[i] = NULL;
        }
    }
    frag_t *f = frag_new(list);
    f->beg = 0;
    f->end = list->leng_m1;
    memcpy(f->tree, list->leaves, list->leaves_mem_size);
    f->nnodes = list->nsam - 1;
    list->ppfrag[0] = f;
    list->ppfrag_leng = 1;
    list->iterator = 0;
}

/*
 * @since 2015.2.12
 */
int frag_list_size(const frag_list_t *list) {
    return list->ppfrag_leng;
}

/*
 * @since 2015.2.11
 */
void frag_list_iterator_reset(frag_list_t *list) {
    if (list->ppfrag_leng <= 0) {
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    list->iterator = 0;
}

/*
 * @since 2015.2.12
 */
frag_t * frag_list_iterator_next(frag_list_t *list) {
    if (list->iterator <= -1) {
        return NULL;
    } else {
        frag_t *re = list->ppfrag[list->iterator];
        list->iterator = re->next;
        return re;
    }
}

/*
 * @since 2015.2.11
 */
frag_t * frag_list_find(const frag_list_t *list, int s) {
    for (int i = 0, j = 0; i < list->ppfrag_leng; i++) {
        frag_t *f = list->ppfrag[j];
        if (f->beg <= s && f->end >= s) {
            return f;
        } else {
            j = f->next;
        }
    }
    fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
    abort();
}

/** 
 * <b>Important:</b> It is assumed that the ppfrag_leng and ppfrag_capacity have not been changed
 * before this function is called.
 * @since 2015.2.11
 */
static void ensure_pfrag_capacity(frag_list_t *list, int new_size) {
    if (new_size > list->ppfrag_capacity) {
        static const int LIMIT = INT_MAX / 2;
        if (new_size >= LIMIT) {
            fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
            abort();
        }
        list->ppfrag_capacity = new_size * 2;
        list->ppfrag = matrixalloc_1d_realloc(list->ppfrag, list->ppfrag_capacity, sizeof(frag_t *));
    }
}

/** 
 * @since 2013.03.21, 2013.04.01, 2015.01.30
 * 
 */
static void frag_treecpy(frag_t *des, const frag_t *src) {
    size_t mem = (size_t) (src->nnodes + 1) * sizeof(node_t);
    memcpy(des->tree, src->tree, mem);
}

/*
 * @since 2015.2.11
 */
void frag_list_split(frag_list_t *list, int brk) {
    if (brk < 0 || brk >= list->leng_m1) {
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    /* Find the fragment that contains brk */
    frag_t *frag = frag_list_find(list, brk);
    if (brk != frag->end) { /* Recombination breaks the segment. Build new frag */
        ensure_pfrag_capacity(list, list->ppfrag_leng + 1);
        frag_t *new_f = frag_new(list);
        new_f->beg = brk + 1;
        new_f->end = frag->end;
        frag_treecpy(new_f, frag);
        new_f->nnodes = frag->nnodes;
        new_f->next = frag->next;
        frag->end = brk;
        frag->next = list->ppfrag_leng;
        list->ppfrag[list->ppfrag_leng] = new_f;
        list->ppfrag_leng++;
    }
}

/*
 * @since 2015.2.11
 */
void frag_get_limits(const frag_t *f, int *beg, int *end) {
    (*beg) = f->beg;
    (*end) = f->end;
}

/*
 * @since 2015.2.12
 */
int frag_add_ca(frag_t *f, int i, int j, double t) {
    if (i == j || i < 0 || i > f->nnodes || j < 0 || j > f->nnodes) {
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    f->nnodes++;
    node_t *tree = f->tree;
    tree[i].abv = f->nnodes;
    tree[j].abv = f->nnodes;
    tree[f->nnodes].time = t;
    tree[f->nnodes].abv = -1;
    return f->nnodes;
}

/*
 * @since 2015.2.12
 */
bool frag_has_mrca(const frag_t *f) {
    if (f->nnodes == f->max_nnodes)
        return true;
    else
        return false;
}

/*
 * @since 2015.2.12
 */
node_t * frag_clone_tree(const frag_t *f) {
    node_t *re = matrixalloc_1d_clone(f->tree, f->max_nnodes + 1, sizeof (node_t));
    return re;
}

/*
 * @since 2015.6.11
 */
const node_t * frag_get_tree(const frag_t *f) {
    return f->tree;
}

void frag_list_print_to_screen(const frag_list_t *list) {
    printf("\nfrag_list:\n");
    printf("ppfrag_capacity=%i\n", list->ppfrag_capacity);
    printf("ppfrag_leng=%i\n", list->ppfrag_leng);
    for (int i = 0, j = 0; i < list->ppfrag_leng; i++) {
        printf("\tfrag %i = [%i, %i]\n", i, list->ppfrag[j]->beg, list->ppfrag[j]->end);
        j = list->ppfrag[j]->next;
    }
    printf("\n");
}

//void segl_print(frag_t *s) {
//    printf("\nsegl_T: {beg=%i,  end=%i,  nnodes=%i}\n", s->beg, s->end, s->nnodes);
//    for (int i = 0; i <= s->nnodes; i++) {
//        printf("\t[%i,  abv=%i,  time=%g,  ndes=%i]\n", i, s->pnode[i].abv, s->pnode[i].time, s->pnode[i].ndes);
//    }
//    printf("\n");
//}
//
//void segl_print_arr(frag_t **arr) {
//    frag_t *next = arr[0];
//    assert(next->beg == 0);
//    printf("\n{segl_T array:\n");
//    int cn = 0;
//    while (true) {
//        printf("%i:", cn);
//        segl_print(next);
//        if (next->next == -1)
//            break;
//        else {
//            next = arr[next->next];
//            cn++;
//        }
//    } 
//    printf("}\n");
//}