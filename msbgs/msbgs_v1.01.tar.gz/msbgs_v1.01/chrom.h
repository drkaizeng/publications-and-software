/* 
 * File:   chrom.h
 * Author: Kai
 *
 * Created on 27 February 2013, 20:51
 */

#ifndef CHROM_H
#define	CHROM_H

#include "gsl/gsl_rng.h"
#include "frag.h"

typedef struct chrom_stack_tag chrom_stack_t;

typedef struct chrom_tag chrom_t;

/**
 * Except for ran, deep defensive copies are made for all other input parameters.
 * @param leng size of the entire simulated region
 * @param nbg number of genetic backgrounds; 0, if everything is neutral
 * @param state state[i] = -1 if the i-th site is a neutral site. If state[i] = j, then
 *              these sites have total deleterious mutation theta[j] and selection coefficient gamma[j]
 * @param gamma the selection coefficient; NULL if nbg=0
 * @param theta the total mutation for all the sites in a genetic background; NULL if nbg=0
 * @param init_stack_size
 * @return 
 */
chrom_stack_t * chrom_stack_new(int leng, int nbg, int *state, double *gamma, double *theta, int init_stack_size, gsl_rng *ran);

/**
 * Free all chrom_t objects in the stack and free the stack itself.
 */
void chrom_stack_free(chrom_stack_t *stack);

void chrom_stack_push(chrom_stack_t *chr_stack, chrom_t *chr);

/**
 * This creates a new chrom_t object that contains ancestral material from 0 to leng-1, and represents
 * the c-th chromosome in the sample (the entire sampling from all subpopulations) collected from the pop-th population.
 * <p>
 * The genetic backgrounds are initialised by sampling at random from Poisson(lambda), the distribution
 * of the number of deleterious mutations in that background.
 */
chrom_t * chrom_new(int c, int pop, chrom_stack_t *stack);


/**
 * @return the number of mutations in the i-th background. If nbg=0, then 0 is returned.
 */
int chrom_get_nmut(const chrom_t *chr, int i);

/**
 * Purge the mut_id-th mutation in the bg_id-th background.
 * <p>
 * This function should not be called if nbg=0.
 */
void chrom_purge_mut(chrom_t *chr, int mut_id, int bg_id, chrom_stack_t *stack);

/**
 * This splits chr according to the given breakpoint. The following are returned:
 * <ul>
 * <li> If the breakpoint falls between the leftmost and rightmost boundaries of
 *         ancestral segments carried by chr, such that these ancestral materials
 *         now reside in 2 different chrom_t objects after the split, then chr
 *         contains segments to the left of brk, and the returned object contains
 *         segments to the right. Both chrom_t objects belong to the same population.
 * <li> If the brk falls outside the leftmost and rightmost boundaries of
 *         ancestral segments carried by chr, but inside the boundaries defined
 *         by the leftmost selected site and the rightmost selected site, 
 *         then NULL is returned, but chr is updated to reflect how recombination
 *         affects that the genetic backgrounds, although these changes do not affect
 *         the ancestral segments.
 * <li> If none of the above is true, then nothing is done, and NULL is returned.
 * </ul>
 * @param brk Ranging from 0 to leng - 2, such that the breakpoint between the first
 *            and second site of the simulated region has brk 0.
 * @param frag_list is updated according to to whether brk results in a new fragment
 *            in the simulated region. This is only true when brk is within the boundaries
 *            of an ancestral segment in chr and this breakpoint is currently not in frag_list.
 */
chrom_t * chrom_split(chrom_t *chr, int brk, chrom_stack_t *chr_stack, frag_list_t *frag_list);

/**
 * chr1 and chr2 coalesce into the returned object. 
 * @param frag_list is updated according to the coalescent event.
 * @return NULL if all ancestral segments in both chr1 and chr2 have reached their MRCAs; otherwise return the 
 *         common ancestor of chr1 and chr2.
 */
chrom_t * chrom_ca(double time, const chrom_t * chr1, const chrom_t *chr2, chrom_stack_t *chr_stack, frag_list_t *frag_list);

/**
 * Move the chrom object to a new population with id pop.
 */
void chrom_switch_pop(chrom_t *chr, int pop);

int chrom_get_pop(const chrom_t *chr);

/**
 * <b>Important:</b> the rate is defined wrt the reference haploid population size.
 */
double chrom_coal_rate(const chrom_t *chr1, const chrom_t *chr2, chrom_stack_t *chr_stack);

void chrom_print_to_screen(const chrom_t *chr);
void chrom_print_to_screen_arr(const chrom_t **arr, int n);

#endif	/* CHROM_H */

