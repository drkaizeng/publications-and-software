/* 
 * File:   frag.h
 * Author: Kai
 *
 * Created on 11 February 2015, 07:40
 */

#ifndef FRAG_H
#define	FRAG_H

#include <stdbool.h>

#include "node.h"

typedef struct frag_tag frag_t;
typedef struct frag_list_tag frag_list_t;

/**
 * The tree returned by this function has the following properties:
 * 1. Tips: time=0
 * 2. Root: abv=-1
 */

/**
 * 
 */
frag_list_t * frag_list_new(int nsam, int leng, int init_stack_size);
void frag_list_free(frag_list_t *list);

/**
 * Initialise the list, so that it contains one fragment that spans from 0 to leng-1.
 * The tree contains nsam nodes, such that each node represents a chromosome in the
 * sample (i.e., the leaves of the tree). 
 * <p>
 * <b>Important:</b> This should be called before each simulation.
 */
void frag_list_init(frag_list_t *list);

/**
 * @return the number of elements in the current list
 */
int frag_list_size(const frag_list_t *list);

/**
 * Reset the iterator to the beginning of the list. This must be called before
 * the first invocation of frag_list_next_frag.
 * <p>
 * This method cannot be called if list is empty.
 */
void frag_list_iterator_reset(frag_list_t *list);

/**
 * <b>Important:</b> frag_list_reset must be called before this function is called
 * for the first time; otherwise the results are undefined.
 * @return NULL if the end of list has be reached; otherwise, the next fragment in the list
 *         is returned. All the returned objects are in strictly ascending order, such that
 *         the end of the frag_t returned by this call is one smaller than the beg of the
 *         frag_t returned by the next call.
 */
frag_t * frag_list_iterator_next(frag_list_t *list);

/**
 * @return The fragment that contains the site s, i.e., beg &le; s &le; end.
 */
frag_t * frag_list_find(const frag_list_t *list, int s);

/**
 * Find a fragment in the list and split it into two with one ending at brk, which ranges from 0 to leng-2, 
 * where leng is the size of the entire simulated region, and the other starting with brk+1. 
 * <p>
 * If the brk is already in the current list, then nothing is done.
 * @param brk [0, leng-2]
 */
void frag_list_split(frag_list_t *list, int brk);

/**
 * Sites are indexed from 0 to leng-1
 * @param beg first site in the fragment, inclusive
 * @param end last site in the fragment, inclusive
 */
void frag_get_limits(const frag_t *f, int *beg, int *end);

/**
 * The i-th and j-th lineages of the tree in this fragment coalesce at time t.
 * @param i &ne; j; 0 &le; i &le; <code>f->nnodes</code>
 * @param j &ne; i; 0 &le; j &le; <code>f->nnodes</code>
 * @return the id of the node in the tree that has been added due to this event. The first
 *         node as id 0. The alleles in the sampled are indexed from 0 to nsam-1. The first
 *         ancestor node backwards in time has index nsam, etc.
 */
int frag_add_ca(frag_t *f, int i, int j, double t);

/**
 * @return true of the mrca of the fragment has been reached.
 */
bool frag_has_mrca(const frag_t *f);

/**
 * The returned tree should be freed by matrixalloc_1d_free
 */
node_t * frag_clone_tree(const frag_t *f);

/**
 * <b>Important:</b> The returned tree should not be altered.
 * 
 * @return The tree stored internally in f. 
 */
const node_t * frag_get_tree(const frag_t *f);

void frag_list_print_to_screen(const frag_list_t *list);

#endif	/* FRAG_H */

