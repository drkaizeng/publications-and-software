/*
 * File:   test_msbgs_cmd.c
 * Author: Kai
 *
 * Created on 04-Jun-2015, 18:51:32
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <limits.h>
#include <string.h>
#include <time.h>

#include "msbgs_param.h"

#include "util/string_util.h"
#include "util/arrayutil.h"
#include "util/matrixalloc.h"

#include "event.h"
#include "msbgs_util.h"
#include "theory.h"

static void print_error(const char *message) {
    fprintf(stderr, "Error:");
    fprintf(stderr, "%s\n\n", message);
    exit(EXIT_FAILURE);
}

/**
 * <b>Important:</b> This function has to be run when there are sites under selection.
 * <p>
 * <b>Important:</b> It is assumed that state has been filled with -1 before calling this function.
 * 
 * @param s The string to be processed. This will be changed by the function.
 * @param sel_arr_leng The number of selection coefficients
 * @param length The length of the simulated region.
 * @param state On return, -1 for a neutral site; 0 for sites using the first selection coefficent from sel_arr; etc
 * @return an integer array, which should be freed by matrixalloc_1d_free, listing the number of 
 *         sites in each genetic background.
 * @since 2015.6.11, 6.14
 */
static int * get_state(char *s, int sel_arr_leng, int length, int state[length]) {
    int n_ele = 0;
    char **element = string_util_split(s, ";", &n_ele);
    if (n_ele != sel_arr_leng) {
        print_error("There must be the same number of elements in both sel_def and region_def!");
    }
    bool hasBeenSet[length];
    arrayutil_fill_b(hasBeenSet, 0, length, false);
    int *bg_leng = matrixalloc_1d_init(sel_arr_leng, sizeof (int));
    string_util_parse_state_t parse_state = string_util_parse_state_init;
    char *endptr;
    for (int ii = 0; ii < n_ele; ii++) {
        char *ele = string_util_trim(element[ii]);
        if (! (string_util_starts_with(ele, "[") == true && string_util_ends_with(ele, "]") == true)) {
            fprintf(stderr, "Error: Problems in element %i of region_def; an element must be surrounded by []!", ii);
            exit(EXIT_FAILURE);
        }
        ele = ele + 1;
        ele[strlen(ele) - 1] = '\0';
        int n_sub = 0;
        char **sub_ele = string_util_split(ele, ",", &n_sub);
        if (n_sub < 1) {
            fprintf(stderr, "Error: Problems in element %i of region_def", ii);
            exit(EXIT_FAILURE);
        }
        for (int jj = 0; jj < n_sub; jj++) {
            char *sub = string_util_trim(sub_ele[jj]);
            if (string_util_starts_with(sub, "(") == true && string_util_ends_with(sub, ")") == true) {
                sub = sub + 1;
                sub[strlen(sub) - 1] = '\0';
                int n = 0;
                char **ss = string_util_split(sub, "_", &n);
                if (n != 3) {
                    fprintf(stderr, "Error: Problems in sub-element %i of element %i of region_def; (start_step_cn) is expected!", jj, ii);
                    exit(EXIT_FAILURE);
                }
                parse_state = string_util_parse_state_init;
                int start = string_util_parse_int(ss[0], &endptr, 10, &parse_state);
                if (parse_state != string_util_parse_state_success) {
                    fprintf(stderr, "Error: Problems in sub-element %i of element %i of region_def; start is not an integer!", jj, ii);
                    exit(EXIT_FAILURE);
                }

                parse_state = string_util_parse_state_init;
                int step = string_util_parse_int(ss[1], &endptr, 10, &parse_state);
                if (parse_state != string_util_parse_state_success) {
                    fprintf(stderr, "Error: Problems in sub-element %i of element %i of region_def; step is not an integer!", jj, ii);
                    exit(EXIT_FAILURE);
                }

                parse_state = string_util_parse_state_init;
                int cn = string_util_parse_int(ss[2], &endptr, 10, &parse_state);
                if (parse_state != string_util_parse_state_success) {
                    fprintf(stderr, "Error: Problems in sub-element %i of element %i of region_def; cn is not an integer!", jj, ii);
                    exit(EXIT_FAILURE);
                }

                matrixalloc_1d_free(ss);

                if (start < 0 || step < 1 || cn < 1) {
                    fprintf(stderr, "Error: Problems in sub-element %i of element %i of region_def; start, step or cn out of bounds!", jj, ii);
                    exit(EXIT_FAILURE);
                }
                int limit = (INT_MAX - start) / step;
                if (cn >= limit) {
                    fprintf(stderr, "Error: Problems in sub-element %i of element %i of region_def; "
                            "(start_step_cn) defines integers larger than INT_MAX", jj, ii);
                    exit(EXIT_FAILURE);
                }
                for (int j = 0, pos = start; j <= cn; j++, pos += step) {
                    if (pos < 0 || pos >= length) {
                        print_error("region_def contains sites with positions < 0 or >= leng!");
                    }
                    if (hasBeenSet[pos] == true) {
                        fprintf(stderr, "Error: Site %d has been set more than once!", pos);
                        exit(EXIT_FAILURE);
                    }
                    hasBeenSet[pos] = true;
                    state[pos] = ii;
                    bg_leng[ii]++;
                }
            } else {
                parse_state = string_util_parse_state_init;
                int pos = string_util_parse_int(sub, &endptr, 10, &parse_state);
                if (parse_state != string_util_parse_state_success) {
                    print_error("Bad format in region_def!");
                }
                if (pos < 0 || pos >= length) {
                    print_error("region_def contains index < 0 or >= leng!");
                }
                if (hasBeenSet[pos] == true) {
                    fprintf(stderr, "Error: Site %d has been set more than once!", pos);
                    exit(EXIT_FAILURE);
                }
                hasBeenSet[pos] = true;
                state[pos] = ii;
                bg_leng[ii]++;
            }
        }
        matrixalloc_1d_free(sub_ele);
    }
    matrixalloc_1d_free(element);
    for (int i = 0; i < sel_arr_leng; i++) {
        if (bg_leng[i] == 0) {
            fprintf(stderr, "Error: %s %d %s", "Element", i, "defined in sel_def contains no corresponding site in region_def!");
            exit(EXIT_FAILURE);
        }
    }
    return bg_leng;
}

typedef enum {
    /** No calculation
     */
    msbgs_cmd_nes_no_cal,
    /** Find the smallest Ne*s
     */        
    msbgs_cmd_nes_min,        
    /** Find Ne*s for all selected sites
     */        
    msbgs_cmd_nes_selected,
    /** Find B for all sites (neutral and selected)
     */        
    msbgs_cmd_nes_B        
} msbgs_cmd_nes_action_t;

typedef struct {
    /**
     * All parameters are initialised.
     */
    msbgs_param_t *msp;
    int nrep;
    /**
     * theta per neutral site.
     * u * Nr, where u is the mutation rate per site per generation
     */
    double thps;
    /**
     * r * Nr, where r is the recombination rate per site per generation
     */    
    double rhops;
    unsigned long int seed;
    /**default=msbgs_cmd_nes_no_cal
     */
    msbgs_cmd_nes_action_t nes_action;
    /**default=false
     */
    bool use_ms_format;
} msbgs_cmd_param_t;

/**
 * @since 2015.6.11
 */
static void msbgs_cmd_param_free(msbgs_cmd_param_t *param) {
    gsl_rng_free(param->msp->ran);
    event_list_free(param->msp->event_list);
    matrixalloc_1d_free(param->msp->theta);
    matrixalloc_1d_free(param->msp->gamma);
    matrixalloc_1d_free(param->msp->state);
    matrixalloc_2d_d_free(param->msp->mig_mat);
    matrixalloc_1d_free(param->msp->sam_config);
    matrixalloc_1d_free(param->msp->pop_size);
    matrixalloc_1d_free(param->msp);
    matrixalloc_1d_free(param);
}

/**
 * Process the basic command line:
 * <p>
 * msbgs nsam leng nrep –t theta –r rho –sel sel_def –region region_def [-seed seed]
 * <p>
 * It is expected that the order of the switches is given as above.
 * 
 * @param next_argv_indx On return, this contains the index of the parameter after that last one
 *                       that is processed by this function.
 * @return The msbgs_cmd_param_t is initialised such that simulation with a single constant-sized population 
 *         can be carried out. nes_action is set to msbgs_cmd_nes_no_cal
 * @since 2015.6.11, 6.14
 */
static msbgs_cmd_param_t * get_basic_cmd(int argc, char **argv, int *next_argv_indx) {
    string_util_parse_state_t parse_state;
    char *endptr;
    
    int argv_indx = 1;
    parse_state = string_util_parse_state_init;
    int nsam = string_util_parse_int(argv[argv_indx++], &endptr, 10, &parse_state);
    if (parse_state != string_util_parse_state_success) {
        print_error("nsam is not an integer!");
    }
    if (nsam < 2) {
        print_error("nsam < 2");
    }
    
    parse_state = string_util_parse_state_init;
    int leng = string_util_parse_int(argv[argv_indx++], &endptr, 10, &parse_state);
    if (parse_state != string_util_parse_state_success) {
        print_error("leng is not an integer!");
    }
    if (leng < 1) {
        print_error("leng < 1");
    }
    
    parse_state = string_util_parse_state_init;
    int nrep = string_util_parse_int(argv[argv_indx++], &endptr, 10, &parse_state);
    if (parse_state != string_util_parse_state_success) {
        print_error("nrep is not an integer!");
    }
    if (nrep < 0) {
        print_error("nrep < 0");
    }
    
    if (string_util_equal("-t", argv[argv_indx++]) == false) {
        print_error("-t is missing!");
    }
    parse_state = string_util_parse_state_init;
    double thps = string_util_parse_double(argv[argv_indx++], &endptr, &parse_state);
    if (parse_state != string_util_parse_state_success) {
        print_error("theta is not a real number!");
    }
    if (thps <= 0 || isnan(thps) || isinf(thps)) {
        print_error("theta <= 0 or is NAN or is INFINITY!");
    }
    
    if (string_util_equal("-r", argv[argv_indx++]) == false) {
        print_error("-r is missing!");
    }
    parse_state = string_util_parse_state_init;
    double rhops = string_util_parse_double(argv[argv_indx++], &endptr, &parse_state);
    if (parse_state != string_util_parse_state_success) {
        print_error("rho is not a real number!");
    }
    if (rhops < 0 || isnan(rhops) || isinf(rhops)) {
        print_error("rho < 0 or is NAN or is INFINITY!");
    }
    
    if (string_util_equal("-sel", argv[argv_indx++]) == false) {
        print_error("-sel is missing!");
    }
    int sel_arr_leng = -1;
    double *sel_arr;
    bool isNeu = false;
    {
        char **arr = string_util_split(argv[argv_indx++], ",", &sel_arr_leng);
        sel_arr = matrixalloc_1d(sel_arr_leng, sizeof (double));
        if (sel_arr_leng == 0) {
            print_error("No element was found in sel_def!");
        }
        for (int i = 0; i < sel_arr_leng; i++) {
            parse_state = string_util_parse_state_init;
            sel_arr[i] = string_util_parse_double(arr[i], &endptr, &parse_state);
            if (parse_state != string_util_parse_state_success) {
                print_error("Failed to convert sel_def to double!");
            }
            if (sel_arr_leng != 1 && sel_arr[i] == 0) {
                print_error("sel_def can be 0 only when it contains exactly one element!");
            }
            if (sel_arr[i] < 0) {
                print_error("Negative elements in sel_def!");
            }
        }
        if (sel_arr_leng == 1 && sel_arr[0] == 0) {
            isNeu = true;
        }
        matrixalloc_1d_free(arr);
    }
    
    if (string_util_equal("-region", argv[argv_indx++]) == false) {
        print_error("-region is missing!");
    }
    int *state = matrixalloc_1d(leng, sizeof (int));
    arrayutil_fill_i(state, 0, leng, -1);
    int nbg;
    int *bg_leng;
    if (isNeu == true) {
        nbg = 0;
        bg_leng = NULL;
        if (string_util_equal("neutral", argv[argv_indx++]) == false) {
            print_error("\"-region neutral\" is expected!");
        }
    } else {
        nbg = sel_arr_leng;
        bg_leng = get_state(argv[argv_indx++], sel_arr_leng, leng, state);
    }
    
    unsigned long seed;
    if (argv_indx < argc && string_util_equal("-seed", argv[argv_indx]) == true) {
        argv_indx++;
        if (argv_indx >= argc) {
            print_error("seed missing!");
        }
        parse_state = string_util_parse_state_init;
        seed = string_util_parse_ulong(argv[argv_indx++], &endptr, 10, &parse_state);
        if (parse_state != string_util_parse_state_success) {
            print_error("Failed to convert seed to unsigned long!");
        }
    } else {
        seed = (unsigned long) time(NULL);
    }
    
    msbgs_cmd_param_t *re = matrixalloc_1d(1, sizeof (msbgs_cmd_param_t));
    re->msp = matrixalloc_1d(1, sizeof (msbgs_param_t));
    re->msp->nsam = nsam;
    re->msp->leng = leng;
    re->msp->npop = 1;
    re->msp->pop_size = matrixalloc_1d(1, sizeof (double));
    re->msp->pop_size[0] = 1.0;
    re->msp->sam_config = matrixalloc_1d(1, sizeof (int));
    re->msp->sam_config[0] = nsam;
    re->msp->mig_mat = NULL;
    re->msp->rho = rhops * leng;
    re->msp->nbg = nbg;
    re->msp->state = matrixalloc_1d(leng, sizeof (int));
    matrixalloc_1d_cpy1(re->msp->state, state, leng, sizeof (int));
    if (nbg == 0) {
        re->msp->gamma = NULL;
        re->msp->theta = NULL;
    } else {
        re->msp->gamma = matrixalloc_1d(nbg, sizeof (double));
        re->msp->theta = matrixalloc_1d(nbg, sizeof (double));
        for (int i = 0; i < nbg; i++) {
            re->msp->gamma[i] = sel_arr[i];
            re->msp->theta[i] = thps * bg_leng[i];
        }
    }
    re->msp->event_list = NULL;
    re->msp->chrom_stk_init_size = 1;
    re->msp->frag_list_init_size = 1;
    re->msp->ran = gsl_rng_alloc(gsl_rng_mt19937);
    if (re->msp->ran == NULL) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    gsl_rng_set(re->msp->ran, seed);
    
    re->nrep = nrep;
    re->thps = thps;
    re->rhops = rhops;
    re->seed = seed;
    re->nes_action = msbgs_cmd_nes_no_cal;
    re->use_ms_format = false;
    
    (*next_argv_indx) = argv_indx;
    
    matrixalloc_1d_free(state);
    matrixalloc_1d_free(bg_leng);
    matrixalloc_1d_free(sel_arr);
    
    return re;
}

/**
 * Build an event_list if it has not been initialised yet.
 * @param msp
 * @since 2015.6.11
 */
static void init_event_list(msbgs_param_t *msp) {
    if (msp->event_list == NULL) {
        msp->event_list = event_list_new();
    }
}

/**
 * @param argv_indx Index of the first unprocessed element in argv
 * @since 2015.6.11(-eN), 6.14 (-nes), 7.6 (-ms_format)
 */
static void get_other_cmd(int argc, char **argv, int argv_indx, msbgs_cmd_param_t *param) {
    string_util_parse_state_t parse_state = string_util_parse_state_init;
    char *endptr;
    
    while (argv_indx < argc) {
        if (string_util_equal(argv[argv_indx], "-nes") == true) {
            argv_indx++;
            if (argv_indx >= argc) {
                print_error("More parameters are needed after -nes!");
            }
            if (string_util_equal(argv[argv_indx], "min") == true) {
                param->nes_action = msbgs_cmd_nes_min;
            } else if (string_util_equal(argv[argv_indx], "selected") == true) {
                param->nes_action = msbgs_cmd_nes_selected;
            } else if (string_util_equal(argv[argv_indx], "B") == true) {
                param->nes_action = msbgs_cmd_nes_B;
            } else {
                print_error("Unknown option after -nes!");
            }
            argv_indx++;
        } else if (string_util_equal(argv[argv_indx], "-eN") == true) {//Set all subpopulations' size to x * Nr and growth rates to zero
            argv_indx++;
            if (argv_indx >= argc) {
                print_error("More parameters are needed after -eN!");
            }
            int arr_leng = 0;
            char **arr = string_util_split(argv[argv_indx++], ",", &arr_leng);
            if (arr_leng != 2) {
                print_error("Two numbers in quotation marks should follow -eN!");
            }
            parse_state = string_util_parse_state_init;
            double time = string_util_parse_double(arr[0], &endptr, &parse_state);
            if (parse_state != string_util_parse_state_success) {
                print_error("Failed to recognise t after -eN!");
            }
            if (time < 0) {
                print_error("t after -eN should be non-negative!");
            }
            parse_state = string_util_parse_state_init;
            double new_size = string_util_parse_double(arr[1], &endptr, &parse_state);
            if (parse_state != string_util_parse_state_success) {
                print_error("Failed to recognise x after -eN!");
            }
            if (new_size <= 0) {
                print_error("x after -eN should be positive!");
            }
            init_event_list(param->msp);
            event_list_add_pop_size_change(param->msp->event_list, time, -1, new_size);
            matrixalloc_1d_free(arr);
        } else if (string_util_equal(argv[argv_indx], "-ms_format") == true) {
            argv_indx++;
            param->use_ms_format = true;
        } else {
            fprintf(stderr, "Error: Unrecognised argument %s\n", argv[argv_indx]);
            exit(EXIT_FAILURE);
        }
    }
    if (param->msp->event_list != NULL) {
        event_name_t name;
        double time;
        int pop;
        bool hasProblem = event_list_check_pop_indx(param->msp->event_list, param->msp->npop, &name, &time, &pop);
        if (hasProblem == true) {
            fprintf(stderr, "Error: The population index (%i) specified by the event occurring "
                    "at time %.15f exceeds the number of populations available at that time. "
                    "Note that the first population has index 0.\n", pop, time);
            exit(EXIT_FAILURE);
        }
    }
}

/*
 * @since 2015.6.11
 */
int main(int argc, char** argv) {
    if (argc < 12) {
        print_error("Not enough parameters! Basic usage:\n"
                "msbgs nsam leng nrep –t theta –r rho –sel sel_def –region region_def [-seed seed]");
    }
    for (int i = 0; i < argc; i++) {
        printf("%s ", argv[i]);
    }
    printf("\n");
    
    int argv_indx;
    msbgs_cmd_param_t *param = get_basic_cmd(argc, argv, &argv_indx);
    if (argv_indx < argc) {
        get_other_cmd(argc, argv, argv_indx, param);
    }
    
    if (param->use_ms_format == false)
        printf("\nseed: %lu\n\n", param->seed);
    else {
        printf("%lu %lu %lu\n\n", param->seed, param->seed, param->seed);
    }
    
    if (param->nes_action != msbgs_cmd_nes_no_cal) {
        int nsel = 0;
        for (int i = 0; i < param->msp->leng; i++) {
            if (param->msp->state[i] >= 0) {
                nsel++;
            }
        }
        if (nsel <= 0) {
            print_error("No selected site was found when trying to calculate Ne*s or B!");
        }
        if (param->nes_action == msbgs_cmd_nes_B) {
            double B[param->msp->leng];
            theory_get_B(param->thps, param->rhops, param->msp->nbg, param->msp->gamma, param->msp->leng, param->msp->state, B);
            printf("nes_B:");
            for (int i = 0; i < param->msp->leng; i++) {
                printf(" %.9f", B[i]);
            }
        } else {
            double nes[nsel];
            double min_nes = theory_get_nes(param->thps, param->rhops, param->msp->nbg, param->msp->gamma, param->msp->leng, param->msp->state, nsel, nes);
            if (param->nes_action == msbgs_cmd_nes_min) {
                printf("nes_min: %.9f", min_nes);
            } else {
                printf("nes_selected:");
                for (int i = 0; i < nsel; i++) {
                    printf(" %.9f", nes[i]);
                }
            }
        }
        printf("\n\n");
    }
    
    msbgs_t *msb = msbgs_new(param->msp);
    msbgs_util_seq_t *seq = msbgs_util_seq_new(param->msp, param->thps, 1);
    for (int i = 0; i < param->nrep; i++) {
        msbgs_simulate(msb);
        msbgs_util_seq_gen(msb, seq);
        printf("//\n");
        if (param->use_ms_format == false) {
            printf("mean_coal_rate: %.9f\n", msbgs_util_get_mean_coal_rate(msb));
        }
        msbgs_util_seq_print_to_screen(seq);
        printf("\n");
    }
    
    msbgs_util_seq_free(seq);
    msbgs_free(msb);
    msbgs_cmd_param_free(param);

    return (EXIT_SUCCESS);
}
