/* 
 * File:   event.h
 * Author: kai
 *
 * Created on 23 January 2015, 14:53
 */

#ifndef EVENT_H
#    define	EVENT_H

#include <stdbool.h>

typedef enum {
    event_name_init,
    /** Merge pop2 into pop1. The resulting population has the size of pop1 */        
    event_name_pop_merger,
    /** One population (pop1) changes its size to paramv */        
    event_name_pop_size_change            
} event_name_t;

typedef struct event_tag event_t;

typedef struct event_list_tag event_list_t;

/**
 * Construct a new, empty event list.
 */
event_list_t * event_list_new(void);

/**
 * Free the memory occupied by the linked list.
 */
void event_list_free(event_list_t *list);

/**
 * This function creates a deep copy of the linked list pointed to ppevent.
 */
event_list_t * event_list_clone(const event_list_t *src);

/**
 * Reset the list, so that the next call of event_list_next_event will return
 * the first event in the list. NULL is returned if the list is empty.
 */
void event_list_iterator_reset(event_list_t *list);

/**
 * If there are multiple events occurring at the same time, the order they are
 * returned is the same as the order they were added to the list.
 * 
 * @return the next event in the list. NULL is returned if the list is empty or
 * the end of the list has been reached.
 */
event_t * event_list_iterator_next(event_list_t *list);

event_name_t event_get_name(const event_t *e);
double event_get_time(const event_t *e);

/**
 * Add a population merger event to the end of the list, whereby pop2 is merged into pop1, and the resulting
 * population takes the id of pop1 and its size. 
 * <p>
 * The new event must be at least as old as the last event in the list.
 */
void event_list_add_pop_merger(event_list_t *list, double time, int pop1, int pop2);
void event_get_param_pop_merger(const event_t *e, int *pop1, int *pop2);

/**
 * Add a population size change event to the end of the list, whereby pop has new_size after the change,
 * where new_size is measure relative to the reference haploid population size. 
 * <p>
 * The new event must be at least as old as the last event in the list.
 * @param pop The index of the population affected (the first population has index 0). If -1, then
 *            all populations existing at the time are changed.
 */
void event_list_add_pop_size_change(event_list_t *list, double time, int pop, double new_size);
void event_get_param_pop_size_change(const event_t *e, int *pop, double *new_size);

/**
 * Go through the list and check that all population indices are in [0, npop-1], where
 * npop is the number of populations at the time.
 * 
 * @param init_npop The number of populations at time 0
 * @param time Stores the time when the problematic event is set to occur
 * @param pop Stores the offending index if there is a problem.
 * @return True if there is a problem; false if no problem.
 */
bool event_list_check_pop_indx(const event_list_t *list, int init_npop, event_name_t *name, double *time, int *pop);

#endif	/* EVENT_H */

