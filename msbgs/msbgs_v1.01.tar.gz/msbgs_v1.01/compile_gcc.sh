GSL_INCLUDE=/Users/Kai/gsl-1.15-g3O0/include
GSL_LIB=/Users/Kai/gsl-1.15-g3O0/lib
gcc -std=c99 -O3 -I$GSL_INCLUDE *.c ./util/arrayutil_binary_search_init.c ./util/arrayutil_fill_init.c ./util/arrayutil_quick_sort_init.c ./util/arrayutil_sum_init.c ./util/matrixalloc_1d.c  ./util/matrixalloc_init.c ./util/my_stack.c ./util/string_util.c -L$GSL_LIB -lgsl -lgslcblas -lm -o msbgs


