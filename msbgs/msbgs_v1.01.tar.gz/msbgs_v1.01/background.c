#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <assert.h>
#include <float.h>
#include <limits.h>

#include "background.h"

#include "gsl/gsl_randist.h"
#include "gsl/gsl_sf_gamma.h"

#include "util/arrayutil.h"
#include "util/my_stack.h"
#include "util/matrixalloc.h"

struct background_tag {
    int leng;//total number of sites
    int sum;//total number of mutations
    
    int n;//the lengths of pts and mut
    /**
     * the positions are defined by the selected sites only, ignoring the neutral sites.
     * pts[i] can take value in the range from 0 to (L-1), where L is the total number 
     * selected sites that define the background. The first interval is [0, pts[0]], and the
     * second is [pts[0]+1, pts[1]], etc. Note that pts[pts.length-1]+1 = L
     * is the total number of selected sites. Note also that pts[i-1] &lt; pts[i].
     */
    int *pts;
    int *mut;
    int capacity;//the maximum number of elements pts and mut can currently hold
    
    double prob;//the multinomial probability
    bool recal;
};

struct background_stack_tag {
    my_stack_t *stack;
    int leng;
    int leng_m1;
    // These are for finding intersects
    int last_intersect_n;//the number of elements in pts and mut found by the most recent call to get_intersect
    int *pts_intersect;
    int *mut_intersect;
    int *mut1_save;
    int *mut2_save;
    
    // These 2 arrays are for replacing and building new segments
    int *newPts;
    int *newMut;
};

/** 
 * @since 2013.03.12, 2013.03.22, 2013.03.29, 2015.01.29, 2.18
 */
background_stack_t * background_stack_new(int leng, int stack_init_size) {
    assert(DBL_MAX > INT_MAX);
    if (leng <= 0 || leng >= (INT_MAX / 2)) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    
    background_stack_t *re = matrixalloc_1d(1, sizeof(background_stack_t));
    
    re->stack = my_stack_new(stack_init_size, 0);
    
    re->leng = leng;
    re->leng_m1 = leng - 1;

    size_t s = sizeof (int);

    re->pts_intersect = matrixalloc_1d(leng, s);

    re->mut_intersect = matrixalloc_1d(leng, s);

    re->mut1_save = matrixalloc_1d(leng, s);

    re->mut2_save = matrixalloc_1d(leng, s);

    re->newPts = matrixalloc_1d(leng, s);

    re->newMut = matrixalloc_1d(leng, s);

    return re;    
}

/** 
 * @since 2013.02.22, 2013.02.23, 2013.03.12, 2013.04.01, 2015.01.30, 2.18
 */
static inline void background_free(void *data) {
    background_t *bgd = (background_t *) data;
    matrixalloc_1d_free(bgd->pts);
    matrixalloc_1d_free(bgd->mut);
    matrixalloc_1d_free(bgd);
}

/** 
 * @since 2013.03.12, 2013.04.01, 2015.01.30, 2.18
 */
void background_stack_free(background_stack_t *stack) {
    matrixalloc_1d_free(stack->pts_intersect);
    matrixalloc_1d_free(stack->mut_intersect);
    matrixalloc_1d_free(stack->mut1_save);
    matrixalloc_1d_free(stack->mut2_save);
    matrixalloc_1d_free(stack->newPts);
    matrixalloc_1d_free(stack->newMut);
    my_stack_clear_free(stack->stack, background_free);
    my_stack_free(stack->stack);
    matrixalloc_1d_free(stack);
}

/**
 * @since 2015.2.19
 */
static inline int min(int a, int b) {
    if (a < b)
        return a;
    else
        return b;
}

/**
 * @since 2013.02.25, 2013.03.12, 2013.03.29, 2013.04.01, 2015.01.30, 2.19
 */
static inline void ensure_capacity(background_t *bg, int n) {
    if (n > bg->capacity) {    
        static const int LIMIT = INT_MAX / 2;
        if (n >= LIMIT) {
            fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
            abort();
        }
        bg->capacity = min(bg->leng, n * 2);
        size_t s = sizeof (int);
        bg->pts = matrixalloc_1d_realloc(bg->pts, bg->capacity, s);
        bg->mut = matrixalloc_1d_realloc(bg->mut, bg->capacity, s);
    }
}

/** 
 * Create a new background_T with capacity n
 * @since 2013.02.22, 2013.02.23, 2012.02.25 (added capacity), 2013.03.12, 2015.01.29, 2.18
 */
static inline background_t * create(int init_capacity, background_stack_t *stack) {
    background_t *re = my_stack_pop(stack->stack);
    if (re == NULL) {
        re = matrixalloc_1d(1, sizeof(background_t));
        size_t s = sizeof(int);
        re->pts = matrixalloc_1d(init_capacity, s);
        re->mut = matrixalloc_1d(init_capacity, s);
        re->capacity = init_capacity;
    } else {
        ensure_capacity(re, init_capacity);
    }
    return re;
}

/*
 * @since 2013.02.22, 2013.02.23, 2013.02.24, 2013.02.25 (added capacity), 2013.03.12, 2013.03.23 (removed leng as parameter)
 * 2015.01.29, 2.18
 */
background_t * background_new(int sum, background_stack_t *stack) {    
    if (sum < 0) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    background_t *re = create(1, stack);
    re->leng = stack->leng;
    re->sum = sum;
    re->n = 1;
    re->pts[0] = stack->leng_m1;
    re->mut[0] = sum;
    re->prob = 1;
    re->recal = false;
    
#ifdef BACKGROUND_CHECK
    background_check(re);
#endif
    
    return re;
}

/*
 * @since 2013.03.22, 2013.04.01, 2015.01.30, 2.18
 */
background_t *background_new1(double lambda, background_stack_t *stack, gsl_rng *ran) { 
    if (lambda < 0) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    background_t *re = create(1, stack);
    re->leng = stack->leng;
    re->sum = (int) gsl_ran_poisson(ran, lambda);
    re->n = 1;
    re->pts[0] = stack->leng - 1;
    re->mut[0] = re->sum;
    re->prob = 1;
    re->recal = false;    
    return re;
}

///**
// * Creates a background_t object with pts and mut, both of which have n elements. leng = pts[n - 1]+1.
// * Defensive copying is done for both pts and mut.
// * @since 2013.02.22, 2013.02.23 (found bug), 2013.02.24, 2013.02.25 (added capacity; found bug), 2013.03.12
// */
//static background_t *background_new2(int n, const int *pts, const int *mut, background_stack_t *stack) {
//#ifdef BACKGROUND_CHECK
//    assert(n <= stack->leng);
//    assert((pts[n - 1] + 1) == stack->leng);
//#endif
//    
//    background_t *re = create(n, stack);
//    re->leng = pts[n - 1] + 1;//2013.02.23 added "+1"
//    re->sum = arrayutil_sum_i_i(mut, 0, n);
//    re->n = n;
//    size_t s = sizeof(int) * (size_t) n;
//    memcpy(re->pts, pts, s);
//    memcpy(re->mut, mut, s);
//    re->recal = true;
//    return re;//2013.02.25
//}

/** 
 * @since 2013.02.22, 2013.02.23, 2013.03.12, 2015.2.18
 */
void background_stack_push(background_stack_t *stack, background_t *bg) {
#ifdef BACKGROUND_CHECK
    assert(bg->leng == stack->leng);
#endif
    my_stack_push(stack->stack, bg);
}

/** 
 * @since 2015.2.18
 */
int background_sum(const background_t *bg) {
    return bg->sum;
}

/** 
 * @since 2013.02.23 (night), 2013.03.12 (by eye), 2013.03.29, 2015.01.30, 2.19
 */
static inline double get_prob(int leng, int sum, int n, const int *pts, const int *mut) {
    if (n == 1 || sum == 0) {
        return 1.0;
    } else {
        /* Multinomial */
        double a = gsl_sf_lnfact((unsigned int) sum);
        for (int i = 0; i < n; i++)
            a -= gsl_sf_lnfact((unsigned int) mut[i]);
        double lo = 0.0, hi, tmp;
        for (int i = 0; i < n; i++) {
            hi = (pts[i] + 1.0) / leng;
            tmp = hi - lo;
            a += mut[i] * log(tmp);
            lo = hi;
        }
        return exp(a);
    }
}

/** 
 * @since 2013.02.23, 2013.03.12, 2013.03.29, 2015.01.30, 2.19
 */
double background_prob(background_t *bg) {
    if (bg->recal == false) {
        return bg->prob;
    } else {
        bg->prob = get_prob(bg->leng, bg->sum, bg->n, bg->pts, bg->mut);
        bg->recal = false;
        return bg->prob;
    }
}

/**
 * Store the number of useful elements in intersect_pts and intersect_mut in last_intersect_n
 * If the two backgrounds are incompatible, then last_intersect_n = -1
 * @since 2013.02.25, 2013.03.12, 2013.03.29 (by eye), 2013.04.01, 2015.2.19
 */
static inline void get_intersect(const background_t *bg1, const background_t *bg2, background_stack_t *stack) {
    int *mut1_save = stack->mut1_save;    
    int *mut2_save = stack->mut2_save;
    int n1 = bg1->n;
    int n2 = bg2->n;
    memcpy(mut1_save, bg1->mut, (size_t) (n1) * sizeof(int));
    memcpy(mut2_save, bg2->mut, (size_t) (n2) * sizeof(int));
    const int *pts1 = bg1->pts;
    const int *pts2 = bg2->pts;
    int index1 = 0;
    int index2 = 0;
    stack->last_intersect_n = 0;
    int end;
    int nmut;
    int *pts_intersect = stack->pts_intersect;
    int *mut_intersect = stack->mut_intersect;
    while (true) {
#ifdef BACKGROUND_CHECK
        if (stack->last_intersect_n >= stack->leng) {
            printf("Error: last_intersect_n >= store->leng");
            abort();
        }
#endif
        if (pts1[index1] > pts2[index2]) {
            end = pts2[index2];
            nmut = mut2_save[index2];
            mut1_save[index1] -= nmut;
            if (mut1_save[index1] < 0) {
                stack->last_intersect_n = -1;
                return;
            }
            index2++;
        } else if (pts1[index1] == pts2[index2]) {
            end = pts1[index1];
            if (mut1_save[index1] == mut2_save[index2])
                nmut = mut1_save[index1];
            else {
                stack->last_intersect_n = -1;
                return;
            }
            index1++;
            index2++;
        } else {
            end = pts1[index1];
            nmut = mut1_save[index1];
            mut2_save[index2] -= nmut;
            if (mut2_save[index2] < 0) {
                stack->last_intersect_n = -1;
                return;
            }
            index1++;
        }
        pts_intersect[stack->last_intersect_n] = end; 
        mut_intersect[stack->last_intersect_n] = nmut;
        stack->last_intersect_n++;
        if (index1 >= n1 && index2 >= n2) {
            return;
        }
    }
}

/**
 * <Important>: this function assumes that bg1-sum == bg2->sum.
 * 
 * Obtain the multinomial probability for the intersect of 2 backgrounds with the same number of mutations.
 * That's the nominator of the right-hand side of Eq. 11 in Zeng and Charlesworth 2011.
 * Return 0 if the two backgrounds are incompatible.
 * @since 2013.02.25, 2013.03.12, 2013.03.29, 2013.04.01, 2015.2.19
 */
static inline double intersect_prob(background_t *bg1, background_t *bg2, background_stack_t *stack) {
    int n1 = bg1->n, n2 = bg2->n;
    if (n1 == 1 && n2 == 1) {
        return 1.0;
    } else if (n1 == 1) {
        return background_prob(bg2);
    } else if (n2 == 1) {
        return background_prob(bg1);
    } else {
        get_intersect(bg1, bg2, stack);
        if (stack->last_intersect_n < 0)
            return 0;
        else {
#ifdef BACKGROUND_CHECK
            assert(bg1->sum == bg2->sum);
            assert(bg1->sum == arrayutil_sum_i(stack->mut_intersect, 0, stack->last_intersect_n));
#endif
            return get_prob(bg1->leng, bg1->sum, stack->last_intersect_n, stack->pts_intersect, stack->mut_intersect);
        }
    }
}

/** 
 * @since 2013.02.25, 2013.03.12, 2013.03.23, 2015.01.30, 2.19
 */
static inline background_t *clone(const background_t *bg, background_stack_t *stack) {
    background_t *re = create(bg->n, stack);
    re->leng = bg->leng;
    re->sum = bg->sum;
    re->n = bg->n;
    re->prob = bg->prob;
    re->recal = bg->recal;
    size_t tmp = (size_t) (bg->n) * sizeof(int);
    memcpy(re->pts, bg->pts, tmp);
    memcpy(re->mut, bg->mut, tmp);
    return re;
}

/** 
 * @since 2013.02.25, 2013.03.12, 2013.03.29, 2013.04.01, 2015.01.29, 2.19
 */
double background_coal_prob(background_t *bg1, background_t *bg2, background_stack_t *stack) {
#ifdef BACKGROUND_CHECK
    assert(bg1->leng == bg2->leng && bg1->leng == stack->leng);
#endif
    if (bg1->sum != bg2->sum)
        return 0;
    else {
        double prob = intersect_prob(bg1, bg2, stack);
        if (prob == 0)
            return 0;
        else
            return prob / (background_prob(bg1) * background_prob(bg2));
    }
}

/*
 * @since 2013.02.25, 2013.03.12, 2013.04.01, 2015.2.19
 */
background_t *background_last_intersect(const background_t *bg1, const background_t *bg2, background_stack_t *stack) {
#ifdef BACKGROUND_CHECK
    assert(bg1->leng == bg2->leng && bg1->leng == stack->leng);
    assert(bg1->sum == bg2->sum);
#endif
    int n1 = bg1->n, n2 = bg2->n;
    if (n1 == 1 && n2 == 1) {
        return clone(bg1, stack);
    } else if (n1 == 1) {
        return clone(bg2, stack);
    } else if (n2 == 1) {
        return clone(bg1, stack);
    } else {
        int last_intersect_n = stack->last_intersect_n;
        background_t *re = create(last_intersect_n, stack);
        re->leng = bg1->leng;
        re->sum = bg1->sum;
        re->n = last_intersect_n;
        size_t tmp = (size_t) last_intersect_n * sizeof (int);
        memcpy(re->pts, stack->pts_intersect, tmp);
        memcpy(re->mut, stack->mut_intersect, tmp);
        re->recal = true;
        return re;
    }
}

/**
 * When bg->sum = 0, then merge all segments into one (by setting bg->n to 1) and set prob to 1.0
 * @since 2015.01.30, 2.19
 */
static void merge_for_zero_sum(background_t *bg) {
    bg->n = 1;
    bg->pts[0] = bg->leng - 1;
    bg->prob = 1.0;
    bg->recal = false;
}

/** 
 * Returns the index of mut where the mutation has just been removed.
 * @since 2013.02.25, 2013.03.12, 2013.03.22, 2015.01.29, 2.19
 */
static inline int purge(int id, background_t *bg) {    
#ifdef BACKGROUND_CHECK
    assert(id >= 0 && id < bg->sum);
#endif
    int cn = -1;
    int n = bg->n;
    int *mut = bg->mut;
    for (int i = 0; i < n; i++) {
        cn += mut[i];
        if (id <= cn) {
            mut[i]--;
            (bg->sum)--;
            if (bg->sum > 0) {
                bg->recal = true;
            } else {
                merge_for_zero_sum(bg);
            }
            return i;
        }
    }
    abort();
}

void background_purge(int id, background_t *bg) {
    if (id < 0 || id >= bg->sum) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    purge(id, bg);
}

/** 
 * @since 2013.02.25, 2013.03.12, 2013.03.22, 2015.2.19
 */
void background_purge_ran(background_t *bg, gsl_rng *r) {
    int id = (int) gsl_rng_uniform_int(r, (unsigned long) bg->sum);
    purge(id, bg);
}

/** 
 * @since 2013.02.25, 2013.03.12, 2015.2.19
 */
int background_purge_ran_pos(background_t *bg, gsl_rng *r) {
    int id = (int) gsl_rng_uniform_int(r, (unsigned long) bg->sum);
    int i = purge(id, bg);
    int *pts = bg->pts;
    int up = pts[i];
    int low;
    if (i == 0)
        low = 0;
    else
        low = 1 + pts[i - 1];
    int tmp = (int) gsl_rng_uniform_int(r, (unsigned long) (up - low + 1)) + low;
    return tmp;
}

/**
 * <ol>
 * <li> ind: the index of the first number in pts that is larger than or equal to brk
 * <li> flag: 2 if pts[ind-1] < brk < pts[ind] (different), 1 if brk = pts[ind] (same)
 * <li> left: the number of mutations in mut[ind] that are sitting on the lefthand side of brk
 * <li> right: the number of mutations in mut[ind] that are sitting on the righthand side of brk
 * </ol>
 */
static int replace_info_data[4];

/** 
 * @since 2013.02.22, 2013.02.23, 2013.03.12 (by eye), 2013.04.01 (by eye), 2015.2.19
 */
static inline void replace_info(const background_t *bg, int brk, gsl_rng *r) {
    const int *pts = bg->pts;
    const int *mut = bg->mut;
    int ind = arrayutil_binary_search_i(pts, 0, bg->n, brk);
    int flag = 1;
    if (ind < 0) {
        ind = -ind - 1;
        flag = 2;
    }
    int left, right;
    if (mut[ind] == 0) {
        left = 0;
        right = 0;
    } else {
        int t1 = pts[ind] - brk;
        if (t1 == 0)
            right = 0;
        else {
            double tmp = (double) t1;
            if (ind == 0) {
                tmp = tmp / (pts[ind] + 1);
            } else {
                tmp = tmp / (pts[ind] - pts[ind - 1]);
            }
            right = (int) gsl_ran_binomial(r, tmp, (unsigned int) mut[ind]);
        }
        left = mut[ind] - right;
    }
    replace_info_data[0] = ind;
    replace_info_data[1] = flag;
    replace_info_data[2] = left;
    replace_info_data[3] = right;
}

/**
 * If onLeft=T, the first 2 segments are
 * <ol>
 * <li>[0, brk] with <code>nmut</code> mutations
 * <li>[brk+1, pts[ind]] with <code>right</code> mutations
 * </ol>
 * <p>
 * If onLeft=F, the last 2 segments are
 * <ol>
 * <li>[pts[ind-1]+1, brk] with <code>left</code> mutations
 * <li>[brk+1, L-1] with <code>nmut</code> mutations
 * </ol>
 * @since 2013.02.22, 2013.02.23, 2013.03.12 (by eye), 2013.04.01, 2015.2.19
 */
static inline void replace(background_t *bg, bool onLeft, int brk, int nmut,
        int ind, int flag, int left, int right, background_stack_t *stack) {
    int n = bg->n;
    int new_n;
    int *newPts = stack->newPts;
    int *newMut = stack->newMut;
    if (onLeft == true) {
        if (flag == 2) {//brk != pts[ind] 
            new_n = n - ind + 1;
            newPts[0] = brk;
            memcpy(newPts + 1, bg->pts + ind, sizeof(int) * (size_t) (new_n - 1));
            newMut[0] = nmut;
            newMut[1] = right;
            memcpy(newMut + 2, bg->mut + ind + 1, sizeof(int) * (size_t) (new_n - 2));
        } else {
            new_n = n - ind; 
            memcpy(newPts, bg->pts + ind, sizeof(int) * (size_t) new_n);
            newMut[0] = nmut;
            memcpy(newMut + 1, bg->mut + ind + 1, sizeof(int) * (size_t) (new_n - 1));
        }
    } else {
        new_n = ind + 2;
        newPts[ind] = brk;
        newPts[ind + 1] = stack->leng_m1;
        size_t s = sizeof(int) * (size_t) (ind);
        memcpy(newPts, bg->pts, s);
        newMut[ind] = left;
        newMut[ind + 1] = nmut;
        memcpy(newMut, bg->mut, s);
    }
        
#ifdef BACKGROUND_CHECK
    if (new_n > stack->leng) {
        printf("\nError: new_n > background_max_leng\n");
        abort();
    }
#endif
    
    size_t s = sizeof (int) * (size_t) new_n;
    ensure_capacity(bg, new_n);
    memcpy(bg->pts, newPts, s);
    memcpy(bg->mut, newMut, s);    
    bg->sum = arrayutil_sum_i_i(bg->mut, 0, new_n);
    if (bg->sum > 0) {
        bg->n = new_n;
        bg->recal = true;
    } else {
        merge_for_zero_sum(bg);
    }
}

/*
 * @since 2013.02.22, 2013.02.23 (added has_overflow), 2013.03.12, 2013.04.01, 2015.2.18
 */
void background_replace_one_side(background_t *bg, bool onLeft, int brk, double lambda, 
        gsl_rng *r, background_stack_t *stack) {
    if (brk < 0 || brk >= stack->leng_m1 || lambda < 0) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    int nmut;
    double x = (1.0 + brk) / bg->leng;
    if (onLeft == true)
        nmut = (int) gsl_ran_poisson(r, x * lambda);
    else
        nmut = (int) gsl_ran_poisson(r, (1 - x) * lambda);
    replace_info(bg, brk, r);
    replace(bg, onLeft, brk, nmut, 
            replace_info_data[0], replace_info_data[1], replace_info_data[2], replace_info_data[3], stack);
}

/** 
 * @since 2013.02.25 (night), 2013.03.12, 2013.03.29, 2013.04.01, 2015.01.30, 2.19
 */
background_t *background_split(background_t *bg, int brk, double lambda, gsl_rng *r, background_stack_t *stack) {   
    if (brk < 0 || brk >= stack->leng_m1 || lambda < 0) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    double x = (1.0 + brk) / bg->leng;
    int nmutLeft = (int) gsl_ran_poisson(r, x * lambda);
    int nmutRight = (int) gsl_ran_poisson(r, (1 - x) * lambda);
    background_t *new_bg = clone(bg, stack);
    replace_info(bg, brk, r);
    replace(bg, false, brk, nmutRight, 
            replace_info_data[0], replace_info_data[1], replace_info_data[2], replace_info_data[3], stack);
    replace(new_bg, true, brk, nmutLeft, 
            replace_info_data[0], replace_info_data[1], replace_info_data[2], replace_info_data[3], stack);
    return new_bg;
}

/** 
 * @since 2013.02.25, 2013.03.12, 2013.04.01, 2015.01.30, 2.19
 */
void background_replace_all(background_t *bg, double lambda, gsl_rng *r) {
#ifdef BACKGROUND_CHECK
    if (bg->capacity < 1) {
        printf("\nError: bg->capacity < 1\n");
        abort();
    }
#endif
    int nmut = (int) gsl_ran_poisson(r, lambda);
    bg->sum = nmut;
    bg->n = 1;
    bg->pts[0] = bg->leng - 1;
    bg->mut[0] = nmut;
    bg->prob = 1;
    bg->recal = false;
}

/** 
 * @since 
 */
void background_print_to_screen(const background_t *bg) {
    int n = bg->n;
    int *pts = bg->pts;
    int *mut = bg->mut;
    for (int i = 0; i < n; i++) {
        if (i == 0) {
            printf("\n{[0, %i]=%i}", pts[0], mut[0]);
        } else {
            printf("{[%i, %i]=%i}", pts[i - 1] + 1, pts[i], mut[i]);
        }
        if (i < n - 1)
            printf("-");
    }
    printf("\n");
}

#ifdef BACKGROUND_CHECK
void background_check(background_t *bg) {
    int *pts = bg->pts;
    int *mut = bg->mut;
    int leng = bg->leng;
    int n = bg->n;
    if (n > bg->capacity) {
        printf("\nError: n > bg->capacity\n");
        abort();
    }
    for (int i = 0; i < n - 1; i++) {
        if (pts[i] >= leng) {
            printf("\nError: pts[i%i] >= leng\n", i);
            abort();
        }
        if (pts[i] >= pts[i + 1])  {
            printf("\nError: pts[i%i] >= pts[i%i + 1]\n", i, i);
            abort();
        }
    }
    if (pts[n - 1] != (leng - 1)) {
        printf("\nError: pts[n - 1] != leng\n");
        abort();
    }
    int tmp = 0;
    for (int i = 0; i < n; i++)
        tmp += mut[i];
    if (tmp != bg->sum) {
        printf("\nError: tmp != bg->sum\n");
        abort();
    }
    if (leng == 0 && (n != 1 || bg->sum != 0 || bg->prob != 1 || bg->recal != false)) {
        printf("\nError: leng == 0 && (n != 1 || bg->sum != 0 || bg->prob != 1 || bg->recal != false)\n");
        abort();
    }
}
#endif