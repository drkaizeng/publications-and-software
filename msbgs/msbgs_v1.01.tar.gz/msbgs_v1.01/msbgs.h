/* 
 * File:   msbgs.h
 * Author: kai
 *
 * Created on 21 January 2015, 15:44
 */

#ifndef MSBGS_H
#    define	MSBGS_H

#include "msbgs_param.h"

typedef struct msbgs_tag msbgs_t;

/**
 * Construct a new msbgs_t object using the parameters given. Defensive deep copying
 * is perform, so that the msbgs_t object is independent of param.
 */
msbgs_t * msbgs_new(msbgs_param_t *param);
void msbgs_free(msbgs_t *msb);

/**
 * Carry out simulations using the details contained in the msbgs_T object.
 * 
 */
void msbgs_simulate(msbgs_t *msb);


#endif	/* MSBGS_H */

