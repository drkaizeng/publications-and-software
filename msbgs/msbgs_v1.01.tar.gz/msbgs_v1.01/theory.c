#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>

#include "theory.h"

/*
 * @since 2015.6.10, 6.14
 */
double theory_get_nes(double thps, double rhops, int nbg, const double gamma[nbg], 
        int leng, const int state[leng], int nsel, double nes[nsel]) {
    if (nbg <= 0 || nsel <= 0) {
        fprintf(stderr, "Error: No selected sites is found when trying to calculate Ne*s\n");
        exit(EXIT_FAILURE);
    }
    
    double lambda[nbg];
    for (int i = 0; i < nbg; i++) {
        lambda[i] = thps / gamma[i];
    }
    double rarr[leng];
    for (int i = 0; i < leng; i++) {
        rarr[i] = rhops * i;
    }
    double min_nes = DBL_MAX;    
    for (int ii = 0, jj = 0; ii < leng; ii++) {
        if (state[ii] < 0)
            continue;
        double B = 0;
        for (int i = 0; i < leng; i++) {
            if (state[i] >= 0) {
                double tmp = lambda[state[i]];
                double s = gamma[state[i]];
                double r = rarr[abs(i - ii)];
                tmp = tmp * pow(s / (r + s), 2);
                B += tmp;
            }
        }
        nes[jj] = exp(-B) * gamma[state[ii]];
        if (nes[jj] < min_nes) {
            min_nes = nes[jj];
        }
        jj++;
    }
    
    return min_nes;
}

/*
 * @since 2015.6.14
 */
void theory_get_B(double thps, double rhops, int nbg, const double gamma[nbg], 
        int leng, const int state[leng], double B[leng]) {
    if (nbg <= 0) {
        fprintf(stderr, "Error: No selected sites is found when trying to calculate B\n");
        exit(EXIT_FAILURE);
    }
    
    double lambda[nbg];
    for (int i = 0; i < nbg; i++) {
        lambda[i] = thps / gamma[i];
    }
    double rarr[leng];
    for (int i = 0; i < leng; i++) {
        rarr[i] = rhops * i;
    }
    for (int ii = 0; ii < leng; ii++) {
        double b = 0;
        for (int i = 0; i < leng; i++) {
            if (state[i] >= 0) {
                double tmp = lambda[state[i]];
                double s = gamma[state[i]];
                double r = rarr[abs(i - ii)];
                tmp = tmp * pow(s / (r + s), 2);
                b += tmp;
            }
        }
        B[ii] = exp(-b);
    }
}
