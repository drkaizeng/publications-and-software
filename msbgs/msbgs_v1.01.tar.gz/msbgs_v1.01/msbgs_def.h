/* 
 * File:   msbgs_def.h
 * Author: Kai
 *
 * Created on 01 February 2015, 22:21
 */

#ifndef MSBGS_DEF_H
#define	MSBGS_DEF_H

#include "chrom.h"
#include "frag.h"

struct msbgs_tag {
    /** SAMPLE SIZE */
    /**
     * Sample size
     */
    int nsam;
    
    /** GENOME SIZE */
    /**
     * Size of the simulated region
     */
    int leng;
    int leng_m1;
    
    /** MIGRATION */
    /**
     * The number of populations at the beginning
     */
    int init_npop;
    /**
     * The current number of subpopulations in the simulation; at time zero, npop = init_npop.
     */
    int npop;
    /**
     * N/Nr, where N is the haploid effective size of the population, and Nr is the reference haploid size.
     * <p>
     * The population sizes at the beginning of the simulation, which is used to initialise
     * pop_size.
     */
    double *init_pop_size;
    size_t init_pop_size_mem_size;
    /**
     * N/Nr, where N is the haploid effective size of the population, and Nr is the reference haploid size.
     * <p>
     * The relative haploid sizes of the populations. These are all expressed relative to
     * the reference haploid population size used to calculate rho, gamma, and theta.
     */
    double *pop_size;
    int pop_size_capacity;
    /**
     * The sampling configuration. sample_config[i] is the number of samples taken from
     * the i-th population. Note that sam_config sums up to nsam.
     */
    int *sam_config;
    size_t sam_config_mem_size;
    /**
     * This is the same as sample_config at the beginning of the simulation, but will be
     * changed as migration takes place.
     */
    int *config;    
    int config_capacity;
    /**
     * This is used to record the id's of chrom's
     */
    int *chrom_id;
    /**
     * The number of elements in migrant_id;
     */
    int chrom_id_leng;
    int chrom_id_capacity;
    /**
     * Nr * m, where Nr is the reference haploid size.
     * <p>
     * The migration rate matrix to be used initially in the simulation. 
     * The rates are scaled by the reference haploid population size.
     * That is, the one used to calculate rho, gamma, and theta.
     * <ul>
     * <li> For i &ne; j, mig_mat[i][j] is the scaled migration from deme i to deme j. 
     * <li> mig_mat[i][i] = 0.
     * </ul>
     */
    double **init_mig_mat;
    /**
     * Nr * m, where Nr is the reference haploid size.
     * <p>
     * At the beginning of simulation, this is the same as init_mig_mat. 
     */
    double **mig_mat;
    int mig_mat_capacity;
    /**
     * Nr * m, where Nr is the reference haploid size.
     * <p>
     * init_total_mig_rate[i] is the total migration rate out of deme i,
     *   and is calculated using init_mig_mat.
     */
    double *init_total_mig_rate;
    size_t init_total_mig_rate_mem_size;
    /**
     * Nr * m, where Nr is the reference haploid size.
     * <p>
     * total_mig_rate, 
     *   and is the same as init_total_mig_rate at the beginning
     */
    double *total_mig_rate;
    /**
     * Nr * m, where Nr is the reference haploid size.
     * <p>
     * cummu_total_mig_rate[i] = config[i] * total_mig_rate[i] + (i > 0 ? cummu_mig_rate[i - 1] : 0)
     */
    double *cummu_total_mig_rate;
    /**
     * Nr * m, where Nr is the reference haploid size.
     * <p>
     * init_cumm_mig_rate[i] is an array of size (npop - 1). <br>
     * init_cumm_mig_rate[i][j] = Sum[mig_rate[i][k], {0 &le; k &le; j and k &ne; i}]
     */
    double **init_cumm_mig_rate;
    double **cumm_mig_rate;
    
    /** CROSSOVER */
    /**
     * rho = r * Nr, where r is the recombination rate of the entire simulated region
     */
    double rho;
    
    /** BGS */
    /**
     * The number of genetic backgrounds
     */
    int nbg;
    /**
     * s * Nr, where s the selection coefficient
     */
    double *gamma;
    /**
     * bg_nmut[i] is the number of mutations in the i-th background.
     */
    int *bg_nmut;
    /**
     * The sum of bg_nmut
     */
    int bg_total_nmut;
    /**
     * An array with zeros as elements for initialising bg_nmut;
     */
    int *init_bg_nmut;
    size_t init_bg_nmut_mem_size;
    /**
     * gamma = s * Nr
     * <p>
     * cummu_mut_rate[i] = bg_nmut[i] * gamma[i] + (i > 0 ? mut_rate[i - 1] : 0)
     */
    double *cummu_mut_rate;
    
    /** PRE-DETERMINED EVENTS */
    event_list_t *event_list;
        
    /** ANCESTRAL CHROM */
    /**
     * The maximum number of elements can be held in ppchrom
     */
    int ppchrom_capacity;
    /**
     * The remaining ancestral segments in the genealogy
     */
    chrom_t **ppchrom;
    /**
     * The current size of ppchrom
     */
    int ppchrom_leng;
    chrom_stack_t *chr_stack;
    
    /** COALESCENT RATES */
    /**
     * Scaled by Nr
     * <p>
     * coal_rate[i][j] = the coalescence rate between the i-th and j-th chrom_T objects in ppchrom (i &lt; j)
     */
    double **coal_rate;
    /**
     * Scaled by Nr
     * <p>
     * The total rate of coalescence, which is the sum of coalescence rates between all pairwise comparisons
     * between permissible pairs.
     */
    double total_coal_rate;
    /**
     * The mean coalescent rate for the coalescent events that have actually occurred.
     * The rate is defined wrt the reference haploid population size.
     */
    double mean_coal_rate;
    
    /** FRAGMENTS IN THE GENOMIC REGION WITHIN WHICH NO RECOMBINATION HAS OCCURRED */
    frag_list_t *frag_list;
    
    /**
     * Time in units of Nr to the present
     */
    double time;
    
    /**
     * No defensive deep copy is made. The caller should free this afterwards.
     */
    gsl_rng *ran;    
};

#endif	/* MSBGS_DEF_H */

