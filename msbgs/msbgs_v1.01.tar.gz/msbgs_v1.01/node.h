/* 
 * File:   node.h
 * Author: Kai
 *
 * Created on 11 February 2015, 10:24
 */

#ifndef NODE_H
#define	NODE_H

typedef struct {
    /**
     * The index in ptree of the node immediately ancestral to this node in the genealogy
     */
    int abv;
    /**
     * Time to the present
     */
    double time;
} node_t;

#endif	/* NODE_H */

