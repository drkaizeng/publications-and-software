#include <math.h>
#include <assert.h>
#include <stdbool.h>
#include <limits.h>
#include <string.h>
#include <float.h>

#include "msbgs.h"

#include "gsl/gsl_rng.h"

#include "util/matrixalloc.h"
#include "util/arrayutil.h"

#include "chrom.h"
#include "msbgs_def.h"

/*
 * @since 2015.2.11 (neutral), 2.15 (neutral), 2.19
 */
msbgs_t * msbgs_new(msbgs_param_t *param) {
    msbgs_t *msb = matrixalloc_1d_init(1, sizeof (msbgs_t));
    msb->nsam = param->nsam;
    
    msb->leng = param->leng;
    msb->leng_m1 = param->leng - 1;
    
    msb->init_npop = param->npop;
    msb->init_pop_size = matrixalloc_1d_clone(param->pop_size, param->npop, sizeof (double));
    msb->init_pop_size_mem_size = (size_t) (param->npop) * sizeof (double);
    msb->pop_size = matrixalloc_1d(param->npop, sizeof (double));
    msb->pop_size_capacity = param->npop;
    msb->sam_config = matrixalloc_1d_clone(param->sam_config, param->npop, sizeof (int));
    msb->sam_config_mem_size = (size_t) param->npop * sizeof (int);
    if (msb->nsam != arrayutil_sum_i_i(param->sam_config, 0, param->npop)) {
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    msb->config = matrixalloc_1d(param->npop, sizeof (int));
    msb->config_capacity = param->npop;
    msb->chrom_id = matrixalloc_1d(param->nsam, sizeof (int));
    msb->chrom_id_capacity = param->nsam;
        
    if (param->npop > 1) {
        msb->init_mig_mat = matrixalloc_2d_d_clone(param->mig_mat, param->npop, param->npop);
        msb->mig_mat = matrixalloc_2d_d(param->npop, param->npop);
        msb->mig_mat_capacity = param->npop;
        msb->init_total_mig_rate = matrixalloc_1d(param->npop, sizeof (double));
        msb->init_total_mig_rate_mem_size = (size_t) param->npop * sizeof (double);
        msb->total_mig_rate = matrixalloc_1d(param->npop, sizeof (double));
        msb->cummu_total_mig_rate = matrixalloc_1d(param->npop, sizeof (double));
        msb->init_cumm_mig_rate = matrixalloc_2d_d(param->npop, param->npop - 1);
        msb->cumm_mig_rate = matrixalloc_2d_d(param->npop, param->npop - 1);
        for (int i = 0; i < param->npop; i++) {
            if (param->mig_mat[i][i] != 0) {
                fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
                abort();
            }
            msb->init_total_mig_rate[i] = arrayutil_sum_d_d(param->mig_mat[i], 0, param->npop);
            if (msb->init_total_mig_rate[i] > 0) {
                for (int j = 0, k = 0; j < param->npop; j++) {
                    if (j != i) {
                        msb->init_cumm_mig_rate[i][k] = arrayutil_sum_d_d(param->mig_mat[i], 0, j + 1);
                        k++;
                    }
                }
            }
        }
    } else {
        msb->init_mig_mat = NULL;
        msb->mig_mat = NULL;
        msb->init_total_mig_rate = NULL;
        msb->total_mig_rate = NULL;
        msb->cummu_total_mig_rate = NULL;
        msb->init_cumm_mig_rate = NULL;
        msb->cumm_mig_rate = NULL;
    }
    
    msb->rho = param->rho;
    
    msb->nbg = param->nbg;
    if (msb->nbg > 0) {
        msb->gamma = matrixalloc_1d_clone(param->gamma, param->nbg, sizeof (double));
        msb->bg_nmut = matrixalloc_1d(param->nbg, sizeof (int));
        msb->init_bg_nmut = matrixalloc_1d_init(param->nbg, sizeof (int));
        msb->init_bg_nmut_mem_size = (size_t) param->nbg * sizeof (int);
        msb->cummu_mut_rate = matrixalloc_1d(param->nbg, sizeof (double));
    } else {
        msb->gamma = NULL;
        msb->bg_nmut = NULL;
        msb->init_bg_nmut = NULL;
        msb->cummu_mut_rate = NULL;
    }
    
    msb->event_list = event_list_clone(param->event_list);
    
    if (param->ran == NULL) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    msb->ran = param->ran;
    
    msb->ppchrom_capacity = param->nsam;
    msb->ppchrom = matrixalloc_1d(msb->ppchrom_capacity, sizeof (chrom_t *));    
    msb->chr_stack = chrom_stack_new(param->leng, param->nbg, param->state, param->gamma, param->theta, param->chrom_stk_init_size, msb->ran);
        
    msb->coal_rate = matrixalloc_1d(msb->ppchrom_capacity - 1, sizeof (double *));
    for (int i = msb->ppchrom_capacity - 1, j = 0; i > 0; i--, j++) {
        msb->coal_rate[j] = matrixalloc_1d(i, sizeof (double));
    }
    
    msb->frag_list = frag_list_new(param->nsam, param->leng, param->frag_list_init_size);
    
    return msb;
}

/*
 * @since 2015.2.19
 */
void msbgs_free(msbgs_t *msb) {
    if (msb->ppchrom_leng != 0) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    frag_list_free(msb->frag_list);
    for (int i = 0; i < msb->ppchrom_capacity - 1; i++) {
        matrixalloc_1d_free(msb->coal_rate[i]);
    }
    matrixalloc_1d_free(msb->coal_rate);
    chrom_stack_free(msb->chr_stack);
    matrixalloc_1d_free(msb->ppchrom);
    event_list_free(msb->event_list);
    if (msb->nbg > 0) {
        matrixalloc_1d_free(msb->cummu_mut_rate);
        matrixalloc_1d_free(msb->init_bg_nmut);
        matrixalloc_1d_free(msb->bg_nmut);
        matrixalloc_1d_free(msb->gamma);
    }
    matrixalloc_2d_d_free(msb->cumm_mig_rate);
    matrixalloc_2d_d_free(msb->init_cumm_mig_rate);
    matrixalloc_1d_free(msb->cummu_total_mig_rate);
    matrixalloc_1d_free(msb->total_mig_rate);
    matrixalloc_1d_free(msb->init_total_mig_rate);
    matrixalloc_2d_d_free(msb->mig_mat);
    matrixalloc_2d_d_free(msb->init_mig_mat);
    
    matrixalloc_1d_free(msb->chrom_id);
    matrixalloc_1d_free(msb->config);
    matrixalloc_1d_free(msb->sam_config);
    matrixalloc_1d_free(msb->init_pop_size);
    matrixalloc_1d_free(msb->pop_size);
    matrixalloc_1d_free(msb);
}

/** 
 * <b>Important:</b>: It is assumed that ppchrom_leng and ppchrom_capacity have not been changed.
 * That is, ppchrom_leng is the same as the number of chrom_t in ppchrom.
 * @since 2015.01.30, 2.11, 2.17
 */
static inline void ensure_ppchrom_coal_rate_capacity(msbgs_t *msb, int new_size) {
    if (new_size > msb->ppchrom_capacity) {
        static const int LIMIT = INT_MAX / 2;
        if (new_size >= LIMIT) {
            fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
            abort();
        }
        int old_capacity_m1 = msb->ppchrom_capacity - 1;
        msb->ppchrom_capacity = new_size * 2;
        msb->ppchrom = realloc(msb->ppchrom, (size_t) msb->ppchrom_capacity * sizeof(chrom_t *));
        if (msb->ppchrom == NULL) {
            fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
            abort();
        }
        msb->coal_rate = realloc(msb->coal_rate , (size_t) (msb->ppchrom_capacity - 1) * sizeof(double *));
        if (msb->coal_rate == NULL) {
            fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
            abort();
        }
        int i = msb->ppchrom_capacity - 1;
        int j = 0;
        while (j < old_capacity_m1) {
            msb->coal_rate[j] = realloc(msb->coal_rate[j], (size_t) i * sizeof (double));
            if (msb->coal_rate[j] == NULL) {
                fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
                abort();
            }
            i--;
            j++;           
        }
        while (i > 0) {
            msb->coal_rate[j] = matrixalloc_1d(i, sizeof (double));
            i--;
            j++;
        }
    }
}


/** 
 * Remove from bg_nmut and bg_total_nmut the contributions from chr
 * @since 2015.01.29, 2.19
 */
static void bg_nmut_rm_contribution(msbgs_t *msb, int c) {
    /* Remove the mutations contained in the chrom */
    chrom_t *chr = msb->ppchrom[c];
    for (int i = 0; i < msb->nbg; i++) {
        int cn = chrom_get_nmut(chr, i);
        msb->bg_nmut[i] -= cn;
        msb->bg_total_nmut -= cn;
    }
}

/** 
 * Remove from bg_nmut and bg_total_nmut the contributions from chr
 * @since 2015.2.19
 */
static void bg_nmut_add_contribution(msbgs_t *msb, chrom_t *chr) {
    for (int i = 0; i < msb->nbg; i++) {
        int cn = chrom_get_nmut(chr, i);
        msb->bg_nmut[i] += cn;
        msb->bg_total_nmut += cn;
    }
}

/** 
 * Remove the contribution to the total_coal_rate due to the c-th chrom in ppchrom. <br>
 * The elements in coal_rate rated to the c-th chrom are set to 0. But no element in coal_rate is moved. <br>
 * <p>
 * <b>Important:</b> It is assumed that the c-th chrom has not been removed from ppchrom.
 * @since 2015.01.30, 2.17
 */
static void rm_contribution_to_total_coal_rate(msbgs_t *msb, int c) {    
    for (int i = 0, j = c - 1; i < c; i++, j--) {
        msb->total_coal_rate -= msb->coal_rate[i][j];
    }
    for (int i = c + 1, j = 0; i < msb->ppchrom_leng; i++, j++) {
        msb->total_coal_rate -= msb->coal_rate[c][j];
    }
}

/** 
 * Update the coal_rate matrix and total_coal_rate by moving the last chrom to the c-th place in ppchrom.
 * <p>
 * <b>Important:</b> It is assumed that the c-th chrom has already been removed and 
 * its contributions to total_coal_rate removed. However, the last element in ppchrom
 * has not been moved to c and ppchrom_size is the same as that prior to the removal
 * of the c-th element.
 * @since 2015.01.30, 2.17
 */
static void coal_rate_update_for_moving_last_to(msbgs_t *msb, int c) {
    if (c != msb->ppchrom_leng - 1) {
        int n_m2 = msb->ppchrom_leng - 2;
        for (int i = 0, j = c - 1; i < c; i++, j--) {
            msb->coal_rate[i][j] = msb->coal_rate[i][n_m2 - i];
        }
        for (int i = c + 1, j = 0; i <= n_m2; i++, j++) {
            msb->coal_rate[c][j] = msb->coal_rate[i][n_m2 - i];
        }
    }
}

/** 
 * Update coal_rate and total_coal_rate after the c-th chrom has been replaced.
 * <p>
 * <b>Important:</b> It is assumed that the c-th chrom_t object has been replaced
 * before this function is called, but coal_rate and total_coal_rate are still
 * based on the <code>msb->ppchrom</code> that existed just before the replacement.
 * @since 2015.01.29, 2.17
 */
static void coal_rate_update_for_replacement(msbgs_t *msb, int c) {
    chrom_t *chr = msb->ppchrom[c];
    double pop_size = msb->pop_size[chrom_get_pop(chr)];
    for (int i = 0, j = c - 1; i < c; i++, j--) {
        msb->total_coal_rate -= msb->coal_rate[i][j];
        msb->coal_rate[i][j] = chrom_coal_rate(msb->ppchrom[i], chr, msb->chr_stack) / pop_size;
        msb->total_coal_rate += msb->coal_rate[i][j];
    }
    for (int i = c + 1, j = 0; i < msb->ppchrom_leng; i++, j++) {
        msb->total_coal_rate -= msb->coal_rate[c][j];
        msb->coal_rate[c][j] = chrom_coal_rate(chr, msb->ppchrom[i], msb->chr_stack) / pop_size;
        msb->total_coal_rate += msb->coal_rate[c][j];
    }
}

/**
 * Update coal_rate and total_coal_rate after a new chrom_t object has been appended
 * to the end of ppchrom.
 * <p>
 * <b>Important:</b> It is assumed that the last chrom_t object in ppchrom is
 * the new addition when this function is called, but coal_rate and total_coal_rate are still
 * based on the msb->ppchrom that existed just before the addition.
 * @since 2015.01.30, 2.11, 2.17
 */
static void coal_rate_update_for_append(msbgs_t *msb) {
    int c = msb->ppchrom_leng - 1;
    chrom_t *chr = msb->ppchrom[c];
    double pop_size = msb->pop_size[chrom_get_pop(chr)];
    for (int i = 0, j = c - 1; i < c; i++, j--) {
        msb->coal_rate[i][j] = chrom_coal_rate(msb->ppchrom[i], chr, msb->chr_stack) / pop_size;
        msb->total_coal_rate += msb->coal_rate[i][j];
    }
}

/** 
 * <ul>
 * <li> Remove the c-th chrom in ppchrom and replace it by the last object in ppchrom and update ppchrom_leng.
 * <li> Update bg_nmut, coal_rate and total_coal_rate.
 * <li> Update config
 * </ul>
 * @since 2015.01.30, 2.17
 */
static void move_last_to(msbgs_t *msb, int c) {
    bg_nmut_rm_contribution(msb, c);
    rm_contribution_to_total_coal_rate(msb, c);
    coal_rate_update_for_moving_last_to(msb, c);
    msb->config[chrom_get_pop(msb->ppchrom[c])]--;
    chrom_stack_push(msb->chr_stack, msb->ppchrom[c]);    
    msb->ppchrom_leng--;
    msb->ppchrom[c] = msb->ppchrom[msb->ppchrom_leng];
    msb->ppchrom[msb->ppchrom_leng] = NULL;
}

/**
 * <ul>
 * <li> Remove the c-th chrom in ppchrom and replace it by chr; update ppchrom and ppchrom_leng 
 * <li> Update bg_nmut, coal_rate and total_coal_rate.
 * <li> Update config
 * </ul>
 * @since 2015.2.17
 */
static void replace(msbgs_t *msb, int c, chrom_t *chr) {
    int pop = chrom_get_pop(msb->ppchrom[c]);
    msb->config[pop]--;
    bg_nmut_rm_contribution(msb, c);
    chrom_stack_push(msb->chr_stack, msb->ppchrom[c]);
    msb->ppchrom[c] = chr;
    pop = chrom_get_pop(chr);
    msb->config[pop]++;
    bg_nmut_add_contribution(msb, chr);
    coal_rate_update_for_replacement(msb, c);
}


/**
 * <ul>
 * <li> Add chr to the end of ppchrom and increase ppchrom_size
 * <li> Update bg_nmut, bg_total_nmut, coal_rate and total_coal_rate.
 * <li> Update config
 * </ul>
 * @since 2015.01.30, 2.17
 */
static void append(msbgs_t *msb, chrom_t *chr) {
    ensure_ppchrom_coal_rate_capacity(msb, msb->ppchrom_leng + 1);
    msb->ppchrom[msb->ppchrom_leng] = chr;
    msb->ppchrom_leng++;
    bg_nmut_add_contribution(msb, chr);
    coal_rate_update_for_append(msb);
    msb->config[chrom_get_pop(chr)]++;
}

/** 
 * @param c1 ID of the first chrom in ppchrom
 * @param c2 ID of the second chrom in ppchrom
 * <p>
 * <b>Important:</b> It is assumed that c1 &lt; c2.
 * @since 2015.2.17
 */
static void ca(msbgs_t *msb, int c1, int c2) {
    chrom_t *chr1 = msb->ppchrom[c1];
    chrom_t *chr2 = msb->ppchrom[c2];
    chrom_t *new_chr = chrom_ca(msb->time, chr1, chr2, msb->chr_stack, msb->frag_list);
    if (new_chr == NULL) {
        move_last_to(msb, c1);
        if (c2 == msb->ppchrom_leng) {//if c2 was the chrom being moved in the previous step
            c2 = c1;
        }
        /* put the last chromo to c2 */
        move_last_to(msb, c2);
    } else {
        /* put the new chromo object to c1 */
        replace(msb, c1, new_chr);
        /* put the last chromo to c2 */
        move_last_to(msb, c2);
    }
}

/** 
 * @since 2015.2.17
 */
static inline void xover(msbgs_t *msb, int c, int brk) {
    bg_nmut_rm_contribution(msb, c);
    chrom_t *new_chr = chrom_split(msb->ppchrom[c], brk, msb->chr_stack, msb->frag_list);
    bg_nmut_add_contribution(msb, msb->ppchrom[c]);
    coal_rate_update_for_replacement(msb, c);
    if (new_chr != NULL) {
        append(msb, new_chr);
    }
}

/**
 * Append the id of a chrom_t in ppchrom being move to another population.
 * <p>
 * <b>Important:</b> Before calling this for the first time, make sure chrom_id_leng has been set to zero.
 * @since 2015.02.01, 2.17
 */
static void chrom_id_append(msbgs_t *msb, int id) {
    if (msb->chrom_id_leng >= msb->chrom_id_capacity) {
        static const int LIMIT = INT_MAX / 2;
        if (msb->chrom_id_leng >= LIMIT) {
            fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
            abort();
        }
        msb->chrom_id_capacity *= 2;
        size_t s = (size_t) msb->chrom_id_capacity * sizeof (int);
        msb->chrom_id = realloc(msb->chrom_id, s);
        if (msb->chrom_id == NULL) {
            fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
            abort();
        }
    }
    msb->chrom_id[msb->chrom_id_leng] = id;
    msb->chrom_id_leng++;
}

/**
 * Merge pop2 into pop1. All populations with id &gt; pop2 now have their id reduced by 1. Update the following:
 * <ul>
 * <li>npop, pop_size, config, mig_mat, total_mig_rate, cummu_mig_rate
 * <li>ppchrom
 * <li>coal_rate, total_coal_rate
 * </ul>
 * <p>
 * <b>Important:</b> pop1 &lt; pop2
 * @since 2015.2.17, 3.27
 */
static void merge_pop(msbgs_t *msb, int pop1, int pop2) {
    if (pop1 < 0 || pop2 <= pop1 || pop2 >= msb->npop) {
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    msb->config[pop1] += msb->config[pop2];
    msb->chrom_id_leng = 0;
    for (int i = 0; i < msb->ppchrom_leng; i++) {
        int pop = chrom_get_pop(msb->ppchrom[i]); 
        if (pop == pop2) {
            chrom_switch_pop(msb->ppchrom[i], pop1);
            chrom_id_append(msb, i);
        } else if (pop > pop2) {
            int tmp = chrom_get_pop(msb->ppchrom[i]) - 1; 
            chrom_switch_pop(msb->ppchrom[i], tmp);
        }
    }
    for (int i = 0; i < msb->chrom_id_leng; i++) {
        coal_rate_update_for_replacement(msb, msb->chrom_id[i]);
    }
    for (int i = pop2 + 1, j = pop2; i < msb->npop; i++, j++) {
        msb->pop_size[j] = msb->pop_size[i];
        msb->config[j] = msb->config[i];
    }
    for (int i = 0; i < msb->npop; i++) {
        if (i == pop2) {
            continue;
        }
        int pop_i;
        if (i > pop2) {
            pop_i = i - 1;
        } else {
            pop_i = i;
        }
        msb->total_mig_rate[pop_i] = msb->total_mig_rate[i] - msb->mig_mat[i][pop2];
        if (msb->total_mig_rate[pop_i] > 0) {
            double sum = 0;
            for (int j = 0, k = 0; j < msb->npop; j++) {
                if (j != i && j != pop2) {
                    sum += msb->mig_mat[i][j];
                    msb->cumm_mig_rate[pop_i][k] = sum;
                    k++;
                }
            }
        }
    }
    for (int i = 0; i < pop2; i++) {
        for (int j = pop2 + 1, k = pop2; j < msb->npop; j++, k++) {
            msb->mig_mat[i][k] = msb->mig_mat[i][j];
            msb->mig_mat[k][i] = msb->mig_mat[j][i];
        }
    }
    size_t s = (size_t) (msb->npop - pop2 - 1) * sizeof (double);
    for (int i = pop2 + 1, j = pop2 + 1; i < msb->npop; i++) {
        memcpy(msb->mig_mat[i - 1] + pop2, msb->mig_mat[i] + j, s);        
    }
    msb->npop--;
}

/**
 * Change the size of the pop-th population to new_size.
 * Update pop_size, coal_rate, and total_coal_rate
 * @param pop Index of the population whose size is to be changed [0, npop-1]
 * @since 2015.2.17
 */
static void change_size(msbgs_t *msb, int pop, double new_size) {
    if (pop < 0 || pop >= msb->npop) {
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    double scale = msb->pop_size[pop] / new_size;
    msb->pop_size[pop] = new_size;
    msb->chrom_id_leng = 0;
    for (int c = 0; c < msb->ppchrom_leng; c++) {
        if (chrom_get_pop(msb->ppchrom[c]) == pop) {
            chrom_id_append(msb, c);
        }
    }
    int n = msb->chrom_id_leng;
    int n_m1 = n - 1;
    double sum = 0;
    for (int i = 0; i < n_m1; i++) {
        int c1 = msb->chrom_id[i];
        for (int j = i + 1; j < n; j++) {
            int c2 = msb->chrom_id[j];
            int k = c2 - c1 - 1;
            sum += msb->coal_rate[c1][k];
            msb->coal_rate[c1][k] *= scale;
        }
    }
    msb->total_coal_rate += (sum * (scale - 1));
}

/**
 * Change the sizes of all subpopulations to new_size
 * @since
 */
static void change_all_size(msbgs_t *msb, double new_size) {
    for (int i = 0; i < msb->npop; i++)
        change_size(msb, i, new_size);
}

/**
 * On return:
 * <ul>
 * <li> mean_coal_rate is the overall mean combining mean_coal_rate and mean_coal_rate_acc
 * <li> mean_coal_rate_n is the overall sample size
 * <li> mean_coal_rate_acc and mean_coal_rate_acc_n are set to 0
 * </ul>
 * 
 * @param mean_coal_rate The mean rate
 * @param mean_coal_rate_n The number of elements used to calculate mean_coal_rate
 * @param mean_coal_rate_acc The sum of coal_rate since the last update of mean_coal_rate
 * @param mean_coal_rate_acc_n The number of elements used to calculate mean_coal_rate_acc 
 * @since 2015.6.11
 */
static void cal_mean_coal_rate(double *mean_coal_rate, int *mean_coal_rate_n, double *mean_coal_rate_acc, int *mean_coal_rate_acc_n) {
    int n = (*mean_coal_rate_n) + (*mean_coal_rate_acc_n);
    double mean = (*mean_coal_rate) / n * (*mean_coal_rate_n) + (*mean_coal_rate_acc) / n;
    (*mean_coal_rate) = mean;
    (*mean_coal_rate_n) = n;
    (*mean_coal_rate_acc) = 0;
    (*mean_coal_rate_acc_n) = 0;
}

typedef enum {
    /** Loss of deleterious mutation */
    msbgs_event_mutation,
    msbgs_event_crossover,
    msbgs_event_migration,
    msbgs_event_coalescent,
} msbgs_event_t;

/* 
 * @since 2015.2.17 (neutral), 2.19
 */
void msbgs_simulate(msbgs_t *msb) {
    msb->npop = msb->init_npop;
    memcpy(msb->pop_size, msb->init_pop_size, msb->init_pop_size_mem_size);
    memcpy(msb->config, msb->sam_config, msb->sam_config_mem_size);
    if (msb->npop > 1) {
        matrixalloc_2d_d_cpy(msb->mig_mat, msb->init_mig_mat, msb->init_npop, msb->init_npop);
        memcpy(msb->total_mig_rate, msb->init_total_mig_rate, msb->init_total_mig_rate_mem_size);
        matrixalloc_2d_d_cpy(msb->cumm_mig_rate, msb->init_cumm_mig_rate, msb->init_npop, msb->init_npop - 1);
    }
    if (msb->nbg > 0) {
        memcpy(msb->bg_nmut, msb->init_bg_nmut, msb->init_bg_nmut_mem_size);
    }    
    
    msb->bg_total_nmut = 0;
    for (int pop = 0, c = 0; pop < msb->npop; pop++) {
        for (int j = 0; j < msb->config[pop]; j++, c++) {
            chrom_t *ch = chrom_new(c, pop, msb->chr_stack);
            bg_nmut_add_contribution(msb, ch);
            msb->ppchrom[c] = ch;
        }
    }
    msb->ppchrom_leng = msb->nsam;
    
    msb->total_coal_rate = 0;
    for (int i = 0; i < msb->ppchrom_leng - 1; i++) {
        chrom_t *chr1 = msb->ppchrom[i];
        double pop_size = msb->pop_size[chrom_get_pop(chr1)];
        for (int j = i + 1, k = 0; j < msb->ppchrom_leng; j++, k++) {
            chrom_t *chr2 = msb->ppchrom[j];
            msb->coal_rate[i][k] = chrom_coal_rate(chr1, chr2, msb->chr_stack) / pop_size;
            msb->total_coal_rate += msb->coal_rate[i][k];
        }
    }
    
    frag_list_init(msb->frag_list);
    
    msb->time = 0;

    event_list_iterator_reset(msb->event_list);
    event_t *next_event = event_list_iterator_next(msb->event_list);
    
    double mean_coal_rate = 0;
    int mean_coal_rate_n = 0;
    double mean_coal_rate_acc = 0;
    int mean_coal_rate_acc_n = 0;
    double mean_coal_rate_cutoff = DBL_MAX / 100;
    
    while(msb->ppchrom_leng > 1) {
        /* Time to the next event*/
        double time_to_event = HUGE_VAL;
        msbgs_event_t event;        

        /* Order events from least to most expensive in terms of getting time_to_event */
        /* Coalescent */
        if (isinf(msb->total_coal_rate)) {
            fprintf(stderr, "Infinite coalescent rate encountered!\n");
            abort();
        } else if (msb->total_coal_rate > 0) {
            double t = -log(gsl_rng_uniform(msb->ran)) / msb->total_coal_rate;
            if (t < time_to_event) {
                time_to_event = t;
                event = msbgs_event_coalescent;
            }
        }

        /* Crossover */
        if (msb->rho > 0) {
            double rate = msb->rho * msb->ppchrom_leng;
            double t = -log(gsl_rng_uniform(msb->ran)) / rate;
            if (t < time_to_event) {
                time_to_event = t;
                event = msbgs_event_crossover;
            }
        }

        /* Mutation */
        if (msb->bg_total_nmut > 0) {
            for (int i = 0; i < msb->nbg; i++) {
                msb->cummu_mut_rate[i] = msb->bg_nmut[i] * msb->gamma[i]
                        + (i > 0 ? msb->cummu_mut_rate[i - 1] : 0);
            }
            double t = -log(gsl_rng_uniform(msb->ran)) / msb->cummu_mut_rate[msb->nbg - 1];
            if (t < time_to_event) {
                time_to_event = t;
                event = msbgs_event_mutation;
            }
        }

        /* Migration */
        if (msb->npop > 1) {
            for (int i = 0; i < msb->npop; i++) {
                msb->cummu_total_mig_rate[i] = msb->config[i] * msb->total_mig_rate[i]
                        + (i > 0 ? msb->cummu_total_mig_rate[i - 1] : 0);
            }
            if (msb->cummu_total_mig_rate[msb->npop - 1] > 0) {
                double t = -log(gsl_rng_uniform(msb->ran)) / msb->cummu_total_mig_rate[msb->npop - 1];
                if (t < time_to_event) {
                    time_to_event = t;
                    event = msbgs_event_migration;
                }
            }
        }
        
        if (time_to_event == HUGE_VAL && next_event == NULL) {
            fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
            abort();
        }
        
        if ((next_event != NULL) && (time_to_event + msb->time >= event_get_time(next_event))) {
            msb->time = event_get_time(next_event); 
            if (event_get_name(next_event) == event_name_pop_merger) {
                /*
                 * Merge pop1 and pop2.
                 * pop1 &lt; pop2
                 * The result population has id pop1
                 */
                int pop1, pop2;
                event_get_param_pop_merger(next_event, &pop1, &pop2);
                merge_pop(msb, pop1, pop2);
            } else if (event_get_name(next_event) == event_name_pop_size_change) {
                int pop;
                double new_size;
                event_get_param_pop_size_change(next_event, &pop, &new_size);
                if (pop == -1)
                    change_all_size(msb, new_size);
                else
                    change_size(msb, pop, new_size);
            } else {
                fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
                abort();
            }          
            next_event = event_list_iterator_next(msb->event_list);
        } else {
            msb->time += time_to_event;
            if (event == msbgs_event_coalescent) {
                double tmp = gsl_rng_uniform(msb->ran) * msb->total_coal_rate;
                int n = msb->ppchrom_leng;
                int n_m1 = n - 1;
                int c1, c2;
                c1 = c2 = -1;
                for (int i = 0; i < n_m1; i++) {
                    for (int j = i + 1, k = 0; j < n; j++, k++) {
                        if (tmp < msb->coal_rate[i][k]) {
                            c1 = i;
                            c2 = j;
                            if (mean_coal_rate_acc >= mean_coal_rate_cutoff) {
                                cal_mean_coal_rate(&mean_coal_rate, &mean_coal_rate_n, &mean_coal_rate_acc, &mean_coal_rate_acc_n);
                            } else {
                                mean_coal_rate_acc += msb->coal_rate[i][k];
                                mean_coal_rate_acc_n++;
                            }
                            goto POST_LOOP;
                        } else {
                            tmp -= msb->coal_rate[i][k];
                        }
                    }
                }
                POST_LOOP:
                if (c1 == -1) {
                    fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
                    abort();
                }            
                ca(msb, c1, c2);
            } else if (event == msbgs_event_crossover) {
                int c = (int) gsl_rng_uniform_int(msb->ran, (unsigned long) msb->ppchrom_leng);
                int brk = (int) gsl_rng_uniform_int(msb->ran, (unsigned long) msb->leng_m1);
                xover(msb, c, brk);
            } else if (event == msbgs_event_mutation) {
                double total_rate = msb->cummu_mut_rate[msb->nbg - 1];
                double tmp;
                do {
                    tmp = gsl_rng_uniform(msb->ran) * total_rate;
                } while (tmp >= total_rate);
                int bg_id = arrayutil_binary_search_d(msb->cummu_mut_rate, 0, msb->nbg, tmp);
                if (bg_id < 0) {
                    bg_id = -bg_id - 1;
                } else {
                    bg_id++;
                    if (bg_id >= msb->nbg) {
                        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
                        abort();
                    }
                }
                if (bg_id > 0) {
                    tmp -= msb->cummu_mut_rate[bg_id - 1];
                }
                int mut_id = (int) (tmp / msb->gamma[bg_id]);
                for (int i = 0; i < msb->ppchrom_leng; i++) {
                    int sum = chrom_get_nmut(msb->ppchrom[i], bg_id);
                    if (mut_id < sum) {
                        chrom_purge_mut(msb->ppchrom[i], mut_id, bg_id, msb->chr_stack);
                        msb->bg_nmut[bg_id]--;
                        msb->bg_total_nmut--;
                        coal_rate_update_for_replacement(msb, i);
                        break;
                    } else
                        mut_id -= sum;
                }
            } else if (event == msbgs_event_migration) {
                double total_rate = msb->cummu_total_mig_rate[msb->npop - 1];
                double tmp;
                do {
                    tmp = gsl_rng_uniform(msb->ran) * total_rate;
                } while (tmp >= total_rate);
                int src_id = arrayutil_binary_search_d(msb->cummu_total_mig_rate, 0, msb->npop, tmp);
                if (src_id < 0) {
                    src_id = -src_id - 1;
                } else {
                    src_id++;
                    if (src_id >= msb->npop) {
                        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
                        abort();
                    }
                }
                if (src_id > 0) {
                    tmp -= msb->cummu_total_mig_rate[src_id - 1];
                }
                int chr_id = (int) (tmp / msb->total_mig_rate[src_id]);
                tmp -= msb->total_mig_rate[src_id] * chr_id;
                int des_id = arrayutil_binary_search_d(msb->cumm_mig_rate[src_id], 0, msb->npop - 1, tmp);
                if (des_id < 0) {
                    des_id = -des_id - 1;
                } else {
                    des_id++;
                    if (des_id >= msb->npop - 1) {
                        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
                        abort();
                    }
                }
                if (des_id >= src_id) {
                    des_id++;
                }
                for (int i = 0, c = -1; i < msb->ppchrom_leng; i++) {
                    int pop = chrom_get_pop(msb->ppchrom[i]);
                    if (pop == src_id) {
                        c++;
                        if (chr_id == c) {
                            chrom_switch_pop(msb->ppchrom[i], des_id);
                            msb->config[des_id]++;
                            msb->config[src_id]--;
                            coal_rate_update_for_replacement(msb, i);
                            break;
                        }
                    }
                }
            } else {
                fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
                abort();
            }
        }
    }
    cal_mean_coal_rate(&mean_coal_rate, &mean_coal_rate_n, &mean_coal_rate_acc, &mean_coal_rate_acc_n);
    msb->mean_coal_rate = mean_coal_rate;
}