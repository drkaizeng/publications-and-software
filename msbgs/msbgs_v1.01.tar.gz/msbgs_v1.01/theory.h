/* 
 * File:   theory.h
 * Author: Kai
 *
 * Created on 12 June 2015, 15:21
 */

#ifndef THEORY_H
#define	THEORY_H

/**
 * 
 * @param thps Nr * u, where Nr is the reference haploid population size and u is 
 *                 the mutation rate per site per generation
 * @param rhops Nr * r, where r is the recombination per site per generation
 * @param nbg The number of backgrounds.
 * @param gamma Nr * s for each background.
 * @param leng Size of the entire simulated region.
 * @param state Neutral: -1; The i-th background: i, where i ranges from 0 to nbg-1.
 * @param nsel Total number of selected sites
 * @param nes The i-th element stores Ne*s for the i-th selected site.
 * @return The smallest value in n0s
 */
double theory_get_nes(double thps, double rhops, int nbg, const double gamma[nbg], 
        int leng, const int state[leng], int nsel, double nes[nsel]);

/**
 * Obtain B for each site.
 */
void theory_get_B(double thps, double rhops, int nbg, const double gamma[nbg], 
        int leng, const int state[leng], double B[leng]);

#endif	/* THEORY_H */

