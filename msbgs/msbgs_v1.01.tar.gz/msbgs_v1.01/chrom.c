#include <assert.h>
#include <stdlib.h>
#include <stdbool.h>
#include <limits.h>
#include <string.h>
#include <math.h>

#include "chrom.h"

#include "gsl/gsl_sf.h"

#include "util/my_stack.h"
#include "util/matrixalloc.h"

#include "background.h"

struct chrom_stack_tag {
    int leng;
    int nbg;
    /**
     * The total number of selected sites in each background
     */
    int *bg_leng;
    int *bg_leng_m1;
    /** 
     * bg_brkpt[i][j]: if a recombination break point is between the j-th and (j+1)-th sites in the simulated region,
     *                 bg_site[i][j] tells after which selected site in the i-th background this breakpoint falls. <br>
     * bg_brkpt[i][j]=-1: before the first site in this class of deleterious sites. <br>
     * bg_brkpt[i][j]=bg_leng_m1[i]: after the last site in this class of deleterious mutations. <br>                          
     */
    int **bg_brkpt;
    /**
     * U/s, where U is the total deleterious mutation rate of the entire region
     */
    double *lambda;  
    /**
     * The background of a new ancestor that is formed by a coalescent event
     */
    background_t **anc_bg;
    size_t anc_bg_mem_size;
    /**
     * Each background has its own stack.
     */
    background_stack_t **bg_stack;
    my_stack_t *chr_stack;
    gsl_rng *ran;    
};

typedef struct {
    /**
     * Start (inclusive) of a segment. <br> 
     * Range: [0, nsites-1]
     */
    int beg;
    /**
     * End (inclusive) of a segment. <br>
     * Range: [0, nsites-1]
     */
    int end;
    /** 
     * The ID of the node in the genealogy that is the immediate descendant of this segment.
     * If an event dose not result in a new node in the genealogy of this segment (e.g., a recombination event),
     * then the seg_T object in the new chrom_T object has the same desc
     * as the seg_T object in the chrom_T object hit by this event. Because
     * up to this event, the sites that are in this segment but on different sides of the breakpoint
     * share the same history of ancestry.
     * Tips are indexed from 0 to nsam-1; the first coalescent node is nsam, etc.
     */
    int desc;
} seg_t;

struct chrom_tag {
    int nbg;
    /**
     * The population to which this chrom object belongs
     */
    int pop;
    /**
     * The actual number of seg_T objects in pseg    
     */
    int pseg_leng;
    /**
     * A list of segments whose ancestral genetic materials are contained by this chrom_T object. <br>
     * These segments are non-overlapping and in strictly increasing order.
     */    
    seg_t *pseg;
    /**
     * The maximum number of seg_T objects that pseg can hold
     */
    int pseg_capacity;
    
    background_t **ppbg;
    /**
     * The sum of ln(f[i]), where f[i] ~ Poisson(lambda[i], k), where lambda[i]
     * is U[i]/s[i] of the i-th background and k is the number of mutations in the 
     * i-th background.
     */
    double ln_f;
};

/** 
 * @since 2015.2.11 (neutral), 2.15 (neutral), 2.19
 * 
 */
chrom_stack_t * chrom_stack_new(int leng, int nbg, int *state, double *gamma, double *theta, int init_stack_size, gsl_rng *ran) {
    if (nbg == 0 && (gamma != NULL || theta != NULL)) {
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    chrom_stack_t *re = matrixalloc_1d(1, sizeof(chrom_stack_t));
    re->leng = leng;
    re->nbg = nbg;
    if (nbg == 0) {
        for (int i = 0; i < leng; i++) {
            if (state[i] != -1) {
                fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
                abort();
            }
        }
        re->bg_leng = NULL;
        re->bg_leng_m1 = NULL;
        re->bg_brkpt = NULL;
        re->lambda = NULL;
        re->anc_bg = NULL;
        re->anc_bg_mem_size = 0;
        re->bg_stack = NULL;
    } else if (nbg > 0) {
        re->bg_leng = matrixalloc_1d_init(nbg, sizeof (int));
        re->bg_leng_m1 = matrixalloc_1d(nbg, sizeof (int));        
        re->bg_brkpt = matrixalloc_2d_i(nbg, leng);
        re->lambda = matrixalloc_1d(nbg, sizeof (double));
        re->anc_bg = matrixalloc_1d(nbg, sizeof (background_t *));  
        re->anc_bg_mem_size = (size_t) nbg * sizeof (background_t *); 
        re->bg_stack = matrixalloc_1d(nbg, sizeof (background_stack_t *));  
        for (int i = 0; i < nbg; i++) {
            if (theta[i] <= 0 || gamma[i] <= 0) {
                fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
                abort();
            }
            re->lambda[i] = theta[i] / gamma[i];
            int nDel = -1;
            for (int j = 0; j < leng; j++) {
                if (state[j] < -1 || state[j] >= nbg) {
                    fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
                    abort();
                } else if (state[j] == i) {
                    nDel++;
                }
                re->bg_brkpt[i][j] = nDel;
            }
            re->bg_leng[i] = nDel + 1;
            re->bg_leng_m1[i] = nDel;         
            re->bg_stack[i] = background_stack_new(re->bg_leng[i], init_stack_size);            
        } 
    } else {
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    re->chr_stack = my_stack_new(init_stack_size, 0);
    re->ran = ran;
    return re;
}

/**
 * Release the memory pointed by chr. The background objects are not freed, but are pushed into bg_stack.
 * @since 2015.2.19
 */
static void chrom_free(void *data) {
    chrom_t *chr = (chrom_t *) data;
    if (chr->nbg > 0) {
        matrixalloc_1d_free(chr->ppbg);
    } else if (chr->ppbg != NULL) {
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    matrixalloc_1d_free(chr->pseg);
    matrixalloc_1d_free(chr);
}

/** 
 * @since 2015.2.15 (neutral), 2.19
 * 
 */
void chrom_stack_free(chrom_stack_t *stack) {
    my_stack_clear_free(stack->chr_stack, chrom_free);
    my_stack_free(stack->chr_stack);
    if (stack->nbg > 0) {
        for (int i = 0; i < stack->nbg; i++) {
            background_stack_free(stack->bg_stack[i]);
        }
        matrixalloc_1d_free(stack->bg_stack);
        matrixalloc_1d_free(stack->anc_bg);  
        matrixalloc_1d_free(stack->lambda);
        matrixalloc_2d_i_free(stack->bg_brkpt);
        matrixalloc_1d_free(stack->bg_leng_m1);
        matrixalloc_1d_free(stack->bg_leng);
    }
    matrixalloc_1d_free(stack);
}

/* 
 * @since 2015.2.19
 */
void chrom_stack_push(chrom_stack_t *chr_stack, chrom_t *chr) {
    for (int i = 0; i < chr->nbg; i++) {
        background_stack_push(chr_stack->bg_stack[i], chr->ppbg[i]);
    }
    my_stack_push(chr_stack->chr_stack, chr);
}

/** 
 * @since 2013.03.22, 2015.01.29, 2.19
 * 
 */
static double ln_pois(double a, int i) {
    double tmp = -a + i * log(a) - gsl_sf_lnfact((unsigned int) i);
    return tmp;
}

/*
 * @since 2015.2.19
 */
static void chrom_get_ln_f(chrom_t *chr, chrom_stack_t *stack) {
    chr->ln_f = 0;
    for (int i = 0; i < chr->nbg; i++) {
        chr->ln_f += ln_pois(stack->lambda[i], background_sum(chr->ppbg[i]));
    }
}

/*
 * @since 2015.2.11 (neutral), 2.19
 */
chrom_t * chrom_new(int c, int pop, chrom_stack_t *stack) {
    chrom_t *re = my_stack_pop(stack->chr_stack);
    if (re == NULL) {
        re = matrixalloc_1d(1, sizeof(chrom_t));
        re->pseg = matrixalloc_1d(1,  sizeof(seg_t));
        re->pseg_capacity = 1;
        if (stack->nbg > 0) {
            re->ppbg = matrixalloc_1d(stack->nbg, sizeof (background_t *));
        } else {
            re->ppbg = NULL;
        }
    }
    re->nbg = stack->nbg;
    re->pop = pop;
    if (re->pseg_capacity < 1) {
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    re->pseg_leng = 1;
    re->pseg[0].beg = 0;
    re->pseg[0].end = stack->leng - 1;
    re->pseg[0].desc = c;
    for (int k = 0; k < stack->nbg; k++) {
        re->ppbg[k] = background_new1(stack->lambda[k], stack->bg_stack[k], stack->ran);
    }
    chrom_get_ln_f(re, stack);
    return re;
}

/* 
 * @since 2015.2.19
 */
int chrom_get_nmut(const chrom_t *chr, int i) {
    if (chr->nbg == 0) {
        return 0;
    } else if (i < 0 || i >= chr->nbg) {
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    } else {
        return background_sum(chr->ppbg[i]);
    }
}

/* 
 * @since 2015.2.19
 */
void chrom_purge_mut(chrom_t *chr, int mut_id, int bg_id, chrom_stack_t *stack) {
    if (bg_id < 0 || bg_id >= chr->nbg) {
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    background_purge(mut_id, chr->ppbg[bg_id]);
    chrom_get_ln_f(chr, stack);
}

/**
 * Find the id of the first segment in chr with end &gt; brk.
 * @since 2015.2.15
 */
static int chrom_find_seg(chrom_t *chr, int brk) {
    int low = 0;
    int high = chr->pseg_leng - 1;
    seg_t *pseg = chr->pseg;
    
    int mid;
    while (low <= high) {
        
        mid = (low + high) >> 1;//if high>low, then mid<high; if high=low, then mid=high

        if (pseg[mid].end > brk) {
            if (pseg[mid].beg <= brk) {
                return mid;
            } else if (mid > 0 && (pseg[mid - 1].end <= brk)) {
                return mid;
            } else {
                high = mid - 1;
            }
        } else {
            low = mid + 1;
        }
    }
    fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
    abort();
}

/**
 * Creates a new chrom_t that can hold at least init_pseg_capacity seg_t objects.
 * However, no variable is initialised.
 * @since 2015.2.11, 2.15
 */
static chrom_t * chrom_new_no_init(int init_pseg_capacity, chrom_stack_t *stack) {
    chrom_t *re = my_stack_pop(stack->chr_stack);
    if (re == NULL) {
        re = matrixalloc_1d(1, sizeof(chrom_t));
        re->pseg = matrixalloc_1d(init_pseg_capacity,  sizeof(seg_t));
        re->pseg_capacity = init_pseg_capacity;
        if (stack->nbg > 0) {
            re->ppbg = matrixalloc_1d(stack->nbg, sizeof (background_t *));
        } else {
            re->ppbg = NULL;
        }
    } else {
        if (init_pseg_capacity > re->pseg_capacity) {
            static int LIMIT = INT_MAX / 2;
            if (init_pseg_capacity >= LIMIT) {
                fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
                abort();
            }
            re->pseg_capacity = init_pseg_capacity * 2;
            matrixalloc_1d_free(re->pseg);
            re->pseg = matrixalloc_1d(re->pseg_capacity, sizeof(seg_t));
        }
    }
    return re;
}

/*
 * @since 2015.2.19
 */
chrom_t * chrom_split(chrom_t *chr, int brk, chrom_stack_t *chr_stack, frag_list_t *frag_list) {
    chrom_t *re = NULL;
    
    /* the entire span wrt to the entire simulated region */
    int min_site = chr->pseg[0].beg;
    int max_site = chr->pseg[chr->pseg_leng - 1].end;
    if (brk < min_site || brk >= max_site) {//the recombination event doesn't alter the pseg list in chr
        int bg_brk;
        for (int i = 0; i < chr->nbg; i++) {
            bg_brk = chr_stack->bg_brkpt[i][brk];
            if (brk < min_site) {
                if (bg_brk < 0)
                    continue;
                else if (bg_brk >= chr_stack->bg_leng_m1[i]) {
                    background_replace_all(chr->ppbg[i], chr_stack->lambda[i], chr_stack->ran);
                } else {
                    background_replace_one_side(chr->ppbg[i], true, bg_brk, chr_stack->lambda[i], chr_stack->ran, chr_stack->bg_stack[i]);
                }
            } else {
                if (bg_brk >= chr_stack->bg_leng_m1[i])
                    continue;
                else if (bg_brk < 0) {
                    background_replace_all(chr->ppbg[i], chr_stack->lambda[i], chr_stack->ran);
                } else {
                    background_replace_one_side(chr->ppbg[i], false, bg_brk, chr_stack->lambda[i], chr_stack->ran, chr_stack->bg_stack[i]);
                }
            }
        }
        chrom_get_ln_f(chr, chr_stack);
    } else {
        /** The index of the first seg_t in chr with end point > the breakpoint */
        int seg_id = chrom_find_seg(chr, brk);
        bool is_split = false;
        if (brk >= chr->pseg[seg_id].beg) /* test if the break point is within the segment */
            is_split = true;
        
        re = chrom_new_no_init(chr->pseg_leng, chr_stack);
        re->nbg = chr->nbg;
        re->pop = chr->pop;
        /* the number of seg_t in the new chrom_t object due to this recombination event */
        re->pseg_leng = chr->pseg_leng - seg_id;
        /* the first segment in the new chrom_t object */
        re->pseg[0].end = chr->pseg[seg_id].end;
        if (is_split == true) {
            re->pseg[0].beg = brk + 1;
            /* this is the end point of the chrom_t object that gets the lefthand side segment */
            chr->pseg[seg_id].end = brk;
        } else {
            re->pseg[0].beg = chr->pseg[seg_id].beg;
        }
        /*
         * the two segments on either side of the breakpoint share the same tree 
         * up to this point
         */
        re->pseg[0].desc = chr->pseg[seg_id].desc;        
        // copy other segments to the new chromo object
        memcpy(re->pseg + 1, chr->pseg + seg_id + 1, (size_t) (re->pseg_leng - 1) * sizeof(seg_t));
        
        // the number of segments remain in c, the original chrom_t object
        chr->pseg_leng = chr->pseg_leng - re->pseg_leng + (is_split ? 1 : 0);

        /** 
         * the part to the left of brk uses the old id and inherits the left part
         * the part to the right of brk uses the new id and inherits the right part 
         */
        for (int i = 0; i < re->nbg; i++) {
            int bg_brk = chr_stack->bg_brkpt[i][brk];
            if (bg_brk < 0) {// the left part has a new and random background, the right part is the existing background
                re->ppbg[i] = chr->ppbg[i];
                chr->ppbg[i] = background_new1(chr_stack->lambda[i], chr_stack->bg_stack[i], chr_stack->ran);
            } else if (bg_brk >= chr_stack->bg_leng_m1[i]) {// the right part has a new and random background, the left part is the existing background
                re->ppbg[i] = background_new1(chr_stack->lambda[i], chr_stack->bg_stack[i], chr_stack->ran);
            } else {
                re->ppbg[i] = background_split(chr->ppbg[i], bg_brk, chr_stack->lambda[i], chr_stack->ran, chr_stack->bg_stack[i]);
            }
        }
        chrom_get_ln_f(chr, chr_stack);
        chrom_get_ln_f(re, chr_stack);
        if (is_split == true) {
            frag_list_split(frag_list, brk);
        }
    }
    return re;
}

static int imin(int a, int b) {
    if (a <= b)
        return a;
    else
        return b;
}

static int imax(int a, int b) {
    if (a >= b)
        return a;
    else
        return b;
}

/**
 * @return true if there is an ancestral segment in chr that contains s; otherwise return false. When true is returned,
 *             the id of the segment that contains s is stored in seg_id. When false is returned, seg_id contains the
 *             id of the segment with beg &gt; s.
 * @since 2013.03.19, 2013.04.01, 2015.01.30
 * 
 */
static bool chrom_in_seg(const chrom_t *chr, int s, int *seg_id) {
    int ns = chr->pseg_leng;
    seg_t *pseg = chr->pseg;

    for (; seg_id[0] < ns && pseg[seg_id[0]].beg <= s; seg_id[0]++)
        if (pseg[seg_id[0]].end >= s)
            return true;
    return false;
}

/*
 * @since 
 */
chrom_t * chrom_ca(double time, const chrom_t * chr1, const chrom_t *chr2, chrom_stack_t *chr_stack, frag_list_t *frag_list) {
    for (int a = 0; a < chr_stack->nbg; a++) {
        double prob = background_coal_prob(chr1->ppbg[a], chr2->ppbg[a], chr_stack->bg_stack[a]);
        if (prob == 0) {
            fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
            abort();
        }
        chr_stack->anc_bg[a] = background_last_intersect(chr1->ppbg[a], chr2->ppbg[a], chr_stack->bg_stack[a]);
    }  
    chrom_t *new_chr = chrom_new_no_init(frag_list_size(frag_list), chr_stack);
    new_chr->nbg = chr1->nbg;
    new_chr->pop = chr1->pop;
    new_chr->pseg_leng = 0;
    if (chr1->nbg > 0) {
        memcpy(new_chr->ppbg, chr_stack->anc_bg, chr_stack->anc_bg_mem_size);
    } else {
        new_chr->ppbg = NULL;
    }
    chrom_get_ln_f(new_chr, chr_stack);
    
    int min_site = imin(chr1->pseg[0].beg, chr2->pseg[0].beg);
    int max_site;
    {
        int i1 = chr1->pseg_leng - 1;
        int i2 = chr2->pseg_leng - 1;
        max_site = imax(chr1->pseg[i1].end, chr2->pseg[i2].end);
    }
    
    int seg_id_1 = 0;
    int seg_id_2 = 0;
    
    frag_t *f;
    int beg, end;
    frag_list_iterator_reset(frag_list);
    while ((f = frag_list_iterator_next(frag_list)) != NULL) {
        frag_get_limits(f, &beg, &end);
        if (end < min_site) {
            continue;
        }
        if (beg > max_site) {
            break;
        }
        bool in1 = chrom_in_seg(chr1, beg, &seg_id_1);
        bool in2 = chrom_in_seg(chr2, beg, &seg_id_2);
        if (in1 || in2) {
            new_chr->pseg[new_chr->pseg_leng].beg = beg;
            new_chr->pseg[new_chr->pseg_leng].end = end;
            if (in1 && in2) {//coalescent
                int node_id = frag_add_ca(f, chr1->pseg[seg_id_1].desc, chr2->pseg[seg_id_2].desc, time);
                if (frag_has_mrca(f) == true) {
                    new_chr->pseg_leng--;
                } else {
                    new_chr->pseg[new_chr->pseg_leng].desc = node_id;
                }
            } else if (in1 == true) {
                new_chr->pseg[new_chr->pseg_leng].desc = chr1->pseg[seg_id_1].desc;                     
            } else {
                new_chr->pseg[new_chr->pseg_leng].desc = chr2->pseg[seg_id_2].desc;       
            }
            new_chr->pseg_leng++;
        }
    }
    if (new_chr->pseg_leng == 0) { 
        chrom_stack_push(chr_stack, new_chr);
        return NULL;
    } else {
        return new_chr;
    }
}

/*
 * @since 2015.2.17
 */
void chrom_switch_pop(chrom_t *chr, int pop) {
    chr->pop = pop;
}

/*
 * @since 2015.2.11
 */
int chrom_get_pop(const chrom_t *chr) {
    return chr->pop;
}

/*
 * @since 2015.2.11 (neutral), 2.19
 */
double chrom_coal_rate(const chrom_t *chr1, const chrom_t *chr2, chrom_stack_t *chr_stack) {
    if (chr1->pop != chr2->pop) {
        return 0;
    } else {
        double ca_pr = 1.0;
        for (int k = 0; k < chr1->nbg; k++) {
            ca_pr *= background_coal_prob(chr1->ppbg[k], chr2->ppbg[k], chr_stack->bg_stack[k]);
            if (ca_pr == 0) {
                return 0;
            }
        }
        return ca_pr / (exp(chr1->ln_f));
    }
}

void chrom_print_to_screen(const chrom_t *ch) {
    printf("\nchrom_T:\n");
    printf("pop = %i\n", ch->pop);
    printf("nseg = %i\n", ch->pseg_leng);
    printf("pseg_capacity = %i\n", ch->pseg_capacity);
    for (int i = 0; i < ch->pseg_leng; i++) {
        printf("\tpseg %i = {beg=%i,  end=%i,  desc=%i}\n", i, (ch->pseg + i)->beg, (ch->pseg + i)->end, (ch->pseg + i)->desc);        
    }
    printf("nbg = %i\n", ch->nbg);
    for (int i = 0; i < ch->nbg; i++) {
        printf("####    background %i", i);
        background_print_to_screen(ch->ppbg[i]);
    }
    printf("\n");
}

void chrom_print_to_screen_arr(const chrom_t **arr, int n) {
    printf("\n{chrom_T array:\n");
    for (int i = 0; i < n; i++) {
        printf("%i", i);
        chrom_print_to_screen(arr[i]);
    }
    printf("}\n");
}
