/* 
 * File:   background.h
 * Author: Kai
 *
 * Created on 08 February 2013, 13:03
 */

#ifndef BACKGROUND_H
#define	BACKGROUND_H

#include <stdbool.h>

#include "gsl/gsl_rng.h"

typedef struct background_tag background_t;

typedef struct background_stack_tag background_stack_t;

/** 
 * This function must be called before any other functions are used. Otherwise, the results
 * are undefined. This method sets up a background_stack_t object that is used to recycle background_t objects.
 * @param leng The number of deleterious sites in the background_t objects to be stored (>0)
 * @param stack_init_size The initial size of the stack (&gt;0)
 */
background_stack_t * background_stack_new(int leng, int stack_init_size);

/** 
 * Release the memory reserved for all the background_T objects in the stack, and then
 * destroy the stack.
 */
void background_stack_free(background_stack_t *stack);

/**
 * Creates a background_t object with leng number of selected sites 
 * and sum number of mutations.
 */
background_t * background_new(int sum, background_stack_t *stack);

/**
 * Creates a background_t object with leng number of selected sites. The number of mutations
 * is drawn from Poisson(lambda).
 */
background_t * background_new1(double lambda, background_stack_t *stack, gsl_rng *ran);

/**
 *  Put the background object into the stack_T object for future use 
 */
void background_stack_push(background_stack_t *stack, background_t *bg);

/**
 * Returns the total number of mutations 
 */
int background_sum(const background_t *bg);

/**
 * The multinomial probability of this background
 */
double background_prob(background_t *bg);

/**
 * Obtain the coalescent probability for the two genetic backgrounds.
 * Incompatible backgrounds (including bg1->sum != bg2->sum) have zero coalescent probability.
 * <p>
 * This is equivalent to Eq. 11 in the Genetics paper, omitting 1/N and fi
 */
double background_coal_prob(background_t *bg1, background_t *bg2, background_stack_t *stack);

/**
 * <b>Important</b>: this function should be called only when background_coal_prob()
 * is called first and returns a non-zero result.
 * <p>
 * Returns a background_T object that represents the intersect produced by the most recent call to
 * background_coal_prob. The 2 background_T objects used in
 * the call to background_coal_prob should be provided.
 */
background_t * background_last_intersect(const background_t *bg1, const background_t *bg2, background_stack_t *stack);

/**
 * Remove the i-th mutation in the background_T object. i = [0, sum-1]
 */
void background_purge(int i, background_t *bg);

/**
 * Randomly select one mutation and remove it from the background.
 */
void background_purge_ran(background_t *bg, gsl_rng *ran);


/**
 * Randomly select one mutation and remove it from the background.
 * Also return the position of the removed mutation, which is defined
 * wrt the sites that define the background only.
 */
int background_purge_ran_pos(background_t *bg, gsl_rng *ran);

/**
 * This function modify the existing background_t object according to the following rules.
 * <p>
 * Let ind be the insertion point of brk in pts (i.e., the index of the first element in pts with pts[ind]>=brk).
 * <p>
 * If onLeft=T, the first 2 segments are: <br>
 * 1. [0, brk] with nmut mutations <br>
 * 2. [brk+1, pts[ind]] with right mutations, if pts[ind] > brk; or [brk+1, pts[ind+1]], if pts[ind] = brk <br>
 * <p>
 * If onLeft=F, the last 2 segments are: <br>
 * 1. [pts[ind-1]+1, brk] with left mutations <br>
 * 2. [brk+1, 1] with nmut mutations <br>
 * <p>
 * where <br>
 * 1. left and right are the numbers of mutations located in [pts[ind-1]+1, pts[ind]], but to the left or right of brk <br>
 * 2. nmut is Poisson(lambda * y) where y = (brk+1)/leng if onLeft=T; otherwise y = 1 - (brk+1)/leng <br>
 * 
 * @param brk [0, leng-2]; defined on the set of sites that define the background
 *             The break point is between the brk-th and (brk+1)-th selected sites
 * @param lambda ud/s, where ud is the total mutation rate for ALL the selected sites that define the background
 * @return 
 */
void background_replace_one_side(background_t *bg, bool onLeft, int brk, double lambda, gsl_rng *ran, background_stack_t *stack);

/**
 * Let ind be the first index in bg->pts, such that bg->pts[ind] >= brk. <br>
 * Let left and right be the numbers of mutations in [bg->pts[ind-1]+1, bg->pts[ind]] that fall to the left and right of brk. <br>
 * <p>
 * 1. The interval [brk + 1, leng-1] in bg is replaced and now contains nmutRight mutations; [bg->pts[ind-1]+1, brk] has left mutations. <br>
 * 2. The returned background_T object contains the second half of bg, and has right mutations in [brk+1, bg->pts[ind]]
 *    and nmutLeft mutations in [0, brk]. <br>
 * <p>
 * where <br>
 * 1. x = (brk+1)/leng <br>
 * 2. nmutLeft: Poisson(x * lambda) <br>
 * 3. nmutRight: Poisson((1-x)*lambda)) <br>
 * 
 * @param brk [0, leng-2]; defined on the set of sites that define the background
 *             The break point is between the brk-th and (brk+1)-th selected sites
 * @param lambda U/s, where U is the total mutation rate for ALL the selected sites that define the background
 */
background_t * background_split(background_t *bg, int brk, double lambda, gsl_rng *ran, background_stack_t *stack);

/**
 * Replace bg with one that has only one segment containing nmut mutations, where nmut ~ Poisson(lambda)
 */
void background_replace_all(background_t *bg, double lambda, gsl_rng *ran);

void background_print_to_screen(const background_t *bg);

#endif	/* BACKGROUND_H */

