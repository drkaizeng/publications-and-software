/* 
 * File:   msbgs_param.h
 * Author: kai
 *
 * Created on 21 January 2015, 15:59
 */

#ifndef MSBGS_PARAM_H
#    define	MSBGS_PARAM_H

#include "event.h"
#include "gsl/gsl_rng.h"

typedef struct {    
    /**
     * Sample size.
     */
    int nsam;
    /**
     * The size of the entire simulated region
     */    
    int leng;    
    /**
     * The number of populations at the beginning
     */
    int npop;
    /**
     * N/Nr
     * <p>
     * The relative haploid sizes of the populations. These are all expressed relative to
     * the reference haploid population size used to calculate rho, gamma, and theta.
     */
    double *pop_size;
    /**
     * The sampling configuration. sam_config[i] is the number of samples taken from
     * the i-th population. Note that sam_config sums up to nsam and has exactly
     * npop elements.
     */
    int *sam_config;
    /**
     * Nr * m
     * <p>
     * The migration rate matrix. The rates are scaled by the reference haploid population size.
     * That is, the one used to calculate rho, gamma, and theta.
     * <ul>
     * <li> For i &ne; j, mig_mat[i][j] is the scaled migration from deme i to deme j. 
     * <li> mig_mat[i][i] = 0.
     * <li> Set to NULL if npop = 1.
     * </ul>
     */
    double **mig_mat;
    /**
     * rho = r * Nr, where r is the recombination rate of the entire simulated region
     */
    double rho;
    /**
     * The number of genetic backgrounds. Selected sites in the same background share the same
     * selection coefficient. For neutrality, nbg=0.
     */
    int nbg;
    /**
     * state[i]=-1, the i-th site is neutral
     * state[i]=0, a selected site of type 0. The selection coefficient and the total mutation rate
     * for all sites of type 0 are given by gamma[0] and theta[0]
     */
    int *state;
    /**
     * s * Nr, where s the selection coefficient. 
     * There are nbg elements in this array.
     * Set to NULL if nbg=0.
     */
    double *gamma;
    /**
     * U * Nr, where U is the total deleterious mutation rate of all the sites in this
     * genetic background. There are nbg elements in this array.
     * Set to NULL if nbg=0.
     */
    double *theta;
    /**
     * time = generations / Nr
     * <p>
     * This is a linked list of events. The events are ordered wrt to time in the past,
     * with the most recent event being the first element in the list.
     * <p>
     * This points to NULL if there is no event.
     */
    event_list_t *event_list;
    /**
     * Initial size of the chrom stack (>0)
     */
    int chrom_stk_init_size;
    /**
     * Initial size of the segl stack (>0)
     */
    int frag_list_init_size;
    
    gsl_rng *ran;
} msbgs_param_t;

#endif	/* MSBGS_PARAM_H */

