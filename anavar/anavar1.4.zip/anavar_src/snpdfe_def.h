/* 
 * Created on 03 February 2017, 14:14
 */

#ifndef SNPDFE_DEF_H
#    define SNPDFE_DEF_H

#include "snpdfe.h"
#include "vardfe_def.h"

struct snpdfe_builder_tag {
    /**
     * <ol>
     * <li>0: no data. The object was just created by new()
     * <li>1: data have been added
     * <li>2: distribution has been added and the variables for dealing with constraints have been initialised by init()
     * <li>3: add_constraint has been called
     * </ol>
     */
    int mode;
    /**
     * <ol>
     * <li> -1: no distribution added
     * <li> 0: spikes
     * <li> 1: continuous
     * </ol>
     */
    int dist;
    
    /* The following are initialised in new() */
    vardfe_t vd;
    integrator_t ig;//set to NULL after calling add_spike or add_gamma_continuous
    int nthreads;
    bool use_r;
    char *name;//the name of the dataset;
    
    /* The following are initialised in add_data() */
    double m;
    bool folded;
    
    /* The following are initialised in add_spikes or add_gamma_continuous */
    void (* add_constraint)(snpdfe_builder_t sb, char **msg, const char *name, va_list args);
};


#endif /* SNPDFE_DEF_H */

