#include <string.h>

#include "indeldfe_def.h"
#include "tau.h"
#include "print_errmsg.h"
#include "param.h"
#include "get_name.h"
#include "dist.h"
#include "vardfe_reflected_gamma_gaussq_adaptive.h"
#include "find_name.h"

#include "util/matrixalloc.h"
#include "util/error_msg.h"
#include "util/string_util.h"

#include "gsl/gsl_deriv.h"

typedef struct {
    int n;
    double m;
    int nthreads;
    
    /* For dist, num_dist_param, and dist_ranges, the first element is for insertions and the second is for deletions */
    dist_t dist[2];//distribution of gamma
    int num_dist_param[2];//number of parameters in the above distribution
    double **dist_ranges[2];//the range of the parameters of dist. ranges[0] is the lower bound and ranges[1] is the upper bound.
    double frac;
    double delta;

    tau_t tau;//with multi-threading, this should be an array of length nthreads.
    double *dist_x[2];//Of length num_dist_param; a copy of input distribution parameters; with multi-threading, each thread needs a separate copy of this.
    size_t dist_xs[2];
    /*
     * t[0] is for insertions and t[1] for deletions. <br>
     * t[0][i] is the value of tau(i, gamma) integrated over the distribution of gamma for insertions.
     */
    double *t[2];
    double **dt[2];//dt[0][i][j] = d(t[0][i])/d(the j-th parameter of the distribution of gamma for insertions) 
    gsl_function dt_func;//for calculating dt numerically
    
    vardfe_reflected_gamma_gaussq_adaptive_t rga;//The default is NULL
    
    int id;//0 for insertions and 1 for deletions
    int i;//with multi-threading, this should be an array of length nthreads.
    int p;//the index of the parameter of the distribution whose derivative is being calculated. Thus p ranges from [0, num_dist_param-1].
} indeldfe_gamma_cont_t;

/*
 * @since 2017.9.8, 2018.3.6 (rga related)
 */
static void free_dfe(void *dfe) {
    indeldfe_gamma_cont_t *gc = (indeldfe_gamma_cont_t *) dfe;
    if (gc->rga != NULL) {
        for (int i = 0; i < 2; i++) {
            if (gc->dist[i] != NULL)
                ERROR_MSG_LMA("error");
        }
        vardfe_reflected_gamma_gaussq_adaptive_free(&(gc->rga));
    }
    for (int i = 0; i < 2; i++) {
        matrixalloc_2d_d_free(gc->dt[i]);
        matrixalloc_1d_free(gc->t[i]);
        matrixalloc_1d_free(gc->dist_x[i]);
        matrixalloc_2d_d_free(gc->dist_ranges[i]);
        if (gc->dist[i] != NULL)
            dist_free(&(gc->dist[i]));
    }
    tau_free(&(gc->tau));
    matrixalloc_1d_free(gc);
}

/*
 * This is for calculating the integration of tau(gamma, i) over the distribution of gamma.
 * @since 2017.4.28, 9.8
 */
static double int_tau(double gamma, void *param) { 
    indeldfe_gamma_cont_t *gc = (indeldfe_gamma_cont_t *) param;
    return tau_cal(gc->i, gamma, gc->tau);
}

/*
 * @since 2017.4.28
 */
static double dt_func(double x, void *param) {
    indeldfe_gamma_cont_t *gc = (indeldfe_gamma_cont_t *) param;
    double tmp = gc->dist_x[gc->id][gc->p];
    gc->dist_x[gc->id][gc->p] = x;
    double t = dist_int(int_tau, gc->dist_x[gc->id], gc, gc->dist[gc->id]);
    gc->dist_x[gc->id][gc->p] = tmp;
    return t;
}

/**
 * 
 * @param x ins_theta, ins_dist_params, ins_e, del_theta, del_dist_params, del_e
 * @param dsfs length(sfs)-by-num_param_full matrix where num_param_full is the number of parameters under the full model including r.
 *             dsfs[i][j] is the partial derivative of sfs[i] wrt the j-th parameter.
 *             If dsfs is NULL, then partial derivatives are not calculated.
 * @param has_der the number of parameters in the full model excluding r
 * @since 2017.4.28, 9.8
 */
static void get_t_dt(indeldfe_gamma_cont_t *gc, const double *x, double **dsfs, const bool *has_der) {
    for (int j = 0, k; j < 2; j++) {
        gc->id = j;
        k = j * (gc->num_dist_param[j] + 2) + 1;
        for (int i = 1; i < gc->n; i++) {
            gc->i = i;
            gc->t[j][i - 1] = dist_int(int_tau, x + k, gc, gc->dist[j]);
        }
    }
    if (dsfs != NULL) {
        for (int r = 0, s; r < 2; r++) {
            gc->id = r;
            s = r * (gc->num_dist_param[r] + 2) + 1;
            memcpy(gc->dist_x[r], x + s, gc->dist_xs[r]);
            for (int i = 1; i < gc->n; i++) {
                gc->i = i;
                for (int j = 0, k; j < gc->num_dist_param[r]; j++) {
                    gc->p = j;
                    k = s + j;
                    if (has_der[k]) {
                        double step = fmax(gc->delta, gc->frac * fabs(x[k]));
                        if (gc->dist_ranges[r][1][j] - gc->dist_ranges[r][0][j] <= step)
                            ERROR_MSG_LMA("The range is too small!\n");
                        int status;
                        double re, abserr;
                        if (x[k] + step > gc->dist_ranges[r][1][j]) {
                            status = gsl_deriv_backward(&(gc->dt_func), x[k], step, &re, &abserr);
                        } else if (x[k] - step < gc->dist_ranges[r][0][j]) {
                            status = gsl_deriv_forward(&(gc->dt_func), x[k], step, &re, &abserr);
                        } else {
                            status = gsl_deriv_central(&(gc->dt_func), x[k], step, &re, &abserr);
                        }
                        if (status)
                            ERROR_MSG_LMA("GSL failure!\n");
                        gc->dt[r][i - 1][j] = re;
                    }
                }
            }
        }
    }
}

/*
 * @since 2017.4.28, 9.8
 */
static void cal_no_r(double *sfs, double **dsfs, const double *x, const double *r, const bool *has_der, void *dfe) {
    indeldfe_gamma_cont_t *gc = (indeldfe_gamma_cont_t *) dfe;
    get_t_dt(gc, x, dsfs, has_der);
    int n = gc->n;
    double m = gc->m;
    double **t = gc->t, ***dt = gc->dt;
    int ti = 0, td = gc->num_dist_param[0] + 2;
    int ei = gc->num_dist_param[0] + 1, ed = ei + gc->num_dist_param[1] + 2;
    for (int i = 1, j, jd, nj; i < n; i++) {
        j = i - 1;
        jd = n - 1 + j;
        nj = n - i - 1;
        sfs[j] = (1 - x[ei]) * m * x[ti] * t[0][j] + x[ed] * m * x[td] * t[1][nj];
        sfs[jd] = (1 - x[ed]) * m * x[td] * t[1][j] + x[ei] * m * x[ti] * t[0][nj];
        if (dsfs != NULL) {
            if (has_der[ti]) {
                dsfs[j][ti] = (1 - x[ei]) * m * t[0][j];
                dsfs[jd][ti] = x[ei] * m * t[0][nj];
            }
            for (int k = 1; k <= gc->num_dist_param[0]; k++) {
                if (has_der[k]) {
                    dsfs[j][k] = (1 - x[ei]) * m * x[ti] * dt[0][j][k - 1];
                    dsfs[jd][k] = x[ei] * m * x[ti] * dt[0][nj][k - 1];
                }
            }
            if (has_der[ei]) {
                dsfs[j][ei] = -m * x[ti] * t[0][j];
                dsfs[jd][ei] = m * x[ti] * t[0][nj];
            }
            if (has_der[td]) {
                dsfs[j][td] = x[ed] * m * t[1][nj];
                dsfs[jd][td] = (1 - x[ed]) * m * t[1][j];
            }
            for (int k = 0, s = td + 1; k < gc->num_dist_param[1]; k++, s++) {
                if (has_der[s]) {
                    dsfs[j][s] = x[ed] * m * x[td] * dt[1][nj][k];
                    dsfs[jd][s] = (1 - x[ed]) * m * x[td] * dt[1][j][k];
                }
            }
            if (has_der[ed]) {
                dsfs[j][ed] = m * x[td] * t[1][nj];
                dsfs[jd][ed] = -m * x[td] * t[1][j];
            }
        }
    }
}

/*
 * @since 2017.4.28, 9.8
 */
static void cal_use_r(double *sfs, double **dsfs, const double *x, const double *r, const bool *has_der, void *dfe) {
    indeldfe_gamma_cont_t *gc = (indeldfe_gamma_cont_t *) dfe;
    get_t_dt(gc, x, dsfs, has_der);
    int n = gc->n;
    double m = gc->m;
    double **t = gc->t, ***dt = gc->dt;
    int ti = 0, td = gc->num_dist_param[0] + 2;
    int ei = gc->num_dist_param[0] + 1, ed = ei + gc->num_dist_param[1] + 2;
    int lo = ed + 1, hi = lo + n - 2;
    if (dsfs != NULL) {
        int cnt = 2 * (n - 1);
        for (int i = 0; i < cnt; i++)//has_der is always true for the r parameters
            for (int j = lo; j < hi; j++)
                dsfs[i][j] = 0;
    }
    for (int i = 1, j, jd, nj; i < n; i++) {
        j = i - 1;
        jd = n - 1 + j;
        nj = n - i - 1;
        double riv = (i == 1 ? 1 : r[i - 2]);
        double rniv = (i == n - 1 ? 1 : r[n - i - 2]);
        sfs[j] = (1 - x[ei]) * m * x[ti] * riv * t[0][j] + x[ed] * m * x[td] * rniv * t[1][nj];
        sfs[jd] = (1 - x[ed]) * m * x[td] * riv * t[1][j] + x[ei] * m * x[ti] * rniv * t[0][nj];
        if (dsfs != NULL) {
            if (has_der[ti]) {
                dsfs[j][ti] = (1 - x[ei]) * m * riv * t[0][j];
                dsfs[jd][ti] = x[ei] * m * rniv * t[0][nj];
            }
            for (int k = 1; k <= gc->num_dist_param[0]; k++) {
                if (has_der[k]) {
                    dsfs[j][k] = (1 - x[ei]) * m * x[ti] * riv * dt[0][j][k - 1];
                    dsfs[jd][k] = x[ei] * m * x[ti] * rniv * dt[0][nj][k - 1];
                }
            }
            if (has_der[ei]) {
                dsfs[j][ei] = -m * x[ti] * riv * t[0][j];
                dsfs[jd][ei] = m * x[ti] * rniv * t[0][nj];
            }
            if (has_der[td]) {
                dsfs[j][td] = x[ed] * m * rniv * t[1][nj];
                dsfs[jd][td] = (1 - x[ed]) * m * riv * t[1][j];
            }
            for (int k = 0, s = td + 1; k < gc->num_dist_param[1]; k++, s++) {
                if (has_der[s]) {
                    dsfs[j][s] = x[ed] * m * x[td] * rniv * dt[1][nj][k];
                    dsfs[jd][s] = (1 - x[ed]) * m * x[td] * riv * dt[1][j][k];
                }
            }
            if (has_der[ed]) {
                dsfs[j][ed] = m * x[td] * rniv * t[1][nj];
                dsfs[jd][ed] = -m * x[td] * riv * t[1][j];
            }
            if (i == n - i && i > 1) {
                dsfs[j][lo + i - 2] += (1 - x[ei]) * m * x[ti] * t[0][j] + x[ed] * m * x[td] * t[1][nj];
                dsfs[jd][lo + i - 2] += (1 - x[ed]) * m * x[td] * t[1][j] + x[ei] * m * x[ti] * t[0][nj];
            } else if (i == 1) {
                dsfs[j][lo + n - 3] += x[ed] * m * x[td] * t[1][nj];
                dsfs[jd][lo + n - 3] += x[ei] * m * x[ti] * t[0][nj];
            } else if (i == n - 1) {
                dsfs[j][lo + i - 2] += (1 - x[ei]) * m * x[ti] * t[0][j];
                dsfs[jd][lo + i - 2] += (1 - x[ed]) * m * x[td] * t[1][j];
            } else {
                dsfs[j][lo + i - 2] += (1 - x[ei]) * m * x[ti] * t[0][j];
                dsfs[jd][lo + i - 2] += (1 - x[ed]) * m * x[td] * t[1][j];

                dsfs[j][lo + n - i - 2] += x[ed] * m * x[td] * t[1][nj];
                dsfs[jd][lo + n - i - 2] += x[ei] * m * x[ti] * t[0][nj];
            }
        }
    }
}

/**
 * @since 2018.3.11
 */
static double fixed_del_ins_ratio_f(const double *x, void *param) {
    double *r = (double *) param;
    return x[0] * r[0];
}

/**
 * @since 2018.3.11
 */
static double fixed_del_ins_ratio_df(const double *x, int i, void *param) {
    double *r = (double *) param;
    return r[0];
}

/*
 * @since 2018.3.11
 */
static void free_double_array(void *param) {
    double *r = (double *) param;
    M1D_FREE(r);
}

/*
 * @since 2018.3.11, 3.13
 */
static void fixed_del_ins_ratio(indeldfe_builder_t ib, double r) {
    int indx[2];
    const char *names[2] = {"ins_", "del_"};
    for (int i = 0; i < 2; i++) {
        char *tmp = get_name2("%s%s%s", ib->name, names[i], "theta");
        indx[i] = find_name(tmp, ib->vd->num_param_full, ib->vd->param_names);
        if (indx[i] < 0) 
            ERROR_MSG_LMA("Failed\n");
        matrixalloc_1d_free(tmp);
    }
    //let the insertion mutation rate be free parameter; r = del/ins
    ib->vd->num_free_param--;
    ib->vd->is_free[indx[1]] = false;
    ib->vd->xi[indx[1]] = -2;
    for (int j = indx[1] + 1; j < ib->vd->nx; j++)
        if (ib->vd->xi[j] >= 0)
            ib->vd->xi[j]--;
    
    constraint_func_t *cf = matrixalloc_1d(1, sizeof(*cf));
    cf->nx = 1;
    cf->x = matrixalloc_1d(cf->nx, sizeof(*cf->x));
    cf->xi = matrixalloc_1d(cf->nx, sizeof(*cf->xi));
    cf->xi[0] = indx[0];
    cf->f = fixed_del_ins_ratio_f;
    cf->df = fixed_del_ins_ratio_df;
    double *val = matrixalloc_1d(1, sizeof(double));
    val[0] = r;
    cf->param = val;
    cf->free_param = free_double_array;
    ib->vd->cf[indx[1]] = cf;
}

/*
 * @since 2018.3.11 (fixed_del_ins_ratio)
 */
static void add_constraint(indeldfe_builder_t sb, char **msg, const char *name, va_list args) {
    msg[0] = NULL;
    
    if (strcmp(name, "none") == 0)
        return;
    if (string_util_starts_with(name, "fixed_del_ins_ratio")) {
        double r = va_arg(args, double);
        if (r <= 0) {
            PRINT_ERRMSG(msg, "fixed_del_ins_ratio: r <= 0");
            return;
        }
        fixed_del_ins_ratio(sb, r);
    } else {
        PRINT_ERRMSG(msg, "Unknown constraint = %s\n.", name);
    }
}

/*
 * @since 2017.4.26, 9.8
 */
void indeldfe_builder_add_gamma_continuous(indeldfe_builder_t ib, 
        dist_t *ins_dist, int ins_num_dist_param, double ins_ranges[ins_num_dist_param + 2][2], 
        dist_t *del_dist, int del_num_dist_param, double del_ranges[del_num_dist_param + 2][2], 
        double frac, double delta, char **msg) {
    msg[0] = NULL;
    
    if (ib->mode != 1)
        ERROR_MSG_LMA("sb->mode != 1\n");
    if (ib->dist != -1)
        ERROR_MSG_LMA("sb->dist != -1\n");
    if (ins_num_dist_param < 1 || del_num_dist_param < 1)
        ERROR_MSG_LMA("Error\n");
    
    dist_t dist[2] = { ins_dist[0], del_dist[0] };
    ins_dist[0] = del_dist[0] = NULL;
    int num_dist_param[2] = { ins_num_dist_param, del_num_dist_param };
    for (int i = 0; i < 2; i++) {
        dist_type_t type = dist_type(dist[i]);
        if (type != GAMMA_DIST) {
            PRINT_ERRMSG(msg, "Unsupported distribution for gamma (4Ns).");
            return;
        }
        if (type == GAMMA_DIST && num_dist_param[i] != 2) {
            PRINT_ERRMSG(msg, "The gamma distribution is specified by the shape and scale parameters.");
            return;
        }
    }
    
    if (frac < 0) {
        PRINT_ERRMSG(msg, "fraction < 0\n");
        return;
    }
    if (delta < 0) {
        PRINT_ERRMSG(msg, "delta < 0\n");
        return;
    }
    if (frac <= 0 && delta <= 0) {
        PRINT_ERRMSG(msg, "fraction <= 0 and delta <= 0. At least one of them should be strictly positive.\n");
        return;
    }
    
    ib->mode = 2;
    ib->dist = 1;
    
    
    indeldfe_gamma_cont_t *gc = matrixalloc_1d(1, sizeof (*gc));
    gc->n = ib->vd->n;
    gc->m = ib->m;
    gc->nthreads = ib->nthreads;
    
    typedef double array_t[2];
    array_t *ranges[2] = {ins_ranges, del_ranges};
    for (int i = 0; i < 2; i++) {
        gc->dist[i] = dist[i];
        gc->num_dist_param[i] = num_dist_param[i];
        gc->dist_ranges[i] = matrixalloc_2d_d(2, gc->num_dist_param[i]);
        for (int j = 1; j <= gc->num_dist_param[i]; j++) {
            gc->dist_ranges[i][0][j - 1] = ranges[i][j][0];
            gc->dist_ranges[i][1][j - 1] = ranges[i][j][1];
        }
        gc->dist_x[i] = matrixalloc_1d(gc->num_dist_param[i], sizeof (double));
        gc->dist_xs[i] = (size_t) gc->num_dist_param[i] * sizeof (double);
        gc->t[i] = matrixalloc_1d(gc->n - 1, sizeof (double));
        gc->dt[i] = matrixalloc_2d_d(gc->n - 1, gc->num_dist_param[i]);
    }
    gc->frac = frac;
    gc->delta = delta;
    gc->tau = tau_new(gc->n, &(ib->ig));//with multithreading, ig needs to be cloned.
    (gc->dt_func).function = dt_func;
    (gc->dt_func).params = gc;
    gc->rga = NULL;
    
    ib->vd->num_param_full = gc->num_dist_param[0] + gc->num_dist_param[1] + 4 + ib->vd->nr;
    ib->vd->num_free_param = ib->vd->num_param_full;
    ib->vd->param_types = matrixalloc_1d(ib->vd->num_param_full, sizeof (param_t));
    ib->vd->param_names = matrixalloc_1d(ib->vd->num_param_full, sizeof (char *));
    {
        int indx = 0;
        const char *names[2] = {"ins_", "del_"};
        for (int i = 0; i < 2; i++) {
            ib->vd->param_types[indx] = THETA;
            ib->vd->param_names[indx++] = get_name2("%s%s%s", ib->name, names[i], "theta");
            if (dist_type(dist[i]) == GAMMA_DIST) {
                ib->vd->param_types[indx] = SHAPE;
                ib->vd->param_names[indx++] = get_name2("%s%s%s", ib->name, names[i], "shape");
                ib->vd->param_types[indx] = SCALE;
                ib->vd->param_names[indx++] = get_name2("%s%s%s", ib->name, names[i], "scale");
            }
            ib->vd->param_types[indx] = ERR;
            ib->vd->param_names[indx++] = get_name2("%s%s%s", ib->name, names[i], "e");
        }
        for (int i = 0; i < ib->vd->nr; i++) {
            ib->vd->param_types[indx] = R;
            ib->vd->param_names[indx++] = get_name("r", i + 2);
        }
    }
    
    ib->vd->dfe = gc;
    ib->vd->ranges = matrixalloc_2d_d(2, ib->vd->num_param_full - ib->vd->nr);
    for (int i = 0, indx = 0; i < 2; i++) {
        int cn = 2 + num_dist_param[i];
        for (int j = 0; j < cn; j++, indx++) {
            if (ranges[i][j][0] >= ranges[i][j][1]) {
                PRINT_ERRMSG(msg, "The range [%g, %g] for %s is invalid. "
                        "The lower bound should be strictly smaller than the upper bound\n",
                        ranges[i][j][0], ranges[i][j][1], ib->vd->param_names[indx]);
                return;
            }
            if (ib->vd->param_types[indx] == THETA || ib->vd->param_types[indx] == SHAPE || ib->vd->param_types[indx] == SCALE) {
                if (ranges[i][j][0] <= 0) {
                    PRINT_ERRMSG(msg, "The lower bound for %s is %g, but it should be positive.\n",
                            ib->vd->param_names[indx], ranges[i][j][0]);
                    return;
                }
            }
            ib->vd->ranges[0][indx] = ranges[i][j][0];
            ib->vd->ranges[1][indx] = ranges[i][j][1];
        }
    }

    ib->vd->free_dfe = free_dfe;
    if (ib->use_r)
        ib->vd->cal = cal_use_r;
    else
        ib->vd->cal = cal_no_r;

    ib->add_constraint = add_constraint;
    
    vardfe_init(ib->vd);
}

/*
 * @since 2018.3.6, 3.11
 */
static void rga_cal(double *sfs, double **dsfs, const double *x, const double *r, const bool *has_der, void *dfe) {
    indeldfe_gamma_cont_t *gc = (indeldfe_gamma_cont_t *) dfe;
    vardfe_reflected_gamma_gaussq_adaptive_t rga = gc->rga;
    vardfe_reflected_gamma_gaussq_adaptive_set_dist(rga, r);
    vardfe_reflected_gamma_gaussq_adaptive_cal(sfs, dsfs, x, r, has_der, dfe, rga);
}

/*
 * @since 2018.3.6, 3.11
 */
void indeldfe_builder_add_reflected_gamma_gaussq_adaptive(indeldfe_builder_t ib, 
        double ins_ranges[4][2], double del_ranges[4][2], 
        double frac, double delta, const char *method, char **msg) {
    msg[0] = NULL;
    
    int d_len = 2;
    dist_t d[d_len];
    for (int i = 0; i < d_len; i++) {
        d[i] = dist_gamma_gaussq(10, true, msg);
        if (msg[0] != NULL)
            return;
    }
    indeldfe_builder_add_gamma_continuous(ib, d, 2, ins_ranges, d + 1, 2, del_ranges, frac, delta, msg);
    
    indeldfe_gamma_cont_t *gc = (indeldfe_gamma_cont_t *) ib->vd->dfe;
    for (int i = 0; i < d_len; i++)
        dist_free(gc->dist + i);
    
    int n_dist = 2;
    dist_t *vd_dist[n_dist];
    for (int i = 0; i < n_dist; i++)
        vd_dist[i] = gc->dist + i;
    gc->rga = vardfe_reflected_gamma_gaussq_adaptive_new(ib->vd, n_dist, vd_dist, method, msg);
    if (msg[0] != NULL) 
        return;

    ib->vd->cal = rga_cal;
}