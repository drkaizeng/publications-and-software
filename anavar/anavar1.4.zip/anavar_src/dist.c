/* 
 * Created on 09 February 2017, 13:35
 */

#include "dist.h"
#include "dist_def.h"

#include "util/matrixalloc.h"

/*
 * @since 2017.4.6, 9.5
 */
void dist_free(dist_t *d) {
    d[0]->free_param(d[0]->param);
    matrixalloc_1d_free(d[0]);
    d[0] = NULL;
}

/*
 * @since 2017.4.6, 9.5
 */
dist_type_t dist_type(dist_t d) {
    return d->type();
}

/*
 * @since 2017.2.10, 4.6, 9.7
 */
double dist_int(double (* func)(double x, void *param), const double *x, void *param, dist_t d) {
    return d->integrate(func, x, param, d->param);
}