/* 
 * Created on 02 February 2017, 14:47
 */


#include "integrator.h"
#include "integrator_def.h"

#include "util/matrixalloc.h"

/*
 * @since 2017.5.8, 9.5
 */
integrator_t integrator_clone(integrator_t ig) {
    return ig->clone(ig->param);
}

/*
 * @since 2017.2.17, 4.6
 */
void integrator_free(integrator_t *ig) {
    ig[0]->free_param(ig[0]->param);
    matrixalloc_1d_free(ig[0]);
    ig[0] = NULL;
}

//void integrator_set_pts(integrator_t ig, bool is_sig, int npts, double *pts) {
//    ig->set_pts(ig->param, is_sig, npts, pts);
//}

/*
 * @since 2017.2.10, 2.16, 4.6
 */
int integrator_int(double *result, gsl_function *func, integrator_t ig) {
    return ig->integrate(result, func, ig->param);
}

/*
 * @since 
 */
double integrator_abserr(integrator_t ig) {
    return ig->abserr(ig->param);
}


