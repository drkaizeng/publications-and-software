/* 
 * Created on 06 February 2017, 06:55
 */

#ifndef DIST_DEF_H
#    define DIST_DEF_H

#include "dist.h"

struct dist_tag {
    void *param;
    void (* free_param)(void *param);
    dist_type_t (* type)(void);
    double (* integrate)(double (* func)(double x, void *param), const double *x, void *param, void *dist_param);
};


#endif /* DIST_DEF_H */

