/* 
 * Created on 02 February 2017, 15:19
 */
#include <string.h>

#include "integrator.h"
#include "integrator_def.h"
#include "print_errmsg.h"

#include "util/matrixalloc.h"
#include "util/error_msg.h"

typedef struct {
    size_t size;
    double epsabs;
    double epsrel;
    gsl_integration_cquad_workspace *w;
    double abserr;
    size_t nevals;
    double pts[2];
} integrator_cquad_t;

/*
 * @since 2017.9.5
 */
static void free_param(void *param) {
    integrator_cquad_t *q = (integrator_cquad_t *) param;
    gsl_integration_cquad_workspace_free(q->w);
    matrixalloc_1d_free(q);
}

///*
// * @since 
// */
//static void set_pts(void *param, bool is_sig, int npts, double *pts) {
//    integrator_cquad_t *q = (integrator_cquad_t *) param;
//    if (is_sig == false) {
//        if (npts != 2)
//            ERROR_MSG_LMA("Failed\n");
//        memcpy(q->pts, pts, 2 * sizeof (double));
//    } else if (npts == -2) {
//        memcpy(q->pts, pts, 2 * sizeof (double));
//    } else if (npts >= 2) {
//        q->pts[0] = pts[0];
//        q->pts[1] = pts[npts - 1];
//    } else
//        ERROR_MSG_LMA("Failed\n");
//}

/*
 * @since 2017.4.6, 9.5
 */
static int integrate(double *result, gsl_function *func, void *param) {
    integrator_cquad_t *q = (integrator_cquad_t *) param;
    return gsl_integration_cquad(func, q->pts[0], q->pts[1], q->epsabs, q->epsrel, q->w, result, &(q->abserr), &(q->nevals));
}

/*
 * @since 2017.9.5
 */
static double abserr(void *param) {
    integrator_cquad_t *q = (integrator_cquad_t *) param;
    return q->abserr;
}

/*
 * @since 2017.9.5
 */
static integrator_t clone(void *param) {
    integrator_cquad_t *q = (integrator_cquad_t *) param;
    integrator_cquad_t *re = matrixalloc_1d(1, sizeof (*re));
    *re = *q;
    re->w = NULL;
    re->w = gsl_integration_cquad_workspace_alloc(re->size);
    if (re->w == NULL)
        ERROR_MSG_LMA("Failed to create workspace\n");
    
    integrator_t ig = matrixalloc_1d(1, sizeof (*ig));
    ig->param = re;
    ig->free_param = free_param;
//    ig->set_pts = set_pts;
    ig->integrate = integrate;
    ig->abserr = abserr;
    ig->clone = clone;
    
    return ig;
}

/*
 * @since 2017.2.10, 4.6, 9.5
 */
integrator_t integrator_new_cquad(int size, double epsabs, double epsrel, char **msg) {
    msg[0] = NULL;
    if (size <= 0) { 
        PRINT_ERRMSG(msg, "size <= 0\n");
        return NULL;
    }
    if (epsabs < 0 || epsrel < 0) {
        PRINT_ERRMSG(msg, "epsabs < 0 || epsrel < 0\n");
        return NULL;
    }
    if (epsabs == 0 && epsrel == 0) {
        PRINT_ERRMSG(msg, "epsabs == 0 && epsrel == 0\n");
        return NULL;
    }
    
    integrator_cquad_t *q = matrixalloc_1d(1, sizeof (*q));
    q->size = (size_t) size;
    q->epsabs = epsabs;
    q->epsrel = epsrel;
    q->w = NULL;
    q->w = gsl_integration_cquad_workspace_alloc((size_t) size);
    if (q->w == NULL)
        ERROR_MSG_LMA("Failed to create workspace\n");
    q->pts[0] = 0;
    q->pts[1] = 1;
    
    integrator_t ig = matrixalloc_1d(1, sizeof (*ig));
    ig->param = q;
    ig->clone = clone;
    ig->free_param = free_param;
//    ig->set_pts = set_pts;
    ig->integrate = integrate;
    ig->abserr = abserr;
    return ig;
}