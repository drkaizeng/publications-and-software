/* 
 * Created on 18 September 2016, 21:04
 */
#include <math.h>

#include "scale_param.h"

#include "util/error_msg.h"

#define ERR_SCALE 100

/*
 * @since 2016.9.18, 9.27, 9.28
 */
double scale_param_check_do(double v, param_t p) {
    if (p == ERR) {
        if (v < 0 || v > 1)
            ERROR_MSG_LMA("v < 0 || v > 1 for ERR\n");
    } else if (p == R) {
        if (v < 0)
            ERROR_MSG_LMA("v < 0 for R\n");
    } else if (v <= 0)
        ERROR_MSG_LMA("v <= 0 for a parameter to be put on ln-scale\n");
    
    return scale_param_do(v, p);
}

/*
 * @since 2016.9.18, 9.27, 9.28
 */
double scale_param_do(double e, param_t p) {
    if (p == ERR || p == R)
        return log(e * ERR_SCALE + 1);
    else
        return log(e);
}

/*
 * @since 2016.9.18, 9.27, 9.28
 */
double scale_param_undo(double sce, param_t p) {
    if (p == ERR || p == R)
        return (exp(sce) - 1) / ERR_SCALE;
    else
        return exp(sce);
}

/*
 * @since 2016.9.27, 9.28
 */
double scale_param_jaco(double v, param_t p) {
    if (p == ERR || p == R)
        return exp(v) / ERR_SCALE;
    else
        return exp(v);
}