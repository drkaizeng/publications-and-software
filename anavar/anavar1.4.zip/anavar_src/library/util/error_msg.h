/* 
 * File:   error_msg.h
 * Author: Kai
 *
 * Created on 23 November 2015, 16:02
 */

#ifndef ERROR_MSG_H
#define	ERROR_MSG_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

/**
 * M: print message to stderr <br>
 * E: exit the program with code EXIT_FAILURE
 */
#define ERROR_MSG_ME(...) \
        do { \
            fprintf(stderr, __VA_ARGS__); \
            exit(EXIT_FAILURE); \
        } while(false)

/**
 * L: location of error (file and line) <br>
 * M: print message to stderr <br>
 * A: abort the program <br>
 * MSG: error message in the form of a strong constant
 */
#define ERROR_MSG_LMA(...) \
        do { \
            fprintf(stderr, "Error in %s %i\n", __FILE__, __LINE__); \
            fprintf(stderr, __VA_ARGS__); \
            abort(); \
        } while (0)  


#endif	/* ERROR_MSG_H */

