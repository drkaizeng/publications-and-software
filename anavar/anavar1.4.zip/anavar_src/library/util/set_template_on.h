/* 
 * Created on 14 September 2016, 13:50
 */

#ifdef SET_INT
#define DATA_TYPE int
#define ABBR i
#endif

#ifdef SET_DOUBLE
#define DATA_TYPE double
#define ABBR d
#endif


/* Generic part */
#define CONCAT2x(a,b) a ## _ ## b
#define CONCAT2(a,b) CONCAT2x(a,b)
#define CONCAT3x(a,b,c) a ## _ ## b ## _ ## c
#define CONCAT3(a,b,c) CONCAT3x(a,b,c)

#define SET_TYPE CONCAT3(set, ABBR, t)
#define SET_NEW CONCAT3(set, ABBR, new)
#define SET_FREE CONCAT3(set, ABBR, free)
#define SET_CONTAINS CONCAT3(set, ABBR, contain)
#define SET_ADD CONCAT3(set, ABBR, add)
#define SET_REMOVE CONCAT3(set, ABBR, remove)
#define SET_SIZE CONCAT3(set, ABBR, size)
#define SET_GET CONCAT3(set, ABBR, get)
#define BIN_SEARCH CONCAT2(arrayutil_binary_search, ABBR)


