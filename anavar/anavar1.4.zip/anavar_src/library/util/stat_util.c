#include <math.h>

#include "stat_util.h"

/*
 * @since 2015.4.1
 */
double stat_util_mean_d_d(const double *a, int n) {
    double re = 0;
    for (int i = 0; i < n; i++) {
        re += a[i] / n;
    }
    return re;
}

/*
 * @since 2015.2.8, 2.17, 4.1
 */
double stat_util_var_d_d(const double *a, int n, double mean) {
    double result = 0.0;
    for (int i = 0; i < n; i++)
        result += pow(a[i] - mean, 2) / (n - 1.0);
    return result;
}

