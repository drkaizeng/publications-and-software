/* 
 * File:   matrixalloc_template_on.h
 * Author: Kai
 *
 * Created on 29 July 2013, 19:51
 */

/* Type-dependent part */
#ifdef MATRIXALLOC_2D_DOUBLE
#    define MATRIXALLOC_TYPE double
#    define MATRIXALLOC_TYPE_ABBR d
#endif

#ifdef MATRIXALLOC_2D_LONG_DOUBLE
#    define MATRIXALLOC_TYPE long double
#    define MATRIXALLOC_TYPE_ABBR ld
#endif

#ifdef MATRIXALLOC_2D_INT
#    define MATRIXALLOC_TYPE int
#    define MATRIXALLOC_TYPE_ABBR i
#endif

#ifdef MATRIXALLOC_2D_BOOL
#    define MATRIXALLOC_TYPE bool
#    define MATRIXALLOC_TYPE_ABBR b
#endif

#ifdef MATRIXALLOC_2D_CHAR
#    define MATRIXALLOC_TYPE char
#    define MATRIXALLOC_TYPE_ABBR c
#endif


/* Generic part */
#define MATRIXALLOC_CONCAT2x(a,b) a ## _ ## b
#define MATRIXALLOC_CONCAT2(a,b) MATRIXALLOC_CONCAT2x(a,b)
#define MATRIXALLOC_CONCAT3x(a,b,c) a ## _ ## b ## _ ## c
#define MATRIXALLOC_CONCAT3(a,b,c) MATRIXALLOC_CONCAT3x(a,b,c)

#define MATRIXALLOC_2D MATRIXALLOC_CONCAT2(matrixalloc_2d, MATRIXALLOC_TYPE_ABBR)
#define MATRIXALLOC_2D_INIT MATRIXALLOC_CONCAT3(matrixalloc_2d, MATRIXALLOC_TYPE_ABBR, init)
#define MATRIXALLOC_2D_CLONE MATRIXALLOC_CONCAT3(matrixalloc_2d, MATRIXALLOC_TYPE_ABBR, clone)
#define MATRIXALLOC_2D_CPY MATRIXALLOC_CONCAT3(matrixalloc_2d, MATRIXALLOC_TYPE_ABBR, cpy)
#define MATRIXALLOC_2D_FREE MATRIXALLOC_CONCAT3(matrixalloc_2d, MATRIXALLOC_TYPE_ABBR, free)


