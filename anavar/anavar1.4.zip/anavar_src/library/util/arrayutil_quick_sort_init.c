#include <stdlib.h>
#include <stdbool.h>

#include "arrayutil.h"

static bool set_seed = false;

void arrayutil_quick_sort_set_seed(unsigned int seed) {
    srand(seed);
    set_seed = true;
}

#define DATA_TYPE_INT
#include "arrayutil_quick_sort_template_on.h"
#include "arrayutil_quick_sort.c"
#include "arrayutil_quick_sort_template_off.h"
#undef DATA_TYPE_INT

#define DATA_TYPE_DOUBLE
#include "arrayutil_quick_sort_template_on.h"
#include "arrayutil_quick_sort.c"
#include "arrayutil_quick_sort_template_off.h"
#undef DATA_TYPE_DOUBLE

