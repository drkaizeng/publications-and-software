#include <stdlib.h>
#include <assert.h>
#include <stdint.h>
#include <stdio.h>

#include "my_stack.h"

#include "matrixalloc.h"


struct my_stack_tag {
    /**
     * The maximum legal index of dataArray; max_i + 1 is the maximum number of 
     * elements that can currently be held without resizing
     */
    int max_i;
    /**
     * The additional capacity put be put in when the existing stack overflows
     */
    int inc_size;
    /**
     * Size of data array in memory = (max_i+1) * sizeof(void *)
     */
    size_t mem_size;
    /**
     * This is equal to inc_size * sizeof(void *);
     */
    size_t inc_mem_size;
    /**
     * The remaining amount of memory that can be added to the current data array
     */
    size_t mem_limit;
    /**
     * The index of the last element; the current number of elements is current_size_m1+1
     */
    int current_size_m1;
    void **data;
};

/*
 * @since 2015.01.21
 */
my_stack_t * my_stack_new(const int init_size, const int inc_size) {
    if (init_size <= 0) {
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();   
    }
    if (inc_size < 0) {
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();   
    }
    assert((size_t) init_size < SIZE_MAX / sizeof(void *));
    assert((size_t) inc_size < SIZE_MAX / sizeof(void *));
        
    
    my_stack_t *re = matrixalloc_1d(1, sizeof (my_stack_t));
    re->max_i = init_size - 1;
    re->inc_size = inc_size;
    re->mem_size = (size_t) init_size * sizeof(void *);
    re->inc_mem_size = (size_t) inc_size * sizeof(void *);
    re->mem_limit = SIZE_MAX - re->mem_size;
    re->current_size_m1 = -1;
    re->data = matrixalloc_1d(1, re->mem_size);
    return re;
}

/*
 * @since 2015.01.21, 01.30
 */
void my_stack_free(my_stack_t * stack) {
    if (stack->current_size_m1 >= 0) {
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort(); 
    }
    matrixalloc_1d_free(stack->data);
    matrixalloc_1d_free(stack);
}

/*
 * @since 2015.01.21
 */
int my_stack_size(my_stack_t * stack) {
    return stack->current_size_m1 + 1;
}

/*
 * @since 2015.01.21, 01.30
 */
void my_stack_push(my_stack_t * stack, void * item) {
    if (item == NULL) {
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();
    }
    if (stack->current_size_m1 >= stack->max_i) {
        size_t addition;
        if (stack->inc_size > 0) {
            addition = stack->inc_mem_size;
            stack->max_i = stack->max_i + stack->inc_size;
        } else {
            addition = stack->mem_size;
            stack->max_i += stack->max_i + 1;
        }
        if (addition >= stack->mem_limit) {
            fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
            abort();
        }
        stack->mem_size += addition;
        stack->mem_limit -= addition;
        stack->data = realloc(stack->data, stack->mem_size);
        if (stack->data == NULL) {
            fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
            abort();
        }
    }
    stack->current_size_m1++;
    stack->data[stack->current_size_m1] = item;
}

/*
 * @since 2015.01.21, 01.30
 */
void * my_stack_pop(my_stack_t * stack) {
    if (stack->current_size_m1 < 0)
        return NULL;
    else {
        void *re = stack->data[stack->current_size_m1];
        stack->data[stack->current_size_m1] = NULL;//2013.04.08
        stack->current_size_m1--;
        return re;
    }
}

/*
 * @since 2015.01.21
 */
void my_stack_clear(my_stack_t * stack) {
    for (int i = 0; i <= stack->current_size_m1; i++)
        stack->data[i] = NULL;
    stack->current_size_m1 = -1;
}

/*
 * @since 2015.01.21, 01.30
 */
void my_stack_clear_free(my_stack_t * stack, void (*f)(void *)) {
    void *d;
    while (stack->current_size_m1 >= 0) {
        d = my_stack_pop(stack);
        f(d);
    }
}

/*
 * @since
 */
void my_stack_print_to_screen(my_stack_t * stack, void (*f)(void *)) {
    int last_i = stack->current_size_m1;
    void **data = stack->data;
    for (int i = 0; i <= last_i; i++) {
        printf("\n#%i\n", i);
        (*f)(data[i]);
        printf("\n");
    }
}