/* 
 * File:   matrixalloc.h
 * Author: Kai
 *
 * Created on 28 February 2013, 17:11
 */

#ifndef MATRIXALLOC_H
#define	MATRIXALLOC_H

#include <stdbool.h>
#include <stddef.h>

/**
 * Use to construct arrays of given length.
 * @param n The number of elements
 * @param styp The size of each element
 */
void * matrixalloc_1d(const int n, const size_t styp);

/**
 * Use to construct arrays of given length with all elements initialised to zero.
 * @param n
 * @param styp
 */
void * matrixalloc_1d_init(const int n, const size_t styp);

/**
 * Make a clone of the src array
 * @param src The source array, which was created by matrixalloc_1d or matrixalloc_1d_init.
 * @param n The number of elements
 * @param styp The size of each element
 */
void * matrixalloc_1d_clone(const void *src, const int n, const size_t styp);

/**
 * @param a Pointer to an array built by matrixalloc_1d, matrixalloc_1d_init, or matrixalloc_1d_clone.
 * @param n New size of the array
 * @param styp
 */
void * matrixalloc_1d_realloc(void *a, int n, size_t styp);
/**
 * Copy the contents of src to des. 
 * @param des The target array, which was created by matrixalloc_1d or matrixalloc_1d_init.
 * @param src The source array, which was created by matrixalloc_1d or matrixalloc_1d_init.
 * @param n The number of elements
 * @param styp The size of each element
 */
void   matrixalloc_1d_cpy1(void *des, const void *src, const int n, const size_t styp);
void   matrixalloc_1d_cpy2(void *des, const void *src, const size_t total_size);
void   matrixalloc_1d_free(void *);

/**
 * ptr has to be declared before calling this macro.
 */
#define M1D_NEW(ptr, n) \
        do { \
            (ptr) = matrixalloc_1d((n), sizeof(*(ptr))); \
        } while(0)

/**
 * ptr has to be declared before calling this macro.
 */
#define M1D_INIT(ptr, n) \
        do { \
            (ptr) = matrixalloc_1d_init((n), sizeof(*(ptr))); \
        } while(0)

/**
 * result has to be declared before calling this macro. 
 * <p>
 * src should be created to either M1D_NEW or M1D_INIT
 */
#define M1D_CLONE(result, src, n) \
        do { \
            (result) = matrixalloc_1d_clone((src), (n), sizeof(*(src))); \
        } while(0)

/**
 * Free the memory and set ptr to NULL.
 */
#define M1D_FREE(ptr) \
        do { \
            matrixalloc_1d_free(ptr); \
            (ptr) = NULL; \
        } while(0)

/**
 * The name of res has to end in _2D. This should be declared as a 1D array of the desired type before using this macro.
 * <p>
 * No checks are carried out re nrow and ncol.
 */
#define M2D_NEW(res, nrow, ncol) \
        do { \
            (res) = matrixalloc_1d((nrow) * (ncol), sizeof(*(res))); \
        } while(0)
            
/**
 * The name of res has to end in _2D. This should be declared as a 1D array of the desired type before using this macro.
 * <p>
 * src has to be created by MATRIXALLOC_N2D.
 */
#define M2D_CLONE(res, src, nrow, ncol) \
        do { \
            (res) = matrixalloc_1d_clone((src), (nrow) * (ncol), sizeof(*(src))); \
        } while(0) 

/**
 * m must be created by M2D_NEW or M2D_CLONE
 * m[i, j]
 */
#define M2D(m, i, j, ncol) (m)[(i) * (ncol) + (j)]

/**
 * Free the memory and set m to NULL.
 */
#define M2D_FREE(m)  \
        do { \
            matrixalloc_1d_free(m); \
            (m) = NULL; \
        } while(0)    
        

/**
 * Use malloc to construct a 2D matrix for double-precision numbers.
 * @param nrow number of rows
 * @param ncol number of columns
 */
double ** matrixalloc_2d_d(const int nrow, const int ncol);
double ** matrixalloc_2d_d_init(const int nrow, const int ncol);
/**
 * @param src This must be created by matrixalloc_2d_d or matrixalloc_2d_d_init; otherwise the result is undefined.
 */
double ** matrixalloc_2d_d_clone(double **src, const int nrow, const int ncol);
void      matrixalloc_2d_d_cpy(double **des, double **src, const int nrow, const int ncol);
void      matrixalloc_2d_d_free(double **);

long double ** matrixalloc_2d_ld(const int nrow, const int ncol);
long double ** matrixalloc_2d_ld_init(const int nrow, const int ncol);
long double ** matrixalloc_2d_ld_clone(long double **src, const int nrow, const int ncol);
void     matrixalloc_2d_ld_cpy(long double **des, long double **src, const int nrow, const int ncol);
void     matrixalloc_2d_ld_free(long double **);

int ** matrixalloc_2d_i(const int nrow, const int ncol);
int ** matrixalloc_2d_i_init(const int nrow, const int ncol);
int ** matrixalloc_2d_i_clone(int **src, const int nrow, const int ncol);
void   matrixalloc_2d_i_cpy(int **des, int **src, const int nrow, const int ncol);
void   matrixalloc_2d_i_free(int **);

bool ** matrixalloc_2d_b(const int nrow, const int ncol);
bool ** matrixalloc_2d_b_init(const int nrow, const int ncol);
bool ** matrixalloc_2d_b_clone(bool **src, const int nrow, const int ncol);
void    matrixalloc_2d_b_cpy(bool **des, bool **src, const int nrow, const int ncol);
void    matrixalloc_2d_b_free(bool **);

char ** matrixalloc_2d_c(const int nrow, const int ncol);
char ** matrixalloc_2d_c_init(const int nrow, const int ncol);
char ** matrixalloc_2d_c_clone(char **src, const int nrow, const int ncol);
void    matrixalloc_2d_c_cpy(char **des, char **src, const int nrow, const int ncol);
void    matrixalloc_2d_c_free(char **);

#endif	/* MATRIXALLOC_H */

