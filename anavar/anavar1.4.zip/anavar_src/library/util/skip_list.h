/* 
 * File:   skip_list.h
 * Author: kai
 *
 * Created on 16 January 2015, 23:21
 */

#ifndef SKIP_LIST_H
#define	SKIP_LIST_H


typedef struct skip_list_node_TAG {
    /**
     * The data should have a natural order so that the list can be sorted into
     * an ascending order
     */
    void *data;
    /**
     * Forward pointers
     */
    struct skip_list_node_TAG **forward;
} skip_list_node_T;

typedef struct skip_list_TAG skip_list_T;

/**
 * 
 * @param max_level The maximum number of levels permitted. A list with N levels is
 *                  appropriate for containing up to 2^N elements.
 * @param compare A function that compare the data contained in the nodes. It
 *                should return the following values:
 *                <ul>
 *                <li> If d1 &gt; d2, then compare &gt; 0
 *                <li> If d1 = d2, then compare = 0
 *                <li> If d1 &lt; d2, then compare &lt; 0
 *                </ul>
 * @param ran A random number generator that returns a random number in [0, 1)
 */
skip_list_T * skip_list_new(int max_level, int (* compare)(void *d1, void *d2), double (* ran)(void *));



#endif	/* SKIP_LIST_H */

