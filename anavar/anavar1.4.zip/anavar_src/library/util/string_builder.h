/* 
 * File:   string_builder.h
 * Author: Kai
 *
 * Created on 01 July 2015, 11:29
 */

#ifndef STRING_BUILDER_H
#define	STRING_BUILDER_H

typedef struct string_builder_tag string_builder_t;

/**
 * @param capacity Initial capacity; if <= 0, then a default value is used.
 */
string_builder_t * string_builder_new(int capacity);
void string_builder_free(string_builder_t *s);

/**
 * @param s Reset the current string_builder to an empty one.
 */
void string_builder_clear(string_builder_t *s);

/**
 * @param s Append data to the end of s.
 * @param data This must be a NULL determined string.
 */
void string_builder_append(string_builder_t *s, const char *data);

/**
 * @return The string represented by s. If nothing is stored in s, then return an empty 
 * string (i.e., with only the NULL character). 
 * <p>
 * <b>Important:</b> The returned object is independent of the internal representation of s,
 * and must be freed by matrixalloc_1d_free.
 */
const char * string_builder_get(const string_builder_t *s);

/**
 * Print the contents of s to file.
 */
void string_builder_print(const string_builder_t *s, FILE *file);

#endif	/* STRING_BUILDER_H */

