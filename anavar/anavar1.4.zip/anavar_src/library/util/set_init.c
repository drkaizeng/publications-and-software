/* 
 * Created on 14 September 2016, 14:00
 */

#include "set.h"

#define SET_INT
#include "set_template_on.h"
#include "set_template.c"
#include "set_template_off.h"
#undef SET_INT

#define SET_DOUBLE
#include "set_template_on.h"
#include "set_template.c"
#include "set_template_off.h"
#undef SET_DOUBLE