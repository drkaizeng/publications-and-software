/* 
 * File:   arrayutil_quick_sort_template_on.h
 * Author: Kai
 *
 * Created on 06 February 2015, 18:16
 */

#ifdef DATA_TYPE_INT
#    define DATA_TYPE int
#    define ABBR i
#endif

#ifdef DATA_TYPE_DOUBLE
#    define DATA_TYPE double
#    define ABBR d
#endif

#define CONCAT2x(a,b) a ## _ ## b
#define CONCAT2(a,b) CONCAT2x(a,b)

#define PARTITION CONCAT2(partition, ABBR)
#define QUICK_SORT_WORK CONCAT2(arrayutil_quick_sort_work, ABBR)
#define QUICK_SORT CONCAT2(arrayutil_quick_sort, ABBR)

