/* 
 * File:   arrayutil_binary_search_template_on.h
 * Author: kai
 *
 * Created on 18 January 2015, 19:59
 */

#ifdef DATA_TYPE_INT
#    define DATA_TYPE int
#    define ABBR i
#endif

#ifdef DATA_TYPE_DOUBLE
#    define DATA_TYPE double
#    define ABBR d
#endif

#define CONCAT2x(a,b) a ## _ ## b
#define CONCAT2(a,b) CONCAT2x(a,b)

#define FUNCTION_NAME CONCAT2(arrayutil_binary_search, ABBR)