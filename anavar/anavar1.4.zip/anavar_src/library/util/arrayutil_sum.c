/**
 * @since 2013.02.22 (added fromIndex and toIndex), 2015.01.19
 */
RETURN_TYPE FUNCTION_NAME(const DATA_TYPE *a, int fromIndex, int toIndex) {
    RETURN_TYPE re = 0;
    for (int i = fromIndex; i < toIndex; i++)
        re += a[i];
    return re;
}

