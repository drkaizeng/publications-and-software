#include <math.h>
#include <string.h>

#include "matrixalloc.h"
#include "error_msg.h"
#include "arrayutil.h"

typedef struct {
    int max_size;
    int size;//current size
    DATA_TYPE *data;
} SET_TYPE;

/*
 * @since 2016.9.14, 9.18
 */
void * SET_NEW(int size) {
    if (size <= 0)
        ERROR_MSG_ME("Set: initial size <= 0\n");
    
    SET_TYPE *s = matrixalloc_1d(1, sizeof (SET_TYPE));
    s->max_size = size;
    s->size = 0;
    s->data = matrixalloc_1d(size, sizeof (DATA_TYPE));
    return s;
}

/*
 * @since 2016.9.14
 */
void SET_FREE(void *set) {
    SET_TYPE *s = (SET_TYPE *)set;
    matrixalloc_1d_free(s->data);
    matrixalloc_1d_free(s);
}

/*
 * @since 2016.9.14
 */
bool SET_CONTAINS(void *set, DATA_TYPE v) {
    SET_TYPE *s = (SET_TYPE *) set;
    int indx = BIN_SEARCH(s->data, 0, s->size, v);
    return (indx >= 0 ? true : false);
}

/*
 * @since 2016.9.14, 9.18
 */
bool SET_ADD(void *set, DATA_TYPE v) {
    SET_TYPE *s = (SET_TYPE *) set;
    int indx = BIN_SEARCH(s->data, 0, s->size, v);
    if (indx < 0) {
        if (s->size >= s->max_size) {
            int new_size = s->size + (int) fmax(1, s->size / 2);
            if (new_size <= s->size)
                ERROR_MSG_LMA("new_size <= s->size\n");
            s->data = matrixalloc_1d_realloc(s->data, new_size, sizeof (DATA_TYPE));
            s->max_size = new_size;
        }
        indx = -indx - 1;
        for (int i = s->size - 1; i >= indx; i--) 
            s->data[i + 1] = s->data[i];
        s->data[indx] = v;
        s->size++;
        return true;
    } else
        return false;
}

/*
 * @since 2016.9.14
 */
bool SET_REMOVE(void *set, DATA_TYPE v) {
    SET_TYPE *s = (SET_TYPE *) set;
    int indx = BIN_SEARCH(s->data, 0, s->size, v);
    if (indx < 0)
        return false;
    else {
        for (int i = indx + 1; i < s->size; i++) 
            s->data[i - 1] = s->data[i];
        s->size--;
        return true;
    }
}

/*
 * @since 2016.9.14, 9.18
 */
int SET_SIZE(void *set) {
    SET_TYPE *s = (SET_TYPE *) set;
    return s->size;
}

/*
 * @since 2016.9.14, 9.18
 */
void SET_GET(DATA_TYPE *x, void *set) {
    SET_TYPE *s = (SET_TYPE *) set;
    size_t mem = (size_t) s->size * sizeof (DATA_TYPE);
    memcpy(x, s->data, mem);
}