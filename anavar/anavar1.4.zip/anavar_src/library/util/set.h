/* 
 * Created on 14 September 2016, 11:39
 */

#ifndef SET_H
#define SET_H

#include <stdbool.h>

/**
 * Basic sets backed by an ordered array and binary search.
 */

void * set_i_new(int size);
void set_i_free(void *s);
/**
 * @return true, if the value is in the set; false, otherwise.
 */
bool set_i_contain(void *s, int v);
/**
 * @return true, if the value was not in the set and has now been added; false, otherwise.
 */
bool set_i_add(void *s, int v);
/**
 * @return true, if the value is in the set and has now been removed; false, otherwise.
 */
bool set_i_remove(void *s, int v);
/**
 * @return The number of elements in the set
 */
int set_i_size(void *s);
/**
 * @param data An array of size at least as big as that returned by set_i_size. 
 *             The elements are stored from the 0-th element.
 */
void set_i_get(int *data, void *s);


void * set_d_new(int size);
void set_d_free(void *s);
bool set_d_contain(void *s, double v);
bool set_d_add(void *s, double v);
bool set_d_remove(void *s, double v);
int set_d_size(void *s);
void set_d_get(double *data, void *s);

#endif /* SET_H */

