/* 
 * File:   nr_dfridr.h
 * Author: kzeng
 *
 * Created on 04 April 2014, 19:50
 */

#ifndef NR_DFRIDR_H
#define	NR_DFRIDR_H

struct nr_dfridr_tag;
typedef struct nr_dfridr_tag nr_dfridr_t;

/**
 * @param ntab  The number of evaluations of the function is typically 6 to 12, but is allowed to be as great as 2*ntab
 */
nr_dfridr_t *nr_dfridr_new(int ntab);
void nr_dfridr_free(nr_dfridr_t *ptr);

/**
 * The function is evaluated at x-h and x+h, but not at x. Accuracy: o(h^2)
 * @param func a 1-D function
 * @param x 
 * @param h an estimated initial stepsize; it need not be small, but rather should be an increment in x over which func change substantially.
 * @param err
 * @return The derivative of func at x.
 */
double nr_dfridr_central(double (*func)(double, void *), double x, void *data, double h, double *err, nr_dfridr_t *ptr);

/**
 * The function is evaluated at x+h/2 and x+h, but not at x. Accuracy: o(h)
 */
double nr_dfridr_forward(double (*func)(double, void *), double x, void *data, double h, double *err, nr_dfridr_t *ptr);

/**
 * The function is evaluated at x-h and x-h/2, but not at x. Accuracy: o(h)
 */
double nr_dfridr_backward(double (*func)(double, void *), double x, void *data, double h, double *err, nr_dfridr_t *ptr);

/**
 * Return an integer value indicating the internal state of the most recent evocation.
 * 0: exit before ntab iterations are done
 * 1: the above is not true, which may suggest convergence problem
 */
int nr_dfridr_state(nr_dfridr_t *ptr);

#endif	/* NR_DFRIDR_H */

