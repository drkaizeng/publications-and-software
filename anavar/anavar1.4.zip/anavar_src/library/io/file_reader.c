#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <limits.h>
#include <stdint.h>

#include "file_reader.h"

#include "../util/matrixalloc.h"

struct file_reader_tag {
    FILE *stream;
    size_t max_width;
    int max_width_p1;
    size_t array_mem_size;
    char *buffer;
};

/*
 * @since 2015.2.6, 2.17, 11.8, 11.12
 */
file_reader_t * file_reader_new(const char *file_path, int max_width, file_reader_state_t *state) {
    if (max_width <= 0 || max_width >= INT_MAX) {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
    if (INT_MAX >= SIZE_MAX && (size_t) max_width >= SIZE_MAX) {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
    file_reader_t *re = matrixalloc_1d(1, sizeof (file_reader_t));
    re->max_width = (size_t) max_width;
    re->max_width_p1 = max_width + 1;
    re->array_mem_size = (size_t) re->max_width_p1 * sizeof (char);
    re->buffer = NULL;
    re->stream = fopen(file_path, "r");
    if (re->stream == NULL) {
        (*state) = file_reader_state_error;
        return NULL;
    } else {
        (*state) = file_reader_state_success;
        return re;
    }
}

/*
 * @since 2015.2.6, 2.17, 11.8 (added state and f)
 */
void file_reader_free(file_reader_t *reader, file_reader_state_t *state, FILE **f) {
    matrixalloc_1d_free(reader->buffer);
    int ind = fclose(reader->stream);
    if (ind == 0) {
        (*state) = file_reader_state_success;
    } else {
        if (f != NULL) {
            f[0] = reader->stream;
        }
        (*state) = file_reader_state_error;
    }
    matrixalloc_1d_free(reader);
}

/**
 * @param max_width the maximum number of characters (including the new-line) <b>before</b> the NULL character.
 * @return true if strlen &lt; max_width.
 * @since 2015.2.6, 2.17, 11.8, 11.12
 */
static bool check_line_width(size_t max_width, const char *s) {
    size_t length = strlen(s);
    if (length == 0) {//at least the new-line character is present
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    } else if (length < max_width) {
        return true;
    } else {
        return false;
    }
}

/*
 * @since 2015.2.17, 11.8
 */
char * file_reader_read_line(file_reader_t *reader, file_reader_state_t *state) {
    char *s = matrixalloc_1d(reader->max_width_p1, sizeof (char));
    char *re = fgets(s, reader->max_width_p1, reader->stream);
    if (re == NULL) {
        matrixalloc_1d_free(s);
        if (feof(reader->stream) != 0) {
            (*state) = file_reader_state_eof;
            return NULL;
        } else {
            (*state) = file_reader_state_error;
            return NULL;
        }
    } else {
        bool flag = check_line_width(reader->max_width, re);
        if (flag == true) {
            (*state) = file_reader_state_success;
            return re;
        } else {
            matrixalloc_1d_free(s);
            (*state) = file_reader_state_overflow;
            return NULL;
        } 
    }
}

/*
 * @since 2015.11.8, 11.12, 11.16, 2016.9.4 (added ftell-fseek)
 */
void file_reader_read_line_buffer(int buffer_size, char buffer[buffer_size], file_reader_t *reader, file_reader_state_t *state) {
    if (buffer_size < 1) {
        (*state) = file_reader_state_overflow;
        return;
    }
    long int fpos = ftell(reader->stream);
    if (fpos == -1L) {
        (*state) = file_reader_state_error;
        return;
    }
    char *re = fgets(buffer, buffer_size, reader->stream);
    if (re == NULL) {
        if (feof(reader->stream) != 0) {
            (*state) = file_reader_state_eof;
            return;
        } else {
            (*state) = file_reader_state_error;
            return;
        }
    } else {
        bool flag = check_line_width((size_t) (buffer_size - 1), re);
        if (flag == true) {
            (*state) = file_reader_state_success;
            return;
        } else {
            (*state) = file_reader_state_overflow;
            fseek(reader->stream, fpos, SEEK_SET);
            return;
        } 
    }
}