/* 
 * File:   read_string.h
 * Author: Kai
 *
 * Created on 02 February 2015, 16:25
 */

#ifndef FILE_READER_H
#define	FILE_READER_H

#include <stdio.h>

typedef struct file_reader_tag file_reader_t;

typedef enum {
    file_reader_state_init,
    /** The last invocation completed without errors */
    file_reader_state_success,
    /** EOF was encountered as defined by feof() */        
    file_reader_state_eof,
    /** Internal error, if the failure was not caused by reaching EOF */        
    file_reader_state_error,
    /** The buffer is not large enough to complete the operation */        
    file_reader_state_overflow        
} file_reader_state_t;

/**
 * The UNIX end-of-line character is a line feed/newline character (\n). 
 * The DOS/Windows end-of-line character is a carriage return, followed by a line feed/newline (\r\n).
 * @param file_path The full path to the text file that is to be opened
 * @param max_width This it is the maximum number of characters, including the new-line character, 
 *                    but excluding the terminating NULL character. The number of characters before
 *                    the NULL character extracted from a line must be <b>strictly smaller</b> than
 *                    max_width. Otherwise, file_reader_state_overflow is assigned to state.
 * @return Opens the file and returns a file_reader_t pointer. If an error was 
 *         encountered when opening the file, NULL is returned.
 */
file_reader_t * file_reader_new(const char *file_path, int max_width, file_reader_state_t *state);
/**
 * Close the file and free the memory.
 * @return If the file was closed successfully, state is set to file_reader_state_success, and f is undefined.
 *         If the file was not closed properly, state is set to file_reader_state_error. If f is not NULL, the
 *         FILE stream that fclose() failed to close is stored in the object pointed to by f. 
 *         <p>
 *         The memory occupied by reader is freed, regardless of whether fclose() succeeds or not.
 */
void file_reader_free(file_reader_t *reader, file_reader_state_t *state, FILE **f);

/**
 * The function reads at most the number of characters specified by buffer_size
 * from the file. No additional characters are read after a new-line character (which is retained) 
 * or after end-of-file. A null character is written immediately after the last character read into 
 * the array. That is the return string can have at most buffer_size + 1 characters, including
 * the new-line and terminating NULL characters.
 * @return If end-of-file is encountered and no characters have been read, or 
 *         if a read error occurs during the operation, NULL is returned.
 *         <p>
 *         The returned pointed should be freed by free or matrixalloc_1d_free.
 */
char * file_reader_read_line(file_reader_t *reader, file_reader_state_t *state);


/**
 * The function reads at most the number of characters specified by (buffer_size-2)
 * from a line in the file, including the new-line character (if any). 
 * Otherwise, file_reader_state_overflow is assigned to state, and the contents of buffer is undefined.
 * <p>
 * When the buffer overflows, the reader automatically moves the file position to that before this function
 * is called, so that in a subsequent call, the same line is read again.
 * <p>
 * No additional characters are read after a new-line character (which is retained) 
 * or after end-of-file. A null character is written immediately after the last character read into 
 * the array. That is the return string can have at most (buffer_size-1) characters, including
 * the new-line and terminating NULL characters.
 * <p>
 * If end-of-file is encountered and no characters have been read, or 
 * if a read error occurs during the operation, the contents of buffer is undefined.
 * <p>
 * The input value of state is unimportant because the state variable will be updated by the function.
 */
void file_reader_read_line_buffer(int buffer_size, char buffer[buffer_size], file_reader_t *reader, file_reader_state_t *state);

#endif	/* READ_STRING_H */

