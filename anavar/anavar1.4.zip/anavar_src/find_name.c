/* 
 * Created on 15 February 2017, 12:25
 */
#include <string.h>

#include "find_name.h"

/*
 * @since 2017.2.16, 9.19
 */
int find_name(const char *name, int n, char **list) {
    for (int i = 0; i < n; i++) {
        if (strlen(name) == strlen(list[i])) {
            if (strcmp(name, list[i]) == 0)
                return i;
        }
    }
    return -1;
}

/*
 * @since 2017.2.16
 */
int find_name2(const char *name, int n, const char *list[n]) {
    for (int i = 0; i < n; i++) {
        if (strlen(name) == strlen(list[i])) {
            if (strcmp(name, list[i]) == 0)
                return i;
        }
    }
    return -1;
}