/* 
 * Created on 21 February 2017, 12:33
 */

#ifndef CONSTRAINT_FUNC_H
#    define CONSTRAINT_FUNC_H

#include <stdbool.h>

/**
 * Constants should not be set by using this
 */
typedef struct {
    double *x;//on the original scale; set to NULL if no used
    /* the length of x in f(x) */
    int nx;
    /* 
     * of length nx. <br>
     * These are the IDs of the parameters in the full model including r. <br>
     * None of the parameters involved should be a constant.
     * Set to NULL if no used
     */
    int *xi;
    double (* f)(const double *x, void *param);
    double (* df)(const double *x, int i, void *param); // d f(x) / dx[i]. The partial derivative of the i-th parameter (i in [0, nx-1]).
    /*
     * Additional parameters for f and df 
     */
    void *param;
    /*
     * This can be NULL if param is not used or is freed by some other methods (e.g., when param points to the current constraint_func object).
     * This is not for freeing x and xi.
     */
    void (* free_param)(void *param);
} constraint_func_t;

/**
 * cf[0] will be freed. On return it will be set to NULL.
 */
void constraint_func_free(constraint_func_t **cf);


#endif /* CONSTRAINT_FUNC_H */

