/* 
 * Created on 01 February 2017, 15:07
 */

#ifndef TAU_H
#    define TAU_H

#include "integrator.h"

typedef struct tau_tag * tau_t;

/**
 * @param n Sample size
 * @param ig On return, ig[0] is set to NULL.
 * @return 
 */
tau_t tau_new(int n, integrator_t *ig);
void tau_free(tau_t *s);

/**
 * tau[i]
 */
double tau_cal(int i, double gamma, tau_t s);

/**
 * d(tau[i])/d(gamma)
 */
double tau_der(int i, double gamma, tau_t s);



#endif /* SFS2_H */

