#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "dfeio.h"
#include "print_errmsg.h"
#include "constants.h"

#include "util/error_msg.h"
#include "util/string_util.h"

/*
 * @since 2016.10.26, 10.29, 2017.4.14
 */
void dfeio_skip_lines(char buffer[BUFFER_SIZE], file_reader_t *reader, int *line_id, char **msg) {
    msg[0] = NULL;
    file_reader_state_t state;
    while (true) {
        line_id[0]++;
        file_reader_read_line_buffer(BUFFER_SIZE, buffer, reader, &state);
        if (state != file_reader_state_success) {
            PRINT_ERRMSG(msg, "Error reading the control file! Bad format, corrupted file, or "
                    "line width greater than %i.\n", BUFFER_SIZE);
            return;
        }
        char *buff = string_util_trim(buffer);
        if (strlen(buff) == 0) 
            continue;
        else if (string_util_starts_with(buff, "#"))
            continue;
        else 
            break;
    }
}

/**
 * @since 2017.2.24, 2.26, 4.12
 */
void dfeio_read_control_param(int num_param, char param[num_param][BUFFER_SIZE], 
        const char *param_name[num_param], file_reader_t *reader, int *line_id, char **msg) {
    msg[0] = NULL;
    char *buff;
    char buffer[BUFFER_SIZE];
    
    for (int i = 0; i < num_param; i++) {
        dfeio_skip_lines(buffer, reader, line_id, msg);
        if (msg[0] != NULL) {
            return;
        }
        buff = string_util_trim(buffer);
        if (string_util_starts_with(buff, param_name[i]) == false) {
            PRINT_ERRMSG(msg, "Failed to find %s at line %i in the control file.\n", param_name[i], line_id[0]);
            return;
        }
        buff += strlen(param_name[i]);
        buff = string_util_trim(buff);
        strcpy(param[i], buff);
    }
}


/*
 * @since 2017.2.24, 2.26, 4.14
 */
int dfeio_get_int(const char *valstr, const char *format, ...) {
    string_util_parse_state_t state;
    char *msg;
    int re = string_util_parse_int(valstr, &msg, 10, &state);
    if (state != string_util_parse_state_success) {
        va_list args;
        va_start(args, format);
        vfprintf(stderr, format, args);
        va_end(args);
        ERROR_MSG_LMA("\n");
    }
    return re;
}

/*
 * @since 2017.2.26, 4.14
 */
static double vget_double(const char *valstr, const char *format, va_list args) {
    string_util_parse_state_t state;
    char *msg;
    double re = string_util_parse_double(valstr, &msg, &state);
    if (state != string_util_parse_state_success) {
        vfprintf(stderr, format, args);
        ERROR_MSG_LMA("\n");
    }
    return re;
}

/*
 * @since 2017.2.26, 4.14
 */
double dfeio_get_double(const char *valstr, const char *format, ...) {
    va_list args;
    va_start(args, format);
    double re = vget_double(valstr, format, args);
    va_end(args);
    return re;
}
/**
 * Process a, b, c
 * @param len The number of elements
 * @since 2017.2.26, 4.14
 */
void dfeio_get_double_array(int len, double result[len], char *valstr, const char *format, ...) {
    va_list args;
    va_start(args, format);
    int cn;
    char **sarr = string_util_split(valstr, ",", &cn);
    if (cn != len) {
        vfprintf(stderr, format, args);
        ERROR_MSG_LMA("\n");
    }
    for (int i = 0; i < cn; i++)
        result[i] = vget_double(sarr[i], format, args);
    va_end(args);
    matrixalloc_1d_free(sarr);
}

/*
 * @since 2017.2.24, 2.26, 4.14
 */
bool dfeio_get_bool(const char *valstr, const char *format, ...) {
    string_util_parse_state_t state;
    bool re = string_util_parse_bool(valstr, &state);
    if (state != string_util_parse_state_success) {
        va_list args;
        va_start(args, format);
        vfprintf(stderr, format, args);
        va_end(args);
        ERROR_MSG_LMA("\n");
    }
    return re;
}

/*
 * @since 2017.5.8, 6.21, 9.17, 2018.3.5 (added adaptive), 2018.3.6, 3.11
 */
static void reflected_gamma_optional(double *frac, double *delta, int *degree, char **adaptive_method, bool optional, file_reader_t *reader, int *line_id, char **msg) {
    frac[0] = FRACTION;
    delta[0] = DELTA;
    degree[0] = DEGREE;
    adaptive_method[0] = NULL;
    if (optional) {
        int np = 3;
        int pid = 0;
        const char *names[np];
        names[pid++] = "fraction:";
        names[pid++] = "delta:";
        names[pid++] = "degree:";
        if (pid != np)
            ERROR_MSG_LMA("error");
        
        char par[np][BUFFER_SIZE];
        dfeio_read_control_param(np, par, names, reader, line_id, msg);
        if (msg[0] != NULL)
            return;

        pid = 0;
        
        frac[0] = dfeio_get_double(par[pid], "Failed to parse fraction at line %i.\n",
                line_id[0] - np + pid + 1);
        pid++;

        delta[0] = dfeio_get_double(par[pid], "Failed to parse delta at line %i.\n",
                line_id[0] - np + pid + 1);
        pid++;

        if (string_util_starts_with(par[pid], "adaptive")) {
            char *tmp = par[pid] + strlen("adaptive");
            adaptive_method[0] = dfeio_remove_square_brackets(tmp, msg);
            if (msg[0] != NULL) {
                PRINT_ERRMSG(msg, "Failed to parse degree at line %i.", line_id[0] - np + pid + 1);
                return;
            }
            degree[0] = -1;
        } else {
            degree[0] = dfeio_get_int(par[pid], "Failed to parse degree at line %i.\n",
                    line_id[0] - np + pid + 1);
        }
        pid++;
    }
}

/*
 * @since 2017.5.8, 5.9, 9.18, 2018.3.5 (added adaptive)
 */
static void indel_reflected_gamma(char **constraint, indeldfe_builder_t ib, file_reader_t *reader, int *line_id, char **msg) {
    const int num_param = 10;
    int param_id = 0;
    const char *param_names[num_param];
    param_names[param_id++] = "ins_theta_range:";
    param_names[param_id++] = "ins_shape_range:";
    param_names[param_id++] = "ins_scale_range:";
    param_names[param_id++] = "ins_e_range:";
    param_names[param_id++] = "del_theta_range:";
    param_names[param_id++] = "del_shape_range:";
    param_names[param_id++] = "del_scale_range:";
    param_names[param_id++] = "del_e_range:";
    param_names[param_id++] = "constraint:";
    param_names[param_id++] = "optional:";
    if (param_id != num_param)
        ERROR_MSG_LMA("error");
    
    char param[num_param][BUFFER_SIZE];
    dfeio_read_control_param(num_param, param, param_names, reader, line_id, msg);
    if (msg[0] != NULL)
        return;
    
    param_id = 0;
    
    double ranges[2][4][2];
    for (int j = 0; j < 2; j++) {
        for (int i = 0; i < 4; i++) {
            dfeio_get_double_array(2, ranges[j][i], param[param_id], "Failed to parse %s at line %i.\n",
                    param_names[param_id], line_id[0] - num_param + param_id + 1);
            param_id++;
        }
    }
    
    constraint[0] = matrixalloc_1d_clone(param[param_id], (int) strlen(param[param_id]) + 1, sizeof (char));
    param_id++;
    
    bool optional = dfeio_get_bool(param[param_id], "Failed to parse optional at line %i.\n", 
            line_id[0] - num_param + param_id + 1);
    param_id++;
    
    double frac, delta;
    int degree;
    char *adaptive;
    reflected_gamma_optional(&frac, &delta, &degree, &adaptive, optional, reader, line_id, msg);
    if (msg[0] != NULL)
        return;
    
    if (adaptive == NULL) {
        dist_t dist[2];
        for (int i = 0; i < 2; i++) {
            dist[i] = dist_gamma_gaussq(degree, true, msg);
            if (msg[0] != NULL)
                return;
        }

        indeldfe_builder_add_gamma_continuous(ib, &dist[0], 2, ranges[0], &dist[1], 2, ranges[1], frac, delta, msg);
        if (msg[0] != NULL)
            return;
    } else {
        indeldfe_builder_add_reflected_gamma_gaussq_adaptive(ib, ranges[0], ranges[1], frac, delta, adaptive, msg);
        if (msg[0] != NULL)
            return;
        M1D_FREE(adaptive);
    }
}

/*
 * @since 2017.5.8, 9.18
 */
void dfeio_indel_continuous(char **constraint, indeldfe_builder_t ib, file_reader_t *reader, int *line_id, char **msg) {
    const int num_param = 1;
    int param_id = 0;
    const char *param_names[num_param];
    param_names[param_id++] = "distribution:";
    if (param_id != num_param)
        ERROR_MSG_LMA("error");
    
    char param[num_param][BUFFER_SIZE];
    dfeio_read_control_param(num_param, param, param_names, reader, line_id, msg);
    if (msg[0] != NULL)
        return;
    
    param_id = 0;

    if (string_util_equal(param[param_id], "reflected_gamma")) {
        indel_reflected_gamma(constraint, ib, reader, line_id, msg);
    } else {
        PRINT_ERRMSG(msg, "Unknown distribution at line %i.\n", line_id[0] - num_param + param_id + 1);
        return;
    }
}

/*
 * @since 2017.5.9, 6.16, 9.19
 */
void dfeio_indel_discrete(int *c, char **constraint, indeldfe_builder_t ib, file_reader_t *reader, int *line_id, char **msg) {
    const int num_param = 8;
    int param_id = 0;
    const char *param_names[num_param];
    param_names[param_id++] = "c:";
    param_names[param_id++] = "ins_theta_range:";
    param_names[param_id++] = "ins_gamma_range:";
    param_names[param_id++] = "ins_e_range:";
    param_names[param_id++] = "del_theta_range:";
    param_names[param_id++] = "del_gamma_range:";
    param_names[param_id++] = "del_e_range:";
    param_names[param_id++] = "constraint:";
    if (param_id != num_param)
        ERROR_MSG_LMA("error");
    
    char param[num_param][BUFFER_SIZE];
    dfeio_read_control_param(num_param, param, param_names, reader, line_id, msg);
    if (msg[0] != NULL)
        return;
    
    param_id = 0;
    
    c[0] = dfeio_get_int(param[param_id], "Failed to parse c at line %i.\n", 
            line_id[0] - num_param + param_id + 1);
    param_id++;
    
    double ranges[c[0]][6][2];
    for (int i = 0; i < 6; i++) {
        double rr[2];  
        dfeio_get_double_array(2, rr, param[param_id], "Failed to parse %s at line %i.\n", 
            param_names[param_id], line_id[0] - num_param + param_id + 1);
        param_id++;
        
        for (int j = 0; j < 2; j++) 
            for (int k = 0; k < c[0]; k++) 
                ranges[k][i][j] = rr[j];
    }
    
    indeldfe_builder_add_spikes(ib, c[0], ranges, msg);
    if (msg[0] != NULL) 
        return;

    constraint[0] = matrixalloc_1d_clone(param[param_id], (int) strlen(param[param_id]) + 1, sizeof (char));
}

/*
 * @since 2017.6.19, 6.21, 9.17, 2018.3.5 (added adaptive), 3.11
 */
static void snp_reflected_gamma(char **constraint, snpdfe_builder_t sb, file_reader_t *reader, int *line_id, char **msg) {
    const int num_param = 6;
    int param_id = 0;
    const char *param_names[num_param];
    param_names[param_id++] = "theta_range:";
    param_names[param_id++] = "shape_range:";
    param_names[param_id++] = "scale_range:";
    param_names[param_id++] = "e_range:";
    param_names[param_id++] = "constraint:";
    param_names[param_id++] = "optional:";
    if (param_id != num_param)
        ERROR_MSG_LMA("error");
    
    char param[num_param][BUFFER_SIZE];
    dfeio_read_control_param(num_param, param, param_names, reader, line_id, msg);
    if (msg[0] != NULL)
        return;
    
    param_id = 0;
    
    double ranges[4][2];
    for (int i = 0; i < 4; i++) {
        double rr[2];  
        dfeio_get_double_array(2, rr, param[param_id], "Failed to parse %s at line %i.\n", 
            param_names[param_id], line_id[0] - num_param + param_id + 1);
        param_id++;
        
        memcpy(ranges[i], rr, 2 * sizeof (double));
    }
    
    constraint[0] = matrixalloc_1d_clone(param[param_id], (int) strlen(param[param_id]) + 1, sizeof (char));
    param_id++;
    
    bool optional = dfeio_get_bool(param[param_id], "Failed to parse optional at line %i.\n", 
            line_id[0] - num_param + param_id + 1);
    param_id++;
    
    double frac, delta;
    int degree;
    char *adaptive;
    reflected_gamma_optional(&frac, &delta, &degree, &adaptive, optional, reader, line_id, msg);
    if (msg[0] != NULL)
        return;

    if (adaptive == NULL) {
        dist_t dist = dist_gamma_gaussq(degree, true, msg);
        if (msg[0] != NULL)
            return;

        snpdfe_builder_add_gamma_continuous(sb, &dist, 2, ranges, frac, delta, msg);
        if (msg[0] != NULL)
            return;
    } else {
        snpdfe_builder_add_reflected_gamma_gaussq_adaptive(sb, ranges, frac, delta, adaptive, msg);
        if (msg[0] != NULL)
            return;
        M1D_FREE(adaptive);
    }
}

/*
 * @since 2017.6.19, 6.21, 9.17
 */
void dfeio_snp_continuous(char **constraint, snpdfe_builder_t sb, file_reader_t *reader, int *line_id, char **msg) {
    const int num_param = 1;
    int param_id = 0;
    const char *param_names[num_param];
    param_names[param_id++] = "distribution:";
    if (param_id != num_param)
        ERROR_MSG_LMA("error");
    
    char param[num_param][BUFFER_SIZE];
    dfeio_read_control_param(num_param, param, param_names, reader, line_id, msg);
    if (msg[0] != NULL)
        return;
    
    param_id = 0;

    if (string_util_equal(param[param_id], "reflected_gamma")) {
        snp_reflected_gamma(constraint, sb, reader, line_id, msg);
    } else {
        PRINT_ERRMSG(msg, "Unknown distribution at line %i.\n", line_id[0] - num_param + param_id + 1);
        return;
    }
}

/*
 * @since 2017.6.19, 6.20, 9.17
 */
void dfeio_snp_discrete(int *c, char **constraint, snpdfe_builder_t sb, file_reader_t *reader, int *line_id, char **msg) {
    const int num_param = 5;
    int param_id = 0;
    const char *param_names[num_param];
    param_names[param_id++] = "c:";
    param_names[param_id++] = "theta_range:";
    param_names[param_id++] = "gamma_range:";
    param_names[param_id++] = "e_range:";
    param_names[param_id++] = "constraint:";
    if (param_id != num_param)
        ERROR_MSG_LMA("error");
    
    char param[num_param][BUFFER_SIZE];
    dfeio_read_control_param(num_param, param, param_names, reader, line_id, msg);
    if (msg[0] != NULL)
        return;
    
    param_id = 0;
    
    c[0] = dfeio_get_int(param[param_id], "Failed to parse c at line %i.\n", 
            line_id[0] - num_param + param_id + 1);
    param_id++;
    
    double ranges[c[0]][3][2];
    for (int i = 0; i < 3; i++) {
        double rr[2];  
        dfeio_get_double_array(2, rr, param[param_id], "Failed to parse %s at line %i.\n", 
            param_names[param_id], line_id[0] - num_param + param_id + 1);
        param_id++;
        
        for (int j = 0; j < 2; j++) 
            for (int k = 0; k < c[0]; k++) 
                ranges[k][i][j] = rr[j];
    }
    
    snpdfe_builder_add_spikes(sb, c[0], ranges, msg);
    if (msg[0] != NULL) 
        return;

    constraint[0] = matrixalloc_1d_clone(param[param_id], (int) strlen(param[param_id]) + 1, sizeof (char));
}

/*
 * @since 2018.1.31, 2.2
 */
char * dfeio_remove_square_brackets(const char *src, char **msg) {
    msg[0] = NULL;

    if ((string_util_starts_with(src, "[") && string_util_ends_with(src, "]")) == false) {
        PRINT_ERRMSG(msg, "%s is not flanked by square brackets.", src);
        return NULL;
    }
    
    char *re;
    size_t len = strlen(src + 1);
    if (len > BUFFER_SIZE) {
        PRINT_ERRMSG(msg, "Overflow.");
        return NULL;
    }
    M1D_CLONE(re, src + 1, (int) len);
    re[len - 1] = '\0';
    return re;
}

/*
 * @since 2018.1.31, 2.2
 */
void dfeio_get_param_value(char **param, double *v, char *src, char **msg) {
    msg[0] = NULL;
    
    int cnt;
    char **sarr = string_util_split(src, "=", &cnt);
    if (cnt != 2) {
        PRINT_ERRMSG(msg, "The input %s does not conform to the format \"param_name = v\".", src);
        return;
    }
    
    param[0] = string_util_trim(sarr[0]);
    
    string_util_parse_state_t state;
    sarr[1] = string_util_trim(sarr[1]);
    char *msg2;
    double re = string_util_parse_double(sarr[1], &msg2, &state);
    if (state != string_util_parse_state_success) {
        PRINT_ERRMSG(msg, "Failed to parse the value in \"%s = %s\".", sarr[0], sarr[1]);
        return;
    }
    
    v[0] = re;
    
    M1D_FREE(sarr);
}