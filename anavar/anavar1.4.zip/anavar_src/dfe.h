/* 
 * Created on 18 February 2017, 07:16
 */

#ifndef DFE_H
#    define DFE_H

#include <stdbool.h>

#include "integrator.h"
#include "param.h"

#include "io/file_reader.h"

#include "gsl/gsl_rng.h"
#include "nlopt.h"

typedef struct dfe_tag * dfe_t;
typedef struct dfe_constr_data_tag * dfe_constr_data_t;

/**
 * Model snp_1. 
 * <p>
 * This model analyses exactly one set of SNPs (i.e., one observed SFS). 
 * The input file format: 
 * <p>
 * model_name: SNP_1 <br>
 * n: sample size <br>
 * m: number of sequenced sites <br>
 * folded: true/false <br>
 * sfs: <br>
 * dfe: discrete/continuous <br>
 * $dfe_related_parameters <br>
 * 
 * <p>
 * If a discrete dfe is used, then $dfe_related_parameters should contain <br>
 * c: (at least 1) <br>
 * theta_range: <br>
 * gamma_range: <br>
 * e_range: <br>
 * constraint: none or no_pol_error <br>
 * 
 * <p>
 * If a continuous dfe is used, then $dfe_related_parameters should contain <br>
 * distribution: reflected_gamma <br>
 * $distribution_related_parameters
 * 
 * <p>
 * If the reflected_gamma distribution is used, then $distribution_related_parameters should contain <br>
 * theta_range: <br>
 * shape_range: <br>
 * scale_range: <br>
 * e_range: <br>
 * constraint: none or no_pol_error <br>
 * optional: true/false <br>
 * $optional_params <br>
 * 
 * <p>
 * If optional is true, then $optional_params should contain <br>
 * fraction: <br>
 * delta: <br>
 * degree: <br>
 * 
 * @param ig This is the integrator to be used. On return it will points to NULL.
 * @param line_id The first line has ID 1. This variable should be initialised to 0.
 * @param msg If no error is detected, then msg[0] points to NULL, otherwise it contains an error message.
 */
dfe_t dfe_snp_1(file_reader_t *reader, int *line_id, integrator_t *ig, char **msg);

/**
 * Model indel_1.
 * 
 * See anavar manual.
 * 
 * @param ig This is the integrator to be used. On return it will points to NULL.
 * @param line_id The first line has ID 1. This variable should be initialised to 0.
 * @param msg If no error is detected, then msg[0] points to NULL, otherwise it contains an error message.
 * @return 
 */
dfe_t dfe_indel_1(file_reader_t *reader, int *line_id, integrator_t *ig, char **msg);

dfe_t dfe_neutralindel_vs_selectedindel(file_reader_t *reader, int *line_id, integrator_t *ig, char **msg);

dfe_t dfe_gbgc_extended_m1s(file_reader_t *reader, int *line_id, integrator_t *ig, char **msg);

dfe_t dfe_neutralsnp_vs_selectedsnp(file_reader_t *reader, int *line_id, integrator_t *ig, char **msg);

dfe_t dfe_neutralsnp_vs_selectedindel(file_reader_t *reader, int *line_id, integrator_t *ig, char **msg);


void dfe_free(dfe_t *d);

/**
 * Return true of the Augmented Langrange method is to be used.
 */
bool dfe_use_auglag(dfe_t d);

/**
 * This should be called only if dfe_use_auglag returns true. 
 * @param constr This should be initialised as nlopt_func *. On return it points to an array of length num[0].
 * @param is_eq_constr Similar to constr. If true, then the corresponding constraint is an equality constraint
 */
void dfe_constraint(int *num, nlopt_func **constr, bool **is_eq_constr, dfe_constr_data_t **constr_data, dfe_t d);

/**
 * The number of free parameters including r
 */
int dfe_num_free_param(dfe_t d);

/**
 * The number of all the parameters in the full model including r without any constraints within and between datasets
 */
int dfe_num_param_full(dfe_t d);

/**
 * The number of r parameters in the model.
 */
int dfe_num_r(dfe_t d);

/**
 * The names of all the parameters in the full model including r without any constraints within and between datasets
 * The returned array should be free (each element by free(names[i]) and then free(names)).
 */
char ** dfe_param_names_full(dfe_t d);

/**
 * The types of all the free parameters in the model including r
 * The returned array should be freed (free(types)).
 */
param_t * dfe_free_param_types(dfe_t d);

/**
 * The names of all the free parameters in the model including r
 * The returned array should be free (each element by free(names[i]) and then free(names)).
 */
char ** dfe_free_param_names(dfe_t d);

/**
 * Convert the array composed of free parameters to one that composed of all the parameters under the full model
 * including r without any constraints within and between datasets.
 * The scale of the free parameters are defined by onln. But the values in all_param are always in the original scale.
 */
void dfe_free_param_to_all_param(double *all_param, const double *free_param, dfe_t d);

/**
 * Convert the array composed of all the parameters under the full model including r without any constraints within and between datasets to one that composed of free the parameters after all constraints have been considered.
 * The values of the parameters in all_param that are not free are ignored.
 * The scale of the free parameters are defined by onln. But the values in all_param are always on the original scale.
 */
void dfe_all_param_to_free_param(double *free_param, const double *all_param, dfe_t d);

/**
 * Generate a random point within the simplex defined by the limits of the parameters.
 * <p>
 * The input array should have num_free_param elements. The scale of the generated values is determined by onln.
 */
void dfe_gen(double *x, gsl_rng *rng, dfe_t d);

/**
 * The returned array contains the ranges for the num_free_param free parameters. 
 * re[0][i] is the lower bound for parameter 1; and re[1][i] is the upper bound.
 * The scale is determined by onln for the corresponding parameters.
 * The returned matrix should be freed by matrixalloc_2d_d_free
 */
double ** dfe_ranges(dfe_t d);

/**
 * @param grad grad[i] is the partial derivative of the lnlike wrt the i-th free parameter on the scale determined by onln
 * @param x Contains num_free_param elements; the scale is determined by the corresponding values in onln
 */
double dfe_lnlike(double *grad, const double *x, dfe_t d);


#endif /* DFE_H */

