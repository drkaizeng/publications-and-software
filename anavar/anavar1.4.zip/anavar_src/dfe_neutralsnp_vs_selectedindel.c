/*
 * Created on 06 October 2017, 10:09
 */
#include <string.h>

#include "dfe_def.h"
#include "indeldfe.h"
#include "snpdfe.h"
#include "dfeio.h"
#include "print_errmsg.h"
#include "find_name.h"
#include "get_name.h"
#include "scale_param.h"

#include "util/error_msg.h"
#include "util/string_util.h"
#include "util/arrayutil.h"

/*
 * @since 2018.3.13
 */
static void free_double_array(void *param) {
    double *r = (double *) param;
    M1D_FREE(r);
}

/*
 * @since 2018.3.13
 */
static int get_indx(const char *name, int nx, char **param_name) {
    int re = find_name(name, nx, param_name);
    if (re < 0)
        ERROR_MSG_LMA("Error!\n");
    return re;
}

/*
 * @since 2018.3.13
 */
static double reflected_gamma_with_fixed_snp_indel_ratio_and_fixed_ins_del_ratio_d(const double *x, void *param) {
    double *r = (double *) param;
    return x[0] * r[0];
}

/*
 * @since 2018.3.13
 */
static double reflected_gamma_with_fixed_snp_indel_ratio_and_fixed_ins_del_ratio_df(const double *x, int i, void *param) {
    double *r = (double *) param;
    return r[0];
}

/*
 * Note that the del/ins ratio has already been fixed. This only fixes the snp/indel ratio
 * @ratio [0] = snp/indel; [1] = del/ins
 * @since 2018.3.13
 */
static void reflected_gamma_with_fixed_snp_indel_ratio_and_fixed_ins_del_ratio(dfe_t d, double snp_indel, double del_ins) {
    int nx = dfe_num_free_param(d);
    if (nx != (2 + 4 + 3 + dfe_num_r(d)))
        ERROR_MSG_LMA("error");
    
    char **param_name = dfe_free_param_names(d);
    
    int neu_ind = get_indx("neu_snp_theta_1", nx, param_name);
    int ins_ind = get_indx("sel_indel_ins_theta", nx, param_name);
    
    for (int i = 0; i < nx; i++) {
        if (i == neu_ind || i == ins_ind)
            continue;
        else if (strstr(param_name[i], "theta") != NULL) {
            ERROR_MSG_LMA("ERROR");
        }
    }
    
    d->is_free[neu_ind] = false;//let sel_indel_ins_theta be the only free mutation parameter
    d->xi[neu_ind] = -1;
    constraint_func_t *cf = matrixalloc_1d(1, sizeof(*cf));
    cf->nx = 1;
    cf->x = matrixalloc_1d(cf->nx, sizeof(*cf->x));
    cf->xi = matrixalloc_1d(cf->nx, sizeof(*cf->xi));
    cf->xi[0] = ins_ind;
    cf->f = reflected_gamma_with_fixed_snp_indel_ratio_and_fixed_ins_del_ratio_d;
    cf->df = reflected_gamma_with_fixed_snp_indel_ratio_and_fixed_ins_del_ratio_df;
    double *r = matrixalloc_1d(1, sizeof (double));
    r[0] = snp_indel * (1 + del_ins);
    cf->param = r;
    cf->free_param = free_double_array;
    d->cf[neu_ind] = cf;
    
    for (int i = 0; i < nx; i++) {
        matrixalloc_1d_free(param_name[i]);
    }
    matrixalloc_1d_free(param_name);
}

/*
 * @since 2018.3.13
 */
static double discrete_model_with_fixed_snp_indel_ratio_f(const double *x, void *param) {
    double *r = (double *) param;
    return r[0] * arrayutil_sum_d_d(x, 0, (int) r[1]);
}

/*
 * @since 2018.3.13
 */
static double discrete_model_with_fixed_snp_indel_ratio_df(const double *x, int i, void *param) {
    double *r = (double *) param;
    return r[0];
}

/*
 * @since 2018.3.13
 */
static void discrete_model_indel_indx(int c, double indx[c], bool ins, int nx, char **param_name) {
    const char *type = (ins == true ? "ins" : "del");
    for (int j = 0; j < c; j++) {
        char *name = get_name2("sel_indel_%s_theta_%i", type, j + 1);
        indx[j] = get_indx(name, nx, param_name);
        matrixalloc_1d_free(name);
    }
}

/*
 * @ratio snp/indel
 * @since 2018.3.11
 */
static void discrete_model_with_fixed_snp_indel_ratio(dfe_t d, int c, double ratio) {
    int nx = dfe_num_free_param(d);
    char **param_name = dfe_free_param_names(d);
    int neu_ind = get_indx("neu_snp_theta_1", nx, param_name);
    
    int indx[2 * c];
    {
        double tmp[2 * c];
        discrete_model_indel_indx(c, tmp + 0, true, nx, param_name);
        discrete_model_indel_indx(c, tmp + c, false, nx, param_name);
        for (int i = 0; i < 2 * c; i++)
            indx[i] = (int) tmp[i];
    }
    
    d->is_free[neu_ind] = false;
    d->xi[neu_ind] = -1;
    constraint_func_t *cf = matrixalloc_1d(1, sizeof(*cf));
    cf->nx = 2 * c;
    M1D_NEW(cf->x, cf->nx);
    M1D_NEW(cf->xi, cf->nx);
    memcpy(cf->xi, indx, (size_t) cf->nx * sizeof(int));
    cf->f = discrete_model_with_fixed_snp_indel_ratio_f;
    cf->df = discrete_model_with_fixed_snp_indel_ratio_df;
    double *r = matrixalloc_1d(2, sizeof(double));
    r[0] = ratio;
    r[1] = cf->nx;
    cf->param = r;
    cf->free_param = free_double_array;
    d->cf[neu_ind] = cf;
    
    for (int i = 0; i < nx; i++) {
        matrixalloc_1d_free(param_name[i]);
    }
    matrixalloc_1d_free(param_name);
}

/*
 * @since 2018.3.13
 */
static void discrete_model_indel_indx_in_free_param(double *info, int c, dfe_t d) {
    info[2] = 1;
    int nfx = dfe_num_free_param(d);
    char **free_param_name = dfe_free_param_names(d);
    discrete_model_indel_indx(c, info + 3, true, nfx, free_param_name);
    discrete_model_indel_indx(c, info + 3 + c, false, nfx, free_param_name);
    for (int i = 0; i < nfx; i++) {
        matrixalloc_1d_free(free_param_name[i]);
    }
    matrixalloc_1d_free(free_param_name);
}

/*
 * @param x The scale is determined by onln
 * @since 2018.3.13
 */
static double discrete_model_fixed_ins_del_ratio(unsigned n, const double *x, double *grad, void *data) {
    dfe_constr_data_t cd = (dfe_constr_data_t) data;
    dfe_t d = cd->d;
    int indx = cd->indx;
    
    // [0]: r; [1]: c; [2..c+1]: indices of insertion mutation rates in x; [c+2, 2c + 1]: deletion mutation rates
    double *info = (double *) d->internal_constr_data[indx];
    double r = info[0];
    int c = (int) info[1];
    
    if (info[2] < 0) 
        discrete_model_indel_indx_in_free_param(info, c, d);
    
    double val[2];
    val[0] = val[1] = 0;
    double *indel[2];
    indel[0] = info + 3;//insertion
    indel[1] = info + 3 + c;//deletion
    if (grad != NULL) {
        for (int i = 0; i < d->num_free_param; i++)
            grad[i] = 0;
        for (int i = 0, k; i < 2; i++) {
            double g = (i == 0 ? r : -1);
            for (int j = 0; j < c; j++) {
                k = (int) indel[i][j];
                if (d->onln[k]) {
                    val[i] += scale_param_undo(x[k], d->free_param_types[k]);
                    grad[k] = g * scale_param_jaco(x[k], d->free_param_types[k]);
                } else {
                    val[i] += x[k];
                    grad[k] = g;
                }
            }
        }
    } else {
        for (int i = 0, k; i < 2; i++) {
            for (int j = 0; j < c; j++) {
                k = (int) indel[i][j];
                if (d->onln[k])
                    val[i] += scale_param_undo(x[k], d->free_param_types[k]);
                else
                    val[i] += x[k];
            }
        }
    }
    
    return r * val[0] - val[1];
}

/*
 * @since 2018.3.13
 */
static void discrete_model_with_fixed_snp_indel_ratio_and_fixed_ins_del_ratio_gen(double *x, gsl_rng *rng, dfe_t d) {
    gen_f gen = d->gen;
    d->gen = NULL;
    dfe_gen(x, rng, d);
    d->gen = gen;
    
    if (d->num_constr != 1 || d->is_eq_constr[0] != true)
        ERROR_MSG_LMA("ERROR");
    double *info = (double *) d->internal_constr_data[0];
    double r = info[0];//del/ins
    int c = (int) info[1];
    
    if (info[2] < 0) 
        discrete_model_indel_indx_in_free_param(info, c, d);
    
    double *ins_indx = info + 3;
    double *del_indx = info + 3 + c;
    
    //reuse the randomly generate insertion mutation rates
    double sum = 0;//on the original scale
    for (int i = 0; i < c; i++) {
        int k = (int) ins_indx[i];
        double tmp = x[k];
        if (d->onln[k])
            tmp = scale_param_undo(x[k], d->free_param_types[k]);
        sum += tmp;
    }
    
    //randomly generate deletion mutation rates
    sum *= r;
    for (int i = 0; i < c; i++) {
        int k = (int) del_indx[i];
        while (true) {
            double tmp = (i == c - 1 ? 1 : gsl_rng_uniform(rng));
            x[k] = sum * tmp;
            if (i == c - 1 && x[k] <= 0)
                ERROR_MSG_LMA("ERROR");
            if (x[k] > 0)
                break;
        }
        sum -= x[k];
        if (d->onln[k])
            x[k] = scale_param_do(x[k], d->free_param_types[k]);
    }
}

/*
 * @since 2018.3.13
 */
static void discrete_model_with_fixed_snp_indel_ratio_and_fixed_ins_del_ratio(dfe_t d, int c, double snp_indel, double del_ins) {
    discrete_model_with_fixed_snp_indel_ratio(d, c, snp_indel);
    
    d->use_auglag = true;
    
    d->num_constr = 1;
    M1D_NEW(d->constr, d->num_constr);
    M1D_NEW(d->is_eq_constr, d->num_constr);
    M1D_NEW(d->constr_data, d->num_constr);
    M1D_NEW(d->internal_constr_data, d->num_constr);
    M1D_NEW(d->free_internal_constr_data, d->num_constr);
    d->gen = discrete_model_with_fixed_snp_indel_ratio_and_fixed_ins_del_ratio_gen;
    
    d->constr[0] = discrete_model_fixed_ins_del_ratio;
    d->is_eq_constr[0] = true;
    
    dfe_constr_data_t cd = matrixalloc_1d(1, sizeof(*cd));
    cd->d = d;
    cd->indx = 0;
    d->constr_data[0] = cd;
    
    double *data = matrixalloc_1d(3 + 2 * c, sizeof(double));
    data[0] = del_ins;
    data[1] = c;
    /*
     * A negative number means the indices of the theta's in the list of free 
     * parameters supplied to lnlike have not been found.
     */
    data[2] = -1;
    
    d->internal_constr_data[0] = data;
    d->free_internal_constr_data[0] = free_double_array;
}

/*
 * @since 2018.3.13
 */
static void get_fixed_mutation_ratio(double ratio[2], char **constraint, char **msg) {
    msg[0] = NULL;
    
    char *cmd = constraint[0] + strlen("fixed_mutation_ratio");
    cmd = dfeio_remove_square_brackets(cmd, msg);
    if (msg[0] != NULL) {
        PRINT_ERRMSG(msg, "Failed to parse fixed_mutation_ratio. constraint = %s", constraint[0]);
        return;
    }
    char *cmd2 = cmd;
    dfeio_get_double_array(2, ratio, cmd, "Failed to parse fixed_mutation_ratio. constraint = %s", constraint[0]);
    M1D_FREE(cmd2);

    if (ratio[0] <= 0 || ratio[1] <= 0) {
        PRINT_ERRMSG(msg, "Problem with fixed_mutation_ratio. ratio <= 0. constraint = %s", constraint[0]);
        return;
    }
}

/*
 * @param c c &gt; 1 means the discrete model; c = -1 means the reflected gamma model
 * @since 2018.1.28, 3.6, 3.13 (added fixed_mutation_ratio)
 */
static dfe_t build(snpdfe_builder_t *sb, indeldfe_builder_t *ib, int c, char **constraint, double r_range[2], char **msg) {
    msg[0] = NULL;
    
    //add within-data set constraints and build vardfe
    vardfe_t vd[2];
    double fixed_mutation_ratio[2]; //[0] = theta(snp)/(theta_indel); [1] = theta(del)/theta(ins)
    
    snpdfe_builder_add_constraint(sb[0], msg, "neutral");
    if (msg[0] != NULL) {
        return NULL;
    }
    
    if (string_util_equal(constraint[0], "none") ||
            (string_util_starts_with(constraint[0], "fixed_mutation_ratio") && c > 0)//these constraints are treated as between-dataset constraints
        ) {
        /* nothing to do */
    } else if (string_util_starts_with(constraint[0], "fixed_mutation_ratio") && c == -1) {//this only works for reflected gamma
        get_fixed_mutation_ratio(fixed_mutation_ratio, constraint, msg);
        if (msg[0] != NULL) {
            return NULL;
        }
        indeldfe_builder_add_constraint(ib[0], msg, "fixed_del_ins_ratio", fixed_mutation_ratio[1]);
        if (msg[0] != NULL) {
            return NULL;
        }
    } else {
        ERROR_MSG_LMA("neutralSNP_vs_selectedINDEL: unknown constraint = %s!\n", constraint[0]);
    }
    
    vd[0] = snpdfe_builder_build(sb, msg);
    if (msg[0] != NULL) {
        return NULL;
    }
    vd[1] = indeldfe_builder_build(ib, msg);
    if (msg[0] != NULL) {
        return NULL;
    }
    dfe_t d = dfe_init2(2, vd, r_range);
    
    //add between-dataset constraints here if new constraints are added
    if (string_util_starts_with(constraint[0], "fixed_mutation_ratio")) {
        if (c > 0) {//the discrete model
            get_fixed_mutation_ratio(fixed_mutation_ratio, constraint, msg);
            if (msg[0] != NULL) {
                return NULL;
            }
            discrete_model_with_fixed_snp_indel_ratio_and_fixed_ins_del_ratio(d, c, fixed_mutation_ratio[0], fixed_mutation_ratio[1]);
        } else if (c == -1) {//the reflected gamma model
            reflected_gamma_with_fixed_snp_indel_ratio_and_fixed_ins_del_ratio(d, fixed_mutation_ratio[0], fixed_mutation_ratio[1]);
        } else {
            ERROR_MSG_LMA("Error!\n");
        }
    }
    
    dfe_rm_param(d);
    
    matrixalloc_1d_free(constraint[0]);
    constraint[0] = NULL;
    
    return d;
}

/*
 * @since 2018.1.28, 3.6
 */
dfe_t dfe_neutralsnp_vs_selectedindel(file_reader_t *reader, int *line_id, integrator_t *ig, char **msg) {
    msg[0] = NULL;
 
    int num_param = 10;
    int param_id = 0;
    const char *param_names[num_param];
    param_names[param_id++] = "n:";
    param_names[param_id++] = "r_range:";
    param_names[param_id++] = "neu_snp_m:";
    param_names[param_id++] = "neu_snp_sfs:";
    param_names[param_id++] = "neu_snp_theta_range:";
    param_names[param_id++] = "neu_snp_e_range:";
    param_names[param_id++] = "sel_indel_m:";
    param_names[param_id++] = "sel_ins_sfs:";
    param_names[param_id++] = "sel_del_sfs:";
    param_names[param_id++] = "dfe:";
    if (param_id != num_param)
        ERROR_MSG_LMA("error");
    
    char param[num_param][BUFFER_SIZE];
    dfeio_read_control_param(num_param, param, param_names, reader, line_id, msg);
    if (msg[0] != NULL)
        return NULL;
    
    param_id = 0;
    int n = dfeio_get_int(param[param_id], "Failed to parse n at line %i.\n", 
            line_id[0] - num_param + param_id + 1);
    param_id++;
    
    double r_range[2];
    dfeio_get_double_array(2, r_range, param[param_id], "Failed to parse r_range at line %i.\n",
            line_id[0] - num_param + param_id + 1);
    param_id++;
    
    double neu_m = dfeio_get_double(param[param_id], "Failed to parse neu_snp_m at line %i.\n", 
            line_id[0] - num_param + param_id + 1);
    param_id++;
    
    double neu_sfs[n - 1];
    dfeio_get_double_array(n - 1, neu_sfs, param[param_id], "Failed to parse neu_snp_sfs at line %i.\n",
            line_id[0] - num_param + param_id + 1);
    param_id++;
    
    double neu_range[1][3][2];
    for (int i = 0; i < 3; i++) {
        if (i == 1) {//gamma
            neu_range[0][i][0] = -1;
            neu_range[0][i][1] = 1;
        } else {
            dfeio_get_double_array(2, neu_range[0][i], param[param_id], "Failed to parse %s at line %i.\n",
                    param_names[param_id], line_id[0] - num_param + param_id + 1);
            param_id++;
        }
    }
    
    double sel_m = dfeio_get_double(param[param_id], "Failed to parse sel_indel_m at line %i.\n", 
            line_id[0] - num_param + param_id + 1);
    param_id++;
    
    double *sel_sfs[2];
    for (int i = 0, cnt = n - 1; i < 2; i++) {
        sel_sfs[i] = matrixalloc_1d(cnt, sizeof (double));
        dfeio_get_double_array(cnt, sel_sfs[i], param[param_id], "Failed to parse sfs at line %i.\n",
                line_id[0] - num_param + param_id + 1);
        param_id++;
    }   
    
    /* neutral SNPs */
    integrator_t ig2 = integrator_clone(ig[0]);
    snpdfe_builder_t sb = snpdfe_builder_new(n, &ig2, 1, true, "neu_snp_", msg);
    if (msg[0] != NULL)
        return NULL;
    snpdfe_builder_add_data(sb, neu_m, false, neu_sfs, msg);
    if (msg[0] != NULL)
        return NULL;
    snpdfe_builder_add_spikes(sb, 1, neu_range, msg);
    if (msg[0] != NULL)
        return NULL;
    
    /* selected INDELs */
    indeldfe_builder_t ib = indeldfe_builder_new(n, ig, 1, true, "sel_indel_", msg);
    if (msg[0] != NULL)
        return NULL;
    indeldfe_builder_add_data(ib, sel_m, sel_sfs, msg);
    if (msg[0] != NULL)
        return NULL;
    for (int j = 0; j < 2; j++)
        matrixalloc_1d_free(sel_sfs[j]);
    int c;    
    char *constraint;
    if (string_util_equal(param[param_id], "discrete"))
        dfeio_indel_discrete(&c, &constraint, ib, reader, line_id, msg);
    else if (string_util_equal(param[param_id], "continuous")) {
        c = -1;
        dfeio_indel_continuous(&constraint, ib, reader, line_id, msg);
    } else {
        PRINT_ERRMSG(msg, "Unknown dfe at line %i.\n", 
                line_id[0] - num_param + param_id + 1);
        return NULL;
    }
    if (msg[0] != NULL)
        return NULL;
    
    dfe_t re = build(&sb, &ib, c, &constraint, r_range, msg);
    if (msg[0] != NULL)
        return NULL;
    
    return re;
}