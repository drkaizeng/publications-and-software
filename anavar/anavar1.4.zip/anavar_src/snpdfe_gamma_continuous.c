/* 
 * Created on 26 February 2017, 14:21
 */
#include <string.h>
#include <stdbool.h>
#include <math.h>

#include "snpdfe_def.h"

#include "tau.h"
#include "param.h"
#include "get_name.h"
#include "print_errmsg.h"
#include "dist.h"
#include "vardfe_reflected_gamma_gaussq_adaptive.h"

#include "util/matrixalloc.h"
#include "util/error_msg.h"

#include "gsl/gsl_deriv.h"

typedef struct {
    int n;
    double m;
    bool folded;
    int nthreads;
    
    dist_t dist;//distribution of gamma
    int num_dist_param;//number of parameters in the above distribution
    double **dist_ranges;//the range of the parameters of dist. ranges[0] is the lower bound and ranges[1] is the upper bound. On the original scale.
    double frac;
    double delta;

    tau_t tau;//with multi-threading, this should be an array of length nthreads.
    double *dist_x;//Of length num_dist_param; a copy of input distribution parameters; with multi-threading, each thread needs a separate copy of this.
    size_t dist_xs;
    double *t;//t[i] is the value of tau(i, gamma) integrated over the distribution of gamma.
    double **dt;//dt[i][j] = d(t[i]) / d(the j-th parameter of the distribution of gamma) 
    gsl_function dt_func;//for calculating dt numerically
    
    vardfe_reflected_gamma_gaussq_adaptive_t rga;//The default is NULL
    
    int i;//with multi-threading, this should be an array of length nthreads.
    int p;//the index of the parameter of the distribution whose derivative is being calculated. Thus p ranges from [0, num_dist_param-1].
} snpdfe_gamma_cont_t;

/*
 * @since 2017.4.11, 9.6, 2018.3.6 (rga related)
 */
static void free_dfe(void *dfe) {
    snpdfe_gamma_cont_t *gc = (snpdfe_gamma_cont_t *) dfe;
    if (gc->rga != NULL) {
        if (gc->dist != NULL) {
            ERROR_MSG_LMA("error");
        }
        vardfe_reflected_gamma_gaussq_adaptive_free(&(gc->rga));
    }
    matrixalloc_2d_d_free(gc->dt);
    matrixalloc_1d_free(gc->t);
    matrixalloc_1d_free(gc->dist_x);
    tau_free(&(gc->tau));
    matrixalloc_2d_d_free(gc->dist_ranges);
    if (gc->dist != NULL)
        dist_free(&(gc->dist));
    matrixalloc_1d_free(gc);
}

/*
 * This is for calculating the integration of tau(gamma, i) over the distribution of gamma.
 * @since 2017.2.28, 4.11, 9.7
 */
static double int_tau(double gamma, void *param) { 
    snpdfe_gamma_cont_t *gc = (snpdfe_gamma_cont_t *) param;
    return tau_cal(gc->i, gamma, gc->tau);
}

/*
 * @since 2017.2.28, 4.11, 9.7
 */
static double dt_func(double x, void *param) {
    snpdfe_gamma_cont_t *gc = (snpdfe_gamma_cont_t *) param;
    double tmp = gc->dist_x[gc->p];
    gc->dist_x[gc->p] = x;
    double t = dist_int(int_tau, gc->dist_x, gc, gc->dist);
    gc->dist_x[gc->p] = tmp;
    return t;
}

/**
 * 
 * @param x theta, num_dist_param parameters for the distribution of gamma, and e
 * @param dsfs length(sfs)-by-num_param_full matrix where num_param_full is the number of parameters under the full model including r.
 *             dsfs[i][j] is the partial derivative of sfs[i] wrt the j-th parameter.
 *             If dsfs is NULL, then partial derivatives are not calculated.
 * @param has_der the number of parameters in the full model excluding r
 * @since 2017.2.28, 4.11, 9.7
 */
static void get_t_dt(snpdfe_gamma_cont_t *gc, const double *x, double **dsfs, const bool *has_der) {
    for (int i = 1; i < gc->n; i++) {
        gc->i = i;
        gc->t[i - 1] = dist_int(int_tau, x + 1, gc, gc->dist);
    }
    if (dsfs != NULL) {
        memcpy(gc->dist_x, x + 1, gc->dist_xs);
        for (int i = 1; i < gc->n; i++) {
            gc->i = i;
            for (int j = 1, k = 0; j <= gc->num_dist_param; j++, k++) {
                gc->p = k;
                if (has_der[j]) {
                    double step = fmax(gc->delta, gc->frac * fabs(x[j]));
                    if (gc->dist_ranges[1][k] - gc->dist_ranges[0][k] <= step)
                        ERROR_MSG_LMA("The range is too small!\n");
                    int status;
                    double re, abserr;
                    if (x[j] + step > gc->dist_ranges[1][k]) {
                        status = gsl_deriv_backward(&(gc->dt_func), x[j], step, &re, &abserr);
                    } else if (x[j] - step < gc->dist_ranges[0][k]) {
                        status = gsl_deriv_forward(&(gc->dt_func), x[j], step, &re, &abserr);
                    } else {
                        status = gsl_deriv_central(&(gc->dt_func), x[j], step, &re, &abserr);
                    }
                    if (status)
                        ERROR_MSG_LMA("GSL failure!\n");
                    gc->dt[i - 1][k] = re;
                }
            }
        }
    }
}

/*
 * @since 2017.2.28, 4.11, 9.7
 */
static void cal_unfolded_no_r(double *sfs, double **dsfs, const double *x, const double *r, const bool *has_der, void *dfe) {
    snpdfe_gamma_cont_t *gc = (snpdfe_gamma_cont_t *) dfe;
    get_t_dt(gc, x, dsfs, has_der);
    int n = gc->n;
    double *t = gc->t, **dt = gc->dt;
    int ei = gc->num_dist_param + 1;
    for (int i = 1, j, nj; i < n; i++) {
        j = i - 1;
        nj = n - i - 1;
        if (i == n - i) {
            sfs[j] = gc->m * x[0] * t[j];
            if (dsfs != NULL) {
                if (has_der[0])//theta
                    dsfs[j][0] = gc->m * t[j];
                for (int k = 1; k <= gc->num_dist_param; k++)
                    if (has_der[k])
                        dsfs[j][k] = gc->m * x[0] * dt[j][k - 1];
                if (has_der[ei])
                    dsfs[j][ei] = 0;
            }
        } else {
            sfs[j] = gc->m * x[0] * ((1 - x[ei]) * t[j] + x[ei] * t[nj]);
            if (dsfs != NULL) {
                if (has_der[0])
                    dsfs[j][0] = gc->m * ((1 - x[ei]) * t[j] + x[ei] * t[nj]);
                for (int k = 1; k <= gc->num_dist_param; k++)
                    if (has_der[k])
                        dsfs[j][k] = gc->m * x[0] * ((1 - x[ei]) * dt[j][k - 1] + x[ei] * dt[nj][k - 1]);
                if (has_der[ei])
                    dsfs[j][ei] = gc->m * x[0] * (-t[j] + t[nj]);
            }
        }
    }
}

/*
 * @since 2017.2.28, 4.11, 9.7
 */
static void cal_unfolded_use_r(double *sfs, double **dsfs, const double *x, const double *r, const bool *has_der, void *dfe) {
    snpdfe_gamma_cont_t *gc = (snpdfe_gamma_cont_t *) dfe;
    get_t_dt(gc, x, dsfs, has_der);
    int n = gc->n;
    double *t = gc->t, **dt = gc->dt;
    int lo = gc->num_dist_param + 2;
    int ei = gc->num_dist_param + 1;
    for (int i = 1, j, nj; i < n; i++) {
        j = i - 1;
        nj = n - i - 1;
        double riv = (i == 1 ? 1 : r[i - 2]);
        double rniv = (i == n - 1 ? 1 : r[n - i - 2]);
        if (i == n - i) {
            sfs[j] = gc->m * x[0] * riv * t[j];
            if (dsfs != NULL) {
                if (has_der[0])
                    dsfs[j][0] = gc->m * riv * t[j];
                for (int k = 1; k <= gc->num_dist_param; k++)
                    if (has_der[k])
                        dsfs[j][k] = gc->m * x[0] * riv * dt[j][k - 1];
                if (has_der[ei])
                    dsfs[j][ei] = 0;
                if (i != 1)
                    dsfs[j][lo + i - 2] = gc->m * x[0] * t[j];
            }
        } else {
            sfs[j] = gc->m * x[0] * ((1 - x[ei]) * riv * t[j] + x[ei] * rniv * t[nj]);
            if (dsfs != NULL) {
                if (has_der[0])
                    dsfs[j][0] = gc->m * ((1 - x[ei]) * riv * t[j] + x[ei] * rniv * t[nj]);
                for (int k = 1; k <= gc->num_dist_param; k++)
                    if (has_der[k])
                        dsfs[j][k] = gc->m * x[0] * ((1 - x[ei]) * riv * dt[j][k - 1] + x[ei] * rniv * dt[nj][k - 1]);
                if (has_der[ei])
                    dsfs[j][ei] = gc->m * x[0] * (-riv * t[j] + rniv * t[nj]);
                if (i == 1)//only r[n-1]
                    dsfs[j][lo + n - i - 2] = gc->m * x[0] * x[ei] * t[nj];
                else if (i == n - 1) {//only r[i]
                    dsfs[j][lo + i - 2] = gc->m * x[0] * (1 - x[ei]) * t[j];
                } else {
                    dsfs[j][lo + i - 2] = gc->m * x[0] * (1 - x[ei]) * t[j];
                    dsfs[j][lo + n - i - 2] = gc->m * x[0] * x[ei] * t[nj];
                }
            }
        }
    }
}

/*
 * @since 2017.2.28, 4.11, 9.7
 */
static void cal_folded_no_r(double *sfs, double **dsfs, const double *x, const double *r, const bool *has_der, void *dfe) {
    snpdfe_gamma_cont_t *gc = (snpdfe_gamma_cont_t *) dfe;
    get_t_dt(gc, x, dsfs, has_der);
    int n = gc->n;
    double *t = gc->t, **dt = gc->dt;
    for (int i = 1, j, nj; i <= n / 2; i++) {
        j = i - 1;
        nj = n - i - 1;
        if (i == n - i) {
            sfs[j] = gc->m * x[0] * t[j];
            if (dsfs != NULL) {
                if (has_der[0])
                    dsfs[j][0] = gc->m * t[j];
                for (int k = 1; k <= gc->num_dist_param; k++)
                    if (has_der[k])
                        dsfs[j][k] = gc->m * x[0] * dt[j][k - 1];
            }
        } else {
            sfs[j] = gc->m * x[0] * (t[j] + t[nj]);
            if (dsfs != NULL) {
                if (has_der[0])
                    dsfs[j][0] = gc->m * (t[j] + t[nj]);
                for (int k = 1; k <= gc->num_dist_param; k++)
                    if (has_der[k])
                        dsfs[j][k] = gc->m * x[0] * (dt[j][k - 1] + dt[nj][k - 1]);
            }
        }
    }
}

/*
 * @since 2017.2.28, 4.11, 9.7
 */
static void cal_folded_use_r(double *sfs, double **dsfs, const double *x, const double *r, const bool *has_der, void *dfe) {
    snpdfe_gamma_cont_t *gc = (snpdfe_gamma_cont_t *) dfe;
    get_t_dt(gc, x, dsfs, has_der);
    int n = gc->n;
    double *t = gc->t, **dt = gc->dt;
    int lo = gc->num_dist_param + 2;
    for (int i = 1, j, nj; i <= n / 2; i++) {
        j = i - 1;
        nj = n - i - 1;
        double riv = (i == 1 ? 1 : r[i - 2]);
        if (i == n - i) {
            sfs[j] = gc->m * x[0] * riv * t[j];
            if (dsfs != NULL) {
                if (has_der[0])
                    dsfs[j][0] = gc->m * riv * t[j];
                for (int k = 1; k <= gc->num_dist_param; k++)
                    if (has_der[k])
                        dsfs[j][k] = gc->m * x[0] * riv * dt[j][k - 1];
                if (i != 1)
                    dsfs[j][lo + i - 2] = gc->m * x[0] * t[j];
            }
        } else {
            sfs[j] = gc->m * x[0] * riv * (t[j] + t[nj]);
            if (dsfs != NULL) {
                if (has_der[0])
                    dsfs[j][0] = gc->m * riv * (t[j] + t[nj]);
                for (int k = 1; k <= gc->num_dist_param; k++)
                    if (has_der[k])
                        dsfs[j][k] = gc->m * x[0] * riv * (dt[j][k - 1] + dt[nj][k - 1]);
                if (i != 1)
                    dsfs[j][lo + i - 2] = gc->m * x[0] * (t[j] + t[nj]);
            }
        }
    }
}

/*
 * @since 2017.4.11, 9.6
 */
static void add_constraint_no_pol_error(snpdfe_builder_t sb) {
    int id = 3;
    double v = 0;
    
    sb->vd->num_free_param--;
    sb->vd->x[id] = v;
    sb->vd->is_free[id] = false;
    sb->vd->has_der[id] = false;
    sb->vd->xi[id] = -1;
    for (int i = id + 1; i < sb->vd->nx; i++)
        if (sb->vd->xi[i] >= 0)
            sb->vd->xi[i]--;
}

/*
 * @since 2017.4.11 (no_pol_error), 9.7
 */
static void add_constraint(snpdfe_builder_t sb, char **msg, const char *name, va_list args) {
    msg[0] = NULL;
    if (strcmp(name, "none") == 0)
        return;
    else if (strcmp(name, "no_pol_error") == 0) {
        if (sb->folded == true) {
            PRINT_ERRMSG(msg, "When the folded SFS is used, the e parameters are always zero. No need to set them to zero again.\n.");
            return;
        }
        add_constraint_no_pol_error(sb);
    } else {
        PRINT_ERRMSG(msg, "Unknown constraint = %s\n.", name);
        return;
    }
    
}

/*
 * @since 2017.2.28, 4.11, 4.19 (changed to vardfe), 9.7
 */
void snpdfe_builder_add_gamma_continuous(snpdfe_builder_t sb, dist_t *dist, int num_dist_param, double ranges[num_dist_param + 2][2], 
       double frac, double delta, char **msg) {
    if (sb->mode != 1)
        ERROR_MSG_LMA("sb->mode != 1\n");
    if (sb->dist != -1)
        ERROR_MSG_LMA("sb->dist != -1\n");
    if (num_dist_param < 1)
        ERROR_MSG_LMA("Error\n");
    
    dist_type_t type = dist_type(dist[0]);
    if (type != GAMMA_DIST) {
        PRINT_ERRMSG(msg, "Unsupported distribution for gamma (4Ns).");
        return;
    }
    if (type == GAMMA_DIST && num_dist_param != 2) {
        PRINT_ERRMSG(msg, "The gamma distribution is specified by the shape and scale parameters.");
        return;
    }
    if (frac < 0) {
        PRINT_ERRMSG(msg, "fraction < 0\n");
        return;
    }
    if (delta < 0) {
        PRINT_ERRMSG(msg, "delta < 0\n");
        return;
    }
    if (frac <= 0 && delta <= 0) {
        PRINT_ERRMSG(msg, "fraction <= 0 and delta <= 0. At least one of them should be strictly positive.\n");
        return;
    }
    
    sb->mode = 2;
    sb->dist = 1;
    
    snpdfe_gamma_cont_t *gc = matrixalloc_1d(1, sizeof (*gc));
    gc->n = sb->vd->n;
    gc->m = sb->m;
    gc->folded = sb->folded;
    gc->nthreads = sb->nthreads;
    gc->dist = dist[0];
    dist[0] = NULL;
    gc->num_dist_param = num_dist_param;
    gc->dist_ranges = matrixalloc_2d_d(2, gc->num_dist_param);
    for (int i = 1; i <= gc->num_dist_param; i++) {
        gc->dist_ranges[0][i - 1] = ranges[i][0];
        gc->dist_ranges[1][i - 1] = ranges[i][1];
    }
    gc->frac = frac;
    gc->delta = delta;
    gc->tau = tau_new(gc->n, &(sb->ig));//with multithreading, ig needs to be cloned.
    gc->dist_x = matrixalloc_1d(gc->num_dist_param, sizeof (*gc->dist_x));
    gc->dist_xs = (size_t) gc->num_dist_param * sizeof (*gc->dist_x);
    gc->t = matrixalloc_1d(gc->n - 1, sizeof (*gc->t));
    gc->dt = matrixalloc_2d_d(gc->n - 1, gc->num_dist_param);
    (gc->dt_func).function = dt_func;
    (gc->dt_func).params = gc;
    gc->rga = NULL;
    
    sb->vd->num_param_full = gc->num_dist_param + 2 + sb->vd->nr;
    sb->vd->num_free_param = sb->vd->num_param_full;
    sb->vd->param_types = matrixalloc_1d(sb->vd->num_param_full, sizeof (*sb->vd->param_types));
    sb->vd->param_names = matrixalloc_1d(sb->vd->num_param_full, sizeof (*sb->vd->param_names));
    {
        int indx = 0;
        sb->vd->param_types[indx] = THETA;
        sb->vd->param_names[indx++] = get_name2("%s%s", sb->name, "theta");
        if (type == GAMMA_DIST) {
            sb->vd->param_types[indx] = SHAPE;
            sb->vd->param_names[indx++] = get_name2("%s%s", sb->name, "shape");
            sb->vd->param_types[indx] = SCALE;
            sb->vd->param_names[indx++] = get_name2("%s%s", sb->name, "scale");
        }
        sb->vd->param_types[indx] = ERR;
        sb->vd->param_names[indx++] = get_name2("%s%s", sb->name, "e");
        for (int i = 0; i < sb->vd->nr; i++) {
            sb->vd->param_types[indx] = R;
            sb->vd->param_names[indx++] = get_name("r", i + 2);
        }
    }
    sb->vd->dfe = gc;
    sb->vd->ranges = matrixalloc_2d_d(2, sb->vd->num_param_full - sb->vd->nr);
    for (int i = 0; i < sb->vd->num_param_full - sb->vd->nr; i++) {
        if (ranges[i][0] >= ranges[i][1]) {
                PRINT_ERRMSG(msg, "The range [%g, %g] for %s is invalid. "
                        "The lower bound should be strictly smaller than the upper bound\n",
                        ranges[i][0], ranges[i][1], sb->vd->param_names[i]);
                return;
            }
        if (sb->vd->param_types[i] == THETA || sb->vd->param_types[i] == SHAPE || sb->vd->param_types[i] == SCALE) {
            if (ranges[i][0] <= 0) {
                PRINT_ERRMSG(msg, "The lower bound for %s is %g, but it should be positive.\n",
                        sb->vd->param_names[i], ranges[i][0]);
                return;
            }
        }
        if (sb->vd->param_types[i] == ERR && (ranges[i][0] < 0 || ranges[i][1] > 1)) {
            PRINT_ERRMSG(msg, "The bounds for %s is [%g, %g], but they should be in [0, 1].\n",
                    sb->vd->param_names[i], ranges[i][0], ranges[i][1]);
            return;
        }
        sb->vd->ranges[0][i] = ranges[i][0];
        sb->vd->ranges[1][i] = ranges[i][1];
    }
    sb->vd->free_dfe = free_dfe;
    if (sb->folded)
        if (sb->use_r)
            sb->vd->cal = cal_folded_use_r;
        else
            sb->vd->cal = cal_folded_no_r;
    else
        if (sb->use_r)
            sb->vd->cal = cal_unfolded_use_r;
        else
            sb->vd->cal = cal_unfolded_no_r;
    
    sb->add_constraint = add_constraint;
    
    vardfe_init(sb->vd);
    
    if (sb->folded) //e has to be 0 
        add_constraint_no_pol_error(sb);
    
    msg[0] = NULL;
}

/*
 * @since 2018.3.6, 3.11
 */
static void rga_cal(double *sfs, double **dsfs, const double *x, const double *r, const bool *has_der, void *dfe) {
    snpdfe_gamma_cont_t *gc = (snpdfe_gamma_cont_t *) dfe;
    vardfe_reflected_gamma_gaussq_adaptive_t rga = gc->rga;
    vardfe_reflected_gamma_gaussq_adaptive_set_dist(rga, r);
    vardfe_reflected_gamma_gaussq_adaptive_cal(sfs, dsfs, x, r, has_der, dfe, rga);
}

/*
 * @since 2018.3.6, 3.11
 */
void snpdfe_builder_add_reflected_gamma_gaussq_adaptive(snpdfe_builder_t sb, double range[4][2], double frac, double delta, const char *method, char **msg) {
    msg[0] = NULL;
    
    dist_t dist = dist_gamma_gaussq(10, true, msg);
    if (msg[0] != NULL)
        return;
    snpdfe_builder_add_gamma_continuous(sb, &dist, 2, range, frac, delta, msg);
    
    snpdfe_gamma_cont_t *gc = (snpdfe_gamma_cont_t *) sb->vd->dfe;
    dist_free(&(gc->dist));
    
    int n_dist = 1;
    dist_t *vd_dist[n_dist];
    vd_dist[0] = &(gc->dist);
    gc->rga = vardfe_reflected_gamma_gaussq_adaptive_new(sb->vd, n_dist, vd_dist, method, msg);
    if (msg[0] != NULL) 
        return;

    sb->vd->cal = rga_cal;
}