#include <string.h>

#include "indeldfe_def.h"
#include "print_errmsg.h"

#include "util/matrixalloc.h"
#include "util/error_msg.h"
#include "util/arrayutil.h"

/*
 * @since 2017.4.26, 9.7
 */
indeldfe_builder_t indeldfe_builder_new(int n, integrator_t *ig, int nthreads, bool use_r, const char *name, char **msg) {
    msg[0] = NULL;
    if (n < 4) {
        PRINT_ERRMSG(msg, "n < 4\n");
        return NULL;
    }
    if (nthreads < 1) {
        PRINT_ERRMSG(msg, "nthreads < 1\n");
        return NULL;
    }
    
    indeldfe_builder_t ib = matrixalloc_1d(1, sizeof (*ib));
    ib->mode = 0;
    ib->dist = -1;
    ib->vd = matrixalloc_1d(1, sizeof (*(ib->vd)));
    ib->vd->type = INDEL;
    ib->vd->n = n;
    ib->ig = ig[0];
    ig[0] = NULL;
    ib->nthreads = nthreads;
    ib->use_r = use_r;
    ib->name = matrixalloc_1d_clone(name, (int) strlen(name) + 1, sizeof (char));
    return ib;
}

/*
 * @since 2017.4.26, 9.7
 */
void indeldfe_builder_add_data(indeldfe_builder_t ib, double m, double *data[2], char **msg) {
    msg[0] = NULL;
    if (ib->mode != 0) 
        ERROR_MSG_LMA("sb->mode != 0\n");
    ib->mode = 1;
    if (m < 1) {
        PRINT_ERRMSG(msg, "m < 1\n");
        return;
    }
    {
        int upper = ib->vd->n - 1;
        for (int j = 0; j < 2; j++)
            for (int i = 0; i < upper; i++)
                if (data[j][i] < 0) {
                    PRINT_ERRMSG(msg, "INDEL sfs[%i][%i] < 0\n", j + 1, i + 1);
                    return;
                }
    }
    ib->m = m;
    ib->vd->data_len = 2 * (ib->vd->n - 1);
    ib->vd->data = matrixalloc_1d(ib->vd->data_len, sizeof (*ib->vd->data));
    memcpy(ib->vd->data, data[0], (size_t) (ib->vd->n - 1) * sizeof (double));
    memcpy(ib->vd->data + ib->vd->n - 1, data[1], (size_t) (ib->vd->n - 1) * sizeof (double));
    ib->vd->sfs = matrixalloc_1d(ib->vd->data_len, sizeof (*ib->vd->sfs));
    if (ib->use_r)
        ib->vd->nr = ib->vd->n - 2;
    else
        ib->vd->nr = 0;
}

/*
 * @since 2017.4.26, 9.7
 */
void indeldfe_builder_add_constraint(indeldfe_builder_t ib, char **msg, const char *name, ...) {
    if (ib->mode != 2)
        ERROR_MSG_LMA("sb->mode != 2\n");
    
    ib->mode = 3;
    
    va_list args;
    va_start(args, name);
    ib->add_constraint(ib, msg, name, args);
    va_end(args);
}

/*
 * @since 2017.4.28, 9.7
 */
vardfe_t indeldfe_builder_build(indeldfe_builder_t *ib, char **msg) {
    msg[0] = NULL;
    
    if (ib[0]->mode < 2)
        ERROR_MSG_LMA("error\n");
    
    vardfe_t re = ib[0]->vd;
    if (re->num_free_param <= 0) {
        PRINT_ERRMSG(msg, "There is no free parameter to be estimated!");
        return NULL;
    }
    
    matrixalloc_1d_free(ib[0]->name);
    matrixalloc_1d_free(ib[0]);
    ib[0] = NULL;
    
    return re;
}