/* 
 * Created on 09 February 2017, 14:00
 */

#include "dist.h"
#include "dist_def.h"
#include "abserr.h"

#include "util/matrixalloc.h"
#include "util/error_msg.h"

#include "gsl/gsl_sf.h"

/*
 * @since
 */
static void free_param(void *param) {
    return;
}

static dist_type_t type(void) {
    return POINT_DIST;
}

/*
 * @since 2017.2.10
 */
static double integrate(double (* func)(double x, void *param), const double *x, void *param, void *dist_param) {
    return func(x[0], param);
}

/*
 * @since 2017.2.10
 */
dist_t dist_point(void) {
    ERROR_MSG_LMA("Need debugging\n");
    dist_t d = matrixalloc_1d(1, sizeof (*d));
    d->param = NULL;
    d->free_param = free_param;
    d->type = type;
    d->integrate = integrate;
    return d;
}