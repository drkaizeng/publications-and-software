#ifndef CONSTANTS_H
#define CONSTANTS_H

//For numerical integration
#define FRACTION 0.005
#define DELTA 1e-3

//For Gaussian quadratures
#define DEGREE 50 

//for qag integrator
#define SIZE 10000
#define KEY 3 
#define EPSABS 1e-5
#define EPSREL 1e-8

//for the searches
#define RFTOL 1e-8
#define CONSTRAINT_TOL 1e-8

#endif /* CONSTANTS_H */

