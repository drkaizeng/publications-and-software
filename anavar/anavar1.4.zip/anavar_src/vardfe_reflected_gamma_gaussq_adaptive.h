/*
 * Created on 05 March 2018, 22:42
 */

#ifndef VARDFE_REFLECTED_GAMMA_GAUSSQ_ADAPTIVE_H
#define VARDFE_REFLECTED_GAMMA_GAUSSQ_ADAPTIVE_H

#include "vardfe_def.h"
#include "dist.h"

typedef struct vardfe_reflected_gamma_gaussq_adaptive * vardfe_reflected_gamma_gaussq_adaptive_t;

/**
 * Supported adaptive methods:
 * <ul>
 * <li> exp[min, factor, max_imp, atol, rtol, restart] <br>
 *      step 0 = min; step 1 = min * factor; step 2 = min * factor * factor <br>
 *      factor > 1 && (int) (min * factor^i) &lt; (int) (min * factor^(i+1)
 * <li> linear[min, step, max_imp, atol, rtol, restart]
 * </ul>
 * restart = 0/1. If 0, then the algorithm starts from the last_index. Otherwise, it starts from min
 * <p>
 * <b>Important:</b> if n_dist is greater than 1, then all elements in vd_dist will be filled with the same
 * dist_t object by vardfe_reflected_gamma_gaussq_adaptive_set_dist()
 * 
 * @param vd The original cal method is saved in the return object. But the one in vd is set to NULL.
 * @param n_dist the length of vd_dist (1 for snpdfe and 2 for indeldfe)
 * @param vd_dist This is &(vd->dfe->dist). This has to be NULL on entry.
 * @param method
 * @param msg
 * @return 
 */
vardfe_reflected_gamma_gaussq_adaptive_t vardfe_reflected_gamma_gaussq_adaptive_new(vardfe_t vd, int n_dist, dist_t *vd_dist[n_dist], const char *method, char **msg);

void vardfe_reflected_gamma_gaussq_adaptive_free(vardfe_reflected_gamma_gaussq_adaptive_t *rga);

/**
 * This sets vd->dfe->dist, which should NULL on entry, to one that with an appropriate degree.
 * <b>Important:</b> set vd->dfe->dist to NULL after use.
 */
void vardfe_reflected_gamma_gaussq_adaptive_set_dist(vardfe_reflected_gamma_gaussq_adaptive_t rga, const double *r);

/**
 * This calculates sfs and dsfs as described in vadfe_def.
 * <p>
 * It also reverse set vd->dfe->dist to NULL.
 */
void vardfe_reflected_gamma_gaussq_adaptive_cal(double *sfs, double **dsfs, const double *x, const double *r, const bool *has_der, void *dfe, vardfe_reflected_gamma_gaussq_adaptive_t rga);

#endif /* VARDFE_REFLECTED_GAMMA_GAUSSQ_ADAPTIVE_H */

