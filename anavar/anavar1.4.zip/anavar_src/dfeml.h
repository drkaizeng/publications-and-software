/* 
 * Created on 18 February 2017, 06:28
 */

#ifndef DFEML_H
#    define DFEML_H

#include "dfe.h"

#include "nlopt.h"
#include "gsl/gsl_rng.h"

typedef struct dfeml_builder_tag * dfeml_builder_t;
typedef struct dfeml_tag * dfeml_t;

/**
 * @param d On return d is set to NULL.
 * @param imprftol A small real number (e.g., 1e-15); used to decide whether a new search 
 *                 initilised using the outcome of the search immediately before results in significant 
 *                 improvements in the ln-likelihood.
 * @param nnoimp A positive integer. If it is set to 1, then no improvement search is attempted. 
 *               Otherwise, improvement searches will be conducted until a nnoimp number of consecutive 
 *               improvement attempts lead to no significant improvement in the ln-likelihood, 
 *               as determined by imprftol.
 * @param maximp A positive integer. This is the maximum number of
 *               improvement searches attempted.
 * @return 
 */
dfeml_builder_t dfeml_builder_new(dfe_t *d, int num_searches, double imprftol, int nnoimp, int maximp, char **msg);

/**
 * Supported algorithms:
 * <ul>
 * <li> NLOPT_LN_NELDERMEAD
 * <li> NLOPT_LD_LBFGS
 * <li> NLOPT_LD_SLSQP
 * <li> NLOPT_LD_VAR1
 * <li> NLOPT_LD_VAR2
 * </ul>
 * 
 * @param rftol Set relative tolerance on optimization parameters: stop when an optimization step 
 *             (or an estimate of the optimum) changes every parameter by less than rtol 
 *             multiplied by the absolute value of the parameter.
 * @param maxeval Stop when the number of function evaluations exceeds maxeval.
 * @param maxtime Stop when the optimization time (in seconds) exceeds maxtime
 */
void dfeml_builder_set_algorithm(dfeml_builder_t db, const char * algstr, 
        double rftol, int maxeval, double maxtime, char **msg);

dfeml_t dfeml_builder_build(dfeml_builder_t *db);

void dfeml_free(dfeml_t *dm);

/**
 * If init is NULL, then the initial value is generated at random in dm->d->range for each new search. In this
 * case num_all_param is ignored.
 * @n This is the length of init, which should be equal to dm->d->num_param_full.
 * @param init The initial values of all the parameters. On the original scale.
 */
void dfeml_search(dfeml_t dm, FILE *res_file, FILE *log_file, gsl_rng *rng, int n, double init[n]);

#endif /* DFEML_H */

