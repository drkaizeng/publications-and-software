/* 
 * Created on 23 February 2017, 12:43
 */

#ifndef PRINT_ERRMSG_H
#    define PRINT_ERRMSG_H

#include "util/matrixalloc.h"
#include "util/error_msg.h"

#define PRINT_ERRMSG(MSG, ...) \
        do { \
            int ERRMSG_BUFFER = 5000; \
            char ERRMSG[ERRMSG_BUFFER]; \
            int CN = snprintf(ERRMSG, (size_t) ERRMSG_BUFFER, __VA_ARGS__); \
            if (CN < 0 || CN >= ERRMSG_BUFFER) \
                ERROR_MSG_LMA("Failed\n"); \
            else {\
                char *STR = matrixalloc_1d_clone(ERRMSG, CN + 1, sizeof (char)); \
                MSG[0] = STR; \
            } \
        } while (0)



#endif /* PRINT_ERRMSG_H */

