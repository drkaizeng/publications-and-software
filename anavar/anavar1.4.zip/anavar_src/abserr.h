/* 
 * Created on 06 February 2017, 10:29
 */

#ifndef ABSERR_H
#    define ABSERR_H


#define ABSERR_THRESHOLD 1e-5


#endif /* ABSERR_H */

