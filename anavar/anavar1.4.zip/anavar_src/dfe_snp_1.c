#include <string.h>

#include "dfe_def.h"
#include "dfeio.h"
#include "get_name.h"
#include "print_errmsg.h"
#include "snpdfe.h"
#include "vardfe.h"
#include "scale_param.h"
#include "constants.h"

#include "util/matrixalloc.h"
#include "util/arrayutil.h"
#include "util/string_util.h"

/**
 * @paran snp On return, snp points to NULL.
 * @param x_onln This is of the length of the full snpdfe model with no constraints (but less the r parameters). This array is cloned.
 * @param rrange The lower and upper bounds for the r parameters. If r is not used, this parameter is ignored. On the original scale.
 * @param r_onln If true, then all the r parameters are on the natural log scale. If r is not used, this parameter is ignored.
 * @since 2017.4.14, 6.19 (changed to dfe_init()), 9.17 (changed to dfe_init2())
 */
static dfe_t dfe_snp_1_build(vardfe_t *snp) {
    return dfe_init2(1, snp, NULL);
}

/*
 * @since 2017.4.15, 5.22 (roughly), 6.19 (changed to dfeio_snp_continuous and dfeio_snp_discrete), 9.17
 */
dfe_t dfe_snp_1(file_reader_t *reader, int *line_id, integrator_t *ig, char **msg) {
    msg[0] = NULL;
    
    int num_param = 5;
    int param_id = 0;
    const char *param_names[num_param];
    param_names[param_id++] = "n:";
    param_names[param_id++] = "m:";
    param_names[param_id++] = "folded:";
    param_names[param_id++] = "sfs:";
    param_names[param_id++] = "dfe:";
    
    char param[num_param][BUFFER_SIZE];
    dfeio_read_control_param(num_param, param, param_names, reader, line_id, msg);
    if (msg[0] != NULL)
        return NULL;
    
    param_id = 0;
    int n = dfeio_get_int(param[param_id], "Failed to parse n at line %i.\n", 
            line_id[0] - num_param + param_id + 1);
    param_id++;
    
    double m = dfeio_get_double(param[param_id], "Failed to parse m at line %i.\n", 
            line_id[0] - num_param + param_id + 1);
    param_id++;
    
    bool folded = dfeio_get_bool(param[param_id], "Failed to parse folded at line %i.\n", 
            line_id[0] - num_param + param_id + 1);
    param_id++;
    
    double *sfs;
    {
        int cnt = folded ? n / 2 : n - 1;
        sfs = matrixalloc_1d(cnt, sizeof (double));
        dfeio_get_double_array(cnt, sfs, param[param_id], "Failed to parse sfs at line %i.\n", 
            line_id[0] - num_param + param_id + 1);
    }   
    param_id++;
    
    snpdfe_builder_t sb = snpdfe_builder_new(n, ig, 1, false, "", msg);
    if (msg[0] != NULL) 
        return NULL;
    
    snpdfe_builder_add_data(sb, m, folded, sfs, msg);
    matrixalloc_1d_free(sfs);
    if (msg[0] != NULL) 
        return NULL;
    
    vardfe_t vd;
    {
        int c;
        char *constraint;
        if (string_util_equal(param[param_id], "discrete"))
            dfeio_snp_discrete(&c, &constraint, sb, reader, line_id, msg);
        else if (string_util_equal(param[param_id], "continuous")) {
            c = -1;
            dfeio_snp_continuous(&constraint, sb, reader, line_id, msg);
        } else {
            PRINT_ERRMSG(msg, "Unknown dfe at line %i.\n",
                    line_id[0] - num_param + param_id + 1);
            return NULL;
        }
        if (msg[0] != NULL)
            return NULL;
        
        snpdfe_builder_add_constraint(sb, msg, constraint);
        matrixalloc_1d_free(constraint);
        if (msg[0] != NULL)
            return NULL;

        vd = snpdfe_builder_build(&sb, msg);
        if (msg[0] != NULL)
            return NULL;
    }
    
    return dfe_snp_1_build(&vd);
}