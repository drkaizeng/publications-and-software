#include <string.h>

#include "dfe_def.h"
#include "dfeio.h"
#include "indeldfe.h"
#include "print_errmsg.h"
#include "find_name.h"
#include "get_name.h"

#include "util/arrayutil.h"
#include "util/string_util.h"
#include "snpdfe.h"

/*
 * The returned array must be freed
 * @since 2017.5.14, 5.16, 9.19
 */
static char * read_constraint(file_reader_t *reader, int *line_id, char **msg) {
    msg[0] = NULL;
    
    int num_param = 1;
    int param_id = 0;
    const char *param_names[num_param];
    param_names[param_id++] = "constraint:";

    char param[num_param][BUFFER_SIZE];
    dfeio_read_control_param(num_param, param, param_names, reader, line_id, msg);
    if (msg[0] != NULL)
        return NULL;
    
    char *re = matrixalloc_1d_clone(param[0], (int) strlen(param[0]) + 1, sizeof (char));
    return re;
}

/*
 * @since 2017.5.14, 5.16, 9.19
 */
static void read_data(double m[3], int n, double sfs[3][n - 1], double range[3][1][3][2], 
        file_reader_t *reader, int *line_id, char **msg) {
    msg[0] = NULL;
    
    const char *header[3] = { "[neutral_SNPs]", "[ws_SNPs]", "[sw_SNPs]" };
    int num_param = 6;
    int param_id = 0;
    const char *param_names[num_param];
    param_names[param_id++] = "";
    param_names[param_id++] = "m:";
    param_names[param_id++] = "sfs:";
    param_names[param_id++] = "theta_range:";
    param_names[param_id++] = "gamma_range:";
    param_names[param_id++] = "e_range:";
    if (param_id != num_param)
        ERROR_MSG_LMA("error");
    
    char param[num_param][BUFFER_SIZE];

    for (int i = 0; i < 3; i++) {
        param_names[0] = header[i];
        dfeio_read_control_param(num_param, param, param_names, reader, line_id, msg);
        if (msg[0] != NULL)
            return;
        
        param_id = 0;
        
        if (strlen(param[0]) != 0) {
            PRINT_ERRMSG(msg, "Unexpected text found after %s at line %i\n", param_names[param_id], line_id[0] - num_param + param_id + 1);
            return;
        }
        param_id++;

        m[i] = dfeio_get_double(param[param_id], "Failed to parse m at line %i.\n",
                line_id[0] - num_param + param_id + 1);
        param_id++;
        
        dfeio_get_double_array(n - 1, sfs[i], param[param_id], "Failed to parse sfs at line %i.\n",
                line_id[0] - num_param + param_id + 1);
        param_id++;
        
        for (int j = 0; j < 3; j++) {
            dfeio_get_double_array(2, range[i][0][j], param[param_id], "Failed to parse %s at line %i.\n",
                    param_names[param_id], line_id[0] - num_param + param_id + 1);
            param_id++;
        }
    }
}

/*
 * @since 2017.5.14, 5.16, 9.19
 */
static void read_n_r(int *n, double r_range[2], file_reader_t *reader, int *line_id, char **msg) {
    msg[0] = NULL;
 
    int num_param = 2;
    int param_id = 0;
    const char *param_names[num_param];
    param_names[param_id++] = "n:";
    param_names[param_id++] = "r_range:";
    if (param_id != num_param)
        ERROR_MSG_LMA("error");
    
    char param[num_param][BUFFER_SIZE];
    dfeio_read_control_param(num_param, param, param_names, reader, line_id, msg);
    if (msg[0] != NULL)
        return;
    
    param_id = 0;
    n[0] = dfeio_get_int(param[param_id], "Failed to parse n at line %i.\n", 
            line_id[0] - num_param + param_id + 1);
    param_id++;
    
    dfeio_get_double_array(2, r_range, param[param_id], "Failed to parse r_range at line %i.\n",
            line_id[0] - num_param + param_id + 1);
    param_id++;
}

/*
 * @since 2017.5.17, 9.19
 */
static double m1s_f(const double *x, void *param) {
    return -x[0];
}

/*
 * @since 2017.5.17, 9.19
 */
static double m1s_df(const double *x, int i, void *param) {
    return -1;
}

/*
 * @since 2017.5.16, 5.17
 */
static void m1s(dfe_t d) {
    int nx = dfe_num_free_param(d);
    char **param_name = dfe_free_param_names(d);
    const char *name[2] = {"ws_gamma_1", "sw_gamma_1"};
    int ind[2];
    for (int i = 0; i < 2; i++) {
        ind[i] = find_name(name[i], nx, param_name);
        if (ind[i] < 0)
            ERROR_MSG_LMA("Error!\n");
    }

    d->is_free[ind[1]] = false;
    d->xi[ind[1]] = -1;
    d->cf[ind[1]] = matrixalloc_1d(1, sizeof (constraint_func_t));
    d->cf[ind[1]]->x = matrixalloc_1d(1, sizeof (double));
    d->cf[ind[1]]->nx = 1;
    d->cf[ind[1]]->xi = matrixalloc_1d(1, sizeof (int));
    d->cf[ind[1]]->xi[0] = ind[0];
    d->cf[ind[1]]->f = m1s_f;
    d->cf[ind[1]]->df = m1s_df;
    d->cf[ind[1]]->param = NULL;
    d->cf[ind[1]]->free_param = NULL;

    for (int i = 0; i < nx; i++) {
        matrixalloc_1d_free(param_name[i]);
    }
    matrixalloc_1d_free(param_name);
}

/*
 * @since 2017.5.14 (none), 5.16, 9.19
 */
dfe_t dfe_gbgc_extended_m1s(file_reader_t *reader, int *line_id, integrator_t *ig, char **msg) {
    int n;
    double r_range[2];
    read_n_r(&n, r_range, reader, line_id, msg);
    
    double m[3];
    double sfs[3][n - 1];
    double range[3][1][3][2];
    read_data(m, n, sfs, range, reader, line_id, msg);
    
    char *constraint = read_constraint(reader, line_id, msg);
    
    snpdfe_builder_t sb[3];
    const char *name[3] = { "neu_", "ws_", "sw_" };
    for (int i = 0; i < 3; i++) {
        integrator_t ig2 = integrator_clone(ig[0]);
        sb[i] = snpdfe_builder_new(n, &ig2, 1, true, name[i], msg);
        if (msg[0] != NULL)
            return NULL;

        snpdfe_builder_add_data(sb[i], m[i], false, sfs[i], msg);
        if (msg[0] != NULL)
            return NULL;
        
        snpdfe_builder_add_spikes(sb[i], 1, range[i], msg);
        if (msg[0] != NULL)
            return NULL;
    }
    integrator_free(ig);
    
    /* add within data constraints */
    if (string_util_equal(constraint, "none") || string_util_equal(constraint, "M1*")) {//no within-set constraint for ws and sw
        snpdfe_builder_add_constraint(sb[0], msg, "neutral");
        if (msg[0] != NULL)
            return NULL;
    } else if (string_util_equal(constraint, "M0*")) {//ws_gamma = 0 and sw_gamma = 0
        for (int i = 0; i < 3; i++) {
            snpdfe_builder_add_constraint(sb[i], msg, "neutral");
            if (msg[0] != NULL)
                return NULL;
        }
    } else if (string_util_equal(constraint, "M1")) {//neu_e = 0 and ws_e = 0 and sw_e = 0
        snpdfe_builder_add_constraint(sb[0], msg, "neutral_AND_no_pol_error");
        if (msg[0] != NULL)
            return NULL;
        
        for (int i = 1; i < 3; i++) {
            snpdfe_builder_add_constraint(sb[i], msg, "no_pol_error");
            if (msg[0] != NULL)
                return NULL;
        }
    } else if (string_util_equal(constraint, "M0")) {
        for (int i = 0; i < 3; i++) {
            snpdfe_builder_add_constraint(sb[i], msg, "neutral_AND_no_pol_error");
            if (msg[0] != NULL)
                return NULL;
        }
    } else {
        PRINT_ERRMSG(msg, "Unknown constraint = %s.\n", constraint);
        return NULL;
    }

    vardfe_t vd[3];
    for (int i = 0; i < 3; i++) {
        vd[i] = snpdfe_builder_build(&sb[i], msg);
        if (msg[0] != NULL)
            return NULL;
    }
    
    dfe_t d = dfe_init2(3, vd, r_range);
    
    /* add between data constraints */
    if (string_util_equal(constraint, "M1*") || string_util_equal(constraint, "M1")) {//ws_gamma_1 = -sw_gamma_1
        m1s(d);
    }
    dfe_rm_param(d);
    
    matrixalloc_1d_free(constraint);
    
    return d;
}