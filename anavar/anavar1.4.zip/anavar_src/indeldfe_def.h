/* 
 * Created on 10 March 2017, 11:39
 */

#ifndef INDELDFE_DEF_H
#    define INDELDFE_DEF_H

#include "indeldfe.h"

#include "vardfe_def.h"

struct indeldfe_builder_tag {
    /**
     * <ol>
     * <li>0: no data. The object was just created by new()
     * <li>1: data have been added
     * <li>2: distribution has been added and the variables for dealing with constraints have been initialised by init()
     * <li>3: add_constraint has been called
     * </ol>
     */
    int mode;
    /**
     * <ol>
     * <li> -1: no distribution added
     * <li> 0: spikes
     * <li> 1: continuous
     * </ol>
     */
    int dist;
    
    /* The following are initialised in new() */
    vardfe_t vd;
    integrator_t ig;//set to NULL after calling add_spike or add_gamma_continuous
    int nthreads;
    bool use_r;
    char *name;//the name of the dataset;
    
    /* The following are initialised in add_data() */
    double m;
    
    /* The following are initialised in add_spikes or add_gamma_continuous */
    void (* add_constraint)(indeldfe_builder_t ib, char **msg, const char *name, va_list args);
};


#endif /* INDELDFE_DEF_H */

