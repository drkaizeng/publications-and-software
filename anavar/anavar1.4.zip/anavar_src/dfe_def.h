/* 
 * Created on 19 February 2017, 06:07
 */

#ifndef DFE_DEF_H
#    define DFE_DEF_H

#include "dfe.h"
#include "vardfe.h"
#include "constraint_func.h"

#include "util/my_stack.h"

typedef void (*free_constraint_data_f)(void *);
typedef void (*gen_f)(double *x, gsl_rng *rng, dfe_t d);

struct dfe_constr_data_tag {
    dfe_t d;
    int indx;
};

struct dfe_tag {
    /* The number of data sets (i.e., the length of data) */
    int num_sets;
    vardfe_t *data;
    
    /* All equality and inequality constraints are treated as between-dataset constraints */
    bool use_auglag;//set to false by init() and init2()
    int num_constr;//[0]: inequality constraints; [1] equality constraints
    /*
     * Note that in the constraint function, the corresponding element in constr_data below should be used as the data.
     */
    nlopt_func *constr;
    bool *is_eq_constr;//if true, then the correspond constraint in constr is an equality constraint
    dfe_constr_data_t *constr_data;
    void **internal_constr_data;
    free_constraint_data_f *free_internal_constr_data;
    /*
     * The default is NULL. In each case the initial value is generated at random from intervals defined by range.
     */
    gen_f gen;
    /**
     * Of length num_sets.
     * pos[i] is the starting position in x of the non-r parameters for data[i].
     * See below for info on x.
     */
    int *pos;
    
    
    /* The number of r parameters. If r is not used, then nr = 0. */
    int nr;
    
    
    /**
     * The total number of parameters under each dataset's full model (less the r parameters) is summed.
     * Then the number of r parameters is added.
     */
    int num_param_full;
    /**
     * The total number of parameters under each dataset's full model (less the r parameters) is summed.
     * Then the number of r parameters is added.
     */
    char **param_names_full;
    
    
    /**
     * The number of each dataset's free parameters (excluding r) after all within-dataset constraints have been added is summed.
     * Then the number of r parameters is added.
     */
    int num_param;
    /**
     * There are num_param elements. This is used to indicate which parameters are still free
     * after between-dataset constraints have been added.
     */
    bool *is_free;
    /**
     * Of length num_param. On the original scale. <br>
     * The dataset-specific free parameters after the dataset-specific constraints 
     * have been added (less the r parameters) appear first. Then the number of r parameters is added.
     */
    double *x;
    /**
     * Of length num_param. The indices of the parameters in x in the input array supplied to lnlike.
     * This is for setting cross-dataset constraints. Constants should not be set this way. Instead,
     * they should be set within dataset. When a parameter is dependent on one or more other parameters,
     * the index is -1.
     */
    int *xi;
    /**
     * Of length num_param. Used to store d(ln-like)/d(x[i]).
     */
    double *gradx;
    /**
     * There are num_param elements. These are for setting between dataset constraints.
     * cf[j] is the constraint functions param[j] = cf(cf->x). The parameters are defined on the original scale.
     * The xi's in cf are defined wrt x here. This is the full model in the current case.
     */
    constraint_func_t **cf;
    
    /**
     * The number of free parameters after between-dataset constraints have been added. 
     * This is the final number of parameters to be estimated from data.
     */
    int num_free_param;
    /**
     * All the free parameters including r. The length is num_free_param.
     */
    param_t *free_param_types;
    /**
     * All the free parameters including r. The length is num_free_param.
     */
    char **free_param_names;
    /**
     * Contains num_free_param elements. If onln[i] is true, then the i-th
     * free parameter is on the natural log scale.
     */
    bool *onln;
    /**
     * ranges[0] (ranges[1]) contains num_free_param elements and give the lower (upper) bounds of the free parameters. 
     * The scale is determined by onln.
     */
    double **ranges;
};

/*
 * This can be called once num_sets and data have been initialised. This function will then initialise all the other variables 
 * assuming no between dataset constraints.
 * <p>
 * For onln, all non-gamma parameters are put on the log scale
 * 
 * @param r_range If r is not used, then supply NULL.
 */
void dfe_init(dfe_t d, double r_range[2]);

/**
 * @param data On return, the elements in data are set to NULL
 */
dfe_t dfe_init2(int num_set, vardfe_t data[num_set], double r_range[2]);

/*
 * <b>Important</b>: this function should be called at most once.
 * This assumes that all parameters were initialised by dfe_init and 
 * that is_free, xi, and cf have been updated as follows:
 * <ol>
 * <li> non-free parameters has been marked by setting is_free to false and xi to -1 and cf to non-NULL.
 * <li> But the other numbers in xi have not been changed (e.g., 0, -1, 2 rather than 0, -1, 1);
 * </ol>
 * This function does the following
 * <ol>
 * <li> Update xi
 * <li> Update num_free_param, free_param_types, free_param_names, onln and ranges
 * </ol>
 */
void dfe_rm_param(dfe_t d);

#endif /* DFE_DEF_H */

