#include <string.h>

#include "dfe_def.h"
#include "dfeio.h"
#include "snpdfe.h"
#include "print_errmsg.h"
#include "find_name.h"
#include "get_name.h"

#include "util/arrayutil.h"
#include "util/string_util.h"

/**
 * @since 2017.5.9, 9.19
 */
static double equal_mut_rate_cont_f(const double *x, void *param) {
    return x[0];
}

/**
 * @since 2017.5.9, 9.19
 */
static double equal_mut_rate_cont_df(const double *x, int i, void *param) {
    return 1;
}

/**
 * @since 2017.6.21, 9.19
 */
static void equal_mut_rate_cont(dfe_t d) {
    int nx = dfe_num_free_param(d);
    char **param_name = dfe_free_param_names(d);
    const char *name[2] = { "neu_theta_1", "sel_theta" };
    int ind[2];
    for (int i = 0; i < 2; i++) {
        ind[i] = find_name(name[i], nx, param_name);
        if (ind[i] < 0)
            ERROR_MSG_LMA("Error!\n");
    }

    int i1 = 0, i2 = 1;
    d->is_free[ind[i1]] = false;
    d->xi[ind[i1]] = -1;
    d->cf[ind[i1]] = matrixalloc_1d(1, sizeof (constraint_func_t));
    d->cf[ind[i1]]->x = matrixalloc_1d(1, sizeof (double));
    d->cf[ind[i1]]->nx = 1;
    d->cf[ind[i1]]->xi = matrixalloc_1d(1, sizeof (int));
    d->cf[ind[i1]]->xi[0] = ind[i2];
    d->cf[ind[i1]]->f = equal_mut_rate_cont_f;
    d->cf[ind[i1]]->df = equal_mut_rate_cont_df;
    d->cf[ind[i1]]->param = NULL;
    d->cf[ind[i1]]->free_param = NULL;
        
    for (int i = 0; i < nx; i++) {
        matrixalloc_1d_free(param_name[i]);
    }
    matrixalloc_1d_free(param_name);
}

/**
 * @since 2017.9.19
 */
static double equal_mut_rate_disc_f(const double *x, void *param) {
    constraint_func_t *cf = (constraint_func_t *) param;
    return arrayutil_sum_d_d(x, 0, cf->nx);
}

/**
 * @since 2017.9.19
 */
static double equal_mut_rate_disc_df(const double *x, int i, void *param) {
    return 1;
}

/**
 * @since 2017.6.20, 9.19
 */
static void equal_mut_rate_disc(dfe_t d, int c) {
    int nx = dfe_num_free_param(d);
    char **param_name = dfe_free_param_names(d);
    int neu_ind;
    {
        const char *name = "neu_theta_1";
        neu_ind = find_name(name, nx, param_name);
        if (neu_ind < 0)
            ERROR_MSG_LMA("Error!\n");
    }
    int sel_ind[c];
    for (int j = 0; j < c; j++) {
        char *name = get_name2("sel_theta_%i", j + 1);
        sel_ind[j] = find_name(name, nx, param_name);
        if (sel_ind[j] < 0)
            ERROR_MSG_LMA("Error!\n");
        matrixalloc_1d_free(name);
    }
    d->is_free[neu_ind] = false;
    d->xi[neu_ind] = -1;
    d->cf[neu_ind] = matrixalloc_1d(1, sizeof (constraint_func_t));
    d->cf[neu_ind]->x = matrixalloc_1d(c, sizeof (double));
    d->cf[neu_ind]->nx = c;
    d->cf[neu_ind]->xi = matrixalloc_1d(c, sizeof (int));
    memcpy(d->cf[neu_ind]->xi, sel_ind, (size_t) c * sizeof (int));
    d->cf[neu_ind]->f = equal_mut_rate_disc_f;
    d->cf[neu_ind]->df = equal_mut_rate_disc_df;
    d->cf[neu_ind]->param = d->cf[neu_ind];
    d->cf[neu_ind]->free_param = NULL;
    for (int i = 0; i < nx; i++) {
        matrixalloc_1d_free(param_name[i]);
    }
    matrixalloc_1d_free(param_name);
}

/**
 * @param neu Set to NULL on return
 * @param sel Set to NULL on return
 * @param c If continuous is used, then c is -1.
 * @param constraint On return, constraint[0] is freed and then set to NULL.
 * @since 2017.6.20, 6.21, 9.19, 2018.3.11 (added equal_mutation_rate_AND_no_pol_error)
 */
static dfe_t build(snpdfe_builder_t *sb[2], int c, char **constraint, double r_range[2], char **msg) {
    vardfe_t vd[2];
    
    if (string_util_equal(constraint[0], "none") || 
        string_util_equal(constraint[0], "equal_mutation_rate")) {
        snpdfe_builder_add_constraint(sb[0][0], msg, "neutral");
        if (msg[0] != NULL)
            return NULL;
    } else if (string_util_equal(constraint[0], "equal_mutation_rate_AND_no_pol_error")) {
        snpdfe_builder_add_constraint(sb[0][0], msg, "neutral_AND_no_pol_error");
        if (msg[0] != NULL)
            return NULL;
        snpdfe_builder_add_constraint(sb[1][0], msg, "no_pol_error");
        if (msg[0] != NULL)
            return NULL;
    } else {
        ERROR_MSG_ME("neutralSNP_vs_selectedSNP: unknown constraint = %s!\n", constraint[0]);
    }
    for (int i = 0; i < 2; i++) {
        vd[i] = snpdfe_builder_build(sb[i], msg);
        if (msg[0] != NULL)
            return NULL;
    }
    
    dfe_t d = dfe_init2(2, vd, r_range);

    if (string_util_equal(constraint[0], "equal_mutation_rate") || 
            string_util_equal(constraint[0], "equal_mutation_rate_AND_no_pol_error")
       ) {
        if (c > 0)
            equal_mut_rate_disc(d, c);
        else if (c == -1)
            equal_mut_rate_cont(d);
        else
            ERROR_MSG_LMA("Error!\n");
    }
    
    dfe_rm_param(d);
    
    matrixalloc_1d_free(constraint[0]);
    constraint[0] = NULL;
    
    return d;
}

/*
 * @since 2017.6.20, 6.21, 9.19
 */
dfe_t dfe_neutralsnp_vs_selectedsnp(file_reader_t *reader, int *line_id, integrator_t *ig, char **msg) {
    msg[0] = NULL;
 
    int num_param = 10;
    int param_id = 0;
    const char *param_names[num_param];
    param_names[param_id++] = "n:";
    param_names[param_id++] = "folded:";
    param_names[param_id++] = "r_range:";
    param_names[param_id++] = "neu_m:";
    param_names[param_id++] = "neu_sfs:";
    param_names[param_id++] = "neu_theta_range:";
    param_names[param_id++] = "neu_e_range:";
    param_names[param_id++] = "sel_m:";
    param_names[param_id++] = "sel_sfs:";
    param_names[param_id++] = "dfe:";
    if (param_id != num_param)
        ERROR_MSG_LMA("error");
    
    char param[num_param][BUFFER_SIZE];
    dfeio_read_control_param(num_param, param, param_names, reader, line_id, msg);
    if (msg[0] != NULL)
        return NULL;
    
    param_id = 0;
    int n = dfeio_get_int(param[param_id], "Failed to parse n at line %i.\n", 
            line_id[0] - num_param + param_id + 1);
    param_id++;
    
    bool folded = dfeio_get_bool(param[param_id], "Failed to parse folded at line %i.\n", 
            line_id[0] - num_param + param_id + 1);
    param_id++;
    
    bool use_r = true;
    double r_range[2];
    dfeio_get_double_array(2, r_range, param[param_id], "Failed to parse r_range at line %i.\n",
            line_id[0] - num_param + param_id + 1);
    if (r_range[0] == r_range[1] && r_range[0] == 1.0)
        use_r = false;
    else if (r_range[0] >= r_range[1]) {
        PRINT_ERRMSG(msg, "r_range[0] >= r_range[1]\n");
        return NULL;
    }
    param_id++;
    
    int sfs_len = (folded ? n / 2 : n - 1);
    
    double m[2];
    double *sfs[2];
    
    m[0] = dfeio_get_double(param[param_id], "Failed to parse neu_m at line %i.\n", 
            line_id[0] - num_param + param_id + 1);
    param_id++;

    sfs[0] = matrixalloc_1d(sfs_len, sizeof (double));
    dfeio_get_double_array(sfs_len, sfs[0], param[param_id], "Failed to parse neu_sfs at line %i.\n",
            line_id[0] - num_param + param_id + 1);
    param_id++;
    
    double neu_range[1][3][2];
    for (int i = 0; i < 3; i++) {
        if (i == 1) {//gamma
            neu_range[0][i][0] = -1;
            neu_range[0][i][1] = 1;
        } else {
            dfeio_get_double_array(2, neu_range[0][i], param[param_id], "Failed to parse %s at line %i.\n",
                    param_names[param_id], line_id[0] - num_param + param_id + 1);
            param_id++;
        }
    }
    
    m[1] = dfeio_get_double(param[param_id], "Failed to parse sel_m at line %i.\n", 
            line_id[0] - num_param + param_id + 1);
    param_id++;

    sfs[1] = matrixalloc_1d(sfs_len, sizeof (double));
    dfeio_get_double_array(sfs_len, sfs[1], param[param_id], "Failed to parse sel_sfs at line %i.\n",
            line_id[0] - num_param + param_id + 1);
    param_id++;
    
    snpdfe_builder_t sb[2];
    const char *names[2] = { "neu_", "sel_" };
    integrator_t igarr[2];
    igarr[0] = ig[0];
    ig[0] = NULL;
    igarr[1] = integrator_clone(igarr[0]);
    for (int i = 0; i < 2; i++) {
        sb[i] = snpdfe_builder_new(n, &igarr[i], 1, use_r, names[i], msg);
        if (msg[0] != NULL)
            return NULL;

        snpdfe_builder_add_data(sb[i], m[i], folded, sfs[i], msg);
        matrixalloc_1d_free(sfs[i]);
        if (msg[0] != NULL)
            return NULL;
    }
    
    /* the neutral SNPs */
    snpdfe_builder_add_spikes(sb[0], 1, neu_range, msg);
    if (msg[0] != NULL)
        return NULL;

    int c;    
    char *constraint;
    
    if (string_util_equal(param[param_id], "discrete"))
        dfeio_snp_discrete(&c, &constraint, sb[1], reader, line_id, msg);
    else if (string_util_equal(param[param_id], "continuous")) {
        c = -1;
        dfeio_snp_continuous(&constraint, sb[1], reader, line_id, msg);
    } else {
        PRINT_ERRMSG(msg, "Unknown dfe at line %i.\n", 
                line_id[0] - num_param + param_id + 1);
        return NULL;
    }
    if (msg[0] != NULL)
        return NULL;
    
    snpdfe_builder_t *sbp[2];
    for (int i = 0; i < 2; i++)
        sbp[i] = &sb[i];
    dfe_t re = build(sbp, c, &constraint, r_range, msg);
    if (msg[0] != NULL)
        return NULL;
    
    return re;
}