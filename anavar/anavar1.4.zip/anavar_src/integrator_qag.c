/* 
 * Created on 02 February 2017, 14:54
 */
#include <string.h>

#include "integrator.h"
#include "integrator_def.h"
#include "print_errmsg.h"

#include "util/matrixalloc.h"
#include "util/error_msg.h"

typedef struct integrator_qag_tag integrator_qag_t;

struct integrator_qag_tag {
    size_t size;
    double epsabs;
    double epsrel;
    int key;
    gsl_integration_workspace *w;
    double abserr;
    double pts[2];
};

/*
 * @since 2017.2.17, 4.6, 9.5 (removed set_pts)
 */
static void free_param(void *param) {
    integrator_qag_t *q = (integrator_qag_t *) param;
    gsl_integration_workspace_free(q->w);
    matrixalloc_1d_free(q);
}

/*
 * @since 2017.2.16, 4.6, 9.5
 */
static int integrate(double *result, gsl_function *func, void *param) {
    integrator_qag_t *q = (integrator_qag_t *) param;
    return gsl_integration_qag(func, q->pts[0], q->pts[1], q->epsabs, q->epsrel, q->size, q->key, q->w, result, &(q->abserr));
}

///*
// * @since 
// */
//static int int_singular_unknown(double *result, gsl_function *func, integrator_qag_t *q) {
//    return gsl_integration_qags(func, q->pts[0], q->pts[1], q->epsabs, q->epsrel, q->size, q->w, result, &(q->abserr));
//}
//
///*
// * @since 
// */
//static int int_singular_known(double *result, gsl_function *func, integrator_qag_t *q) {
//    return gsl_integration_qagp(func, q->pts, q->npts, q->epsabs, q->epsrel, q->size, q->w, result, &(q->abserr));
//}

/*
 * @since 2017.
 */
//static void set_pts(void *param, bool is_sig, int npts, double *pts) {
//    integrator_qag_t *q = (integrator_qag_t *) param;
//    if (is_sig == false) {
//        if (npts != 2)
//            ERROR_MSG_LMA("Failed\n");
//        q->npts = 2;
//        memcpy(q->pts, pts, 2 * sizeof (double));
//        q->integrate = int_smooth;
//    } else if (npts == -2) {
//        q->npts = 2;
//        memcpy(q->pts, pts, 2 * sizeof (double));
//        q->integrate = int_singular_unknown;
//    } else if (npts >= 2) {
//        if (npts > q->pts_len) {
//            q->pts_len = npts;
//            q->pts = matrixalloc_1d_realloc(q->pts, q->pts_len, sizeof (double));
//        }
//        q->npts = (size_t) npts;
//        memcpy(q->pts, pts, q->npts * sizeof (double));
//        q->integrate = int_singular_known;
//    } else
//        ERROR_MSG_LMA("Failed\n");
//}

///*
// * @since 2017.2.16, 4.6
// */
//static int integrate(double *result, gsl_function *func, void *param) {
//    integrator_qag_t *q = (integrator_qag_t *) param;
//    return q->integrate(result, func, q);
//}

/*
 * @since 2017.9.6
 */
static double abserr(void *param) {
    integrator_qag_t *q = (integrator_qag_t *) param;
    return q->abserr;
}

/*
 * @since 2017.5.8, 6.20, 9.5 (removed set_pts)
 */
static integrator_t clone(void *param) {
    integrator_qag_t *q = (integrator_qag_t *) param;
    integrator_qag_t *re = matrixalloc_1d(1, sizeof (*re));
    *re = *q;
    re->w = NULL;
    re->w = gsl_integration_workspace_alloc(re->size);
    if (re->w == NULL)
        ERROR_MSG_LMA("Failed to create workspace\n");
    
    integrator_t ig = matrixalloc_1d(1, sizeof (*ig));
    ig->param = re;
    ig->free_param = free_param;
//    ig->set_pts = set_pts;
    ig->integrate = integrate;
    ig->abserr = abserr;
    ig->clone = clone;
    
    return ig;
}

/*
 * @since 2017.4.6, 9.5 (removed set_pts)
 */
integrator_t integrator_new_qag(int size, double epsabs, double epsrel, int key, char **msg) {
    msg[0] = NULL;
    if (size <= 0) { 
        PRINT_ERRMSG(msg, "size <= 0\n");
        return NULL;
    }
    if (epsabs < 0 || epsrel < 0) {
        PRINT_ERRMSG(msg, "epsabs < 0 || epsrel < 0\n");
        return NULL;
    }
    if (epsabs == 0 && epsrel == 0) {
        PRINT_ERRMSG(msg, "epsabs == 0 && epsrel == 0\n");
        return NULL;
    }
    if (key < 1 || key > 6) {
        PRINT_ERRMSG(msg, "key < 1 || key > 6\n");
        return NULL;
    }
    
    integrator_qag_t *q = matrixalloc_1d(1, sizeof (*q));
    q->size = (size_t) size;
    q->epsabs = epsabs;
    q->epsrel = epsrel;
    q->key = key;
    q->w = NULL;
    q->w = gsl_integration_workspace_alloc((size_t) size);
    if (q->w == NULL)
        ERROR_MSG_LMA("Failed to create workspace\n");
    q->pts[0] = 0;
    q->pts[1] = 1;
    
    integrator_t ig = matrixalloc_1d(1, sizeof (*ig));
    ig->param = q;
    ig->free_param = free_param;
//    ig->set_pts = set_pts;
    ig->integrate = integrate;
    ig->abserr = abserr;
    ig->clone = clone;
    return ig;
}





