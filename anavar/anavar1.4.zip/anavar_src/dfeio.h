#ifndef DFEIO_H
#define DFEIO_H

#include <stdio.h>
#include <stdarg.h>

#include "indeldfe.h"
#include "snpdfe.h"

#include "io/file_reader.h"

#define BUFFER_SIZE 32767

/**
 * Return the next line that is non-empty or not starting with # (after trimming)
 * @line_id The first line has ID 1. This variable should be initialised to 0.
 * @param msg If no error is detected, then msg[0] points to NULL, otherwise it contains an error message.
 */
void dfeio_skip_lines(char buffer[BUFFER_SIZE], file_reader_t *reader, int *line_id, char **msg);

/**
 * Read the parameters (param_name) and store them in param.
 * @line_id The first line has ID 1. This variable should be initialised to 0.
 * @param msg If no error is detected, then msg[0] points to NULL, otherwise it contains an error message.
 */
void dfeio_read_control_param(int num_param, char param[num_param][BUFFER_SIZE], const char *param_name[num_param], 
        file_reader_t *reader, int *line_id, char **msg);

int dfeio_get_int(const char *valstr, const char *format, ...);

double dfeio_get_double(const char *valstr, const char *format, ...);

void dfeio_get_double_array(int len, double result[len], char *valstr, const char *format, ...);

bool dfeio_get_bool(const char *valstr, const char *format, ...);

/**
 * This function performs indeldfe_builder_add_gamma_continuous on the ib object. But it does not deal with constraints.
 * <p>
 * Control file format is described in INDEL_1 in the anavar manual.
 * 
 * @param constraint On return, this points to the string representing the constraint. This needs to be freed.
 * @param ib indeldfe_builder_new and indeldfe_builder_add_data have been called for this object.
 * @param reader
 * @param line_id
 * @param msg
 */
void dfeio_indel_continuous(char **constraint, indeldfe_builder_t ib, file_reader_t *reader, int *line_id, char **msg);

/**
 * This function performs indeldfe_builder_add_spikes on the ib object. But it does not deal with constraints.
 * <p>
 * Control file format is described in INDEL_1 in the anavar manual.
 * 
 * @param c The number of site classes
 * @param constraint On return, this points to the string representing the constraint. This needs to be freed.
 * @param ib indeldfe_builder_new and indeldfe_builder_add_data have been called for this object.
 * @param reader
 * @param line_id
 * @param msg
 */
void dfeio_indel_discrete(int *c, char **constraint, indeldfe_builder_t ib, file_reader_t *reader, int *line_id, char **msg);

/**
 * This function performs snpdfe_builder_add_gamma_continuous on the ib object. But it does not deal with constraints.
 * <p>
 * Control file format is described in SNP_1 in the anavar manual.
 * 
 * @param constraint On return, this points to the string representing the constraint. This needs to be freed.
 * @param sb snpdfe_builder_new and snpdfe_builder_add_data have been called for this object.
 * @param reader
 * @param line_id
 * @param msg
 */
void dfeio_snp_continuous(char **constraint, snpdfe_builder_t sb, file_reader_t *reader, int *line_id, char **msg);

/**
 * This function performs snpdfe_builder_add_spikes on the sb object. But it does not deal with constraints.
 * <p>
 * Control file format is described in SNP_1 in the anavar manual.
 * 
 * @param c The number of site classes
 * @param constraint On return, this points to the string representing the constraint. This needs to be freed.
 * @param sb snpdfe_builder_new and snpdfe_builder_add_data have been called for this object.
 * @param reader
 * @param line_id
 * @param msg
 */
void dfeio_snp_discrete(int *c, char **constraint, snpdfe_builder_t sb, file_reader_t *reader, int *line_id, char **msg);

/**
 * @param msg On return, msg[0] should point to NULL if everything is fine. Otherwise, it contains an error message
 * @return A cloned version of the string. This should be freed by M1D_FREE() or matrixalloc_1d_free
 */
char * dfeio_remove_square_brackets(const char *src, char **msg);

/**
 * The input string will be modified by this function. So it is important to keep a copy of the pointer src, so that
 * the memory can be freed correctly. 
 * @param param On return, param[o] points to a substring in src.
 * @param v
 * @param src The input should be of the form "param_name = v". Note that this function makes changes directly to the input string.
 *            So it is important to keep a copy pointing to the beginning of the memory, so that free works properly.
 * @param msg
 */
void dfeio_get_param_value(char **param, double *v, char *src, char **msg);


#endif /* DFEIO_H */

