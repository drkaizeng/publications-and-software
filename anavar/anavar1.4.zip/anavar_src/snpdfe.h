/* 
 * Created on 03 February 2017, 14:01
 */

#ifndef SNPDFE_H
#    define SNPDFE_H

#include <stdbool.h>
#include <stdarg.h>

#include "integrator.h"
#include "dist.h"
#include "vardfe.h"

typedef struct snpdfe_builder_tag * snpdfe_builder_t;

/**
 * @param n
 * @param ig On return, ig[0] will be set to NULL. This is for calculating tau(gamma, i) 
 * @param nthreads
 * @param use_r
 * @param name The name of this dataset. This will be the prefix of all its parameter names. This is cloned.
 * @param msg If an error occurs, then msg[0] points to the error message. Otherwise msg[0] = NULL.
 * @return 
 */
snpdfe_builder_t snpdfe_builder_new(int n, integrator_t *ig, int nthreads, bool use_r, const char *name, char **msg);

/**
 * @param m
 * @param data This is cloned
 * @return 
 */
void snpdfe_builder_add_data(snpdfe_builder_t sb, double m, bool folded, double *data, char **msg);


/**
 * This must be called after add_data() has been called.
 * The parameters are arranged as follows: <br>
 * theta_1, gamma_1, e_1, theta_2, gamma_2, e_2, ..., theta_c, gamma_c, e_c, r_2, r_3, ... <br>
 * <p>
 * theta is defined on a per-site basis
 * 
 * @param c The number of site categories
 * @param ranges The ranges of the parameters (theta, gamma, e for each category) on the original scale. The array is cloned.
 */
void snpdfe_builder_add_spikes(snpdfe_builder_t sb, int c, double ranges[c][3][2], char **msg);

/**
 * Let gamma follow a continuous distribution.
 * Distributions permitted:
 * <ol>
 * <li> Gamma
 * </ol>
 * 
 * @param sb
 * @param dist The distribution of selection coefficients (gamma = 4Ns). On return, dist is set to NULL
 * @param num_dist_param The number of parameters determining dist
 * @param ranges range[0] contains the range for theta. 
 *               range[1..num_dist_param] are the range for the parameters of the distribution.
 *               range[num_dist_param+1] is the range for e.
 *               On the original scale.
 * @param frac
 * @param delta
 * @param msg
 */
void snpdfe_builder_add_gamma_continuous(snpdfe_builder_t sb, dist_t *dist, int num_dist_param, double ranges[num_dist_param + 2][2], 
       double frac, double delta, char **msg);

/**
 * 
 * @param sb
 * @param range range[0:3] are for theta, shape, scale and e. All on the original scale
 * @param frac
 * @param delta
 * @param method See vardfe_reflected_gamma_gaussq_adaptive_new for supported adaptive Gaussian quadrature methods
 * @param msg
 */
void snpdfe_builder_add_reflected_gamma_gaussq_adaptive(snpdfe_builder_t sb, double range[4][2], double frac, double delta, const char *method, char **msg);

/**
 * This must be called after add_spikes or add_continuous has been called. This function can be called exactly once.
 * <p>
 * For snpdfe_gamma_cont_t, the following constraints are allowed 
 * <ul>
 * <li> none
 * <li> no_pol_error
 * </ul>
 * 
 * <p>
 * For snpdfe_spikes_t, the following constraints are allowed 
 * <ul>
 * <li> none
 * <li> no_pol_error
 * </ul>
 */
void snpdfe_builder_add_constraint(snpdfe_builder_t sb, char **msg, const char *name, ...);

/**
 * On return sb will be set to NULL.
 */
vardfe_t snpdfe_builder_build(snpdfe_builder_t *sb, char **msg);


#endif /* SNPDEF_H */

