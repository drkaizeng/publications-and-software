#include <string.h>

#include "dfe_def.h"
#include "dfeio.h"
#include "indeldfe.h"
#include "print_errmsg.h"
#include "constants.h"
#include "find_name.h"
#include "get_name.h"

#include "util/arrayutil.h"
#include "util/string_util.h"

/**
 * @since 2017.5.9
 */
static double equal_mut_rate_cont_f(const double *x, void *param) {
    return x[0];
}

/**
 * @since 2017.5.9
 */
static double equal_mut_rate_cont_df(const double *x, int i, void *param) {
    return 1;
}

/**
 * @since 2017.5.9, 9.19
 */
static void equal_mut_rate_cont(dfe_t d) {
    int nx = dfe_num_free_param(d);
    char **param_name = dfe_free_param_names(d);
    const char *name[4] = { "neu_ins_theta_1", "sel_ins_theta", "neu_del_theta_1", "sel_del_theta" };
    int ind[4];
    for (int i = 0; i < 4; i++) {
        ind[i] = find_name(name[i], nx, param_name);
        if (ind[i] < 0)
            ERROR_MSG_LMA("Error!\n");
    }
    for (int i = 0, i1 = 0, i2 = 1; i < 2; i++, i1 += 2, i2 += 2) {
        d->is_free[ind[i1]] = false;
        d->xi[ind[i1]] = -1;
        d->cf[ind[i1]] = matrixalloc_1d(1, sizeof (constraint_func_t));
        d->cf[ind[i1]]->x = matrixalloc_1d(1, sizeof (double));
        d->cf[ind[i1]]->nx = 1;
        d->cf[ind[i1]]->xi = matrixalloc_1d(1, sizeof (int));
        d->cf[ind[i1]]->xi[0] = ind[i2];
        d->cf[ind[i1]]->f = equal_mut_rate_cont_f;
        d->cf[ind[i1]]->df = equal_mut_rate_cont_df;
        d->cf[ind[i1]]->param = NULL;
        d->cf[ind[i1]]->free_param = NULL;
    }
    for (int i = 0; i < nx; i++) {
        matrixalloc_1d_free(param_name[i]);
    }
    matrixalloc_1d_free(param_name);
}

/**
 * @since 2017.9.19
 */
static double equal_mut_rate_disc_f(const double *x, void *param) {
    constraint_func_t *cf = (constraint_func_t *) param;
    return arrayutil_sum_d_d(x, 0, cf->nx);
}

/**
 * @since 2017.9.19
 */
static double equal_mut_rate_disc_df(const double *x, int i, void *param) {
    return 1;
}

/**
 * @since 2017.5.9, 9.19
 */
static void equal_mut_rate_disc(dfe_t d, int c) {
    int nx = dfe_num_free_param(d);
    char **param_name = dfe_free_param_names(d);
    int neu_ind[2];
    {
        const char *name[2] = {"neu_ins_theta_1", "neu_del_theta_1"};
        for (int i = 0; i < 2; i++) {
            neu_ind[i] = find_name(name[i], nx, param_name);
            if (neu_ind[i] < 0)
                ERROR_MSG_LMA("Error!\n");
        }
    }
    int sel_ind[2][c];
    for (int i = 0; i < 2; i++) {
        const char *id = i == 0 ? "ins" : "del";
        for (int j = 0; j < c; j++) {
            char *name = get_name2("sel_%s_theta_%i", id, j + 1);
            sel_ind[i][j] = find_name(name, nx, param_name);
            if (sel_ind[i][j] < 0)
                ERROR_MSG_LMA("Error!\n");
            matrixalloc_1d_free(name);
        }
    }
    for (int i = 0; i < 2; i++) {
        d->is_free[neu_ind[i]] = false;
        d->xi[neu_ind[i]] = -1;
        d->cf[neu_ind[i]] = matrixalloc_1d(1, sizeof (constraint_func_t));
        d->cf[neu_ind[i]]->x = matrixalloc_1d(c, sizeof (double));
        d->cf[neu_ind[i]]->nx = c;
        d->cf[neu_ind[i]]->xi = matrixalloc_1d(c, sizeof (int));
        memcpy(d->cf[neu_ind[i]]->xi, sel_ind[i], (size_t) c * sizeof (int));
        d->cf[neu_ind[i]]->f = equal_mut_rate_disc_f;
        d->cf[neu_ind[i]]->df = equal_mut_rate_disc_df;
        d->cf[neu_ind[i]]->param = d->cf[neu_ind[i]];
        d->cf[neu_ind[i]]->free_param = NULL;
    }
    for (int i = 0; i < nx; i++) {
        matrixalloc_1d_free(param_name[i]);
    }
    matrixalloc_1d_free(param_name);
}

/**
 * @param neu Set to NULL on return
 * @param sel Set to NULL on return
 * @param c If continuous is used, then c is -1.
 * @param constraint On return, constraint[0] is freed and then set to NULL.
 * @since 2017.5.8 (no constraint), 5.9 (equal_mutation_rate for c=-1 and c>0), 9.19 (changed to dfe_init2)
 *        2018.2.2 (added equal_mutation_rate_AND_fixedSEL)
 */
static dfe_t build(indeldfe_builder_t *ib[2], int c, char **constraint, double r_range[2], char **msg) {
    vardfe_t vd[2];
    
    // Within-data constraints
    if (string_util_equal(constraint[0], "none") || 
        string_util_equal(constraint[0], "equal_mutation_rate")) {
        indeldfe_builder_add_constraint(ib[0][0], msg, "neutral");
    } else if (string_util_starts_with(constraint[0], "equal_mutation_rate_AND_fixedSEL")) {
        if (c <= 0) {
            PRINT_ERRMSG(msg, "equal_mutation_rate_AND_fixedSEL can only be used when dfe is set to discrete.");
            return NULL;
        }
        if (strstr(constraint[0], "theta") != NULL) {
            PRINT_ERRMSG(msg, "The theta parameters cannot be fixed using equal_mutation_rate_AND_fixedSEL.");
            return NULL;
        }
        indeldfe_builder_add_constraint(ib[0][0], msg, "neutral");
        char *str = string_util_make("fixed%s", constraint[0] + strlen("equal_mutation_rate_AND_fixedSEL"));
        indeldfe_builder_add_constraint(ib[1][0], msg, str);
        M1D_FREE(str);
    } else {
        ERROR_MSG_LMA("neutralINDEL_vs_selectedINDEL: unknown constraint!\n");
    }
    
    if (msg[0] != NULL)
        return NULL;

    for (int i = 0; i < 2; i++) {
        vd[i] = indeldfe_builder_build(ib[i], msg);
        if (msg[0] != NULL)
            return NULL;
    }
    
    dfe_t d = dfe_init2(2, vd, r_range);

    if (string_util_equal(constraint[0], "equal_mutation_rate")) {
        if (c > 0)
            equal_mut_rate_disc(d, c);
        else if (c == -1)
            equal_mut_rate_cont(d);
        else
            ERROR_MSG_LMA("Error!\n");
    }
    
    dfe_rm_param(d);
    
    matrixalloc_1d_free(constraint[0]);
    constraint[0] = NULL;
    
    return d;
}

/**
 * Perform add_spike on the input object. But it does not deal with constraints.
 * @since 2017.5.8, 5.9
 */
static void read_continuous(char **constraint, indeldfe_builder_t sel, file_reader_t *reader, int *line_id, char **msg) {
    dfeio_indel_continuous(constraint, sel, reader, line_id, msg);
}

/**
 * Perform add_spike on the input object. But it does not deal with constraints.
 * @since 2017.5.9, 9.19
 */
static void read_discrete(int *c, char **constraint, indeldfe_builder_t sel, file_reader_t *reader, int *line_id, char **msg) {
    dfeio_indel_discrete(c, constraint, sel, reader, line_id, msg);
}

/*
 * @since 2017.5.8
 */
dfe_t dfe_neutralindel_vs_selectedindel(file_reader_t *reader, int *line_id, integrator_t *ig, char **msg) {
    msg[0] = NULL;
 
    int num_param = 13;
    int param_id = 0;
    const char *param_names[num_param];
    param_names[param_id++] = "n:";
    param_names[param_id++] = "r_range:";
    param_names[param_id++] = "neu_indel_m:";
    param_names[param_id++] = "neu_ins_sfs:";
    param_names[param_id++] = "neu_del_sfs:";
    param_names[param_id++] = "neu_ins_theta_range:";
    param_names[param_id++] = "neu_ins_e_range:";
    param_names[param_id++] = "neu_del_theta_range:";
    param_names[param_id++] = "neu_del_e_range:";
    param_names[param_id++] = "sel_indel_m:";
    param_names[param_id++] = "sel_ins_sfs:";
    param_names[param_id++] = "sel_del_sfs:";
    param_names[param_id++] = "dfe:";
    if (param_id != num_param)
        ERROR_MSG_LMA("error");
    
    char param[num_param][BUFFER_SIZE];
    dfeio_read_control_param(num_param, param, param_names, reader, line_id, msg);
    if (msg[0] != NULL)
        return NULL;
    
    param_id = 0;
    int n = dfeio_get_int(param[param_id], "Failed to parse n at line %i.\n", 
            line_id[0] - num_param + param_id + 1);
    param_id++;
    
    double r_range[2];
    dfeio_get_double_array(2, r_range, param[param_id], "Failed to parse r_range at line %i.\n",
            line_id[0] - num_param + param_id + 1);
    param_id++;
    
    double m[2];
    double *sfs[2][2];
    
    m[0] = dfeio_get_double(param[param_id], "Failed to parse neu_indel_m at line %i.\n", 
            line_id[0] - num_param + param_id + 1);
    param_id++;
    
    for (int i = 0, cnt = n - 1; i < 2; i++) {
        sfs[0][i] = matrixalloc_1d(cnt, sizeof (double));
        dfeio_get_double_array(cnt, sfs[0][i], param[param_id], "Failed to parse sfs at line %i.\n",
                line_id[0] - num_param + param_id + 1);
        param_id++;
    }   
    
    double neu_range[1][6][2];
    for (int i = 0; i < 6; i++) {
        if (i == 1 || i == 4) {//gamma
            neu_range[0][i][0] = -1;
            neu_range[0][i][1] = 1;
        } else {
            dfeio_get_double_array(2, neu_range[0][i], param[param_id], "Failed to parse %s at line %i.\n",
                    param_names[param_id], line_id[0] - num_param + param_id + 1);
            param_id++;
        }
    }
    
    m[1] = dfeio_get_double(param[param_id], "Failed to parse sel_indel_m at line %i.\n", 
            line_id[0] - num_param + param_id + 1);
    param_id++;
    
    for (int i = 0, cnt = n - 1; i < 2; i++) {
        sfs[1][i] = matrixalloc_1d(cnt, sizeof (double));
        dfeio_get_double_array(cnt, sfs[1][i], param[param_id], "Failed to parse sfs at line %i.\n",
                line_id[0] - num_param + param_id + 1);
        param_id++;
    }   
    
    indeldfe_builder_t ib[2];
    const char *names[2] = { "neu_", "sel_" };
    integrator_t igarr[2];
    igarr[0] = ig[0];
    ig[0] = NULL;
    igarr[1] = integrator_clone(igarr[0]);
    for (int i = 0; i < 2; i++) {
        ib[i] = indeldfe_builder_new(n, &igarr[i], 1, true, names[i], msg);
        if (msg[0] != NULL)
            return NULL;

        indeldfe_builder_add_data(ib[i], m[i], sfs[i], msg);
        for (int j = 0; j < 2; j++)
            matrixalloc_1d_free(sfs[i][j]);
        if (msg[0] != NULL)
            return NULL;
    }
    
    /* the neutral INDELs */
    indeldfe_builder_add_spikes(ib[0], 1, neu_range, msg);
    if (msg[0] != NULL)
        return NULL;

    int c;    
    char *constraint;
    
    if (string_util_equal(param[param_id], "discrete"))
        read_discrete(&c, &constraint, ib[1], reader, line_id, msg);
    else if (string_util_equal(param[param_id], "continuous")) {
        c = -1;
        read_continuous(&constraint, ib[1], reader, line_id, msg);
    } else {
        PRINT_ERRMSG(msg, "Unknown dfe at line %i.\n", 
                line_id[0] - num_param + param_id + 1);
        return NULL;
    }
    if (msg[0] != NULL)
        return NULL;
    
    indeldfe_builder_t *ibp[2];
    for (int i = 0; i < 2; i++)
        ibp[i] = &ib[i];
    dfe_t re = build(ibp, c, &constraint, r_range, msg);
    if (msg[0] != NULL)
        return NULL;
    
    return re;
}