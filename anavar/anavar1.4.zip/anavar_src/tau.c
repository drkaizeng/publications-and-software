/* 
 * Created on 02 February 2017, 12:47
 */
#include <stdio.h>
#include <math.h>

#include "tau.h"
#include "abserr.h"

#include "util/matrixalloc.h"
#include "util/error_msg.h"

#include "gsl/gsl_sf_gamma.h"
#include "integrator_def.h"

#define GAMMA_THRESHOLD 1e-3


struct tau_tag {
    int n;
    integrator_t ig;
    gsl_function tau;
    gsl_function dtau;
    double *ln_bino;//ln(n choose i)
    
    int i;
    double gamma;
};

/*
 * See glemin_sim_v1.nb
 * @since 2016.9.15, 9.18, 9.28 (added x=0,x=1 and +/-gamma), 2017.2.16, 4.6
 */
static double tau(double x, void *param) {
    tau_t s = (tau_t) param;
    int i = s->i;
    if (x == 0) {
        if (i == 1)
            return 1;
        else
            return 0;
    } else if (x == 1)
        return 0;
    else if (fabs(s->gamma) < GAMMA_THRESHOLD) {
        double gamma = s->gamma;
        double re = (i - 1) * log(x);
        re += (s->n - i) * log(1 - x);
        re = exp(re) * (24 + gamma * x * (12 + gamma * (-2 + x * (4 - gamma * (1 - x))))) / 24;
        return re;
    } else {
        double gamma = s->gamma;
        double re = (i - 1) * log(x);
        re += (s->n - i - 1) * log(1 - x);
        if (gamma >= 0)
            re = exp(re) * (1 - exp(-gamma * (1 - x))) / (1 - exp(-gamma));
        else {
            double tmp = exp(gamma);
            re = exp(re) * (tmp - exp(gamma * x)) / (tmp - 1);
        }
        return re;
    }
}

/*
 * @since 2016.9.20, 9.28 (added x=0,1; +/-gamma), 2017.2.16, 4.6
 */
static double dtau(double x, void *param) {
    if (x == 0 || x == 1)
        return 0;
    else {
        tau_t s = (tau_t) param;
        double gamma = s->gamma;
        if (fabs(gamma) < GAMMA_THRESHOLD) {
            double re = (s->i) * log(x);
            re += (s->n - s->i) * log(1 - x);
            double re1 = (180 - 45 * pow(gamma, 2) * x * (1 - x) - 60 * gamma * (1 - 2 * x)
                    + 2 * pow(gamma, 3) * (1 + x - 9 * pow(x, 2) + 6 * pow(x, 3))) / 360;
            re = exp(re) * re1;
            return re;
        } else {
            double re = (s->i - 1) * log(x);
            re += (s->n - s->i - 1) * log(1 - x);
            if (gamma <= 0) {
                double eg = exp(gamma);
                double re1 = (-eg + exp(gamma * x) * (eg * (1 - x) + x)) / pow(1 - eg, 2);
                re = exp(re) * re1;
            } else {
                double eg = exp(-gamma);
                double re1 = (-eg + exp(-(1 - x) * gamma) * (1 - x + x * eg)) / pow(1 - eg, 2);
                re = exp(re) * re1;
            }
            return re;
        }
    }
}

/*
 * @since 2017.2.10, 2.16, 4.6
 */
tau_t tau_new(int n, integrator_t *ig) {
    if (n < 2)
        ERROR_MSG_LMA("n < 2\n");
    
    tau_t s = matrixalloc_1d(1, sizeof (*s));
    s->n = n;
    s->ig = ig[0];
    ig[0] = NULL;
    s->tau.function = tau;
    s->tau.params = s;
    s->dtau.function = dtau;
    s->dtau.params = s;
    
    s->ln_bino = matrixalloc_1d(n - 1, sizeof (double));
    for (int i = 1, ii = 0; i < n; i++, ii++) 
        s->ln_bino[ii] = gsl_sf_lnchoose((unsigned) n, (unsigned) i);
    
    return s;
}

/*
 * @since 2017.2.17, 4.6
 */
void tau_free(tau_t *s) {
    matrixalloc_1d_free(s[0]->ln_bino);
    integrator_free(&(s[0]->ig));
    matrixalloc_1d_free(s[0]);
    s[0] = NULL;
}

/*
 * @since 2017.2.10, 2.16 (added gamma=0), 4.6
 */
double tau_cal(int i, double gamma, tau_t s) {
    if (gamma == 0) {
        return 1.0 / i;
    } else {
        s->i = i;
        s->gamma = gamma;
        double re;
        int status = integrator_int(&re, &(s->tau), s->ig);
        if (status)
            fprintf(stderr, "Warning: GSL integration failure in tau!\n"
                "gamma = %g, n = %i, i = %i\n", gamma, s->n, i);
        re = exp(log(re) + s->ln_bino[s->i - 1]);
        return re;
    }
}

/*
 * @since 2017.2.16, 4.6
 */
double tau_der(int i, double gamma, tau_t s) {
    if (gamma == 0) {
        return 1.0 / (2.0 * (1.0 + s->n));
    } else {
        s->i = i;
        s->gamma = gamma;
        double re;
        int status = integrator_int(&re, &(s->dtau), s->ig);
        if (status)
            fprintf(stderr, "Warning: GSL integration failure in dtau!\n"
                "gamma = %g, n = %i, i = %i\n", gamma, s->n, i);
        re = exp(log(re) + s->ln_bino[i - 1]);
        return re;
    }
}