/* 
 * Created on 02 February 2017, 13:52
 */

#ifndef INTEGRATOR_H
#    define INTEGRATOR_H

#include <stdbool.h>

#include "gsl/gsl_integration.h"

typedef struct integrator_tag * integrator_t;

/**
 * Integration of a smooth function in (0, 1). 
 * @param size Size of the workspace
 * @param epsabs
 * @param epsrel
 * @param key 1-6
 */
integrator_t integrator_new_qag(int size, double epsabs, double epsrel, int key, char **msg);
/**
 * Integration of a smooth function in (0, 1). 
 */
integrator_t integrator_new_cquad(int size, double epsabs, double epsrel, char **msg);

/**
 * Make an identical copy of the given integrator.
 */
integrator_t integrator_clone(integrator_t ig);

void integrator_free(integrator_t *ig);

/**
 * If is_sig is false, then npts must be 2, and pts[0] and pts[1] are the boundaries of the integration. 
 * The function is assumed to be smooth.
 * <p>
 * If is_sig is true, then singular points exist. 
 * <ul>
 * <li> If npts = -2, then there are internal singular points, but their locations are unknown.
 * <li> If npts &gt; 2, then pts[0] and pts[npts-1] are the boundaries (also possibly singular), and the other are internal singular points.
 */
//void integrator_set_pts(integrator_t ig, bool is_sig, int npts, double *pts);

/**
 * @param func
 * @return 0 (GLS_SUCCESS); otherwise an error has occurred.
 */
int integrator_int(double *result, gsl_function *func, integrator_t ig);

/**
 * @return The absolute error produced by the most recent call of integrator_int
 */
double integrator_abserr(integrator_t ig);


#endif /* INTEGRATOR_H */

