/*
 * Created on 05 March 2018, 22:44
 */
#include <stdbool.h>
#include <limits.h>
#include <math.h>
#include <string.h>

#include "vardfe_reflected_gamma_gaussq_adaptive.h"
#include "print_errmsg.h"
#include "dfeio.h"

#include "util/matrixalloc.h"
#include "util/string_util.h"
#include "util/error_msg.h"

struct vardfe_reflected_gamma_gaussq_adaptive {
    vardfe_t vd;
    int n_dist;
    dist_t **vd_dist;//vd_dist[0] is vd->dfe->dist
    void (* cal)(double *sfs, double **dsfs, const double *x, const double *r, const bool *has_der, void *dfe);//see vadfe_def
    int last_indx;//the index in degree of the last use
    
    int min;//the mininum number of degree
    int max_imp;//the maximum rounds of improvement
    double atol;
    double rtol;
    bool restart;
    int *degree;//of length max_imp + 1
    dist_t *d[2];//var[i]: of length max_imp + 1. var[0][i]: degree[i]. var[1][i]: 2*degree[i] + 1
    
    double val[2];
};

/*
 * @since 2018.3.5 (double, linear), 3.6 (linea; added n_dist, vd_dist; changed double to exp), 3.11
 */
vardfe_reflected_gamma_gaussq_adaptive_t vardfe_reflected_gamma_gaussq_adaptive_new(vardfe_t vd, int n_dist, dist_t *vd_dist[n_dist], const char *method, char **msg) {
    if (strlen(method) >= (size_t) INT_MAX)
        ERROR_MSG_LMA("error");
    if (n_dist != 1 && n_dist != 2)
        ERROR_MSG_LMA("error");
    for (int i = 0; i < n_dist; i++)
        if (vd_dist[i][0] != NULL)
            ERROR_MSG_LMA("error");
    
    
    char *cmd = matrixalloc_1d_clone(method, (int) strlen(method) + 1, sizeof (*cmd));
    
    struct vardfe_reflected_gamma_gaussq_adaptive *re = matrixalloc_1d(1, sizeof (*re));
    
    re->vd = vd;
    re->n_dist = n_dist;
    M1D_NEW(re->vd_dist, n_dist);
    for (int i = 0; i < n_dist; i++)
        re->vd_dist[i] = vd_dist[i];
    re->cal = vd->cal;
    vd->cal = NULL;
    re->last_indx = 0;
    
    if (string_util_starts_with(method, "exp")) {
        char *tmp = cmd + strlen("exp");
        tmp = dfeio_remove_square_brackets(tmp, msg);
        if (msg[0] != NULL) {
            PRINT_ERRMSG(msg, "Unknown control method for adaptive Gaussian quadrature = %s", method);
            return NULL;
        }
        int len = 6;
        double val[len];
        char *tmp2 = tmp;
        dfeio_get_double_array(len, val, tmp, "Unknown control method for adaptive Gaussian quadrature = %s", method);
        M1D_FREE(tmp2);
        
        int indx = 0;
        if ((int) val[indx] < 5) {
            PRINT_ERRMSG(msg, "Invalid control method for adaptive Gaussian quadrature = %s. min < 5.", method);
            return NULL;
        }
        re->min = (int) val[indx];
        indx++;
        
        if (val[indx] <= 1) {
            PRINT_ERRMSG(msg, "Invalid control method for adaptive Gaussian quadrature = %s. factor <= 1.", method);
            return NULL;
        }
        double factor = val[indx];
        indx++;
        
        if ((int) val[indx] < 0) {
            PRINT_ERRMSG(msg, "Invalid control method for adaptive Gaussian quadrature = %s. max_imp < 0.", method);
            return NULL;
        }
        re->max_imp = (int) val[indx];
        if (re->max_imp >= (int) ((log(INT_MAX) - log(re->min)) / log(factor))) {
            PRINT_ERRMSG(msg, "Invalid control method for adaptive Gaussian quadrature = %s. max_imp too large.", method);
            return NULL;
        }
        indx++;
        
        re->atol = val[indx++];
        re->rtol = val[indx++];
        if (re->atol <= 0 && re->rtol <= 0) {
            PRINT_ERRMSG(msg, "Invalid control method for adaptive Gaussian quadrature = %s. atol <= 0 && re->rtol.", method);
            return NULL;
        }
        
        int restart = (int) val[indx++];
        if (restart != 0 && restart != 1) {
            PRINT_ERRMSG(msg, "Invalid control method for adaptive Gaussian quadrature = %s. restart not 0 or 1.", method);
            return NULL;
        }
        re->restart = (restart == 0 ? false : true);
        indx++;
        
        M1D_NEW(re->degree, re->max_imp + 1);
        for (int i = 0; i <= re->max_imp; i++) {
            re->degree[i] = (int) (re->min * pow(factor, i));
            if (i > 0 && re->degree[i] <= re->degree[i - 1]) {
                PRINT_ERRMSG(msg, "Invalid control method for adaptive Gaussian quadrature = %s. factor too small.", method);
                return NULL;
            }
        }
    } else if (string_util_starts_with(method, "linear")) {
        char *tmp = cmd + strlen("linear");
        tmp = dfeio_remove_square_brackets(tmp, msg);
        if (msg[0] != NULL) {
            PRINT_ERRMSG(msg, "Unknown control method for adaptive Gaussian quadrature = %s", method);
            return NULL;
        }
        int len = 6;
        double val[len];
        char *tmp2 = tmp;
        dfeio_get_double_array(len, val, tmp, "Unknown control method for adaptive Gaussian quadrature = %s", method);
        M1D_FREE(tmp2);
        
        int indx = 0;
        if ((int) val[indx] < 5) {
            PRINT_ERRMSG(msg, "Invalid control method for adaptive Gaussian quadrature = %s. min < 5.", method);
            return NULL;
        }
        re->min = (int) val[indx];
        indx++;
        
        if ((int) val[indx] < 1) {
            PRINT_ERRMSG(msg, "Invalid control method for adaptive Gaussian quadrature = %s. step < 1.", method);
            return NULL;
        }
        int step = (int) val[indx];
        indx++;
        
        if ((int) val[indx] < 0) {
            PRINT_ERRMSG(msg, "Invalid control method for adaptive Gaussian quadrature = %s. max_imp < 0.", method);
            return NULL;
        }
        re->max_imp = (int) val[indx];
        if (step >= (INT_MAX - re->min) / re->max_imp)
            ERROR_MSG_ME("error");
        indx++;
        
        re->atol = val[indx++];
        re->rtol = val[indx++];
        if (re->atol <= 0 && re->rtol <= 0) {
            PRINT_ERRMSG(msg, "Invalid control method for adaptive Gaussian quadrature = %s. atol <= 0 && re->rtol.", method);
            return NULL;
        }
        
        int restart = (int) val[indx++];
        if (restart != 0 && restart != 1) {
            PRINT_ERRMSG(msg, "Invalid control method for adaptive Gaussian quadrature = %s. restart not 0 or 1.", method);
            return NULL;
        }
        re->restart = (restart == 0 ? false : true);
        indx++;
        
        M1D_NEW(re->degree, re->max_imp + 1);
        for (int i = 0; i <= re->max_imp; i++) 
            re->degree[i] = re->min + i * step;
    } else {
        PRINT_ERRMSG(msg, "Unknown control method for adaptive Gaussian quadrature = %s", method);
        return NULL;
    }
    
    for (int i = 0; i < 2; i++) 
        M1D_NEW(re->d[i], re->max_imp + 1);

    for (int i = 0; i <= re->max_imp; i++) {
        re->d[0][i] = dist_gamma_gaussq(re->degree[i], true, msg);
        if (msg[0] != NULL)
            return NULL;
        re->d[1][i] = dist_gamma_gaussq(2 * re->degree[i] + 1, true, msg);
        if (msg[0] != NULL)
            return NULL;
    }
    
    M1D_FREE(cmd);
    
    return re;
}

/*
 * @since 2018.3.6, 3.11
 */
void vardfe_reflected_gamma_gaussq_adaptive_free(vardfe_reflected_gamma_gaussq_adaptive_t *rga2) {
    vardfe_reflected_gamma_gaussq_adaptive_t rga = rga2[0];
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j <= rga->max_imp; j++)
            dist_free(&(rga->d[i][j]));
        M1D_FREE(rga->d[i]);
    }
    M1D_FREE(rga->degree);
    M1D_FREE(rga->vd_dist);
    M1D_FREE(rga);
    rga2[0] = NULL;
}

/*
 * @since 2018.3.6, 3.11
 */
void vardfe_reflected_gamma_gaussq_adaptive_set_dist(vardfe_reflected_gamma_gaussq_adaptive_t rga, const double *r) {
    vardfe_t vd = rga->vd;
    int n_dist = rga->n_dist;
    dist_t **dist = rga->vd_dist;
    for (int i = 0; i < rga->n_dist; i++) {
        if (dist[i][0] != NULL)
            ERROR_MSG_LMA("error");
    }
    double *sfs = vd->sfs;
    double *val = rga->val;
    bool ok = false;
    int indx = (rga->restart == true ? 0 : rga->last_indx);
    for (; indx <= rga->max_imp; indx++) {
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < n_dist; j++)
                dist[j][0] = rga->d[i][indx];
            rga->cal(sfs, NULL, vd->x, r, vd->has_der, vd->dfe);
            double lnlike = 0;
            for (int j = 0; j < vd->data_len; j++) {
                if (sfs[j] <= 0) { //possible loss of accuracy due to numerical instability
                    sfs[j] = DBL_MIN;
                } 
                lnlike += -sfs[j] + vd->data[j] * log(sfs[j]);
            }
            val[i] = lnlike;
        }
        double diff = fabs(val[0] - val[1]);
//        printf("%i\t%g\t%g\t%g\n", rga->degree[indx], val[0], val[1], diff);
        double mean = (fabs(val[0]) + fabs(val[1])) / 2;
        if (diff <= rga->atol || diff <= rga->rtol * mean) {
            ok = true;
            rga->last_indx = indx;
            for (int j = 0; j < n_dist; j++)
                dist[j][0] = rga->d[0][indx];
            break;
        }
    }
    if (ok == false) {
        fprintf(stderr, "Possible numerical instability in snpdfe with reflected gamma and adaptive Gaussian quadrature.\n");
        for (int i = 0; i < vd->nx; i++)
            fprintf(stderr, "%g\t", vd->x[i]);
        fprintf(stderr, "\n\n");
    }
}

/*
 * @since 2018.3.6, 3.11
 */
void vardfe_reflected_gamma_gaussq_adaptive_cal(double *sfs, double **dsfs, const double *x, const double *r, const bool *has_der, 
        void *dfe, vardfe_reflected_gamma_gaussq_adaptive_t rga) {
    rga->cal(sfs, dsfs, x, r, has_der, dfe);
    for (int i = 0; i < rga->n_dist; i++)
        rga->vd_dist[i][0] = NULL;
}