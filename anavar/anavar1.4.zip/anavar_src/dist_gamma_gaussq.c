/* 
 * Created on 01 March 2017, 22:59
 */
#include <math.h>

#include "dist_def.h"

#include "util/matrixalloc.h"
#include "util/error_msg.h"
#include "print_errmsg.h"

typedef struct {
    int n;
    bool neg;
    double sign;//1 if neg = false; -1 otherwise
    
    double alpha;//the value used in the most recent call; see to -1 by dist_gamma_gaussq()
    double beta;//the value used in the most recent call; see to -1 by dist_gamma_gaussq()
    
    double *a;
    double *b;
    double *z;
} dist_gamma_gaussq_t;


#define ABS(x) ((x) >= 0 ? (x) : -(x))

static double dsign(double a, double b) {
    return b >= 0 ? ABS(a) : -ABS(a);
}

/*  This function was extracted from the file gaussq.f, downloaded from */
/*  http://www.netlib.org/go/gaussq.f on 7 August 2012. */
/*  The function was modified for portability (Aug and Sep 2012) and */
/*  updated to Fortran 77 (28 Aug 2016) by Gordon Smyth. */
/*  All modified lines are commented out with a capital "C" and the new */
/*  version follows immediately. */
/* Subroutine */ 
static int gausq2_(int *n, double *d__, double *e, 
	double *z__, int *ierr)
{
    /* System generated locals */
    int i__1, i__2;
    double d__1, d__2, d__3;

    /* Builtin functions */
    //double pow_dd(double *a, double *b) = a^b, sqrt(double), 
    //d_sign(double *a, double *b); = (b >= 0 ? fabs(a) : -fabs(a))

    /* Local variables */
    double b, c__, f, g;
    int i__, j, k, l, m;
    double p, r__, s;
    int ii, mml;
    double machep;


/*     this subroutine is a translation of an algol procedure, */
/*     num. math. 12, 377-383(1968) by martin and wilkinson, */
/*     as modified in num. math. 15, 450(1970) by dubrulle. */
/*     handbook for auto. comp., vol.ii-linear algebra, 241-248(1971). */
/*     this is a modified version of the 'eispack' routine imtql2. */

/*     this subroutine finds the eigenvalues and first components of the */
/*     eigenvectors of a symmetric tridiagonal matrix by the implicit ql */
/*     method. */

/*     on input: */

/*        n is the order of the matrix; */

/*        d contains the diagonal elements of the input matrix; */

/*        e contains the subdiagonal elements of the input matrix */
/*          in its first n-1 positions.  e(n) is arbitrary; */

/*        z contains the first row of the identity matrix. */

/*      on output: */

/*        d contains the eigenvalues in ascending order.  if an */
/*          error exit is made, the eigenvalues are correct but */
/*          unordered for indices 1, 2, ..., ierr-1; */

/*        e has been destroyed; */

/*        z contains the first components of the orthonormal eigenvectors */
/*          of the symmetric tridiagonal matrix.  if an error exit is */
/*          made, z contains the eigenvectors associated with the stored */
/*          eigenvalues; */

/*        ierr is set to */
/*          zero       for normal return, */
/*          j          if the j-th eigenvalue has not been */
/*                     determined after 30 iterations. */

/*     ------------------------------------------------------------------ */

/*      real*8 d(n), e(n), z(n), b, c, f, g, p, r, s, machep */
/*      real*8 dsqrt, dabs, dsign, d1mach */

/*      machep=d1mach(4) */
    /* Parameter adjustments */
    --z__;
    --e;
    --d__;

    /* Function Body */
/* Table of constant values */
    machep = pow(2, -52);

    *ierr = 0;
    if (*n == 1) {
        goto L1001;
    }

    e[*n] = 0.;
    i__1 = *n;
    for (l = 1; l <= i__1; ++l) {
	j = 0;
/*     :::::::::: look for small sub-diagonal element :::::::::: */
L105:
        i__2 = *n;
        for (m = l; m <= i__2; ++m) {
            if (m == *n) {
                goto L120;
            }
            if ((d__1 = e[m], ABS(d__1)) <= machep * ((d__2 = d__[m], ABS(
                    d__2)) + (d__3 = d__[m + 1], ABS(d__3)))) {
                goto L120;
            }
/* L110: */
	}

L120:
	p = d__[l];
	if (m == l) {
	    goto L240;
	}
	if (j == 50) {// was 30 in the original version
	    goto L1000;
	}
	++j;
/*     :::::::::: form shift :::::::::: */
	g = (d__[l + 1] - p) / (e[l] * 2.);
	r__ = sqrt(g * g + 1.);
	g = d__[m] - p + e[l] / (g + dsign(r__, g));
	s = 1.;
	c__ = 1.;
	p = 0.;
	mml = m - l;

/*     :::::::::: for i=m-1 step -1 until l do -- :::::::::: */
	i__2 = mml;
	for (ii = 1; ii <= i__2; ++ii) {
	    i__ = m - ii;
	    f = s * e[i__];
	    b = c__ * e[i__];
	    if (ABS(f) < ABS(g)) {
		goto L150;
	    }
	    c__ = g / f;
	    r__ = sqrt(c__ * c__ + 1.);
	    e[i__ + 1] = f * r__;
	    s = 1. / r__;
	    c__ *= s;
	    goto L160;
L150:
	    s = f / g;
	    r__ = sqrt(s * s + 1.);
	    e[i__ + 1] = g * r__;
	    c__ = 1. / r__;
	    s *= c__;
L160:
	    g = d__[i__ + 1] - p;
	    r__ = (d__[i__] - g) * s + c__ * 2. * b;
	    p = s * r__;
	    d__[i__ + 1] = g + p;
	    g = c__ * r__ - b;
/*     :::::::::: form first component of vector :::::::::: */
	    f = z__[i__ + 1];
	    z__[i__ + 1] = s * z__[i__] + c__ * f;
/*  200       z(i) = c * z(i) - s * f */
	    z__[i__] = c__ * z__[i__] - s * f;
/* L200: */
	}

	d__[l] -= p;
	e[l] = g;
	e[m] = 0.;
	goto L105;
L240:
	;
    }

/*     :::::::::: order eigenvalues and eigenvectors :::::::::: */
    i__1 = *n;
    for (ii = 2; ii <= i__1; ++ii) {
	i__ = ii - 1;
	k = i__;
	p = d__[i__];

	i__2 = *n;
	for (j = ii; j <= i__2; ++j) {
	    if (d__[j] >= p) {
		goto L260;
	    }
	    k = j;
	    p = d__[j];
L260:
	    ;
	}

	if (k == i__) {
	    goto L300;
	}
	d__[k] = d__[i__];
	d__[i__] = p;
	p = z__[i__];
	z__[i__] = z__[k];
	z__[k] = p;
L300:
	;
    }

    goto L1001;
/*     :::::::::: set error -- no convergence to an */
/*                eigenvalue after 30 iterations :::::::::: */
L1000:
    *ierr = l;
L1001:
    return 0;
/*     :::::::::: last card of gausq2 :::::::::: */
} /* gausq2_ */

/*
 * @since 2017.3.1, 4.6
 */
static double integrate(double (* func)(double x, void *param), const double *x, void *param, void *dist_param) {
    dist_gamma_gaussq_t *gg = (dist_gamma_gaussq_t *) dist_param;
    double alpha = x[0];//shape
    double beta = x[1];//scale
    int n = gg->n;
    double *a = gg->a, *z = gg->z;
    if (!(alpha == gg->alpha && beta == gg->beta)) {
        gg->alpha = alpha;
        gg->beta = beta;
        double *b = gg->b;
        for (int i = 0; i < n; i++) {
            a[i] = alpha + 2 * i;
            z[i] = 0;
        }
        z[0] = 1;
        for (int i = 1; i < n; i++)
            b[i - 1] = sqrt(i * (i + alpha - 1));
        b[n - 1] = 0;
        int ierr = 0;
        gausq2_(&n, a, b, z, &ierr);
        if (ierr != 0)
            ERROR_MSG_LMA("Numerical instability encountered! shape = %g; scale = %g\n", alpha, beta);
        for (int k = 0; k < n; k++) {
            a[k] *= beta; //abscissas
            z[k] *= z[k]; //weight
        }
    }
    double re = 0;
    if (gg->neg) {
        for (int k = 0; k < n; k++)
            re += func(-a[k], param) * z[k];
    } else {
        for (int k = 0; k < n; k++)
            re += func(a[k], param) * z[k];
    }
    return re;
}

/*
 * @since 2017.4.6
 */
static void free_param(void *param) {
    dist_gamma_gaussq_t *gg = (dist_gamma_gaussq_t *) param;
    matrixalloc_1d_free(gg->z);
    matrixalloc_1d_free(gg->b);
    matrixalloc_1d_free(gg->a);
    matrixalloc_1d_free(gg);
}

static dist_type_t type(void) {
    return GAMMA_DIST;
}

/*
 * @since 2017.4.6
 */
dist_t dist_gamma_gaussq(int n, bool neg, char **msg) {
    if (n < 1) {
        PRINT_ERRMSG(msg, "The degree of Gaussian quadrature should be at least 1. But n = %i.", n);
        return NULL;
    }
    dist_gamma_gaussq_t *gg = matrixalloc_1d(1, sizeof (*gg));
    gg->n = n;
    gg->neg = neg;
    gg->sign = (neg ? -1 : 1);
    gg->alpha = -1;
    gg->beta = -1;
    gg->a = matrixalloc_1d(n, sizeof (double));
    gg->b = matrixalloc_1d(n, sizeof (double));
    gg->z = matrixalloc_1d(n, sizeof (double));
    
    dist_t re = matrixalloc_1d(1, sizeof (*re));
    re->param = gg;
    re->free_param = free_param;
    re->type = type;
    re->integrate = integrate;
    msg[0] = NULL;
    return re;
}