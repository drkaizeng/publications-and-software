/* 
 * Created on 23 February 2017, 12:39
 */

#ifndef DFEML_DEF_H
#    define DFEML_DEF_H

#include "dfeml.h"

struct dfeml_builder_tag {
    /**
     * 0: A newly created object
     * 1: Algorithm has been added
     */
    int mode;
    dfe_t d;
    int num_searches;
    double imprftol; 
    int nnoimp;
    int maximp;
    
    nlopt_algorithm nlopt_alg;
    double rftol; 
    int maxeval;
    double maxtime;
};

struct dfeml_tag {
    int num_searches;
    double imprftol; 
    int nnoimp;
    int maximp;
    dfe_t d;
    int num_param_full;
    int num_free_param;
    nlopt_opt nlopt;
};

#endif /* DFEML_DEF_H */

