#include <string.h>
#include <math.h>
#include <float.h>

#include "vardfe_def.h"

#include "util/matrixalloc.h"
#include "util/arrayutil.h"

/*
 * @since 2017.4.11, 4.12, 4.26, 9.6
 */
void vardfe_init(vardfe_t vd) {
    vd->dsfs = matrixalloc_2d_d_init(vd->data_len, vd->num_param_full);
    
    vd->nx = vd->num_param_full - vd->nr;
    vd->x = matrixalloc_1d(vd->nx, sizeof (*vd->x));
    
    vd->is_free = matrixalloc_1d(vd->nx, sizeof (*vd->is_free));
    arrayutil_fill_b(vd->is_free, 0, vd->nx, true);
    
    vd->has_der = matrixalloc_1d(vd->nx, sizeof (*vd->has_der));
    arrayutil_fill_b(vd->has_der, 0, vd->nx, true);
    
    vd->xi = matrixalloc_1d(vd->nx, sizeof (*vd->xi));
    vd->cf = matrixalloc_1d(vd->nx, sizeof (*vd->cf));
    for (int i = 0; i < vd->nx; i++) {
        vd->xi[i] = i;
        vd->cf[i] = NULL;
    }
}

/*
 * @since 2017.2.19, 4.16 (no cf), 5.22 (only the cf part), 9.6
 */
void vardfe_free(vardfe_t *vd) {
    for (int i = 0; i < vd[0]->nx; i++) {
        if (vd[0]->cf[i] != NULL) {
            constraint_func_free(&(vd[0]->cf[i]));
        }
    }
    matrixalloc_1d_free(vd[0]->cf);
    matrixalloc_1d_free(vd[0]->xi);
    matrixalloc_1d_free(vd[0]->has_der);
    matrixalloc_1d_free(vd[0]->is_free);
    matrixalloc_1d_free(vd[0]->x);
    vd[0]->free_dfe(vd[0]->dfe);
    matrixalloc_2d_d_free(vd[0]->ranges);
    for (int i = 0; i < vd[0]->num_param_full; i++) 
        matrixalloc_1d_free(vd[0]->param_names[i]);
    matrixalloc_1d_free(vd[0]->param_names);
    matrixalloc_1d_free(vd[0]->param_types);
    matrixalloc_2d_d_free(vd[0]->dsfs);
    matrixalloc_1d_free(vd[0]->sfs);
    matrixalloc_1d_free(vd[0]->data);
    matrixalloc_1d_free(vd[0]);
    vd[0] = NULL;
}

/*
 * @since 2017.9.6
 */
int vardfe_n(vardfe_t vd) {
    return vd->n;
}

/*
 * @since 2017.2.16, 2.26, 4.11, 9.6
 */
int vardfe_num_free_param(vardfe_t vd) {
    return vd->num_free_param;
}

/*
 * @since 2017.4.19, 9.6
 */
int vardfe_num_free_param_no_r(vardfe_t vd) {
    return vd->num_free_param - vd->nr;
}

/*
 * @since 2017.2.16, 2.26, 4.11, 9.6
 */
int vardfe_num_param_full(vardfe_t vd) {
    return vd->num_param_full;
}

/*
 * @since 2017.4.19, 9.6
 */
int vardfe_num_param_full_no_r(vardfe_t vd) {
    return vd->num_param_full - vd->nr;
}

/*
 * @since 2017.2.23, 2.26, 4.11, 9.6
 */
int vardfe_num_r(vardfe_t vd) {
    return vd->nr;
}

/*
 * @since 2017.9.6
 */
param_t * vardfe_param_types_full(vardfe_t vd) {
    return matrixalloc_1d_clone(vd->param_types, vd->num_param_full, sizeof (*vd->param_types));
}

/*
 * @since 2017.2.23, 2.26, 4.14, 9.6
 */
param_t * vardfe_param_types_full_no_r(vardfe_t vd) {
    return matrixalloc_1d_clone(vd->param_types, vd->nx, sizeof (*vd->param_types));
}

/*
 * @since 2017.4.14, 9.6
 */
char ** vardfe_param_names_full(vardfe_t vd) {
    char **re = matrixalloc_1d(vd->num_param_full, sizeof (char *));
    for (int i = 0; i < vd->num_param_full; i++)
        re[i] = matrixalloc_1d_clone(vd->param_names[i], (int) strlen(vd->param_names[i]) + 1, sizeof (char));
    return re;
}

/*
 * @since 2017.2.23, 2.26, 9.6
 */
char ** vardfe_param_names_full_no_r(vardfe_t vd) {
    char **re = matrixalloc_1d(vd->nx, sizeof (char *));
    for (int i = 0; i < vd->nx; i++)
        re[i] = matrixalloc_1d_clone(vd->param_names[i], (int) strlen(vd->param_names[i]) + 1, sizeof (char));
    return re;
}

/*
 * @since 2017.2.23, 2.26, 9.6
 */
param_t * vardfe_free_x_types(vardfe_t vd) {
    param_t *re = matrixalloc_1d(vd->num_free_param - vd->nr, sizeof (*re));
    for (int i = 0, j = 0; i < vd->nx; i++) 
        if (vd->is_free[i])
            re[j++] = vd->param_types[i];
    return re;
}

/*
 * @since 2017.4.14, 9.6
 */
param_t * vardfe_free_param_types(vardfe_t vd) {
    param_t *re = matrixalloc_1d(vd->num_free_param, sizeof (*re));
    int j = 0;
    for (int i = 0; i < vd->nx; i++) 
        if (vd->is_free[i])
            re[j++] = vd->param_types[i];
    for (int i = 0; i < vd->nr; i++)
        re[j++] = vd->param_types[vd->nx + i];
    return re;
}

/*
 * @since 2017.2.23, 2.26, 9.6
 */
char ** vardfe_free_x_names(vardfe_t vd) {
    char **re = matrixalloc_1d(vd->num_free_param - vd->nr, sizeof (char *));
    for (int i = 0, j = 0; i < vd->nx; i++) 
        if (vd->is_free[i])
            re[j++] = matrixalloc_1d_clone(vd->param_names[i], (int) strlen(vd->param_names[i]) + 1, sizeof (char));
    return re;
}

/*
 * @since 2017.4.14, 9.6
 */
char ** vardfe_free_param_names(vardfe_t vd) {
    char **re = matrixalloc_1d(vd->num_free_param, sizeof (char *));
    int j = 0;
    for (int i = 0; i < vd->nx; i++) 
        if (vd->is_free[i])
            re[j++] = matrixalloc_1d_clone(vd->param_names[i], (int) strlen(vd->param_names[i]) + 1, sizeof (char));
    for (int i = 0; i < vd->nr; i++)
        re[j++] = matrixalloc_1d_clone(vd->param_names[vd->nx + i], (int) strlen(vd->param_names[vd->nx + i]) + 1, sizeof (char));
    return re;
}

/*
 * @since 2017.2.23, 2.26, 9.6
 */
bool * vardfe_x_is_free(vardfe_t vd) {
    return matrixalloc_1d_clone(vd->is_free, vd->nx, sizeof (*vd->is_free));
}

/*
 * @since 2017.4.11 (no cf), 4.16 (no cf), 4.28 (no cf), 5.22 (with cf), 9.6
 */
void vardfe_free_x_to_all_x(double *all_x, const double *free_x, vardfe_t vd) {
    int *xi = vd->xi;
    for (int i = 0; i < vd->nx; i++) {
        if (xi[i] == -1)//constant
            all_x[i] = vd->x[i];
        else if (vd->is_free[i])
            all_x[i] = free_x[xi[i]];
    }
    for (int i = 0; i < vd->nx; i++) {
        constraint_func_t *cf = vd->cf[i];
        if (cf != NULL) {
            for (int j = 0; j < cf->nx; j++) 
                cf->x[j] = all_x[cf->xi[j]];
                
            all_x[i] = cf->f(cf->x, cf->param);
        }
    }
}

/*
 * @since 2017.2.23, 2.28, 4.11, 4.28
 */
void vardfe_all_x_to_free_x(double *free_x, const double *all_x, vardfe_t vd) {
    for (int i = 0, j = 0; i < vd->nx; i++) 
        if (vd->is_free[i]) 
            free_x[j++] = all_x[i];
}

/*
 * @since 2017.2.23, 2.26, 4.14, 9.6
 */
double ** vardfe_free_x_ranges(vardfe_t vd) {
    double **re = matrixalloc_2d_d(2, vd->num_free_param - vd->nr);
    for (int i = 0, j = 0; i < vd->nx; i++) 
        if (vd->is_free[i]) {
            re[0][j] = vd->ranges[0][i];
            re[1][j] = vd->ranges[1][i];
            j++;
        }
    return re;
}

/*
 * @since 2017.2.16, 2.28, 4.11 (no cf), 5.22 (with cf), 9.6
 */
double vardfe_lnlike(double *gradx, double *gradr, const double *x, const double *r, vardfe_t vd) {
    vardfe_free_x_to_all_x(vd->x, x, vd);
    int data_len = vd->data_len;
    double *data = vd->data;
    double *sfs = vd->sfs;
    double **dsfs = vd->dsfs;
    if (gradx == NULL)//gradr must also be NULL
        vd->cal(sfs, NULL, vd->x, r, vd->has_der, vd->dfe);
    else 
        vd->cal(sfs, dsfs, vd->x, r, vd->has_der, vd->dfe);
    double re = 0;
    for (int i = 0; i < data_len; i++) {
        if (sfs[i] <= 0) //possible loss of accuracy due to numerical instability
            sfs[i] = DBL_MIN;
        re += -sfs[i] + data[i] * log(sfs[i]);
    }
    if (gradx != NULL) {
        int *xi = vd->xi;
        for (int j = 0; j < data_len; j++)
            sfs[j] = -1 + data[j] / sfs[j];
        for (int i = 0; i < vd->nx; i++) {
            if (xi[i] == -1)//constant
                continue;
            double tmp = 0;
            for (int j = 0; j < data_len; j++)
                tmp += sfs[j] * dsfs[j][i];
            if (vd->is_free[i] == false) {
                constraint_func_t *cf = vd->cf[i];
                for (int j = 0; j < cf->nx; j++) {
                    double tmp2 = cf->df(cf->x, j, cf->param);//cf->x was updated at the beginning of this function by the call to snpdfe_free_param_to_all_param()
                    gradx[xi[cf->xi[j]]] += tmp * tmp2;
                }
            } else 
                gradx[xi[i]] += tmp;
        }
        
        for (int i = 0, j = vd->nx; i < vd->nr; i++, j++) {//r are always free within vardfe
            double tmp = 0;
            for (int k = 0; k < data_len; k++)
                tmp += sfs[k] * dsfs[k][j];
            gradr[i] += tmp;
        }
    }
    return re;
}