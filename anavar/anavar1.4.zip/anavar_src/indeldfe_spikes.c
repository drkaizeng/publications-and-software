#include <string.h>

#include "indeldfe_def.h"
#include "tau.h"
#include "print_errmsg.h"
#include "param.h"
#include "get_name.h"

#include "util/matrixalloc.h"
#include "util/string_util.h"
#include "dfeio.h"
#include "find_name.h"

typedef struct {
    int n;
    double m;
    int c;
    int nthreads;

    tau_t tau;//
    /*
     * t[0] is for insertions and t[1] for deletions. <br>
     * t[0][c][i] is tau[i] determined by gamma for the insertions in site class c
     */
    double **t[2];
    double **dt[2];//d(t[0][c][i])/d(gamma) is d(tau[i])/d(gamma) for the insertions in site class c.
} indeldfe_spikes_t;

/*
 * @since 2017.9.7
 */
static void free_dfe(void *dfe) {
    indeldfe_spikes_t *spi = (indeldfe_spikes_t *) dfe;
    for (int i = 0; i < 2; i++) {
        matrixalloc_2d_d_free(spi->t[i]);
        matrixalloc_2d_d_free(spi->dt[i]);
    }
    tau_free(&(spi->tau));
    matrixalloc_1d_free(spi);
}

/*
 * @since 2017.5.1, 9.7
 */
static void get_t_dt(indeldfe_spikes_t *ip, const double *x, double **dsfs, const bool *has_der) {
    tau_t tau = ip->tau;
    int n = ip->n;
    double ***t = ip->t;
    double ***dt = ip->dt;
    for (int k = 0; k < 2; k++) {
        for (int i = 1, i1 = 0; i < n; i++, i1++) {
            for (int c = 0, gi = k * 3 + 1; c < ip->c; c++, gi += 6) {
                t[k][c][i1] = tau_cal(i, x[gi], tau);
                if (dsfs != NULL && has_der[gi])
                    dt[k][c][i1] = tau_der(i, x[gi], tau);
            }
        }
    }
}

/*
 * @since 2017.9.7
 */
static void cal_no_r(double *sfs, double **dsfs, const double *x, const double *r, const bool *has_der, void *dfe) {
    indeldfe_spikes_t *ip = (indeldfe_spikes_t *) dfe;
    get_t_dt(ip, x, dsfs, has_der);
    int n = ip->n;
    double m = ip->m;
    double ***t = ip->t, ***dt = ip->dt;
    for (int i = 1, j, jd, nj; i < n; i++) {
        j = i - 1;
        jd = n - 1 + j;
        nj = n - i - 1;
        sfs[j] = 0;
        sfs[jd] = 0;
        int ti = 0, gi = 1, ei = 2;
        int td = 3, gd = 4, ed = 5;
        for (int c = 0; c < ip->c; c++) {
            sfs[j] += (1 - x[ei]) * m * x[ti] * t[0][c][j] + x[ed] * m * x[td] * t[1][c][nj];
            sfs[jd] += (1 - x[ed]) * m * x[td] * t[1][c][j] + x[ei] * m * x[ti] * t[0][c][nj];
            if (dsfs != NULL) {
                if (has_der[ti]) {
                    dsfs[j][ti] = (1 - x[ei]) * m * t[0][c][j];
                    dsfs[jd][ti] = x[ei] * m * t[0][c][nj];
                }
                if (has_der[gi]) {
                    dsfs[j][gi] = (1 - x[ei]) * m * x[ti] * dt[0][c][j];
                    dsfs[jd][gi] = x[ei] * m * x[ti] * dt[0][c][nj];
                }
                if (has_der[ei]) {
                    dsfs[j][ei] = -m * x[ti] * t[0][c][j];
                    dsfs[jd][ei] = m * x[ti] * t[0][c][nj];
                }
                if (has_der[td]) {
                    dsfs[j][td] = x[ed] * m * t[1][c][nj];
                    dsfs[jd][td] = (1 - x[ed]) * m * t[1][c][j];
                }
                if (has_der[gd]) {
                    dsfs[j][gd] = x[ed] * m * x[td] * dt[1][c][nj];
                    dsfs[jd][gd] = (1 - x[ed]) * m * x[td] * dt[1][c][j];
                }
                if (has_der[ed]) {
                    dsfs[j][ed] = m * x[td] * t[1][c][nj];
                    dsfs[jd][ed] = -m * x[td] * t[1][c][j];
                }
            }
            ti += 6, gi += 6, ei += 6;
            td += 6, gd += 6, ed += 6;
        }
    }
}

/*
 * @since 2017.5.1, 9.7
 */
static void cal_use_r(double *sfs, double **dsfs, const double *x, const double *r, const bool *has_der, void *dfe) {
    indeldfe_spikes_t *ip = (indeldfe_spikes_t *) dfe;
    get_t_dt(ip, x, dsfs, has_der);
    int n = ip->n;
    double m = ip->m;
    double ***t = ip->t, ***dt = ip->dt;
    int lo = 6 * ip->c, hi = lo + n - 2;
    if (dsfs != NULL) {
        int cnt = 2 * (n - 1);
        for (int i = 0; i < cnt; i++)//has_der is always true for the r parameters
            for (int j = lo; j < hi; j++)
                dsfs[i][j] = 0;
    }
    for (int i = 1, j, jd, nj; i < n; i++) {
        j = i - 1;
        jd = n - 1 + j;
        nj = n - i - 1;
        sfs[j] = 0;
        sfs[jd] = 0;
        double riv = (i == 1 ? 1 : r[i - 2]);
        double rniv = (i == n - 1 ? 1 : r[n - i - 2]);
        int ti = 0, gi = 1, ei = 2;
        int td = 3, gd = 4, ed = 5;
        for (int c = 0; c < ip->c; c++) {
            sfs[j] += (1 - x[ei]) * m * x[ti] * riv * t[0][c][j] + x[ed] * m * x[td] * rniv * t[1][c][nj];
            sfs[jd] += (1 - x[ed]) * m * x[td] * riv * t[1][c][j] + x[ei] * m * x[ti] * rniv * t[0][c][nj];
            if (dsfs != NULL) {
                if (has_der[ti]) {
                    dsfs[j][ti] = (1 - x[ei]) * m * riv * t[0][c][j];
                    dsfs[jd][ti] = x[ei] * m * rniv * t[0][c][nj];
                }
                if (has_der[gi]) {
                    dsfs[j][gi] = (1 - x[ei]) * m * x[ti] * riv * dt[0][c][j];
                    dsfs[jd][gi] = x[ei] * m * x[ti] * rniv * dt[0][c][nj];
                }
                if (has_der[ei]) {
                    dsfs[j][ei] = -m * x[ti] * riv * t[0][c][j];
                    dsfs[jd][ei] = m * x[ti] * rniv * t[0][c][nj];
                }
                if (has_der[td]) {
                    dsfs[j][td] = x[ed] * m * rniv * t[1][c][nj];
                    dsfs[jd][td] = (1 - x[ed]) * m * riv * t[1][c][j];
                }
                if (has_der[gd]) {
                    dsfs[j][gd] = x[ed] * m * x[td] * rniv * dt[1][c][nj];
                    dsfs[jd][gd] = (1 - x[ed]) * m * x[td] * riv * dt[1][c][j];
                }
                if (has_der[ed]) {
                    dsfs[j][ed] = m * x[td] * rniv * t[1][c][nj];
                    dsfs[jd][ed] = -m * x[td] * riv * t[1][c][j];
                }
                if (i == n - i && i > 1) {
                    dsfs[j][lo + i - 2] += (1 - x[ei]) * m * x[ti] * t[0][c][j] + x[ed] * m * x[td] * t[1][c][nj];
                    dsfs[jd][lo + i - 2] += (1 - x[ed]) * m * x[td] * t[1][c][j] + x[ei] * m * x[ti] * t[0][c][nj];
                } else if (i == 1) {
                    dsfs[j][lo + n - 3] += x[ed] * m * x[td] * t[1][c][nj];
                    dsfs[jd][lo + n - 3] += x[ei] * m * x[ti] * t[0][c][nj]; 
                } else if (i == n - 1) {
                    dsfs[j][lo + i - 2] += (1 - x[ei]) * m * x[ti] * t[0][c][j];
                    dsfs[jd][lo + i - 2] += (1 - x[ed]) * m * x[td] * t[1][c][j]; 
                } else {
                    dsfs[j][lo + i - 2] += (1 - x[ei]) * m * x[ti] * t[0][c][j];
                    dsfs[jd][lo + i - 2] += (1 - x[ed]) * m * x[td] * t[1][c][j]; 
                    
                    dsfs[j][lo + n - i - 2] += x[ed] * m * x[td] * t[1][c][nj];
                    dsfs[jd][lo + n - i - 2] += x[ei] * m * x[ti] * t[0][c][nj]; 
                }
            }
            ti += 6, gi += 6, ei += 6;
            td += 6, gd += 6, ed += 6;
        }
    }
}

/*
 * @since 2017.5.8, 5.9, 6.16, 9.7
 */
static void neutral(indeldfe_builder_t ib, char **msg) {
    int c = ((indeldfe_spikes_t *) ib->vd->dfe)->c;
    if (c != 1) {
        PRINT_ERRMSG(msg, "When all sites are neutral, only one site class can be used.");
        return;
    }
    vardfe_t vd = ib->vd;
    vd->num_free_param -= 2;//ins_gamma = del_gamma = 0
    vd->x[1] = vd->x[4] = 0;
    vd->is_free[1] = vd->is_free[4] = false;
    vd->has_der[1] = vd->has_der[4] = false;
    vd->xi[1] = vd->xi[4] = -1;
    for (int i = 0, j = 0; i < vd->nx; i++) {
        if (vd->xi[i] >= 0) {
            vd->xi[i] = j;
            j++;
        }
    }
}

/*
 * @since 2018.1.31, 2.2
 */
static void fixed(indeldfe_builder_t ib, char **msg, const char *name) {
    char *n = dfeio_remove_square_brackets(name + strlen("fixed"), msg);
    if (msg[0] != NULL) {
        PRINT_ERRMSG(msg, "Problems found in constraint = %s.\n%s", name, msg[0]);
        return;
    }
    char *n2 = string_util_trim(n);
    int cnt;
    char **sarr = string_util_split(n2, ",", &cnt);
    if (cnt <= 0) {
        PRINT_ERRMSG(msg, "Problems found in constraint = %s.", name);
        return;
    }
    vardfe_t vd = ib->vd;
    for (int i = 0; i < cnt; i++) {
        char *pn;
        double v;
        dfeio_get_param_value(&pn, &v, sarr[i], msg);
        if (msg[0] != NULL) {
            PRINT_ERRMSG(msg, "Problems found in constraint = %s.\n%s", name, msg[0]);
            return;
        }
        int indx = find_name(pn, vd->num_param_full, vd->param_names);
        if (indx < 0) {
            PRINT_ERRMSG(msg, "Invalid parameter name = %s in constraint = %s.", pn, name);
            return;
        }
        if (indx >= vd->nx) {
            PRINT_ERRMSG(msg, "Fixing %s is not permitted.", pn);
            return;
        }
        if (vd->is_free[indx] == false) {
            PRINT_ERRMSG(msg, "%s appears more than once in constraint = %s.", pn, name);
            return;
        }
        vd->num_free_param--;
        if (vd->param_types[indx] == ERR && (v < 0 || v > 1)) {
            PRINT_ERRMSG(msg, "In constraint = %s: invalid value for polarisation error parameters = %g.", name, v);
            return;
        }
        if (vd->param_types[indx] == THETA && (v <= 0)) {
            PRINT_ERRMSG(msg, "In constraint = %s: invalid value for theta = %g.", name, v);
            return;
        }
        vd->x[indx] = v;
        vd->is_free[indx] = false;
        vd->has_der[indx] = false;
        vd->xi[indx] = -1;
    }
    for (int i = 0, j = 0; i < vd->nx; i++) {
        if (vd->xi[i] >= 0) {
            vd->xi[i] = j;
            j++;
        }
    }
    M1D_FREE(n);
    M1D_FREE(sarr);
}

/*
 * @since 2017.5.8, 9.7; 2018.1.31 (added fixed)
 */
static void add_constraint(indeldfe_builder_t sb, char **msg, const char *name, va_list args) {
    msg[0] = NULL;
    
    if (strcmp(name, "none") == 0)
        return;
    else if(strcmp(name, "neutral") == 0)
        neutral(sb, msg);
    else if (string_util_starts_with(name, "fixed")) {
        fixed(sb, msg, name);
    } else {
        PRINT_ERRMSG(msg, "Unknown constraint = %s\n.", name);
    }
}

/*
 * @since 2017.5.1, 9.7
 */
void indeldfe_builder_add_spikes(indeldfe_builder_t ib, int c, double ranges[c][6][2], char **msg) {
    msg[0] = NULL;
    
    if (ib->mode != 1)
        ERROR_MSG_LMA("sb->mode != 1\n");
    if (ib->dist != -1)
        ERROR_MSG_LMA("sb->dist != -1\n");
    if (c < 1) {
        PRINT_ERRMSG(msg, "The number of SNP types, c, is less than 1\n");
        return;
    }
    
    ib->mode = 2;
    ib->dist = 0;
    
    indeldfe_spikes_t *spi = matrixalloc_1d(1, sizeof (*spi));
    spi->n = ib->vd->n;
    spi->m = ib->m;
    spi->c = c;
    spi->nthreads = ib->nthreads;
    spi->tau = tau_new(spi->n, &(ib->ig));//with multithreading, ig needs to be cloned.
    for (int i = 0; i < 2; i++) {
        spi->t[i] = matrixalloc_2d_d(c, spi->n - 1);
        spi->dt[i] = matrixalloc_2d_d(c, spi->n - 1);
    }
    
    ib->vd->num_param_full = 6 * c + ib->vd->nr;
    ib->vd->num_free_param = ib->vd->num_param_full;
    ib->vd->param_types = matrixalloc_1d(ib->vd->num_param_full, sizeof (param_t));
    ib->vd->param_names = matrixalloc_1d(ib->vd->num_param_full, sizeof (char *));
    for (int i = 0, j = 0; i < c; i++) {
        ib->vd->param_types[j] = THETA;
        ib->vd->param_names[j] = get_name2("%s%s_%i", ib->name, "ins_theta", i + 1);
        j++;
        ib->vd->param_types[j] = GAMMA;
        ib->vd->param_names[j] = get_name2("%s%s_%i", ib->name, "ins_gamma", i + 1);
        j++;
        ib->vd->param_types[j] = ERR;
        ib->vd->param_names[j] = get_name2("%s%s_%i", ib->name, "ins_e", i + 1);
        j++;
        ib->vd->param_types[j] = THETA;
        ib->vd->param_names[j] = get_name2("%s%s_%i", ib->name, "del_theta", i + 1);
        j++;
        ib->vd->param_types[j] = GAMMA;
        ib->vd->param_names[j] = get_name2("%s%s_%i", ib->name, "del_gamma", i + 1);
        j++;
        ib->vd->param_types[j] = ERR;
        ib->vd->param_names[j] = get_name2("%s%s_%i", ib->name, "del_e", i + 1);
        j++;
    }
    if (ib->use_r) {
        for (int i = 2, j = 6 * c; i < ib->vd->n; i++, j++) {
            ib->vd->param_types[j] = R;
            ib->vd->param_names[j] = get_name("r", i);
        }
    }
    ib->vd->dfe = spi;
    ib->vd->ranges = matrixalloc_2d_d(2, ib->vd->num_param_full - ib->vd->nr);
    for (int i = 0, pi = 0; i < c; i++) {
        for (int j = 0; j < 6; j++, pi++) {
            if (ranges[i][j][0] >= ranges[i][j][1]) {
                PRINT_ERRMSG(msg, "The range [%g, %g] for %s is invalid. "
                        "The lower bound should be strictly smaller than the upper bound\n",
                        ranges[i][j][0], ranges[i][j][1], ib->vd->param_names[pi]);
                return;
            }
            if (ib->vd->param_types[pi] == THETA && ranges[i][j][0] <= 0) {
                PRINT_ERRMSG(msg, "The lower bound for %s is %g, but it should be positive.\n",
                        ib->vd->param_names[pi], ranges[i][j][0]);
                return;
            }
            if (ib->vd->param_types[pi] == ERR && (ranges[i][j][0] < 0 || ranges[i][j][1] > 1)) {
                PRINT_ERRMSG(msg, "The bounds for %s is [%g, %g], but they should be in [0, 1].\n",
                        ib->vd->param_names[pi], ranges[i][j][0], ranges[i][j][1]);
                return;
            }
            ib->vd->ranges[0][pi] = ranges[i][j][0];
            ib->vd->ranges[1][pi] = ranges[i][j][1];
        }
    }
    
    ib->vd->free_dfe = free_dfe;
    if (ib->use_r)
        ib->vd->cal = cal_use_r;
    else
        ib->vd->cal = cal_no_r;
    
    ib->add_constraint = add_constraint;
    
    vardfe_init(ib->vd);
}