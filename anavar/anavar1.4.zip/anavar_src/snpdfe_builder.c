/* 
 * Created on 13 February 2017, 22:04
 */
#include <string.h>

#include "snpdfe_def.h"
#include "print_errmsg.h"

#include "util/matrixalloc.h"
#include "util/error_msg.h"
#include "util/arrayutil.h"

/*
 * @since 2017.2.16, 2.19 (spike), 2.28 (gamma_continuous), 3.19 (gamma_continuous), 4.10
 * 2017.4.19 (changed to vardfe), 9.6
 */
snpdfe_builder_t snpdfe_builder_new(int n, integrator_t *ig, int nthreads, bool use_r, const char *name, char **msg) {
    msg[0] = NULL;
    if (n < 4) {
        PRINT_ERRMSG(msg, "n < 4\n");
        return NULL;
    }
    if (nthreads < 1) {
        PRINT_ERRMSG(msg, "nthreads < 1\n");
        return NULL;
    }
    
    snpdfe_builder_t sb = matrixalloc_1d(1, sizeof (*sb));
    sb->mode = 0;
    sb->dist = -1;
    sb->vd = matrixalloc_1d(1, sizeof (*(sb->vd)));
    sb->vd->type = SNP;
    sb->vd->n = n;
    sb->ig = ig[0];
    ig[0] = NULL;
    sb->nthreads = nthreads;
    sb->use_r = use_r;
    sb->name = matrixalloc_1d_clone(name, (int) strlen(name) + 1, sizeof (char));
    return sb;
}

/*
 * @since 2017.2.16, 2.19 (spike), 2.28 (gamma_continuous), 3.19 (gamma_continuous), 4.6
 * 4.19 (changed to vardfe), 9.6
 */
void snpdfe_builder_add_data(snpdfe_builder_t sb, double m, bool folded, double *data, char **msg) {
    msg[0] = NULL;
    if (sb->mode != 0) 
        ERROR_MSG_LMA("sb->mode != 0\n");
    sb->mode = 1;
    if (m < 1) {
        PRINT_ERRMSG(msg, "m < 1\n");
        return;
    }
    {
        int upper;
        if (folded)
            upper = sb->vd->n / 2;
        else
            upper = sb->vd->n - 1;
        for (int i = 0; i < upper; i++)
            if (data[i] < 0) {
                PRINT_ERRMSG(msg, "SNP sfs[%i] < 0\n", i + 1);
                return;
            }
    }
    sb->m = m;
    sb->folded = folded;
    if (folded)
        sb->vd->data_len = sb->vd->n / 2;
    else
        sb->vd->data_len = sb->vd->n - 1;
    sb->vd->data = matrixalloc_1d_clone(data, sb->vd->data_len, sizeof (double));
    sb->vd->sfs = matrixalloc_1d(sb->vd->data_len, sizeof (double));
    if (sb->use_r)
        sb->vd->nr = sb->vd->data_len - 1;
    else
        sb->vd->nr = 0;
}


/*
 * @since 2017.4.12, 9.6
 */
void snpdfe_builder_add_constraint(snpdfe_builder_t sb, char **msg, const char *name, ...) {
    if (sb->mode != 2)
        ERROR_MSG_LMA("sb->mode != 2\n");
    
    sb->mode = 3;
    
    va_list args;
    va_start(args, name);
    sb->add_constraint(sb, msg, name, args);
    va_end(args);
    
    
//    int ids[2];
//    const char *names[2] = {dep, indep};
//    for (int i = 0; i < 2; i++) {
//        ids[i] = find_name(names[i], sb->num_param_full, sb->param_names);
//        if (ids[i] < 0) {
//            PRINT_ERRMSG(msg, "Unknown parameter %s\n", names[i]);
//            return;
//        }
//        if (sb->param_types[ids[i]] == R) {
//            PRINT_ERRMSG(msg, "We can't get the r parameters in any constraints\n");
//            return;
//        }
//        if (sb->in_constr[ids[i]]) {
//            PRINT_ERRMSG(msg, "The parameter, %s, has been used by another constraint!\n", names[i]);
//            return;
//        }
//        sb->in_constr[ids[i]] = true;
//    }
//    if (ids[0] == ids[1]) {
//        PRINT_ERRMSG(msg, "The same parameter, %s, has been used as both the dependent and independent parameters in the constraint!\n", dep);
//        return;
//    }
////    if (sb->param_types[ids[0]] != sb->param_types[ids[1]]) {
////        PRINT_ERRMSG(msg, "The dependent (%s) and independent (%s) parameters in the constraint are not of the same type!\n", dep, indep);
////        return;
////    }
//    sb->num_free_param--;
//    sb->is_free[ids[0]] = false;
//    sb->xi[ids[0]] = sb->xi[ids[1]];
//    for (int i = ids[0] + 1; i < sb->nx; i++)
//        if (sb->xi[i] >= 0)
//            sb->xi[i]--;
//    if (ids[0] < ids[1])
//        sb->xi[ids[0]]--;
//    
//    constraint_func_t *cf = matrixalloc_1d(1, sizeof (*cf));
//    cf->f = f;
//    cf->df = df;
//    cf->param = param;
//    cf->free_param = free_param;
//    sb->cf[ids[0]] = cf;
//    
//    msg[0] = NULL;
}

/*
 * @since 2017.4.19, 9.6
 */
vardfe_t snpdfe_builder_build(snpdfe_builder_t *sb, char **msg) {
    msg[0] = NULL;
    
    if (sb[0]->mode < 2)
        ERROR_MSG_LMA("error\n");
    
    vardfe_t re = sb[0]->vd;
    if (re->num_free_param <= 0) {
        PRINT_ERRMSG(msg, "There is no free parameter to be estimated!");
        return NULL;
    }
    
    matrixalloc_1d_free(sb[0]->name);
    matrixalloc_1d_free(sb[0]);
    sb[0] = NULL;
    
    return re;
}