#ifndef VARDFE_H
#define VARDFE_H

#include <stdbool.h>

#include "param.h"

typedef enum {
    SNP, INDEL
} vartype_t;

typedef struct vardfe_tag * vardfe_t;

void vardfe_free(vardfe_t *vd);

int vardfe_n(vardfe_t vd);

/**
 * The number of free parameters including r
 */
int vardfe_num_free_param(vardfe_t vd);

/**
 * The number of free parameters excluding r
 */
int vardfe_num_free_param_no_r(vardfe_t vd);

/**
 * The number of all the parameters in the full model including r without any constraints
 * @param sd
 * @return 
 */
int vardfe_num_param_full(vardfe_t vd);

/**
 * The number of all the parameters in the full model excluding r without any constraints
 * @param sd
 * @return 
 */
int vardfe_num_param_full_no_r(vardfe_t vd);

/**
 * The number of r parameters.
 */
int vardfe_num_r(vardfe_t vd);

/**
 * The types of all the parameters in the full model without any constraints including r.
 * The returned array should be freed (free(types)).
 */
param_t * vardfe_param_types_full(vardfe_t vd);

/**
 * The types of all the parameters in the full model without any constraints excluding the r parameters.
 * The returned array should be freed (free(types)).
 */
param_t * vardfe_param_types_full_no_r(vardfe_t vd);

/**
 * The names of all the parameters in the full model without any constraints including r.
 * The returned array should be freed (each element by free(names[i]) and then free(names)).
 */
char ** vardfe_param_names_full(vardfe_t vd);

/**
 * The names of all the parameters in the full model without any constraints, excluding the r parameters.
 * The returned array should be freed (each element by free(names[i]) and then free(names)).
 */
char ** vardfe_param_names_full_no_r(vardfe_t vd);


/**
 * The types of the free parameters excluding any r parameters.
 * The returned array should be freed (free(types)).
 */
param_t * vardfe_free_x_types(vardfe_t vd);

/**
 * The types of the free parameters including any r parameters.
 * The returned array should be freed (free(types)).
 */
param_t * vardfe_free_param_types(vardfe_t vd);

/**
 * The names of the free parameters excluding any r parameters.
 * The returned array should be freed (each element by free(names[i]) and then free(names)).
 */
char ** vardfe_free_x_names(vardfe_t vd);

/**
 * The names of the free parameters including any r parameters.
 * The returned array should be freed (each element by free(names[i]) and then free(names)).
 */
char ** vardfe_free_param_names(vardfe_t vd);

/**
 * Return an array of length (vardfe_num_param_full(sd) - vardfe_num_r(sd)) 
 * indicating whether the non-r parameters are free parameters.
 * The returned array should be freed.
 */
bool * vardfe_x_is_free(vardfe_t vd);

/**
 * Convert the array composed of free parameters, free_x, (excluding r) to one that composed of all the parameters under the full model, all_x (excluding r).
 * Both all_x and free_x are on the original scale
 */
void vardfe_free_x_to_all_x(double *all_x, const double *free_x, vardfe_t vd);

/**
 * Convert the array composed of all parameters excluding r to one that composed of free the parameters after all constraints have been considered (excluding r).
 * The values of the parameters in all_param that are not free are ignored.
 * Both all_x and free_x are on the original scale
 */
void vardfe_all_x_to_free_x(double *free_x, const double *all_x, vardfe_t vd);

/**
 * Return the ranges of all free parameters (excluding r). re[0][i] is the lower bound for parameter i and re[1][i] is the upper bound.
 * The returned matrix should be freed by using matrixalloc_2d_d_free(re).
 * All values are on the original scale.
 */
double ** vardfe_free_x_ranges(vardfe_t vd);

/**
 * @param gradx The gradient of x. The values are added directly by using gradx[i] += d(lnL)/d(x[i])
 * @param gradr The gradient of r. The values are added directly by using gradr[i] += d(lnL)/d(r[i])
 * @param x Contains num_free_param elements (less the r parameters); on the original scale
 * @param r Ignored if use_r is false; on the original scale
 */
double vardfe_lnlike(double *gradx, double *gradr, const double *x, const double *r, vardfe_t sd);

#endif /* VARDFE_H */

