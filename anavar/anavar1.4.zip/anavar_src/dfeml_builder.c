/* 
 * Created on 23 February 2017, 12:40
 */

#include "dfeml_def.h"
#include "print_errmsg.h"
#include "find_name.h"
#include "constants.h"

#include "util/matrixalloc.h"
#include "util/error_msg.h"

#include "nlopt.h"

/*
 * @since 2017.2.23, 4.16, 9.19
 */
dfeml_builder_t dfeml_builder_new(dfe_t *d, int num_searches, double imprftol, int nnoimp, int maximp, char **msg) {
    if (num_searches < 1) {
        PRINT_ERRMSG(msg, "num_searches < 1");
        return NULL;
    }
    if (imprftol <= 0 || imprftol >= 0.01) {
        PRINT_ERRMSG(msg, "imprftol <= 0 or imprftol >= 0.01");
        return NULL;
    }
    if (nnoimp < 1) {
        PRINT_ERRMSG(msg, "nnoimp < 1\n");
        return NULL;
    }
    if (maximp < 1) {
        PRINT_ERRMSG(msg, "maximp < 1\n");
        return NULL;
    }
    dfeml_builder_t db = matrixalloc_1d(1, sizeof (*db));
    db->mode = 0;
    db->d = d[0];
    d[0] = NULL;
    db->num_searches = num_searches;
    db->imprftol = imprftol;
    db->nnoimp = nnoimp;
    db->maximp = maximp;
    return db;
}

/*
 * @since 201
 */
static double nlopt_f(unsigned n, const double *x, double *grad, void *f_data) {
    return dfe_lnlike(grad, x, f_data);
}

/*
 * @since 2017.2.23, 4.16, 9.19
 */
void dfeml_builder_set_algorithm(dfeml_builder_t db, const char * algstr, 
        double rftol, int maxeval, double maxtime, char **msg) {
    if (db->mode != 0)
        ERROR_MSG_LMA("Failed\n");
    db->mode = 1;
    
    int num_alg = 6;
    const char *alg_name[num_alg];
    alg_name[0] = "NLOPT_LD_SLSQP"; 
    alg_name[1] = "NLOPT_LD_LBFGS";
    alg_name[2] = "NLOPT_LD_VAR1";
    alg_name[3] = "NLOPT_LD_VAR2";
    alg_name[4] = "NLOPT_LN_NELDERMEAD";  
    alg_name[5] = "NLOPT_LD_TNEWTON_PRECOND_RESTART";
    
    nlopt_algorithm alg_type[num_alg]; 
    alg_type[0] = NLOPT_LD_SLSQP; 
    alg_type[1] = NLOPT_LD_LBFGS;
    alg_type[2] = NLOPT_LD_VAR1;
    alg_type[3] = NLOPT_LD_VAR2;
    alg_type[4] = NLOPT_LN_NELDERMEAD; 
    alg_type[5] = NLOPT_LD_TNEWTON_PRECOND_RESTART;
    
    int id = find_name2(algstr, num_alg, alg_name);
    if (id < 0) {
        PRINT_ERRMSG(msg, "Unknown optimisation algorithm: %s", algstr);
        return;
    }
    
    if (rftol <= 0 || rftol >= 0.01) {
        PRINT_ERRMSG(msg, "rftol <= 0 or rftol >= 0.01\n");
        return;
    }
    if (maxeval < 1) {
        PRINT_ERRMSG(msg, "maxeval < 1\n");
        return;
    }
    if (maxtime <= 0) {
        PRINT_ERRMSG(msg, "maxtime <= 0\n");
        return;
    }
    db->nlopt_alg = alg_type[id];
    db->rftol = rftol;
    db->maxeval = maxeval;
    db->maxtime = maxtime;
}

/*
 * @since 2018.3.11, 3.13
 */
static nlopt_opt get_nlopt_opt(nlopt_algorithm nlopt_alg, unsigned num_free_param, 
        double rftol, int maxeval, double maxtime, dfe_t d) {
    nlopt_opt re = nlopt_create(nlopt_alg, num_free_param);
    if (re == NULL) 
        ERROR_MSG_LMA("Failed\n");
    if (nlopt_set_ftol_rel(re, rftol) != NLOPT_SUCCESS) 
        ERROR_MSG_LMA("\n");
    if (nlopt_set_maxeval(re, maxeval) != NLOPT_SUCCESS) 
        ERROR_MSG_LMA("\n");
    if (nlopt_set_maxtime(re, maxtime) != NLOPT_SUCCESS) 
        ERROR_MSG_LMA("\n");
    if (nlopt_set_max_objective(re, nlopt_f, d) != NLOPT_SUCCESS)
        ERROR_MSG_LMA("\n");
    double **ranges = dfe_ranges(d);
    if (nlopt_set_lower_bounds(re, ranges[0]) != NLOPT_SUCCESS) 
        ERROR_MSG_LMA("\n");
    if (nlopt_set_upper_bounds(re, ranges[1]) != NLOPT_SUCCESS) 
        ERROR_MSG_LMA("\n");
    matrixalloc_2d_d_free(ranges);
    return re;
}

/*
 * @since 2017.2.23, 4.16, 9.19, 2018.3.13 (added auglag)
 */
dfeml_t dfeml_builder_build(dfeml_builder_t *db) {
    if (db[0]->mode != 1)
        ERROR_MSG_LMA("Failed\n");
    
    dfeml_t dm = matrixalloc_1d(1, sizeof (*dm));
    dm->num_searches = db[0]->num_searches;
    dm->imprftol = db[0]->imprftol;
    dm->nnoimp = db[0]->nnoimp;
    dm->maximp = db[0]->maximp;
    dm->d = db[0]->d;
    dm->num_param_full = dfe_num_param_full(dm->d);
    dm->num_free_param = dfe_num_free_param(dm->d);
    dm->nlopt = NULL;
    if (dfe_use_auglag(dm->d) == true) {
        dm->nlopt = get_nlopt_opt(NLOPT_AUGLAG, (unsigned) dm->num_free_param,
                db[0]->rftol, db[0]->maxeval, db[0]->maxtime, db[0]->d);
        
        int num;
        nlopt_func *constr;
        bool *is_eq_constr;
        dfe_constr_data_t *constr_data;
        dfe_constraint(&num, &constr, &is_eq_constr, &constr_data, db[0]->d);
        if (num <= 0)
            ERROR_MSG_LMA("error");
        for (int i = 0; i < num; i++) {
            if (is_eq_constr[i] == true) {
                if (nlopt_add_equality_constraint(dm->nlopt, constr[i], constr_data[i], CONSTRAINT_TOL) != NLOPT_SUCCESS)
                    ERROR_MSG_LMA("\n");
            } else {
                if (nlopt_add_inequality_constraint(dm->nlopt, constr[i], constr_data[i], CONSTRAINT_TOL) != NLOPT_SUCCESS)
                    ERROR_MSG_LMA("\n");
            }
        }
        M1D_FREE(constr);
        M1D_FREE(is_eq_constr);
        M1D_FREE(constr_data);
        
        nlopt_opt tmp = get_nlopt_opt(db[0]->nlopt_alg, (unsigned) dm->num_free_param,
                db[0]->rftol, db[0]->maxeval, db[0]->maxtime, db[0]->d);
        if (nlopt_set_local_optimizer(dm->nlopt, tmp) != NLOPT_SUCCESS)
            ERROR_MSG_LMA("\n");
        nlopt_destroy(tmp);
    } else {
        dm->nlopt = get_nlopt_opt(db[0]->nlopt_alg, (unsigned) dm->num_free_param,
                db[0]->rftol, db[0]->maxeval, db[0]->maxtime, db[0]->d);
    }
    
    matrixalloc_1d_free(db[0]);
    db[0] = NULL;
    
    return dm;
}