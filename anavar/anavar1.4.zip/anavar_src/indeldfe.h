/* 
 * Created on 10 March 2017, 10:18
 */

#ifndef INDELDFE_H
#    define INDELDFE_H

#include <stdbool.h>
#include <stdarg.h>

#include "integrator.h"
#include "dist.h"
#include "vardfe.h"

typedef struct indeldfe_builder_tag * indeldfe_builder_t;

/**
 * @param n
 * @param ig On return, ig[0] will be set to NULL. This is for calculating tau(gamma, i) 
 * @param nthreads
 * @param use_r
 * @param name The name of this dataset. This will be the prefix of all its parameter names. This is cloned.
 * @param msg If an error occurs, then msg[0] points to the error message. Otherwise msg[0] = NULL.
 * @return 
 */
indeldfe_builder_t indeldfe_builder_new(int n, integrator_t *ig, int nthreads, bool use_r, const char *name, char **msg);

/**
 * @param m
 * @param data This is cloned. data[0] contains the insertions and data[1] contains the deletions.
 * @return 
 */
void indeldfe_builder_add_data(indeldfe_builder_t ib, double m, double *data[2], char **msg);

/**
 * This must be called after add_data() has been called.
 * The parameters are arranged as follows: <br>
 * ins_theta_1, ins_gamma_1, ins_e_1, del_theta_1, del_gamma_1, del_e_1 <br>
 * ins_theta_2, ins_gamma_2, ins_e_2, del_theta_2, del_gamma_2, del_e_2 <br>
 * ... <br>
 * ins_theta_c, ins_gamma_c, ins_e_c, del_theta_c, del_gamma_c, del_e_c <br>
 * r_2, r_3, ... <br>
 * <p>
 * theta is defined on a per-site basis
 * 
 * @param c The number of site categories
 * @param ranges The ranges of the parameters for each category on the original scale. The array is cloned.
 */
void indeldfe_builder_add_spikes(indeldfe_builder_t ib, int c, double ranges[c][6][2], char **msg);

/**
 * Let gamma follow a continuous distribution.
 * Distributions permitted:
 * <ol>
 * <li> Reflected gamma. The parameters are arranged as follows: <br>
 *             ins_theta, ins_shape, ins_scale, ins_e, del_theta, del_shape, del_scale, del_e
 * </ol>
 * 
 * 
 * @param dist The distribution of selection coefficients (gamma = 4Ns). On return, dist is set to NULL
 * @param num_dist_param The number of parameters determining dist
 * @param ranges This should have the same number of rows as the number of parameters in the full model (excluding r).
 *               Everything is on the natural scale and the array is cloned.
 * @param frac
 * @param delta
 * @param msg
 */
void indeldfe_builder_add_gamma_continuous(indeldfe_builder_t ib, 
        dist_t *ins_dist, int ins_num_dist_param, double ins_ranges[ins_num_dist_param + 2][2], 
        dist_t *del_dist, int del_num_dist_param, double del_ranges[del_num_dist_param + 2][2], 
        double frac, double delta, char **msg);

/**
 * 
 * @param ib
 * @param ins_ranges range[0:3] are for theta, shape, scale and e. All on the original scale
 * @param del_ranges range[0:3] are for theta, shape, scale and e. All on the original scale
 * @param frac
 * @param delta
 * @param method See vardfe_reflected_gamma_gaussq_adaptive_new for supported adaptive Gaussian quadrature methods
 * @param msg
 */
void indeldfe_builder_add_reflected_gamma_gaussq_adaptive(indeldfe_builder_t ib, 
        double ins_ranges[4][2], double del_ranges[4][2], 
        double frac, double delta, const char *method, char **msg);

/**
 * This must be called after add_spikes or add_continuous has been called. This function can be called exactly once.
 * <p>
 * For indeldfe_gamma_t, the following constraints are allowed 
 * <ul>
 * <li> none
 * <li> no_pol_error
 * </ul>
 * 
 * <p>
 * For indeldfe_spikes_t, the following constraints are allowed 
 * <ul>
 * <li> none
 * <li> no_pol_error
 * </ul>
 */
void indeldfe_builder_add_constraint(indeldfe_builder_t ib, char **msg, const char *name, ...);

/**
 * On return ib will be set to NULL.
 */
vardfe_t indeldfe_builder_build(indeldfe_builder_t *ib, char **msg);

#endif /* INDELDFE_H */

