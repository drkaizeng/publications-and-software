#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>

#include "dfe.h"
#include "dfeml.h"
#include "dfeio.h"
#include "print_errmsg.h"
#include "constants.h"

#include "util/error_msg.h"
#include "util/string_util.h"
#include "io/file_reader.h"


/**
 * @since 2016.9.27, 9.28, 2017.2.26
 */
static FILE * get_file(char *path) {
//    FILE *re = fopen(path, "r");
//    if (re != NULL) {//TODO
//        fprintf(stderr, "Error: output file exists!\n");
//        abort();
//    }
//    re = fopen(path, "w");
    
    FILE *re = fopen(path, "w");
    if (re == NULL) {
        fprintf(stderr, "Error: cannot open output file!\n");
        abort();
    }
    return re;
}

typedef struct {
    char *search_algorithm;//this needs to be freed by matrixalloc_1d_free
    int maxeval;
    double maxtime;
    int num_searches;
    int nnoimp;
    int maximp;
    //for qag integrator
    int size;
    int key; 
    double epsabs;
    double epsrel;
    //for the searches
    double rftol;
    int init_len;
    double *init;
} algorithm_param_t;

/**
 * @since 2017.5.17, 9.19, 2018.1.12 (added init_len and init)
 */
static void get_algorithm_opt(algorithm_param_t *alg, bool optional, file_reader_t *reader, int *line_id, char **msg) {
    //for qag integrator
    alg->size = SIZE;
    alg->key = KEY; 
    alg->epsabs = EPSABS;
    alg->epsrel = EPSREL;
    //for the searches
    alg->rftol = RFTOL;
    alg->init_len = 0;
    alg->init = NULL;
    
    if (optional) {
        int np = 6;
        int pid = 0;
        const char *names[np];
        names[pid++] = "size:";
        names[pid++] = "key:";
        names[pid++] = "epsabs:";
        names[pid++] = "epsrel:";
        names[pid++] = "rftol:";
        names[pid++] = "init:";
        if (pid != np)
            ERROR_MSG_LMA("Error");
        
        char par[np][BUFFER_SIZE];
        dfeio_read_control_param(np, par, names, reader, line_id, msg);
        if (msg[0] != NULL)
            return;
        
        pid = 0;
        
        alg->size = dfeio_get_int(par[pid], "Failed to parse size at line %i.\n",
                line_id[0] - np + pid + 1);
        pid++;
        
        alg->key = dfeio_get_int(par[pid], "Failed to parse key at line %i.\n",
                line_id[0] - np + pid + 1);
        pid++;
        
        alg->epsabs = dfeio_get_double(par[pid], "Failed to parse epsabs at line %i.\n",
                line_id[0] - np + pid + 1);
        pid++;
        
        alg->epsrel = dfeio_get_double(par[pid], "Failed to parse epsrel at line %i.\n",
                line_id[0] - np + pid + 1);
        pid++;
        
        alg->rftol = dfeio_get_double(par[pid], "Failed to parse rftol at line %i.\n",
                line_id[0] - np + pid + 1);
        pid++;
        
        if (string_util_starts_with(par[pid], "given")) {
            char *tmp = par[pid];
            tmp = tmp + 5;
            if (! (string_util_starts_with(tmp, "[") && string_util_ends_with(tmp, "]"))) {
                PRINT_ERRMSG(msg, "Unknown init = %s.", par[pid]);
                return;
            }
            tmp = tmp + 1;
            tmp[strlen(tmp) - 1] = '\0';
            int n;
            char **sarr = string_util_split(tmp, "\\s+", &n);
            if (n <= 0) {
                PRINT_ERRMSG(msg, "Invalid number of elements in init.");
                return;
            }
            alg->init_len = n;
            M1D_NEW(alg->init, n);
            for (int i = 0; i < n; i++) {
                alg->init[i] = dfeio_get_double(sarr[i], "Failed to parse the %d-th element in init.\n", i + 1);
            }
            matrixalloc_1d_free(sarr);
        } else if (string_util_equal(par[pid], "random") == false) {
            PRINT_ERRMSG(msg, "Unknown init = %s.", par[pid]);
            return;
        }
        pid++;
    }
}

/**
 * @since 2017.5.17, 9.19
 */
static void get_algorithm_param(algorithm_param_t *alg, file_reader_t *reader, int *line_id, char **msg) {
    /* control parameters */
    const int num_param = 8;
    int param_id = 0;
    const char *param_names[num_param];
    param_names[param_id++] = "[algorithm_commands]";
    param_names[param_id++] = "search_algorithm:";
    param_names[param_id++] = "maxeval:";
    param_names[param_id++] = "maxtime:";
    param_names[param_id++] = "num_searches:";
    param_names[param_id++] = "nnoimp:";
    param_names[param_id++] = "maximp:";
    param_names[param_id++] = "optional:";
    if (param_id != num_param)
        ERROR_MSG_LMA("par_id != num_ctlp\n");
    
    char param[num_param][BUFFER_SIZE];
    dfeio_read_control_param(num_param, param, param_names, reader, line_id, msg);
    if (msg[0] != NULL)
        return;
    
    param_id = 1;//skip [algorithm_commands]
    
    const char *search_algorithm = param[param_id];
    alg->search_algorithm = matrixalloc_1d_clone(search_algorithm, (int) strlen(search_algorithm) + 1, sizeof (char));
    param_id++;
    
    alg->maxeval = dfeio_get_int(param[param_id], "Failed to parse maxeval at line %i.\n", 
            line_id[0] - num_param + param_id + 1);
    param_id++;
    
    alg->maxtime = dfeio_get_double(param[param_id], "Failed to parse maxtime at line %i.\n", 
            line_id[0] - num_param + param_id + 1);
    param_id++;
    
    alg->num_searches = dfeio_get_int(param[param_id], "Failed to parse num_searches at line %i.\n", 
            line_id[0] - num_param + param_id + 1);
    param_id++;
    
    alg->nnoimp = dfeio_get_int(param[param_id], "Failed to parse nnoimp at line %i.\n", 
            line_id[0] - num_param + param_id + 1);
    param_id++;
    
    alg->maximp = dfeio_get_int(param[param_id], "Failed to parse maximp at line %i.\n", 
            line_id[0] - num_param + param_id + 1);
    param_id++;
    
    bool optional = dfeio_get_bool(param[param_id], "Failed to parse optional at line %i.\n", 
            line_id[0] - num_param + param_id + 1);
    param_id++;
    
    get_algorithm_opt(alg, optional, reader, line_id, msg);
}
/**
 * @since 2017.5.17, 9.19
 */
static dfeml_t get_dfeml(algorithm_param_t *alg, FILE *result_file, file_reader_t *reader, int *line_id, char **msg) {
    int np = 2;
    int pid = 0;
    const char *names[np];
    names[pid++] = "[model_commands]";
    names[pid++] = "model:";
    if (pid != np)
        ERROR_MSG_LMA("Error");
    
    char par[np][BUFFER_SIZE];
    dfeio_read_control_param(np, par, names, reader, line_id, msg);
    if (msg[0] != NULL)
        return NULL;

    pid = 1; //skip [model_commands]

    dfe_t d;

    integrator_t ig = integrator_new_qag(alg->size, alg->epsabs, alg->epsrel, alg->key, msg);
    if (msg[0] != NULL)
        return NULL;

    if (string_util_equal(par[pid], "SNP_1")) {
        d = dfe_snp_1(reader, line_id, &ig, msg);
    } else if (string_util_equal(par[pid], "INDEL_1")) {
        d = dfe_indel_1(reader, line_id, &ig, msg);
    } else if (string_util_equal(par[pid], "neutralINDEL_vs_selectedINDEL")) {
        d = dfe_neutralindel_vs_selectedindel(reader, line_id, &ig, msg);
    } else if (string_util_equal(par[pid], "gBGC_EXTENDED_M1*")) {
        d = dfe_gbgc_extended_m1s(reader, line_id, &ig, msg);
    } else if (string_util_equal(par[pid], "neutralSNP_vs_selectedSNP")) {
        d = dfe_neutralsnp_vs_selectedsnp(reader, line_id, &ig, msg);
    } else if (string_util_equal(par[pid], "neutralSNP_vs_selectedINDEL")) {
        d = dfe_neutralsnp_vs_selectedindel(reader, line_id, &ig, msg);
    } else {
        PRINT_ERRMSG(msg, "Unknown model = %s\n", par[pid]);
        return NULL;
    }
    if (msg[0] != NULL)
        return NULL;
    pid++;

    {
        file_reader_state_t state;
        char buffer[BUFFER_SIZE];
        while (true) {
            line_id[0]++;
            file_reader_read_line_buffer(BUFFER_SIZE, buffer, reader, &state);
            if (state == file_reader_state_overflow) {
                PRINT_ERRMSG(msg, "Line %i has more than %i characters.\n", line_id[0], BUFFER_SIZE);
                return NULL;
            } else if (state == file_reader_state_success) {
                char *buff = string_util_trim(buffer);
                if (strlen(buff) == 0)
                    continue;
                else if (string_util_starts_with(buff, "#"))
                    continue;
                else {
                    PRINT_ERRMSG(msg, "Unexpected command, %s, at line %i.\n", buff, line_id[0]);
                    return NULL;
                }
            } else if (state == file_reader_state_eof)
                break;
            else
                ERROR_MSG_LMA("Internal error.\n");
        }
    }

    int nfp = dfe_num_free_param(d);
    char **free_param_names = dfe_free_param_names(d);
    fprintf(result_file, "List of free parameters:");
    for (int i = 0; i < nfp; i++) {
        fprintf(result_file, "   %s", free_param_names[i]);
        matrixalloc_1d_free(free_param_names[i]);
    }
    matrixalloc_1d_free(free_param_names);
    fprintf(result_file, "\n\n");
    fflush(result_file);

    dfeml_builder_t db = dfeml_builder_new(&d, alg->num_searches, alg->rftol, alg->nnoimp, alg->maximp, msg);
    if (msg[0] != NULL)
        return NULL;

    dfeml_builder_set_algorithm(db, alg->search_algorithm, alg->rftol, alg->maxeval, alg->maxtime, msg);
    if (msg[0] != NULL)
        return NULL;

    return dfeml_builder_build(&db);
}

/**
 * @since 2017.4.16 (SNP_1), 5.17, 9.19
 */
int main(int argc, char** argv) {
    if (argc != 4 && argc != 5) 
        ERROR_MSG_LMA("Usage: anavar control_file result_file log_file [seed]\n");
    
    file_reader_t *reader;
    {
        file_reader_state_t state;
        reader = file_reader_new(argv[1], BUFFER_SIZE, &state);
        if (state != file_reader_state_success) {
            fprintf(stderr, "Error: failed to open the following file: %s\n", argv[1]);
            exit(EXIT_FAILURE);
        }
    }
    
    FILE *result_file = get_file(argv[2]);
    fprintf(result_file, "Control file: %s\n\n", argv[1]);
    fflush(result_file);
    
    FILE *log_file = get_file(argv[3]);

    int line_id = 0;
    char *msg;
    
    algorithm_param_t *alg = matrixalloc_1d(1, sizeof (*alg));

    get_algorithm_param(alg, reader, &line_id, &msg);
    if (msg != NULL)
        ERROR_MSG_LMA("%s\n", msg);
    
    dfeml_t dm = get_dfeml(alg, result_file, reader, &line_id, &msg);
    if (msg != NULL)
        ERROR_MSG_LMA("%s\n", msg);
    
    gsl_rng *rng = gsl_rng_alloc(gsl_rng_mt19937);
    unsigned long seed;
    if (argc == 4)
        seed = (unsigned long) time(NULL);
    else {
        int tmp = dfeio_get_int(argv[4], "Failed to parse seed");
        if (tmp <= 0)
            ERROR_MSG_ME("seed <= 0\n");
        seed = (unsigned long) tmp;
    }
    gsl_rng_set(rng, seed);
    fprintf(result_file, "seed = %lu\n\n", seed);
    fflush(result_file);
    
    dfeml_search(dm, result_file, log_file, rng, alg->init_len, alg->init);
    
    gsl_rng_free(rng);
    dfeml_free(&dm);
    matrixalloc_1d_free(alg->init);
    matrixalloc_1d_free(alg->search_algorithm);
    matrixalloc_1d_free(alg);
    fclose(log_file);
    fclose(result_file);
    {
        file_reader_state_t s;
        file_reader_free(reader, &s, NULL);
    }
    return (EXIT_SUCCESS);
}
