/* 
 * Created on 23 February 2017, 10:57
 */

#ifndef GET_NAME_H
#    define GET_NAME_H

/**
 * Return name_index.
 * The returned object should be freed by free() or matrixalloc_1d_free.
 */
char * get_name(const char *name, int index);

/**
 * The returned object should be freed by free() or matrixalloc_1d_free.
 */
char * get_name2(const char *format, ...);

#endif /* GET_NAME_H */

