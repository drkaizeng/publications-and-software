/* 
 * Created on 18 September 2016, 21:02
 */

#ifndef SCALE_PARAM_H
#    define SCALE_PARAM_H

#include "param.h"

/**
 * Check whether v is in [0, 1] for ERR, and whether is greater than 0 for parameters to be put on ln-scale
 * @param e
 * @param p
 * @return 
 */
double scale_param_check_do(double v, param_t p);

double scale_param_do(double v, param_t p);

double scale_param_undo(double scv, param_t p);

/**
 * The Jacobian 
 */
double scale_param_jaco(double v, param_t p);

#endif /* ERR_LN_H */

