#include "constraint_func.h"

#include "util/matrixalloc.h"

/*
 * @since 2017.5.10, 5.22, 9.6
 */
void constraint_func_free(constraint_func_t **cf) {
    if (cf[0]->free_param != NULL)
        cf[0]->free_param(cf[0]->param);
    matrixalloc_1d_free(cf[0]->xi);
    matrixalloc_1d_free(cf[0]->x);
    matrixalloc_1d_free(cf[0]);
    cf[0] = NULL;
}