/* 
 * Created on 18 September 2016, 21:11
 */

#ifndef PARAM_H
#    define PARAM_H

typedef enum {
    THETA, KAPPA, GAMMA, ERR, R, 
            SHAPE, SCALE //these are for the gamma distribution
} param_t;

#endif /* PARAM_H */

