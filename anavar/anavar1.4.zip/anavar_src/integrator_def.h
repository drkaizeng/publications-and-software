/* 
 * Created on 02 February 2017, 14:51
 */

#ifndef INTEGRATOR_DEF_H
#    define INTEGRATOR_DEF_H


struct integrator_tag {
    void *param;
    void (* free_param)(void *param);
//    void (* set_pts)(void *param, bool is_sig, int npts, double *pts);
    int (* integrate)(double *result, gsl_function *func, void *param);
    double (* abserr)(void *param);
    integrator_t (* clone)(void *param);
};

#endif /* INTEGRATOR_DEF_H */

