/* 
 * Created on 04 February 2017, 08:43
 */

#ifndef DIST_H
#    define DIST_H

#include <stdbool.h>

#include "integrator.h"

typedef enum {
    GAMMA_DIST, //Gamma distribution with support in (0, +infinity) or (-infinity, 0)
    POINT_DIST, //A point distribution (delta function)
} dist_type_t;

typedef struct dist_tag * dist_t;

/**
 * A single, variable point
 */
dist_t dist_point(void);


/**
 * The integration of f(x) over the support is approximated by a n-degree Gaussian quadrature.
 * 
 * @param neg If true, then x &le; 0 and fabs(x) follows a gamma distribution. Otherwise, x &ge; 0.
 * @param msg On return, if msg[0] is not NULL, it means an error was encountered and the error message
 *            is contained in msg[0]
 * @return 
 */
dist_t dist_gamma_gaussq(int n, bool neg, char **msg);

void dist_free(dist_t *d);

dist_type_t dist_type(dist_t d);

/**
 * This integrates the function over the range of the distribution.
 * <p>
 * For gamma, shape and scale.
 * <p>
 * For the point distribution, this is ignored.
 * @param x The parameters of the distribution. This is not to be confused with the x in the function pointer.
 * @param param The parameters needed to evaluate func
 */
double dist_int(double (* func)(double x, void *param), const double *x, void *param, dist_t d);

#endif /* DIST_H */

