/* 
 * Created on 23 February 2017, 13:30
 */
#include <string.h>
#include <stdarg.h>

#include "dfe_def.h"

#include "util/matrixalloc.h"
#include "util/error_msg.h"
#include "util/arrayutil.h"
#include "dfeml_def.h"

/*
 * @since 2017.2.23, 9.19
 */
void dfeml_free(dfeml_t *dm) {
    nlopt_destroy(dm[0]->nlopt);
    dfe_free(&(dm[0]->d));
    matrixalloc_1d_free(dm[0]);
    dm[0] = NULL;
}

/*
 * @since 2017.4.16
 */
static void write(FILE *f, const char *name, const char *format, ...) {
    va_list args;
    va_start(args, format);
    int write_log = vfprintf(f, format, args);
    if (write_log < 0)
        ERROR_MSG_ME("Failed to write to %s\n", name);
    va_end(args);
}

/*
 * @param mle The MLEs of the parameters on return
 * @param lnl The ln-likelihood at the MLE
 * @param imp_id The ID of the improvement round when the search stops
 * @param init Initial values for the search
 * @param run_id
 * 
 * @since 2017.2.23, 4.16, 9.19
 */
static void nlopt_run(double *mle, double *lnl, int *imp_id, nlopt_result *exit_code, 
        double *init, int run_id, dfeml_t dm, FILE *log_file) {
//    nfunc = 0;
    int nnoimp = 1;
    double fold, fnow;
    size_t mem = (size_t) (dm->num_free_param) * sizeof (double);
    for (int i = 1; i <= dm->maximp; i++) {
        nlopt_result code = nlopt_optimize(dm->nlopt, init, &fnow);
        write(log_file, "log file", "%i\t%i\t%i", run_id, i, code);
        for (int j = 0; j < dm->num_free_param; j++) 
            write(log_file, "log file", "\t%.15g", init[j]);
        write(log_file, "log file", "\t%.15g\n", fnow);
        fflush(log_file);
        if (i == 1) {
            lnl[0] = fnow;
            memcpy(mle, init, mem);
            imp_id[0] = i;
            exit_code[0] = code;
        } else {
            double tmp = fabs(fnow - fold);
            if (tmp <= dm->imprftol * 0.5 * (fabs(fnow) + fabs(fold)))
                nnoimp++;
            else
                nnoimp = 1;
            if (lnl[0] < fnow) {
                lnl[0] = fnow;
                memcpy(mle, init, mem);
                imp_id[0] = i;
                exit_code[0] = code;
            }
        }
        fold = fnow;
        if (nnoimp >= dm->nnoimp)
            break;
    }
//    printf("%d\n", nfunc);
}

/*
 * @since 2017.2.23, 4.16, 9.19, 2018.1.12 (added n and init[n])
 */
void dfeml_search(dfeml_t dm, FILE *res_file, FILE *log_file, gsl_rng *rng, int n, double init[n]) {
    {
        char **param_names_full = dfe_param_names_full(dm->d);
        write(res_file, "result file", "run\timp\texit_code");
        for (int i = 0; i < dm->num_param_full; i++) {
            write(res_file, "result file", "\t%s", param_names_full[i]);
            matrixalloc_1d_free(param_names_full[i]);
        }
        write(res_file, "result file", "\tlnL\n");
        fflush(res_file);
        matrixalloc_1d_free(param_names_full);
    }
    
    if (init != NULL && n != dfe_num_param_full(dm->d)) {
        ERROR_MSG_ME("Invalid number of parameters in init. Expected = %d. The number read = %d", dfe_num_param_full(dm->d), n);
    }
    
    double x[dm->num_free_param];
    double lnl[dm->num_searches];
    double mle[dm->num_searches][dm->num_free_param];
    int run_id[dm->num_searches];
    int imp_id[dm->num_searches];
    nlopt_result exit_code[dm->num_searches];
    double re[dm->num_free_param];
    size_t mem = (size_t) dm->num_free_param * sizeof (double);
    for (int i = 0; i < dm->num_searches; i++) {
        if (init == NULL) {
            dfe_gen(x, rng, dm->d);
        } else {
            dfe_all_param_to_free_param(x, init, dm->d);
        }
        double v;
        int imp;
        nlopt_result code;
        nlopt_run(re, &v, &imp, &code, x, i + 1, dm, log_file);
        int indx = arrayutil_binary_search_d(lnl, 0, i, -v);
        if (indx < 0)
            indx = -indx - 1;
        for (int j = i; i > 0 && i > indx && j > indx; j--) {
            lnl[j] = lnl[j - 1];
            memcpy(mle[j], mle[j - 1], mem);
            run_id[j] = run_id[j - 1];
            imp_id[j] = imp_id[j - 1];
            exit_code[j] = exit_code[j - 1];
        }
        lnl[indx] = -v;
        memcpy(mle[indx], re, mem);
        run_id[indx] = i + 1;
        imp_id[indx] = imp;
        exit_code[indx] = code;
    }
    double all_param[dm->num_param_full];
    for (int i = 0; i < dm->num_searches; i++) {
        write(res_file, "result file", "%i\t%i\t%i", run_id[i], imp_id[i], exit_code[i]);
        dfe_free_param_to_all_param(all_param, mle[i], dm->d);
        for (int j = 0; j < dm->num_param_full; j++) 
            write(res_file, "result file", "\t%.15g", all_param[j]);
        write(res_file, "result file", "\t%.15g\n", -lnl[i]);
        fflush(res_file);
    }
}