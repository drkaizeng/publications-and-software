# Supply path info for GSL, NLOPT, and LIBRARY
# IMPORTANT: DO NOT end the following with '/'
GSL="/home/kzeng/libraries/gcc5.3/gsl-1.15-g3O0"
NLOPT="/home/kzeng/libraries/gcc5.3/nlopt-2.4.2-default"
LIBRARY="./library"

INCLUDE="-I${LIBRARY} -I${GSL}/include -I${NLOPT}/include"
LIB="-L${LIBRARY} -L${GSL}/lib -L${NLOPT}/lib"

gcc -Wall -std=c99 -O0 -g3 $INCLUDE $LIB  *.c -o anavar -llibrary -lnlopt -lgsl -lgslcblas -lm