/* 
 * Created on 03 February 2017, 14:15
 */
#include <string.h>
#include <stdbool.h>

#include "snpdfe_def.h"

#include "tau.h"
#include "param.h"
#include "get_name.h"
#include "print_errmsg.h"
#include "find_name.h"

#include "util/matrixalloc.h"
#include "util/error_msg.h"
#include "util/string_util.h"

typedef struct {
    int n;
    double m;
    bool folded;
    int c;
    int nthreads;

    tau_t tau;//for multi-threading, simply create an array of size nthreads and 
    double **t;//t[c][i] is tau[i] determined by gamma_c for 0 < i < n
    double **dt;//d(t[c][i])/d(gamma_c)
} snpdfe_spikes_t;

/*
 * @since 2017.2.17, 4.12, 9.6
 */
static void free_dfe(void *dfe) {
    snpdfe_spikes_t *sp = (snpdfe_spikes_t *) dfe;
    matrixalloc_2d_d_free(sp->dt);
    matrixalloc_2d_d_free(sp->t);
    tau_free(&(sp->tau));
    matrixalloc_1d_free(sp);
}

/*
 * @since 2017.2.16, 4.12, 9.6
 */
static void get_t_dt(snpdfe_spikes_t *sp, const double *x, double **dsfs, const bool *has_der) {
    tau_t tau = sp->tau;
    int n = sp->n;
    double **t = sp->t, **dt = sp->dt;
    for (int i = 1, i1 = 0; i < n; i++, i1++) {
        for (int c = 0, gi = 1; c < sp->c; c++, gi += 3) {
            t[c][i1] = tau_cal(i, x[gi], tau);
            if (dsfs != NULL && has_der[gi])
                dt[c][i1] = tau_der(i, x[gi], tau);
        }
    }
}

/*
 * @since 2017.2.16, 4.12, 9.6
 */
static void cal_unfolded_no_r(double *sfs, double **dsfs, const double *x, const double *r, const bool *has_der, void *dfe) {
    snpdfe_spikes_t *sp = (snpdfe_spikes_t *) dfe;
    get_t_dt(sp, x, dsfs, has_der);
    int n = sp->n;
    double **t = sp->t, **dt = sp->dt;
    for (int i = 1, j, nj; i < n; i++) {
        j = i - 1;
        nj = n - i - 1;
        sfs[j] = 0;
        for (int c = 0, ti = 0, gi = 1, ei = 2; c < sp->c; c++, ti += 3, gi += 3, ei += 3) {
            if (i == n - i) {
                sfs[j] += sp->m * x[ti] * t[c][j];
                if (dsfs != NULL) {
                    if (has_der[ti])
                        dsfs[j][ti] = sp->m * t[c][j];
                    if (has_der[gi])
                        dsfs[j][gi] = sp->m * x[ti] * dt[c][j];
                    if (has_der[ei])
                        dsfs[j][ei] = 0;
                }
            } else {
                sfs[j] += sp->m * x[ti] * ((1 - x[ei]) * t[c][j] + x[ei] * t[c][nj]);
                if (dsfs != NULL) {
                    if (has_der[ti])
                        dsfs[j][ti] = sp->m * ((1 - x[ei]) * t[c][j] + x[ei] * t[c][nj]);
                    if (has_der[gi])
                        dsfs[j][gi] = sp->m * x[ti] * ((1 - x[ei]) * dt[c][j] + x[ei] * dt[c][nj]);
                    if (has_der[ei])
                        dsfs[j][ei] = sp->m * x[ti] * (-t[c][j] + t[c][nj]);
                }
            }
        }
    }
}

/*
 * @since 2017.2.16, 4.12, 9.6
 */
static void cal_unfolded_use_r(double *sfs, double **dsfs, const double *x, const double *r, const bool *has_der, void *dfe) {
    snpdfe_spikes_t *sp = (snpdfe_spikes_t *) dfe;
    get_t_dt(sp, x, dsfs, has_der);
    int n = sp->n;
    double **t = sp->t, **dt = sp->dt;
    int lo = 3 * sp->c, hi = lo + n - 2;
    if (dsfs != NULL) {
        for (int i = 0; i < n - 1; i++)//has_der is always true for the r parameters
            for (int j = lo; j < hi; j++)
                dsfs[i][j] = 0;
    }
    for (int i = 1, j, nj; i < n; i++) {
        j = i - 1;
        nj = n - i - 1;
        sfs[j] = 0;
        double riv = (i == 1 ? 1 : r[i - 2]);
        double rniv = (i == n - 1 ? 1 : r[n - i - 2]);
        for (int c = 0, ti = 0, gi = 1, ei = 2; c < sp->c; c++, ti += 3, gi += 3, ei += 3) {
            if (i == n - i) {
                sfs[j] += sp->m * x[ti] * riv * t[c][j];
                if (dsfs != NULL) {
                    if (has_der[ti])
                        dsfs[j][ti] = sp->m * riv * t[c][j];
                    if (has_der[gi])
                        dsfs[j][gi] = sp->m * x[ti] * riv * dt[c][j];
                    if (has_der[ei])
                        dsfs[j][ei] = 0;
                    if (i != 1)
                        dsfs[j][lo + i - 2] += sp->m * x[ti] * t[c][j];
                }
            } else {
                sfs[j] += sp->m * x[ti] * ((1 - x[ei]) * riv * t[c][j] + x[ei] * rniv * t[c][nj]);
                if (dsfs != NULL) {
                    if (has_der[ti])
                        dsfs[j][ti] = sp->m * ((1 - x[ei]) * riv * t[c][j] + x[ei] * rniv * t[c][nj]);
                    if (has_der[gi])
                        dsfs[j][gi] = sp->m * x[ti] * ((1 - x[ei]) * riv * dt[c][j] + x[ei] * rniv * dt[c][nj]);
                    if (has_der[ei])
                        dsfs[j][ei] = sp->m * x[ti] * (-riv * t[c][j] + rniv * t[c][nj]);
                    if (i == 1)//only r[n-1]
                        dsfs[j][lo + n - i - 2] += sp->m * x[ti] * x[ei] * t[c][nj];
                    else if (i == n - 1) {//only r[i]
                        dsfs[j][lo + i - 2] += sp->m * x[ti] * (1 - x[ei]) * t[c][j];
                    } else {
                        dsfs[j][lo + i - 2] += sp->m * x[ti] * (1 - x[ei]) * t[c][j];
                        dsfs[j][lo + n - i - 2] += sp->m * x[ti] * x[ei] * t[c][nj];
                    }
                }
            }
        }
    }
}

/*
 * @since 2017.2.17, 4.12, 9.6
 */
static void cal_folded_no_r(double *sfs, double **dsfs, const double *x, const double *r, const bool *has_der, void *dfe) {
    snpdfe_spikes_t *sp = (snpdfe_spikes_t *) dfe;
    get_t_dt(sp, x, dsfs, has_der);
    int n = sp->n;
    double **t = sp->t, **dt = sp->dt;
    for (int i = 1, j, nj; i <= n/2; i++) {
        j = i - 1;
        nj = n - i - 1;
        sfs[j] = 0;
        for (int c = 0, ti = 0, gi = 1; c < sp->c; c++, ti += 3, gi += 3) {
            if (i == n - i) {
                sfs[j] += sp->m * x[ti] * t[c][j];
                if (dsfs != NULL) {
                    if (has_der[ti])
                        dsfs[j][ti] = sp->m * t[c][j];
                    if (has_der[gi])
                        dsfs[j][gi] = sp->m * x[ti] * dt[c][j];
                }
            } else {
                sfs[j] += sp->m * x[ti] * (t[c][j] + t[c][nj]);
                if (dsfs != NULL) {
                    if (has_der[ti])
                        dsfs[j][ti] = sp->m * (t[c][j] + t[c][nj]);
                    if (has_der[gi])
                        dsfs[j][gi] = sp->m * x[ti] * (dt[c][j] + dt[c][nj]);
                }
            }
        }
    }
}

/*
 * @since 2017.2.17, 4.12, 9.6
 */
static void cal_folded_use_r(double *sfs, double **dsfs, const double *x, const double *r, const bool *has_der, void *dfe) {
    snpdfe_spikes_t *sp = (snpdfe_spikes_t *) dfe;
    get_t_dt(sp, x, dsfs, has_der);
    int n = sp->n;
    double **t = sp->t, **dt = sp->dt;
    int lo = 3 * sp->c, hi = lo + n/2 - 1;
    if (dsfs != NULL) {
        for (int i = 0; i < n / 2; i++)//has_der is always true for the r parameters
            for (int j = lo; j < hi; j++)
                dsfs[i][j] = 0;
    }
    for (int i = 1, j, nj; i <= n/2; i++) {
        j = i - 1;
        nj = n - i - 1;
        sfs[j] = 0;
        double riv = (i == 1 ? 1 : r[i - 2]);
        for (int c = 0, ti = 0, gi = 1; c < sp->c; c++, ti += 3, gi += 3) {
            if (i == n - i) {
                sfs[j] += sp->m * x[ti] * riv * t[c][j];
                if (dsfs != NULL) {
                    if (has_der[ti])
                        dsfs[j][ti] = sp->m * riv * t[c][j];
                    if (has_der[gi])
                        dsfs[j][gi] = sp->m * x[ti] * riv * dt[c][j];
                    if (i != 1)
                        dsfs[j][lo + i - 2] += sp->m * x[ti] * t[c][j];
                }
            } else {
                sfs[j] += sp->m * x[ti] * riv * (t[c][j] + t[c][nj]);
                if (dsfs != NULL) {
                    if (has_der[ti])
                        dsfs[j][ti] = sp->m * riv * (t[c][j] + t[c][nj]);
                    if (has_der[gi])
                        dsfs[j][gi] = sp->m * x[ti] * riv * (dt[c][j] + dt[c][nj]);
                    if (i != 1)
                        dsfs[j][lo + i - 2] += sp->m * x[ti] * (t[c][j] + t[c][nj]);
                }
            }
        }
    }
}

/*
 * @since 2017.5.14, 5.16, 9.5, 2018.3.11
 */
static void add_constraint_neutral(snpdfe_builder_t sb, int c, char **msg) {
    if (c != 1) {
        PRINT_ERRMSG(msg, "When all sites are neutral, only one site class can be used.");
        return;
    }
    vardfe_t vd = sb->vd;
    vd->num_free_param--;//gamma = 0
    vd->x[1] = 0;
    vd->is_free[1] = false;
    vd->has_der[1] = false;
    vd->xi[1] = -1;
    for (int i = 0, j = 0; i < vd->nx; i++) {
        if (vd->xi[i] >= 0) {
            vd->xi[i] = j;
            j++;
        }
    }
}

/*
 * @since 2017.4.12, 5.17, 9.6, 2018.3.11
 */
static void add_constraint_no_pol_error(snpdfe_builder_t sb, int c) {
    for (int i = 0; i < c; i++) {
        char *name = get_name2("%s%s_%i", sb->name, "e", i + 1);
        int id = find_name(name, sb->vd->num_param_full, sb->vd->param_names);
        if (id < 0) 
            ERROR_MSG_LMA("Failed\n");
        double v = 0;
        
        sb->vd->num_free_param--;
        sb->vd->x[id] = v;
        sb->vd->is_free[id] = false;
        sb->vd->has_der[id] = false;
        sb->vd->xi[id] = -1;
        for (int j = id + 1; j < sb->vd->nx; j++)
            if (sb->vd->xi[j] >= 0)
                sb->vd->xi[j]--;
        
        matrixalloc_1d_free(name);
    }
}

/**
 * @since 2017.5.22, 9.6
 */
static double equal_rate_cont_f(const double *x, void *param) {
    return x[0];
}

/**
 * @since 2017.5.22, 9.6
 */
static double equal_rate_cont_df(const double *x, int i, void *param) {
    return 1;
}

/*
 * @since 2017.5.22, 5.26 (roughly), 9.6 (changed such that it only works for e)
 */
static void add_constraint_equal_e(snpdfe_builder_t sb, int c) {
    int id[c];
    for (int i = 0; i < c; i++) {
        char *name = get_name2("%s%s_%i", sb->name, "e", i + 1);
        id[i] = find_name(name, sb->vd->num_param_full, sb->vd->param_names);
        if (id[i] < 0) 
            ERROR_MSG_LMA("Failed\n");
        matrixalloc_1d_free(name);
    }
    
    for (int i = 1; i < c; i++) {//let e_1 be the free parameter
        sb->vd->num_free_param--;
        sb->vd->is_free[id[i]] = false;
        sb->vd->xi[id[i]] = -2;
        for (int j = id[i] + 1; j < sb->vd->nx; j++)
            if (sb->vd->xi[j] >= 0)
                sb->vd->xi[j]--;
        constraint_func_t *cf = matrixalloc_1d(1, sizeof (*cf));
        cf->x = matrixalloc_1d(1, sizeof (*cf->x));
        cf->nx = 1;
        cf->xi = matrixalloc_1d(1, sizeof (*cf->xi));
        cf->xi[0] = id[0];
        cf->f = equal_rate_cont_f;
        cf->df = equal_rate_cont_df;
        cf->param = NULL;
        cf->free_param = NULL;
        sb->vd->cf[id[i]] = cf;
    }
}

/*
 * @since 2017.4.12 (no_pol_error), 5.14 (neutral), 5.17 (neutral_AND_no_pol_error), 
 * 5.27 (equal_mut_rate_AND_equal_pol_error), 9.6 (checked and removed equal_mutation_rate and equal_mut_rate_AND_equal_pol_error)
 * 2018.3.11 (neutral_AND_no_pol_error)
 */
static void add_constraint(snpdfe_builder_t sb, char **msg, const char *name, va_list args) {
    msg[0] = NULL;

    snpdfe_spikes_t *spi = (snpdfe_spikes_t *) sb->vd->dfe;
    
    if (string_util_equal(name, "none"))
        return;
    else if (string_util_equal(name, "no_pol_error")) {
        if (sb->folded == true) {
            PRINT_ERRMSG(msg, "When the folded SFS is used, the e parameters are always zero. We cannot use no_pol_error.\n.");
            return;
        }
        add_constraint_no_pol_error(sb, spi->c);
    } else if (string_util_equal(name, "neutral")) {
        add_constraint_neutral(sb, spi->c, msg);
    } else if (string_util_equal(name, "neutral_AND_no_pol_error")) {
        if (sb->folded == true) {
            PRINT_ERRMSG(msg, "When the folded SFS is used, the e parameters are always zero. We cannot use neutral_AND_no_pol_error.\n.");
            return;
        }
        add_constraint_neutral(sb, spi->c, msg);
        add_constraint_no_pol_error(sb, spi->c);
    } else if (string_util_equal(name, "equal_pol_error")) {
        if (sb->folded == true) {
            PRINT_ERRMSG(msg, "When the folded SFS is used, the e parameters are always zero. We cannot use equal_pol_error.\n.");
            return;
        }
        add_constraint_equal_e(sb, spi->c);
    } else {
        PRINT_ERRMSG(msg, "Unknown constraint = %s\n.", name);
    }
} 

/*
 * @since 2017.2.16, 2.22, 4.12, 4.19 (changed to vardfe), 9.6
 */
void snpdfe_builder_add_spikes(snpdfe_builder_t sb, int c, double ranges[c][3][2], char **msg) {
    if (sb->mode != 1)
        ERROR_MSG_LMA("sb->mode != 1\n");
    if (sb->dist != -1)
        ERROR_MSG_LMA("sb->dist != -1\n");
    if (c < 1) {
        PRINT_ERRMSG(msg, "The number of SNP types, c, is less than 1\n");
        return;
    }
    
    sb->mode = 2;
    sb->dist = 0;
    
    snpdfe_spikes_t *spi = matrixalloc_1d(1, sizeof (*spi));
    spi->n = sb->vd->n;
    spi->m = sb->m;
    spi->folded = sb->folded;
    spi->c = c;
    spi->nthreads = sb->nthreads;
    spi->tau = tau_new(spi->n, &(sb->ig));//with multithreading, ig needs to be cloned.
    spi->t = matrixalloc_2d_d(c, spi->n - 1);
    spi->dt = matrixalloc_2d_d(c, spi->n - 1);
    
    sb->vd->num_param_full = 3 * c + sb->vd->nr;//nr is initialsed in add_data(), which must be called first
    sb->vd->num_free_param = sb->vd->num_param_full;
    sb->vd->param_types = matrixalloc_1d(sb->vd->num_param_full, sizeof (*sb->vd->param_types));
    sb->vd->param_names = matrixalloc_1d(sb->vd->num_param_full, sizeof (*sb->vd->param_names));
    for (int i = 0, j = 0; i < c; i++) {
        sb->vd->param_types[j] = THETA;
        sb->vd->param_names[j] = get_name2("%s%s_%i", sb->name, "theta", i + 1);
        j++;
        sb->vd->param_types[j] = GAMMA;
        sb->vd->param_names[j] = get_name2("%s%s_%i", sb->name, "gamma", i + 1);
        j++;
        sb->vd->param_types[j] = ERR;
        sb->vd->param_names[j] = get_name2("%s%s_%i", sb->name, "e", i + 1);
        j++;
    }
    if (sb->use_r) {
        for (int i = 2, j = 3 * c; i <= sb->vd->data_len; i++, j++) {
            sb->vd->param_types[j] = R;
            sb->vd->param_names[j] = get_name("r", i);
        }
    }
    
    sb->vd->dfe = spi;
    sb->vd->ranges = matrixalloc_2d_d(2, sb->vd->num_param_full - sb->vd->nr);
    for (int i = 0, pi = 0; i < c; i++) {
        for (int j = 0; j < 3; j++, pi++) {
            if (ranges[i][j][0] >= ranges[i][j][1]) {
                PRINT_ERRMSG(msg, "The range [%g, %g] for %s is invalid. "
                        "The lower bound should be strictly smaller than the upper bound\n",
                        ranges[i][j][0], ranges[i][j][1], sb->vd->param_names[pi]);
                return;
            }
            if (sb->vd->param_types[pi] == THETA && ranges[i][j][0] <= 0) {
                PRINT_ERRMSG(msg, "The lower bound for %s is %g, but it should be positive.\n",
                        sb->vd->param_names[pi], ranges[i][j][0]);
                return;
            }
            if (sb->vd->param_types[pi] == ERR && (ranges[i][j][0] < 0 || ranges[i][j][1] > 1)) {
                PRINT_ERRMSG(msg, "The bounds for %s is [%g, %g], but they should be in [0, 1].\n",
                        sb->vd->param_names[pi], ranges[i][j][0], ranges[i][j][1]);
                return;
            }
            sb->vd->ranges[0][pi] = ranges[i][j][0];
            sb->vd->ranges[1][pi] = ranges[i][j][1];
        }
    }
    sb->vd->free_dfe = free_dfe;
    if (sb->folded)
        if (sb->use_r)
            sb->vd->cal = cal_folded_use_r;
        else
            sb->vd->cal = cal_folded_no_r;
    else
        if (sb->use_r)
            sb->vd->cal = cal_unfolded_use_r;
        else
            sb->vd->cal = cal_unfolded_no_r;
    
    sb->add_constraint = add_constraint;
    
    vardfe_init(sb->vd);
    
    if (sb->folded) //e has to be 0 
        add_constraint_no_pol_error(sb, c);
        
    msg[0] = NULL;
}
