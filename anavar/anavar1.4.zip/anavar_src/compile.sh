# Supply path info for GSL, NLOPT, and LIBRARY
# IMPORTANT: DO NOT end the following with '/'
GSL="/home/kzeng/gsl-1.15-gcc-m64-O3"
NLOPT="/home/kzeng/nlopt-2.4.2"
LIBRARY="/home/kzeng/code_tests/Library"

INCLUDE="-I${LIBRARY} -I${GSL}/include -I${NLOPT}/include"
LIB="-L${LIBRARY} -L${GSL}/lib -L${NLOPT}/lib"

gcc -std=c99 -O3 -g $INCLUDE $LIB  *.c -o anavar -llibrary -lnlopt -lgsl -lgslcblas -lm
