/* 
 * Created on 19 February 2017, 06:05
 */
#include <string.h>

#include "dfe_def.h"
#include "snpdfe.h"
#include "scale_param.h"

#include "util/matrixalloc.h"
#include "util/error_msg.h"
#include "util/arrayutil.h"
#include "get_name.h"

/*
 * @since 2017.5.8 (num_set=1 and 2), 5.9, 9.17, 2018.3.12 (usg_auglan and related variables)
 */
void dfe_init(dfe_t d, double r_range[2]) {
    d->use_auglag = false;
    d->num_constr = 0;
    d->constr = NULL;
    d->is_eq_constr = NULL;
    d->constr_data = NULL;
    d->internal_constr_data = NULL;
    d->free_internal_constr_data = NULL;
    
    d->gen = NULL;
    
    d->pos = matrixalloc_1d(d->num_sets, sizeof (int));
    d->pos[0] = 0;
    for (int i = 1; i < d->num_sets; i++)
        d->pos[i] = d->pos[i - 1] + vardfe_num_free_param_no_r(d->data[i - 1]);
    
    d->nr = vardfe_num_r(d->data[0]);
    
    d->num_param_full = d->nr;
    for (int i = 0; i < d->num_sets; i++)
        d->num_param_full += vardfe_num_param_full_no_r(d->data[i]);
    
    d->param_names_full = matrixalloc_1d(d->num_param_full, sizeof (char *));
    for (int i = 0, j = 0; i < d->num_sets; i++) {
        int nx = vardfe_num_param_full_no_r(d->data[i]);
        char **name = vardfe_param_names_full_no_r(d->data[i]);
        memcpy(d->param_names_full + j, name, (size_t) nx * sizeof (char *));
        j += nx;
        if (i == d->num_sets - 1) {
            for (int r = 2; j < d->num_param_full; j++, r++)
                d->param_names_full[j] = get_name2("r_%i", r);
        }
        matrixalloc_1d_free(name);
    }
    
    d->num_param = d->nr;
    for (int i = 0; i < d->num_sets; i++)
        d->num_param += vardfe_num_free_param_no_r(d->data[i]);
    
    d->is_free = matrixalloc_1d(d->num_param, sizeof (bool));
    arrayutil_fill_b(d->is_free, 0, d->num_param, true);
    d->x = matrixalloc_1d(d->num_param, sizeof (double));
    d->xi = matrixalloc_1d(d->num_param, sizeof (int));
    for (int i = 0; i < d->num_param; i++)
        d->xi[i] = i;
    d->gradx = matrixalloc_1d(d->num_param, sizeof (double));
    d->cf = matrixalloc_1d(d->num_param, sizeof (constraint_func_t *));
    for (int i = 0; i < d->num_param; i++)
        d->cf[i] = NULL;
    
    d->num_free_param = d->num_param;
    d->free_param_types = matrixalloc_1d(d->num_free_param, sizeof (param_t));
    d->free_param_names = matrixalloc_1d(d->num_free_param, sizeof (char *));
    d->onln = matrixalloc_1d(d->num_free_param, sizeof (bool));
    d->ranges = matrixalloc_2d_d(2, d->num_free_param);
    for (int i = 0, j = 0; i < d->num_sets; i++) {
        int nx = vardfe_num_free_param_no_r(d->data[i]);
        param_t *type = vardfe_free_x_types(d->data[i]);
        char **name = vardfe_free_x_names(d->data[i]);
        double **range = vardfe_free_x_ranges(d->data[i]);
        memcpy(d->free_param_types + j, type, (size_t) nx * sizeof (param_t));
        memcpy(d->free_param_names + j, name, (size_t) nx * sizeof (char *));
        for (int k = 0; k < nx; k++) {
            if (type[k] != GAMMA)
                d->onln[j + k] = true;
            else
                d->onln[j + k] = false;
        }
        for (int k = 0; k < 2; k++) {
            memcpy(d->ranges[k] + j, range[k], (size_t) nx * sizeof (double));
        }
        j += nx;
        if (i == d->num_sets - 1) {
            for (int k = 0; k < d->nr; k++) {
                d->free_param_types[j] = R;
                d->free_param_names[j] = get_name2("r_%i", k + 2);
                d->onln[j] = true;
                d->ranges[0][j] = r_range[0];
                d->ranges[1][j] = r_range[1];
                j++;
            }
        }
        matrixalloc_1d_free(type);
        matrixalloc_1d_free(name);
        matrixalloc_2d_d_free(range);
    }
    for (int i = 0; i < d->num_free_param; i++) {
        if (d->onln[i]) {
            d->ranges[0][i] = scale_param_do(d->ranges[0][i], d->free_param_types[i]);
            d->ranges[1][i] = scale_param_do(d->ranges[1][i], d->free_param_types[i]);
        }
    }
}

/*
 * @since 2017.9.17, 9.19
 */
dfe_t dfe_init2(int num_set, vardfe_t data[num_set], double r_range[2]) {
    dfe_t d = matrixalloc_1d(1, sizeof (*d));
    d->num_sets = num_set;
    d->data = matrixalloc_1d(d->num_sets, sizeof (*d->data));
    for (int i = 0; i < num_set; i++) {
        d->data[i] = data[i];
        data[i] = NULL;
    }
    dfe_init(d, r_range);
    return d;
}

/*
 * @since 2017.5.9, 5.17, 6.20
 */
void dfe_rm_param(dfe_t d) {
    for (int i = 0, cnt = 0; i < d->num_param; i++) {
        if (d->is_free[i] == true) {
            cnt++;
            continue;
        } 
        if (d->xi[i] != -1 || d->cf[i] == NULL)
                ERROR_MSG_LMA("Error\n");
        for (int j = i + 1; j < d->num_param; j++) {
            if (d->xi[j] >= 0)
                d->xi[j]--;
        }
        matrixalloc_1d_free(d->free_param_names[cnt]);
        for (int j = cnt + 1; j < d->num_free_param; j++) {
            d->free_param_types[j - 1] = d->free_param_types[j];
            d->free_param_names[j - 1] = d->free_param_names[j];
            d->onln[j - 1] = d->onln[j];
            for (int k = 0; k < 2; k++)
                d->ranges[k][j - 1] = d->ranges[k][j];
        }
        d->num_free_param--;
    }
    double **range = matrixalloc_2d_d(2, d->num_free_param);
    for (int i = 0; i < 2; i++)
        memcpy(range[i], d->ranges[i], (size_t) d->num_free_param * sizeof (double));
    matrixalloc_2d_d_free(d->ranges);
    d->ranges = range;
}

/*
 * @since 2017.2.23, 4.16 (no cf), 5.10 (with cf), 2018.3.13 (auglag related)
 */
void dfe_free(dfe_t *d) {
    matrixalloc_2d_d_free(d[0]->ranges);
    matrixalloc_1d_free(d[0]->onln);
    for (int i = 0; i < d[0]->num_free_param; i++)
        matrixalloc_1d_free(d[0]->free_param_names[i]);
    matrixalloc_1d_free(d[0]->free_param_names);
    matrixalloc_1d_free(d[0]->free_param_types);
    
    for (int i = 0; i < d[0]->num_param; i++) {
        if (d[0]->cf[i] != NULL) {
            constraint_func_free(&(d[0]->cf[i]));
        }
    }
    matrixalloc_1d_free(d[0]->cf);
    matrixalloc_1d_free(d[0]->gradx);
    matrixalloc_1d_free(d[0]->xi);
    matrixalloc_1d_free(d[0]->x);
    matrixalloc_1d_free(d[0]->is_free);
    
    for (int i = 0; i < d[0]->num_param_full; i++)
        matrixalloc_1d_free(d[0]->param_names_full[i]);
    matrixalloc_1d_free(d[0]->param_names_full);
    
    matrixalloc_1d_free(d[0]->pos);

    for (int i = 0; i < d[0]->num_constr; i++) {
        d[0]->free_internal_constr_data[i](d[0]->internal_constr_data[i]);
        M1D_FREE(d[0]->constr_data[i]);
    }
    M1D_FREE(d[0]->free_internal_constr_data);
    M1D_FREE(d[0]->internal_constr_data);
    M1D_FREE(d[0]->constr_data);
    M1D_FREE(d[0]->is_eq_constr);
    M1D_FREE(d[0]->constr);
    
    for (int i = 0; i < d[0]->num_sets; i++)
        vardfe_free(&(d[0]->data[i]));
    matrixalloc_1d_free(d[0]->data);
    matrixalloc_1d_free(d[0]);
    
    d[0] = NULL;
}

/*
 * @since 2018.3.13
 */
bool dfe_use_auglag(dfe_t d) {
    return d->use_auglag;
}

/*
 * @since 2018.3.13
 */
void dfe_constraint(int *num, nlopt_func **constr, bool **is_eq_constr, dfe_constr_data_t **constr_data, dfe_t d) {
    num[0] = d->num_constr;
    if (num[0] > 0) {
        constr[0] = matrixalloc_1d_clone(d->constr, num[0], sizeof(*d->constr));
        is_eq_constr[0] = matrixalloc_1d_clone(d->is_eq_constr, num[0], sizeof(*d->is_eq_constr));
        constr_data[0] = matrixalloc_1d_clone(d->constr_data, num[0], sizeof(*d->constr_data));
    } else {
        constr[0] = NULL;
        is_eq_constr[0] = NULL;
        constr_data[0] = NULL;
    }
}

/*
 * @since 2017.2.24, 4.15
 */
int dfe_num_free_param(dfe_t d) {
    return d->num_free_param;
}

/*
 * @since 2017.4.15, 9.19
 */
int dfe_num_param_full(dfe_t d) {
    return d->num_param_full;
}

/*
 * @since 2017.4.15, 9.19
 */
int dfe_num_r(dfe_t d) {
    return d->nr;
}

/* 
 * @since 2017.2.23, 2.26, 4.16
 */
char ** dfe_param_names_full(dfe_t d) {
    char **re = matrixalloc_1d(d->num_param_full, sizeof (char *));
    for (int i = 0; i < d->num_param_full; i++)
        re[i] = matrixalloc_1d_clone(d->param_names_full[i], (int) strlen(d->param_names_full[i]) + 1, sizeof (char));
    return re;
}

/*
 * @since 2017.9.19
 */
param_t * dfe_free_param_types(dfe_t d) {
    return matrixalloc_1d_clone(d->free_param_types, d->num_free_param, sizeof (param_t));
}

/* 
 * @since 2017.2.24, 2.26, 9.19
 */
char ** dfe_free_param_names(dfe_t d) {
    char **re = matrixalloc_1d(d->num_free_param, sizeof (char *));
    for (int i = 0; i < d->num_free_param; i++)
        re[i] = matrixalloc_1d_clone(d->free_param_names[i], (int) strlen(d->free_param_names[i]) + 1, sizeof (char));
    return re;
}

/* 
 * Convert the free parameters to the set of parameters with only within-dataset constrains applied.
 * The values in param are on the original scale
 * @since 2017.4.15 (no cf), 5.9 (with cf), 5.10 (with cf), 5.17 (with cf), 9.19
 */
static void free_param_to_param(double *param, const double *free_param, dfe_t d) {
    int *xi = d->xi;
    for (int i = 0; i < d->num_param; i++) {
        if (xi[i] >= 0) {
            if (d->onln[xi[i]])
                param[i] = scale_param_undo(free_param[xi[i]], d->free_param_types[xi[i]]);
            else
                param[i] = free_param[xi[i]];
        }
    }
    for (int i = 0; i < d->num_param; i++) {
        constraint_func_t *cf = d->cf[i];
        if (cf != NULL) {
            for (int j = 0; j < cf->nx; j++) 
                cf->x[j] = param[cf->xi[j]];
                
            param[i] = cf->f(cf->x, cf->param);
        }
    }
}

/* 
 * @since 20147.2.23 (SNP), 4.16 (SNP num_sets=1), 9.19
 */
void dfe_free_param_to_all_param(double *all_param, const double *free_param, dfe_t d) {
    free_param_to_param(d->x, free_param, d);
    for (int i = 0, j = 0, np; i < d->num_sets; i++) {
        np = vardfe_num_param_full_no_r(d->data[i]);
        vardfe_free_x_to_all_x(all_param + j, d->x + d->pos[i], d->data[i]);
        j += np;
    }
    memcpy(all_param + d->num_param_full - d->nr, d->x + d->num_param - d->nr, (size_t) d->nr * sizeof (double));
}

/*
 * @since 2017.2.23 (SNP), 4.15 (SNP), 5.8 (INDEL), 9.19
 */
void dfe_all_param_to_free_param(double *free_param, const double *all_param, dfe_t d) {
    double param[d->num_param];//no between-data constraints
    for (int i = 0, j = 0, k = 0, np, nfp; i < d->num_sets; i++) {
        np = vardfe_num_param_full_no_r(d->data[i]);
        nfp = vardfe_num_free_param_no_r(d->data[i]);
        vardfe_all_x_to_free_x(param + k, all_param + j, d->data[i]);
        j += np;
        k += nfp;
    }
    for (int i = 0, j = d->num_param - d->nr, k = d->num_param_full - d->nr; i < d->nr; i++, j++, k++)
        param[j] = all_param[k];
    for (int i = 0, j = 0; i < d->num_param; i++)
        if (d->is_free[i]) {
            free_param[j] = param[i];
            if (d->onln[j])
                free_param[j] = scale_param_do(free_param[j], d->free_param_types[j]);
            j++;
        }
}

/*
 * @since 2017.2.23, 4.16, 2018.3.13 (added d->gen)
 */
void dfe_gen(double *x, gsl_rng *rng, dfe_t d) {
    if (d->gen == NULL) {
        for (int i = 0; i < d->num_free_param; i++) {
            double tmp = gsl_rng_uniform(rng);
            x[i] = tmp * (d->ranges[1][i] - d->ranges[0][i]) + d->ranges[0][i];
        }
    } else {
        d->gen(x, rng, d);
    }
}

/*
 * @since 2017.2.23, 4.16
 */
double ** dfe_ranges(dfe_t d) {
    return matrixalloc_2d_d_clone(d->ranges, 2, d->num_free_param);
}

/*
 * @since 2017.2.23 (SNP), 4.15 (SNP, no r, no cf), 5.9 (with cf and r), 5.17 (with cf and r), 9.19
 */
double dfe_lnlike(double *grad, const double *x, dfe_t d) {
    free_param_to_param(d->x, x, d);
    int *pos = d->pos;
    int nx = d->num_param - d->nr;
    double re = 0;
    if (grad == NULL) {
        for (int i = 0; i < d->num_sets; i++)
            re += vardfe_lnlike(NULL, NULL, d->x + pos[i], d->x + nx, d->data[i]);
    } else {
        double *gradx = d->gradx;
        for (int i = 0; i < d->num_param; i++)
            gradx[i] = 0;
        for (int i = 0; i < d->num_sets; i++) 
            re += vardfe_lnlike(gradx + pos[i], gradx + nx, d->x + pos[i], d->x + nx, d->data[i]);
        for (int i = 0; i < d->num_free_param; i++)
            grad[i] = 0;
        int *xi = d->xi;
        for (int i = 0; i < d->num_param; i++) {
            if (d->is_free[i] == false) {
                constraint_func_t *cf = d->cf[i];
                for (int j = 0; j < cf->nx; j++) {
                    double tmp = cf->df(cf->x, j, cf->param);
                    grad[xi[cf->xi[j]]] += tmp * gradx[i];
                }
            } else {
                grad[xi[i]] += gradx[i];
            }
        }
        for (int i = 0; i < d->num_free_param; i++) {
            if (d->onln[i])
                grad[i] *= scale_param_jaco(x[i], d->free_param_types[i]);
        }
    }
    return re;
}