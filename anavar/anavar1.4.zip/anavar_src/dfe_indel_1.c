#include <string.h>

#include "dfe_def.h"
#include "dfeio.h"
#include "print_errmsg.h"
#include "constants.h"
#include "dist.h"
#include "scale_param.h"
#include "indeldfe.h"

#include "util/arrayutil.h"
#include "util/string_util.h"


/**
 * @paran snp On return, snp points to NULL.
 * @param x_onln This is of the length of the full snpdfe model with no constraints (but less the r parameters). This array is cloned.
 * @param rrange The lower and upper bounds for the r parameters. If r is not used, this parameter is ignored. On the original scale.
 * @param r_onln If true, then all the r parameters are on the natural log scale. If r is not used, this parameter is ignored.
 * @since 2017.5.2, 5.8 (changed to dfe_init), 9.18 (changed to dfe_init2)
 */
static dfe_t dfe_indel_1_build(vardfe_t *indel) {
    return dfe_init2(1, indel, NULL);
}

/*
 * @param sb This is set to NULL on return.
 * @since 2017.5.2, 5.8 (changed to dfeio_indel_continuous), 9.18
 */
static vardfe_t read_continuous(indeldfe_builder_t *ib, file_reader_t *reader, int *line_id, char **msg) {
    char *constraint;
    dfeio_indel_continuous(&constraint, ib[0], reader, line_id, msg);
    if (msg[0] != NULL)
        return NULL;

    indeldfe_builder_add_constraint(ib[0], msg, constraint);
    if (msg[0] != NULL)
        return NULL;
    
    vardfe_t vd = indeldfe_builder_build(ib, msg);
    if (msg[0] != NULL)
        return NULL;
    
    matrixalloc_1d_free(constraint);
    
    return vd;
}

/*
 * @param ib This is set to NULL on return.
 * @since 2017.5.2, 5.8 (changed to dfeio_indel_discrete), 6.16 (added constraint=neutral), 9.19
 */
static vardfe_t read_discrete(indeldfe_builder_t *ib, file_reader_t *reader, int *line_id, char **msg) {
    int c;
    char *constraint;
    dfeio_indel_discrete(&c, &constraint, ib[0], reader, line_id, msg);
    if (msg[0] != NULL)
        return NULL;

    indeldfe_builder_add_constraint(ib[0], msg, constraint);
    if (msg[0] != NULL)
        return NULL;
    
    vardfe_t vd = indeldfe_builder_build(ib, msg);
    if (msg[0] != NULL)
        return NULL;
    
    matrixalloc_1d_free(constraint);
    
    return vd;
}

/*
 * @since 2017.5.2, 9.19
 */
dfe_t dfe_indel_1(file_reader_t *reader, int *line_id, integrator_t *ig, char **msg) {
    msg[0] = NULL;
    
    int num_param = 5;
    int param_id = 0;
    const char *param_names[num_param];
    param_names[param_id++] = "n:";
    param_names[param_id++] = "m:";
    param_names[param_id++] = "ins_sfs:";
    param_names[param_id++] = "del_sfs:";
    param_names[param_id++] = "dfe:";
    
    char param[num_param][BUFFER_SIZE];
    dfeio_read_control_param(num_param, param, param_names, reader, line_id, msg);
    if (msg[0] != NULL)
        return NULL;
    
    param_id = 0;
    int n = dfeio_get_int(param[param_id], "Failed to parse n at line %i.\n", 
            line_id[0] - num_param + param_id + 1);
    param_id++;
    
    double m = dfeio_get_double(param[param_id], "Failed to parse m at line %i.\n", 
            line_id[0] - num_param + param_id + 1);
    param_id++;

    double *sfs[2];
    for (int i = 0, cnt = n - 1; i < 2; i++) {
        sfs[i] = matrixalloc_1d(cnt, sizeof (double));
        dfeio_get_double_array(cnt, sfs[i], param[param_id], "Failed to parse sfs at line %i.\n",
                line_id[0] - num_param + param_id + 1);
        param_id++;
    }   
    
    indeldfe_builder_t ib = indeldfe_builder_new(n, ig, 1, false, "", msg);
    if (msg[0] != NULL) 
        return NULL;
    
    indeldfe_builder_add_data(ib, m, sfs, msg);
    for (int i = 0; i < 2; i++)
        matrixalloc_1d_free(sfs[i]);
    if (msg[0] != NULL) 
        return NULL;
    
    vardfe_t vd;
    if (string_util_equal(param[param_id], "discrete"))
        vd = read_discrete(&ib, reader, line_id, msg);
    else if (string_util_equal(param[param_id], "continuous")) {
        vd = read_continuous(&ib, reader, line_id, msg);
    } else {
        PRINT_ERRMSG(msg, "Unknown dfe at line %i.\n", 
                line_id[0] - num_param + param_id + 1);
        return NULL;
    }
    if (msg[0] != NULL)
        return NULL;
    
    return dfe_indel_1_build(&vd);
}