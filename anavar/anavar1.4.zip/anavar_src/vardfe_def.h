#ifndef VARDFE_DEF_H
#define VARDFE_DEF_H

#include "vardfe.h"
#include "constraint_func.h"

struct vardfe_tag {
    /* The following are initialised in new() and add_data(). 
     * dsfs is the exception and should be initialised in build() */
    vartype_t type;
    int n;//the sample size
    /*
     * For SNPs, either n/2 or n-1 elements, depending on whether it's folded or not. <br>
     * For INDELs, the first n-1 elements contain the SFS for insertions and the rest contain the SFS for deletions.
     */
    double *data;
    int data_len;
    double *sfs;//containing the same number of elements as data
    /**
     * //dsfs[i][j] = d(sfs[i])/d(param[j]); includes all parameters (with r)
     * All elements should be set to zero on initialisation. 
     * This is because for a given sfs[i], its derivative is non-zero wrt some of the parameters (e.g., some of the r's).
     * These are not calculated, but may be used in the calculation of the partial derivative of the likelihood function.
     */
    double **dsfs;
    int nr;//the number of r parameters. If r is not used, then set to 0.
    
    /* The following are initialised in add_spikes or add_gamma_continuous */
    int num_param_full;//the number of parameters under the full model including r
    int num_free_param;//the number of free parameters including r
    param_t *param_types;//parameter types under the full model including r    
    char **param_names;//parameter names under the full model including r   
    double **ranges;//ranges of the parameters under the full model excluding r; range[0] contains the lower bounds; range[1] contains the upper bound; on the original scale
    void *dfe;//points to snpdfe_spikes, indeldfe_spikes etc
    void (* free_dfe)(void *dfe);
    /**
     * @param sfs An array of the same length as data.
     * @param dsfs sfs[i] length(sfs)-by-num_param_full matrix where num_param_full is the number of parameters under the full model including r.
     *             dsfs[i][j] is the partial derivative of sfs[i] wrt the j-th parameter.
     *             If dsfs is NULL, then partial derivatives are not calculated.
     * @param x All non-r parameter in the full model on the natural scale. This includes the e parameters when folded is true
     * @param has_der The length is nx. 
     */
    void (* cal)(double *sfs, double **dsfs, const double *x, const double *r, const bool *has_der, void *dfe);
    
    /* The following are initialised in init() */
    int nx;//the number of parameters in the full model excluding r; the length of x
    double *x;//the parameters of the full model excluding r; on the original scale
    bool *is_free;//an array of size nx; if true, the parameter is to be estimated.
    bool *has_der;//an array of size nx; if true, then partial derivative should be calculated for the parameter concerned.
    /**
     * The indices of the parameters in the full model (excluding r) in the input parameter array supplied to lnlike in vardfe.c not cal(). 
     * If a parameter takes a constant value, then the index is -1. If a parameter is dependent on one or more other parameters (specified using cf),
     * then the index is -2. Note that r are always free within vardfe
     */
    int *xi;
    /**
     * There are nx elements. 
     * cf[j] is the constraint functions param[j] = cf(param[i]). The parameters are defined on the original scale.
     */
    constraint_func_t **cf;
    
    /* 
     * Parameters affected by constraint 
     * num_free_param, x, is_free, has_der, xi, cf
     */
    
};

/**
 * This should be called internally inside add_spikes or add_continuous.
 * The purpose is to initialise the variables listed above, assuming no constraints in the model.
 */
void vardfe_init(vardfe_t vd);

#endif /* VARDFE_DEF_H */

