/* 
 * File:   tam_step.h
 * Author: Kai
 *
 * Created on 06 September 2013, 14:51
 */

#ifndef MODEL_2A_STEP_H
#    define	MODEL_2A_STEP_H

struct model_2a_step_TAG;
typedef struct model_2a_step_TAG model_2a_step_T;


/**
 * 
 * @param K The interval [0, 1] is divided into bins of size 1/K
 * @param nstep The number of times the population size changes (>=0)
 * @param maxT The maximum length of time of each step; must be NULL when nstep = 0; this array is copied by the function.
 *                  Time is scaled by the population size of each individual step.
 * @param tau The step size used to discretise time (in units of 2 Ne_i generations, 
 *                 where Ne_i is the population size of the i-th step). 
 *                 1. If nstep > 0, tau < min(maxT) and max(maxT) / tau < INT_MAX
 *               2. If nstep = 0, tau = 0
 * @return 
 */
model_2a_step_T *model_2a_step_new(const int K, const int nstep, const double *maxT, const double tau);
void model_2a_step_free(model_2a_step_T *);

/**
 * @param method Take values of 1 or 2; when a new object is constructed, 1 is set by default.
 */
void model_2a_step_set_iteration_method(model_2a_step_T *, int method);

/**
 * Solve the diffusion equation and obtain the population allele frequency spectrum of the A0 allele.
 * Ne is the population size before any change, and the mutation and selection parameters are scaled by Ne.
 * par[0]: (theta01, 4 Ne u01)
 * par[1]: (theta10, 4 Ne u10)
 * par[2]: gamma (4 Ne s) (A0A0: 1 + 2s, A0A1: 1 + 2hs, A1A1: 1)
 * par[3]: h (dominance coefficient)
 * par[4]: rho_1, rho(1) = Ne(1)/Ne, where Ne is the population size before any change.
 * par[5]: t_1, in units of 2*Ne(1) generations, where Ne(1) is the population size after the first change.
 * 
 * @return 0, if successful; 1, if parameter out of range; 2, if numerical difficulty was encountered.
 */
int model_2a_step_iterate(const double *par, model_2a_step_T *);

/**
 * Obtain the spectrum produced by the last invocation of model_2a_step_iterate().
 * double[i] is the proportion of sites where the A0 allele has frequency i/K.
 * 
 * <b>NOTE:</b> THE RETURN ARRAY COMES DIRECTLY FROM INTERNAL DATA, AND SHOULD NOT BE ALTERED.
 */
const double *model_2a_step_spectrum(model_2a_step_T *);


/**
 * 1. model_2a_step_spectrum is used to produce a spectrum, p = (p[i]).
 * 2. nl: the number of data lines
 * 3. ns[i]: the sample size of the i-th line
 * 4. data[i]: the data in the i-th line; data[i][j] the number of times the A0 allele is found j times
 * 5. bino (see data_util_bino_new)
 * 6. No sanity checks are done
 * 7. The result is stored in lnlike; -HUGE_VAL is returned if there is any error (info != 0).
 * 8. Return 0, if successful
 *           1, if parameters out of bounds
 *           2, if the results are numerically unstable.
 */
int model_2a_step_lnlike(const double *par, model_2a_step_T *stp, const int nl, const int *ns, double **data, double ***bino, double *lnlikePtr);

#endif	/* TAM_STEP_H */

