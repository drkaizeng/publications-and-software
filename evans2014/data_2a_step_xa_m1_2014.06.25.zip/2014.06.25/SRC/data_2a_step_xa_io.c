#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "util/matrixalloc.h"

#include "data_io.h"
#include "data_2a_step_xa_io.h"
#include "data_2a_io_work.h"


/**
 * @since 2013.08.01, 2013.08.11, 2013.09.10, 2013.09.26
 */
void data_2a_step_xa_io_m1_get_data(char *dataFile, int buffer_size,
        int *x_nlPtr, int **x_nsPtr, double ***x_dataPtr,
        int *a_nlPtr, int **a_nsPtr, double ***a_dataPtr) {    
    FILE *in;
    {
        char *df = data_io_trim(dataFile);
        in = fopen(df, "r");
        if (in == NULL) {
            fprintf(stderr, "Error: failed to open data file, %s\n", dataFile);
            exit(EXIT_FAILURE);
        }
    }
    
    int lineNo = 0;
    char buffer[buffer_size];
    char *st; 
    bool readX = false;
    bool readA = false;
    
    while ((st = fgets(buffer, buffer_size, in)) != NULL) {
        lineNo++;
        if (data_io_check_line_width(in, st) == false)
            data_io_print_file_error(dataFile, lineNo, buffer, NULL);
        int ind = data_io_first_nonspace(st);
        if (ind < 0)
            continue;
        else if (st[ind] == '#')
            continue;
        else if (st[ind] == 'X') {
            if (readX == true) {
                fprintf(stderr, "Error: Bad data file format!\n");
                exit(EXIT_FAILURE);
            }
            if (data_io_all_space(st + ind + 1) == false)
                data_io_print_file_error(dataFile, lineNo, buffer, NULL);
            data_2a_io_work_get_data(in, buffer_size, buffer, dataFile, &lineNo, x_nlPtr, x_nsPtr, x_dataPtr);
            readX = true;
        } else if (st[ind] == 'A') {
            if (readA == true || readX == false) {
                fprintf(stderr, "Error: Bad data file format!\n");
                exit(EXIT_FAILURE);
            }
            if (data_io_all_space(st + ind + 1) == false)
                data_io_print_file_error(dataFile, lineNo, buffer, NULL);
            data_2a_io_work_get_data(in, buffer_size, buffer, dataFile, &lineNo, a_nlPtr, a_nsPtr, a_dataPtr);
            readA = true;
        } else {
            data_io_print_file_error(dataFile, lineNo, buffer, NULL);
        }
    }
    if (x_nlPtr[0] == 0 || a_nlPtr[0] == 0) {
        fprintf(stderr, "Error: no data was read!\n");
        abort();
    }
    fclose(in);
}

/**
 * @since 2013.08.11, 2013.09.10
 */
void data_2a_step_xa_io_m1_free_data(int x_nl, int *x_ns, double **x_data, int a_nl, int *a_ns, double **a_data) {
    data_2a_io_work_free_data(x_nl, x_ns, x_data);
    data_2a_io_work_free_data(a_nl, a_ns, a_data);
}

/**
 * @since 2013.09.10, 2013.09.13, 2013.09.26
 */
void data_2a_step_xa_io_m1_write_data(FILE *outF,
        int x_nl, int *x_ns, double **x_data,
        int a_nl, int *a_ns, double **a_data) {
    data_2a_io_work_write_data(outF, "X", x_nl, x_ns, x_data);
    fprintf(outF, "\n");
    data_2a_io_work_write_data(outF, "A", a_nl, a_ns, a_data);
}

#define GET_TEST(test, status, instr, teststr, testPtr) \
            if (status == NOT_FOUND && strstr(#test, instr) != NULL) { \
                status = FOUND_TEST; \
                teststr = #test; \
                testPtr[0] = test; \
            }

/**
 * @since 2013.09.25 (NO_TEST), 2013.09.26 (GAMMA_X_EQ_LAMBDA_GAMMA_A), 2013.09.29 (LAMBDA_EQ_C), 2013.09.30, 2014.04.09
 */
void data_2a_step_xa_io_m1_get_test(data_2a_step_xa_m1_test_T *testPtr, double *testCPtr, 
        const char *stptr, const char *ctlFile, const int parN, FILE *outF, const char *parName) {
    enum { NOT_FOUND, FOUND_TEST } status;
    status = NOT_FOUND;
    {// Tests that do not require additional input parameters
        char stptr2[strlen(stptr) + 1];
        strcpy(stptr2, stptr);
        char *instr = data_io_trim(stptr2);
        if (instr == NULL || strlen(instr) == 0) {
            data_io_print_file_error(ctlFile, parN, stptr, NULL);
        }
        const char *teststr;
//      GET_TEST(test, status, instr, teststr, testPtr)
        GET_TEST(data_2a_step_xa_m1_test_NO_TEST, status, instr, teststr, testPtr);
        GET_TEST(data_2a_step_xa_m1_test_GAMMA_X_EQ_LAMBDA_GAMMA_A, status, instr, teststr, testPtr);
        GET_TEST(data_2a_step_xa_m1_test_GAMMA_X_EQ_3OVER4_GAMMA_A, status, instr, teststr, testPtr);
        GET_TEST(data_2a_step_xa_m1_test_THETA_01_X_EQ_LAMBDA_THETA_01_A, status, instr, teststr, testPtr);
        GET_TEST(data_2a_step_xa_m1_test_THETA_10_X_EQ_LAMBDA_THETA_10_A, status, instr, teststr, testPtr);
        GET_TEST(data_2a_step_xa_m1_test_THETA_01_X_EQ_THETA_10_X, status, instr, teststr, testPtr);
        GET_TEST(data_2a_step_xa_m1_test_THETA_01_A_EQ_THETA_10_A, status, instr, teststr, testPtr);
        if (status == FOUND_TEST) {
            if (outF != NULL)
                fprintf(outF, "%s %s\n", parName, teststr);
            return;
        }
    } 
    if (status == NOT_FOUND)  {// Tests that require an additional double constant
        char stptr2[strlen(stptr) + 1];
        strcpy(stptr2, stptr);
        char *instr = data_io_trim(stptr2);
        if (instr == NULL || strlen(instr) == 0) {
            data_io_print_file_error(ctlFile, parN, stptr, NULL);
        }
        int ind = data_io_first_space(instr);
        if (ind > 0) {
            instr[ind] = '\0'; //split the string
            if (strlen(instr) == 0) {
                data_io_print_file_error(ctlFile, parN, stptr, NULL);
            }
            const char *teststr;
            GET_TEST(data_2a_step_xa_m1_test_GAMMA_X_EQ_C, status, instr, teststr, testPtr);
            GET_TEST(data_2a_step_xa_m1_test_GAMMA_A_EQ_C, status, instr, teststr, testPtr);
            GET_TEST(data_2a_step_xa_m1_test_LAMBDA_EQ_C, status, instr, teststr, testPtr);
            if (status == FOUND_TEST) {
                testCPtr[0] = data_io_control_get_double(instr + ind + 1, ctlFile, parN, NULL, parName);
                if (outF != NULL)
                    fprintf(outF, "%s %s %g\n", parName, teststr, testCPtr[0]);
                return;
            }
        } else {
            data_io_print_file_error(ctlFile, parN, stptr, NULL);    
        }
    }
    data_io_print_file_error(ctlFile, parN, stptr, NULL);    
}

/**
 * @since 
 */
//void data_2a_step_xa_io_m1a_m_get_data(char *dataFile, int buffer_size, 
//        int x_m, int x_nlArr[x_m], int *x_nsArr[x_m], double **x_dataArr[x_m],
//        int a_m, int a_nlArr[a_m], int *a_nsArr[a_m], double **a_dataArr[a_m]) {
//    FILE *in;
//    {
//        char *df = data_io_trim(dataFile);
//        in = fopen(df, "r");
//        if (in == NULL) {
//            fprintf(stderr, "Error: failed to open data file, %s\n", dataFile);
//            exit(EXIT_FAILURE);
//        }
//    }
//    
//    int lineNo = 0;
//    char buffer[buffer_size];
//    char *st; 
//    
//    int preX = 0;
//    int preA = 0;
//    char *endPtr;
//    
//    while ((st = fgets(buffer, buffer_size, in)) != NULL) {
//        lineNo++;
//        if (data_io_check_line_width(in, st) == false)
//            data_io_print_file_error(dataFile, lineNo, buffer, NULL);
//        int ind = data_io_first_nonspace(st);
//        if (ind < 0)
//            continue;
//        else if (st[ind] == '#')
//            continue;
//        else if (st[ind] == 'X') {
//            if (preA != 0) {
//                fprintf(stderr, "Error: Bad data file format!\n");
//                abort();
//            }
//            int tmp;
//            data_io_next_int(st + ind + 1, &endPtr, &tmp);
//            tmp--;
//            if (tmp != preX || data_io_all_space(endPtr) == false) {
//                fprintf(stderr, "Error: Bad data file format!\n");
//                abort();
//            } 
//            data_2a_io_work_get_data(in, buffer_size, buffer, dataFile, &lineNo, &x_nlArr[preX], &x_nsArr[preX], &x_dataArr[preX]);
//            preX++;
//        } else if (st[ind] == 'A') {
//            if (preX != x_m) {
//                fprintf(stderr, "Error: Bad data file format!\n");
//                abort();
//            }
//            int tmp;
//            data_io_next_int(st + ind + 1, &endPtr, &tmp);
//            tmp--;
//            if (tmp != preA || data_io_all_space(endPtr) == false) {
//                fprintf(stderr, "Error: Bad data file format!\n");
//                abort();
//            } 
//            data_2a_io_work_get_data(in, buffer_size, buffer, dataFile, &lineNo, &x_nlArr[preA], &x_nsArr[preA], &x_dataArr[preA]);
//            preA++;
//        }
//    }
//}

