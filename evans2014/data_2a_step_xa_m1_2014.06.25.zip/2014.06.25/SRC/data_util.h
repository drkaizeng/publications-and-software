/* 
 * File:   data_util.h
 * Author: Kai
 *
 * Created on 06 September 2013, 16:43
 */

#ifndef DATA_UTIL_H
#    define	DATA_UTIL_H

#include <stdbool.h>

#include "gsl/gsl_rng.h"

/**
 * This checks whether
 * 1. double overflows to HUGE_VAL.
 * 2. DBL_MAX < HUGE_VAL
 * Warning is printed is any of the above is not true.
 */
void data_util_check_inf(void);

/**
 * bino[i][j][k]
 * 1. Population allele frequency is k/hapsize
 * 2. Sample size is ns[i]
 * 3. bino[i][j][k] = the probability that, in the sample, the allele concerned is observed j times, given 1 & 2.
 * 
 * It is guaranteed that the array of size hapsize pointed by bino[i][j] is allocated as a continuous memory block.
 */
double ***data_util_bino_new(const int nl, const int *ns, const int hapsize);
void data_util_bino_free(const int nl, const int *ns, double ***bino);

/**
 * Get a random number from [min, max).
 * max > min
 */
double data_util_get_unif(gsl_rng *, const double min, const double max);
/**
 * rho: Ne(t)/Ne
 * lambda: Ne_x / Ne_a
 * min, max: minimum and maximum values whose scales are determined by onLn
 * onLn: whether min and max are on natural-log scale
 */
double data_util_get_rho_lam_unif(gsl_rng *rng, double min, double max, bool onLn);


/**
 * Returns true only if the algorithm is gradient-based. 
 */
bool data_util_nlopt_is_ld(nlopt_algorithm alg);

#endif	/* DATA_UTIL_H */

