/* 
 * File:   data_2a_step_xa_io.h
 * Author: Kai
 *
 * Created on 06 September 2013, 18:41
 */

#ifndef DATA_2A_STEP_XA_IO_H
#    define	DATA_2A_STEP_XA_IO_H

#include <stdio.h>

#include "data_2a_step_xa_m1_param.h"

/**
 * On entry:
 * x_nlPtr[0] = 0,
 * x_nsPtr[0] = NULL
 * x_dataPtr[0] = NULL
 * 
 * @param dataFile
 * @param buffer_size
 * @param x_nlPtr x_lnPtr[0] contains the number of data lines
 * @param x_nsPtr x_nsPtr[0] points to a 1d integer array where each element tells the samples of the data line
 * @param x_dataPtr x_dataPtr[0] points a 2d double matrix. The ith row is the data collected from the i-th data line
 * @param a_nlPtr
 * @param a_nsPtr
 * @param a_dataPtr
 */
void data_2a_step_xa_io_m1_get_data(char *dataFile, int buffer_size,
        int *x_nlPtr, int **x_nsPtr, double ***x_dataPtr,
        int *a_nlPtr, int **a_nsPtr, double ***a_dataPtr);
void data_2a_step_xa_io_m1_free_data(int x_nl, int *x_ns, double **x_data, int a_nl, int *a_ns, double **a_data);
void data_2a_step_xa_io_m1_write_data(FILE *outF,
        int x_nl, int *x_ns, double **x_data,
        int a_nl, int *a_ns, double **a_data);
/**
 * @param testPtr On return, testPtr[0] stores the name of the test
 * @param testCPtr On return, testCPtr[0] stores the constant needed to carry out the test; 
                       if the test does not require a constant, then the value is undefined
 */
void data_2a_step_xa_io_m1_get_test(data_2a_step_xa_m1_test_T *testPtr, double *testCPtr, 
        const char *stptr, const char *ctlFile, const int parN, FILE *outF, const char *parName);

/**
 * @param x_m The number of X-linked sets
 */
//void data_2a_step_xa_io_m1a_m_get_data(char *dataFile, int buffer_size, 
//        int x_m, int x_nlArr[x_m], int *x_nsArr[x_m], double **x_dataArr[x_m],
//        int a_m, int a_nlArr[a_m], int *a_nsArr[a_m], double **a_dataArr[a_m]);
//void data_2a_step_xa_io_m1a_m_write_data(FILE *outF,
//        int x_m, int x_nlArr[x_m], int *x_nsArr[x_m], double **x_dataArr[x_m],
//        int a_m, int a_nlArr[a_m], int *a_nsArr[a_m], double **a_dataArr[a_m]);

#endif	/* DATA_2A_STEP_XA_IO_H */

