/* 
 * File:   data_2a_xa.h
 * Author: Kai
 *
 * Created on 06 September 2013, 15:49
 */

#ifndef DATA_2A_STEP_XA_H
#    define	DATA_2A_STEP_XA_H


/**
 * Model m1: 
 * 1. Parameters (all scaled by the Ne for the chromosome type concerned):
 *    1.1 theta_01_x, theta_10_x, gamma_x
 *    1.2 theta_01_a, theta_10_a, gamma_a
 *    1.3 lambda = Ne_x / Ne_a, where both Ne's are the values before any change in population size
 *    1.4 rho_i, t_a_i, where i = [1..steps], rho_i = Ne_i/Ne (the same for both all chromosome types,
 *                            t_a_i = T / (2 Ne_a_i), where T is the number of generation after the change,
 *                                 Ne_a_i is the autosomal population size of the current step.
 * 2. Equilibrium:
 *    2.1 Let Ne_x and Ne_a be the effective population sizes of the X and autosomes at equilibrium
 *                theta_ij_x(a) = 4 Ne_x(a) u_ij_x(a)
 *                gamma_x(a) = 4 Ne_x(a) s_x(a)
 *            where genic selection is assumed (A0A0: 1+2s, A0A1: 1+s, A1A1: 1)
 *    2.2 Therefore at equilibrium the two data sets are totally independent, each characterised by 3 parameters, and lambda is unnecessary.
 *    2.3 If, for instance, the allele-frequency spectra are constructed with respect to counts of G/C nucleotides in noncoding regions, 
 *        then GC will be allele A0, and AT will be allele A1. When gamma is positive, GC is favoured over AT, and vice versa.
 * 3. Non-equilibrium
 *    3.1 The stationary distributions can be obtained as above using the two sets of parameters for the 2
 *            chromosome sets.
 *    3.2 Assumed that the population size changed rho-fold T generations ago, so that 
 *                Ne_x(T)/Ne_x = Ne_a(T)/Ne_a = rho
 *                Ne_x(T) / Ne_a(T) = lambda
 *    3.3 Time is scaled by the corresponding Ne_i of each type of chromosome in the current time step. Therefore
 *                t_a = T / (2 Ne_a * rho)
 *                t_x = T / (2 Ne_x * rho)
 *                t_x = T / (2 Ne_a lambda * rho) = t_a / lambda
 *    3.4 In the diffusion algorithm, tau (the time step) is defined wrt the Ne_i of the i-th time step 
 *            for the type of chromosome concerned.
 * 
 * 
 * Data file format:
 * X
 * nl (this is the number of data lines below; nl must be an integer)
 * ns a[0] a[1] ... a[ns] (ns is the sample size; 
 *                         ns in different rows must be in strictly ascending order;
 *                         a[i] is the number of sites where the A0 allele is represented i times; 
 *                         a[i] is a nonnegative double value)
 * A
 * nl
 * ns a[0] a[1] ... a[ns]
 * 
 * 
 * Control file format: 
 * outputFile:
 * dataFile:
 * K: (>=10)
 * nstep: (integer; the number of maxT values).
 * maxTA: zero or more positive numbers; 
 *        if no number (empty line) is given, an equilibrium model is assumed;
 *        these are defined wrt the autosomes;
 *        different numbers are separated by space characters.
 * tau: (>0; but <min(maxTA))
 * nlopt_alg: 
 * useAugLag:
 * initThetaRange:
 * initGammaRange:
 * initLambdaRange:
 * initRhoRange:
 * seed: (if empty, a random seed is used; otherwise a non-negative number should be supplied)
 * thetaOnLn: (0: not on ln-scale; 1: on ln-scale)
 * lambdaOnLn: 
 * rhoOnLn:
 * setBound: (0/1)
 * rftol: (>=0; Relative tolerance on function value)
 * maxeval: (>0; Stop when the number of function evaluations exceeds maxeval)
 * maxtime: (the maximum time, in seconds, each search can spend)
 * imprftol: (>=0; the relative tolerance on function value to decide whether there is significant improvement 
 *                 compared to the result of a previous search)
 * nnoimp: (>0; if set to 1, the program stops after the first search ends; if > 1, then the program restart the search
 *              using the outcome of a previous attempt, and stops after the given number of attempts give no significant
 *              improvement in the result)
 * maximp: (>=nnoimp; the maximum number of searches based on the result of a previous search)
 */
void *data_2a_step_xa_m1_new(const char *controlFile, const int f_ind);
void data_2a_step_xa_m1_free(void *);
void data_2a_step_xa_m1_ml(void *);
/*
 * This program use the parameters given in the control file to generate a SFS predicted by the model.
 */
void data_2a_step_xa_m1_sfs(const char *controlFile, const int f_ind);


/**
 * Model m1a:
 * 1. This is a simplified version of model m1. Specifically, it assumes that the raw mutation rates are the same for
 *        both the X and autosomes, so that
 *            theta_01_x = theta_01_a * lambda
 * 2. Parameters (gamma and theta are scaled by the Ne for the chromosome type concerned):
 *    2.1 gamma_x
 *    2.2 theta_01_a, theta_10_a, gamma_a
 *    2.3 lambda = Ne_x / Ne_a, where both Ne's are the values before any change in population size
 *    2.4 rho_i, t_a_i, where i = [1..steps], rho_i = Ne_i/Ne (the same for both all chromosome types,
 *                            t_a_i = T / (2 Ne_a_i), where T is the number of generation after the change,
 *                                 Ne_a_i is the population size of the current step.
 * 3. Equilibrium:
 *    3.1 Let Ne_x and Ne_a be the effective population sizes of the X and autosomes at equilibrium
 *                theta_ij_x = 4 Ne_x u_ij = 4 Ne_a lambda u_ij = theta_ij_a lambda
 *                theta_ij_a = 4 Ne_a u_ij
 *                gamma_x = 4 Ne_x s_x
 *                gamma_a = 4 Ne_a s_a
 *            where genic selection is assumed (A0A0: 1+2s, A0A1: 1+s, A1A1: 1)
 * 4. Non-equilibrium
 *    4.1 The stationary distributions can be obtained as above using the two sets of parameters for the 2
 *            chromosome sets.
 *    4.2 Assumed that the population size changed rho-fold T generations ago, so that 
 *                Ne_x(T)/Ne_x = Ne_a(T)/Ne_a = rho
 *                Ne_x(T) / Ne_a(T) = lambda
 *    4.3 Time is scaled by the corresponding Ne_i of each type of chromosome in the current time step. Therefore
 *                t_a = T / (2 Ne_a * rho)
 *                t_x = T / (2 Ne_x * rho)
 *                t_x = T / (2 Ne_a lambda * rho) = t_a / lambda
 *    4.4 In the diffusion algorithm, tau (the time step) is defined wrt the Ne_i of the i-th time step 
 *            for the type of chromosome concerned.
 */
void *data_2a_step_xa_m1a_new(const char *controlFile, const int f_ind);
void data_2a_step_xa_m1a_free(void *);
void data_2a_step_xa_m1a_ml(void *);

/**
 * Model m1a_exp1:
 * 1. This is an extension of model m1a. It allows multiple sets of genes for both the X and the autosomes.
 *        These genes still have the same raw mutation rates, as well as lambda, rho and t_a. But each gene set has its own
 *        selection coefficient.
 * 2. Parameters (gamma and theta are scaled by the Ne for the chromosome type concerned):
 *    2.1 gamma_x_i, where i = [1..x_m], where x_m is the number of X-linked gene sets
 *    2.2 theta_01_a, theta_10_a, gamma_a_i, where i = [1..a_m]
 *    2.3 lambda = Ne_x / Ne_a, where both Ne's are the values before any change in population size
 *    2.4 rho_i, t_a_i, where i = [1..steps], rho_i = Ne_i/Ne (the same for both all chromosome types,
 *                            t_a_i = T / (2 Ne_a_i), where T is the number of generation after the change,
 *                                 Ne_a_i is the population size for the i-th step.
 * 
 * Data file:
 * X1:
 * nl
 * ...
 * 
 * X2:
 * nl
 * ...
 * 
 * A1:
 * nl
 * ...
 * 
 * 
 */
void *data_2a_step_xa_m1a_ext1_new(const char *controlFile, const int f_ind);
void data_2a_step_xa_m1a_ext1_free(void *);
void data_2a_step_xa_m1a_ext1_ml(void *);

#endif	/* DATA_2A_XA_H */

