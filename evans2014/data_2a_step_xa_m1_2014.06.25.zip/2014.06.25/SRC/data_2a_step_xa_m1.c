#include <math.h>
#include <string.h>
#include <time.h>
#include <limits.h>
#include <float.h>

#if defined (USE_MKL)
    #include "mkl.h"
#elif defined (USE_ATLAS)
    #include "cblas.h"    
#else
    #error Either USE_ATLAS OR USE_MKL must be set
#endif

#include "util/matrixalloc.h"
#include "nr/nr_simplex.h"

#include "data_2a_step_xa.h"
#include "data_2a_step_xa_m1_param.h"
#include "data_2a_step_xa_io.h"
#include "data_io.h"
#include "data_util.h"


/**
 * @since 2013.09.25, 2013.09.28, 2014.04.09
 */
static void header(FILE *outF, data_2a_step_xa_m1_param_T *par) {     
    fprintf(outF, "\nResults by %s:\n", __FILE__);
    fprintf(outF, "nimp\texit_code");
    for (int i = 0; i < par->npar; i++)
        fprintf(outF, "\t%s", par->parnstr[i]);
    fprintf(outF, "\tlnLike\n");
}

/**
 * Transform x to the original scale depending on onLn. If onLn is true, then x has previously been ln-transformed;
 * otherwise, x is on the natural scale.
 * @since 2013.09.25, 2013.09.30, 2014.04.08
 */
static inline double par_to_nat(const bool onLn, const double x) {
    return onLn ? exp(x) : x;
}

/**
 * @since 2013.09.25, 2013.09.28 (changed par->onLn to par->onLnNoTest), 2013.09.30, 2014.04.08
 */
static double lnlike_NO_TEST(const double *x, void *params) {    
    data_2a_step_xa_m1_param_T *par = (data_2a_step_xa_m1_param_T *) params;
    
    double *x_param = par->x_param;
    x_param[3] = 0.5;
    double *a_param = par->a_param;
    a_param[3] = 0.5;
    
    int ptr = 0;
    for (int i = 0; i <= 2; i++) {
        x_param[i] = par_to_nat(par->onLnNoTest[ptr], x[ptr]);
        ptr++;
    }
    
    for (int i = 0; i <= 2; i++) {
        a_param[i] = par_to_nat(par->onLnNoTest[ptr], x[ptr]);
        ptr++;
    }

    if (par->nstep > 0) {
        double lambda = par_to_nat(par->onLnNoTest[ptr], x[ptr]);
        ptr++;
        if (lambda <= 0)
            return -HUGE_VAL;
        for (int i = 0, pp = 4; i < par->nstep; i++) {
            double rho = par_to_nat(par->onLnNoTest[ptr], x[ptr]);
            ptr++;
            double t_a = par_to_nat(par->onLnNoTest[ptr], x[ptr]);
            ptr++;
            double t_x = t_a / lambda;
            x_param[pp] = rho;
            a_param[pp] = rho;
            pp++;
            x_param[pp] = t_x;
            a_param[pp] = t_a;
            pp++;
        }
    }
    
    double lnx;
    int info = model_2a_step_lnlike(par->x_param, par->x_model, par->x_nl, par->x_ns, par->x_data, par->x_bino, &lnx);
    if (info != 0)
        return -HUGE_VAL;
    
    double lna;
    info = model_2a_step_lnlike(par->a_param, par->a_model, par->a_nl, par->a_ns, par->a_data, par->a_bino, &lna);
    if (info != 0)
        return -HUGE_VAL;
    
    return lnx + lna; 
}

/**
 * x should be on the natural scale
 * @since 2013.09.28, 2013.09.30
 */
static inline double par_to_ln(const bool onLn, double x) {
    return onLn ? log(x) : x;
}

/**
 * @since 2013.09.28, 2013.09.30, 2014.04.09
 */
static double lnlike_GAMMA_X_EQ_LAMBDA_GAMMA_A(const double *x, void *params) {        
    data_2a_step_xa_m1_param_T *par = (data_2a_step_xa_m1_param_T *) params;
    static size_t s1 = 2 * sizeof (double);
    memcpy(par->xNoTest, x, s1);
    memcpy(par->xNoTest + 3, x + 2, (size_t) (par->npar - 2) * sizeof (double));
    double lambda = par_to_nat(par->onLn[5], x[5]);
    double gamma_a = par_to_nat(par->onLn[4], x[4]);
    double gamma_x = lambda * gamma_a;
    par->xNoTest[2] = par_to_ln(par->onLnNoTest[2], gamma_x);
    return lnlike_NO_TEST(par->xNoTest, params);
}

/**
 * @since 2013.10.13, 2014.04.09 (changed, so that nstep=0 is allowed)
 */
static double lnlike_GAMMA_X_EQ_3OVER4_GAMMA_A(const double *x, void *params) {        
    data_2a_step_xa_m1_param_T *par = (data_2a_step_xa_m1_param_T *) params;
    static size_t s1 = 2 * sizeof (double);
    memcpy(par->xNoTest, x, s1);
    static size_t s2 = 3 * sizeof (double);
    memcpy(par->xNoTest + 3, x + 2, s2);
    double lambda = 0.75;
    double gamma_a = par_to_nat(par->onLn[4], x[4]);
    double gamma_x = lambda * gamma_a;
    par->xNoTest[2] = par_to_ln(par->onLnNoTest[2], gamma_x);
    if (par->nstep > 0) {
        par->xNoTest[6] = par_to_ln(par->onLnNoTest[6], lambda);
        memcpy(par->xNoTest + 7, x + 5, (size_t) (par->npar - 5) * sizeof (double));
    }
    return lnlike_NO_TEST(par->xNoTest, params);
}

/**
 * @since 2013.09.30, 2014.04.09
 */
static double lnlike_THETA_01_X_EQ_LAMBDA_THETA_01_A(const double *x, void *params) {    
    data_2a_step_xa_m1_param_T *par = (data_2a_step_xa_m1_param_T *) params;
    memcpy(par->xNoTest + 1, x, (size_t) par->npar * sizeof (double));
    double lambda = par_to_nat(par->onLn[5], x[5]);
    double theta_01_a = par_to_nat(par->onLn[2], x[2]);
    double theta_01_x = lambda * theta_01_a;
    par->xNoTest[0] = par_to_ln(par->onLnNoTest[0], theta_01_x);
    return lnlike_NO_TEST(par->xNoTest, params);
}

/**
 * @since 2013.09.30, 2014.04.09
 */
static double lnlike_THETA_10_X_EQ_LAMBDA_THETA_10_A(const double *x, void *params) {    
    data_2a_step_xa_m1_param_T *par = (data_2a_step_xa_m1_param_T *) params;
    par->xNoTest[0] = x[0];
    memcpy(par->xNoTest + 2, x + 1, (size_t) (par->npar - 1) * sizeof (double));
    double lambda = par_to_nat(par->onLn[5], x[5]);
    double theta_10_a = par_to_nat(par->onLn[3], x[3]);
    double theta_10_x = lambda * theta_10_a;
    par->xNoTest[1] = par_to_ln(par->onLnNoTest[1], theta_10_x);
    return lnlike_NO_TEST(par->xNoTest, params);
}

/**
 * @since 2013.09.30, 2014.04.09
 */
static double lnlike_THETA_01_X_EQ_THETA_10_X(const double *x, void *params) {    
    data_2a_step_xa_m1_param_T *par = (data_2a_step_xa_m1_param_T *) params;
    par->xNoTest[0] = x[0];//both theta must be on the same scale
    memcpy(par->xNoTest + 1, x, (size_t) (par->npar) * sizeof (double));
    return lnlike_NO_TEST(par->xNoTest, params);
}

/**
 * @since 2013.09.30, 2014.04.09
 */
static double lnlike_THETA_01_A_EQ_THETA_10_A(const double *x, void *params) {    
    data_2a_step_xa_m1_param_T *par = (data_2a_step_xa_m1_param_T *) params;
    static size_t s1 = 3 * sizeof (double);
    memcpy(par->xNoTest, x, s1);
    memcpy(par->xNoTest + 4, x + 3, (size_t) (par->npar - 3) * sizeof (double));
    par->xNoTest[3] = x[3];//all thetas are on the same scale
    return lnlike_NO_TEST(par->xNoTest, params);
}

/**
 * @since 2013.09.30, 2014.04.09
 */
static double lnlike_GAMMA_X_EQ_C(const double *x, void *params) {    
    data_2a_step_xa_m1_param_T *par = (data_2a_step_xa_m1_param_T *) params;
    static size_t s1 = 2 * sizeof (double);
    memcpy(par->xNoTest, x, s1);
    memcpy(par->xNoTest + 3, x + 2, (size_t) (par->npar - 2) * sizeof (double));
    par->xNoTest[2] = par_to_ln(par->onLnNoTest[2], par->testC);
    return lnlike_NO_TEST(par->xNoTest, params);
}

/**
 * @since 2013.09.30, 2014.04.09
 */
static double lnlike_GAMMA_A_EQ_C(const double *x, void *params) {    
    data_2a_step_xa_m1_param_T *par = (data_2a_step_xa_m1_param_T *) params;
    static size_t s1 = 5 * sizeof (double);
    memcpy(par->xNoTest, x, s1);
    memcpy(par->xNoTest + 6, x + 5, (size_t) (par->npar - 5) * sizeof (double));
    par->xNoTest[5] = par_to_ln(par->onLnNoTest[5], par->testC);
    return lnlike_NO_TEST(par->xNoTest, params);
}

/**
 * @since 2013.09.29, 2013.09.30, 2014.04.09
 */
static double lnlike_LAMBDA_EQ_C(const double *x, void *params) {    
    data_2a_step_xa_m1_param_T *par = (data_2a_step_xa_m1_param_T *) params;
    static size_t s1 = 6 * sizeof (double);
    memcpy(par->xNoTest, x, s1);
    memcpy(par->xNoTest + 7, x + 6, (size_t) (par->npar - 6) * sizeof (double));
    par->xNoTest[6] = par_to_ln(par->onLnNoTest[6], par->testC);
    return lnlike_NO_TEST(par->xNoTest, params);
}

/**
 * i_min and i_max (both inclusive) are the range in p and y that are to be updated.
 * @since 2013.09.26 (NO_TEST), 2013.09.29, 2014.04.09 (by eye)
 */
static void init_point(double **p, double *y, int i_min, int i_max, data_2a_step_xa_m1_param_T *par) {
    for (int i = i_min; i <= i_max; i++) {
        while (true) {
            for (int j = 0; j < par->npar; j++) {
                if (par->parn[j] == data_2a_step_xa_m1_param_name_THETA) {
                    if (par->onLn[j] == true)
                        p[i][j] = data_util_get_unif(par->rng, par->lb[j], par->ub[j]);
                    else
                        p[i][j] = exp(data_util_get_unif(par->rng, log(par->lb[j]), log(par->ub[j])));
                } else if (par->parn[j] == data_2a_step_xa_m1_param_name_RHO || par->parn[j] == data_2a_step_xa_m1_param_name_LAMBDA) {
                    p[i][j] = data_util_get_rho_lam_unif(par->rng, par->lb[j], par->ub[j], par->onLn[j]);
                } else {//gamma and tau
                    p[i][j] = data_util_get_unif(par->rng, par->lb[j], par->ub[j]);
                }
            }
            y[i] = par->lnlike(p[i], par);
            if (! (isnan(y[i]) || isinf(y[i]) || y[i] <= -HUGE_VAL || y[i] >= HUGE_VAL)) 
                break;
        }
    }
}

/**
 * @since 2013.09.26, 2013.09.28, 2014.04.08
 */
static void write_result(FILE *outF, double *x, double y, data_2a_step_xa_m1_param_T *par) {
    for (int j = 0; j < par->npar; j++) {
        fprintf(outF, "\t%.8e", par->onLn[j] ? exp(x[j]) : x[j]);
    }
    fprintf(outF, "\t%.15e\n", y);
}

static double nlopt_f(unsigned n, const double *x, double *grad, void *f_data) {
    data_2a_step_xa_m1_param_T *par = (data_2a_step_xa_m1_param_T *) f_data;
    if (grad != NULL) {//setBound is always true; see new()
        abort();
    }
    return par->lnlike(x, f_data);
}

/**
 * @since 2014.05.12
 */
static void nlopt_set_bound(nlopt_opt opt, data_2a_step_xa_m1_param_T *par) {
    if (nlopt_set_lower_bounds(opt, par->lb) != NLOPT_SUCCESS) {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
    if (nlopt_set_upper_bounds(opt, par->ub) != NLOPT_SUCCESS) {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
}

/**
 * @since 2014.05.08, 2014.05.12, 2014.06.01
 */
static nlopt_opt nlopt_get_opt_work(nlopt_algorithm alg, data_2a_step_xa_m1_param_T *par) {
    nlopt_opt opt = nlopt_create(alg, (unsigned) par->npar);
    if (opt == NULL) {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
    if (nlopt_set_ftol_rel(opt, par->rftol) != NLOPT_SUCCESS) {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
    if (nlopt_set_maxeval(opt, par->maxeval) != NLOPT_SUCCESS) {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
    if (nlopt_set_maxtime(opt, par->maxtime) != NLOPT_SUCCESS) {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
    return opt;
}

/**
 * @since 2014.06.01
 */
static nlopt_opt nlopt_get_opt(data_2a_step_xa_m1_param_T *par) {
    nlopt_opt opt = nlopt_get_opt_work(par->nlopt_alg, par);
    if (par->nlopt_alg == NLOPT_G_MLSL || par->nlopt_alg == NLOPT_G_MLSL_LDS) {
        nlopt_opt local = nlopt_get_opt_work(NLOPT_LN_NELDERMEAD, par);
        if (nlopt_set_local_optimizer(opt, local) != NLOPT_SUCCESS) {
            fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
            abort();
        }
    }
    if (nlopt_set_max_objective(opt, nlopt_f, par) != NLOPT_SUCCESS) {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
    nlopt_set_bound(opt, par);
    return opt;
}

/**
 * @since 2013.09.13, 2013.09.26, 2014.04.09
 */
static void nlopt_run(data_2a_step_xa_m1_param_T *par) {
    nlopt_opt opt = nlopt_get_opt(par);
    double *x = matrixalloc_1d(par->npar, sizeof (double));
    if (par->initPoint != NULL) {
        memcpy(x, par->initPoint, (size_t) par->npar * sizeof (double));
    } else {
        double tmp;
        init_point(&x, &tmp, 0, 0, par);
    }
    FILE *outF = par->outF;
    int nnoimp = 1;
    double fold;
    clock_t rt = clock();
    for (int i = 1; i <= par->maximp; i++) {
        double opt_f;
        nlopt_result info = nlopt_optimize(opt, x, &opt_f);      
        fprintf(outF, "%d\t%d", i, info);
        write_result(outF, x, opt_f, par);
        fflush(outF);
        if (i > 1) {
            double tmp = fabs(opt_f - fold);
            if (tmp <= par->imprftol * 0.5 * (fabs(opt_f) + fabs(fold)))
                nnoimp++;
            else
                nnoimp = 1;
        }
        fold = opt_f;
        if (nnoimp >= par->nnoimp)
            break;
    }
    rt = clock() - rt;
    clock_t rt_1 = rt / CLOCKS_PER_SEC;
    clock_t rt_2 = rt - (rt_1 * CLOCKS_PER_SEC);
    long double rt_d = (long double) rt_1 + (long double) rt_2 / CLOCKS_PER_SEC;
    fprintf(outF, "Done!\n");
    fprintf(outF, "Time used (in seconds) = %.3Lf\n\n", rt_d);
    fflush(outF);
    nlopt_destroy(opt);
    matrixalloc_1d_free(x);
}

/**
 * @since 2013.09.26
 */
static double nrsimplex_f(double *x, void *f_data) {
    data_2a_step_xa_m1_param_T *par = (data_2a_step_xa_m1_param_T *) f_data;
    for (int i = 0; i < par->npar; i++) {
        if (x[i] < par->lb[i] || x[i] > par->ub[i])
            return HUGE_VAL;
    }
    return -par->lnlike(x, f_data);
}

/**
 * @since 2013.09.13, 2013.09.30, 2014.04.09
 */
static void nrsimplex_run(data_2a_step_xa_m1_param_T *par) {
    nr_simplex_T *sim = nr_simplex_new(par->npar, nrsimplex_f, par, par->rftol, -1, par->maxeval, par->maxtime);
    int nparp1 = par->npar + 1;
    double **p = matrixalloc_2d_d(nparp1, par->npar);
    double *y = matrixalloc_1d(nparp1, sizeof (double));
    if (par->initPoint != NULL) {
        memcpy(p[0], par->initPoint, (size_t) par->npar * sizeof (double));
        y[0] = par->lnlike(p[0], par);
        init_point(p, y, 1, par->npar, par);
    } else {
        init_point(p, y, 0, par->npar, par);
    }
    cblas_dscal(nparp1, -1, y, 1);
    FILE *outF = par->outF;
    int nnoimp = 1;
    double fold, opt_f;
    clock_t rt = clock();
    for (int i = 1; i <= par->maximp; i++) {
        nr_simplex_result info = nr_simplex_search(p, y, sim);
        opt_f = -y[0];
        fprintf(outF, "%d\t%d", i, info);
        write_result(outF, p[0], opt_f, par);
        fflush(outF);
        if (i > 1) {
            double tmp = fabs(opt_f - fold);
            if (tmp <= par->imprftol * 0.5 * (fabs(opt_f) + fabs(fold)))
                nnoimp++;
            else
                nnoimp = 1;
        }
        fold = opt_f;
        if (nnoimp >= par->nnoimp)
            break;
        if (i < par->maximp) {
            init_point(p, y, 1, par->npar, par);
            cblas_dscal(par->npar, -1, y + 1, 1);
        }
    }
    rt = clock() - rt;
    clock_t rt_1 = rt / CLOCKS_PER_SEC;
    clock_t rt_2 = rt - (rt_1 * CLOCKS_PER_SEC);
    long double rt_d = (long double) rt_1 + (long double) rt_2 / CLOCKS_PER_SEC;
    fprintf(outF, "Done!\n");
    fprintf(outF, "Time used (in seconds) = %.3Lf\n\n", rt_d);
    fflush(outF);
    matrixalloc_1d_free(y);
    matrixalloc_2d_d_free(p);
    nr_simplex_free(sim);
}

/**
 * @since 2013.09.13, 2013.09.26, 2014.04.09
 */
void data_2a_step_xa_m1_ml(void *ptr) {     
    data_2a_step_xa_m1_param_T *par = (data_2a_step_xa_m1_param_T *) ptr;
    header(par->outF, par);
    if (par->useNrSimplex == true) {
        nrsimplex_run(par);
    } else {
        nlopt_run(par);
    }
}

/**
 * This functions inserts the parameter to the ind-th element of
 * parn
 * parnstr
 * onLn
 * lb
 * ub
 * onLnNoTest
 * 
 * @since 2013.09.25, 2013.09.26, 2013.09.28 (added parnstr and onLnNoTest), 2013.09.30, 2014.04.08
 */
static void new_par(data_2a_step_xa_m1_param_T *par, const int ind, 
        const data_2a_step_xa_m1_param_name_T name, const char *namestr, const bool onLn, const double initL, const double initU) {
    par->parn[ind] = name;
    par->parnstr[ind] = matrixalloc_1d((int) (strlen(namestr) + 1), sizeof (char));
    strcpy(par->parnstr[ind], namestr);
    par->onLn[ind] = onLn;
    if (onLn == true) {
        par->lb[ind] = log(initL);
        par->ub[ind] = log(initU);
    } else {
        par->lb[ind] = initL;
        par->ub[ind] = initU;
    }
    par->onLnNoTest[ind] = onLn;
}

/**
 * Remove the ind-th element in 
 * parn
 * parnstr
 * onLn
 * lb
 * ub
 * 
 * On return, par->npar is one smaller than that before calling this function.
 * 
 * @since 2013.09.26, 2013.09.28 (added par->npar--), 2013.09.29, 2013.09.30, 2014.04.09
 */
static void rm_par(data_2a_step_xa_m1_param_T *par, const int ind) {
    matrixalloc_1d_free(par->parnstr[ind]);
    for (int i = ind + 1; i < par->npar; i++) {
        par->parn[i - 1] = par->parn[i];
        par->parnstr[i - 1] = par->parnstr[i];
        par->onLn[i - 1] = par->onLn[i];
        par->lb[i - 1] = par->lb[i];
        par->ub[i - 1] = par->ub[i];
    }
    par->npar--;
}

#define GET_NPAR_CHECK_NSTEP(nstep) \
            if (nstep < 1) { \
                fprintf(stderr, "Error: %s %d\n", __FILE__, __LINE__); \
                abort(); \
            }

/**
 * @since 2013.09.28 (NO_TEST; GAMMA_X_EQ_LAMBDA_GAMMA_A), 2013.09.30 (LAMBDA_EQ_C), 2014.04.08
 * 2014.04.09 (allow GAMMA_X_EQ_3OVER4_GAMMA_A to be carried when nstep=0)
 */
static void get_test(data_2a_step_xa_m1_param_T *par,
        double *initThetaRange, double *initGammaRange, double *initLambdaRange, double *initRhoRange, double *initTARange, 
        bool thetaOnLn, bool gammaOnLn, bool lambdaOnLn, bool rhoOnLn, bool taOnLn) {
    int nstep = par->nstep;
    data_2a_step_xa_m1_test_T test = par->test;    
    par->npar = 6;//the number of parameters when there is NO_TEST
    if (nstep != 0)
        par->npar += 1 + 2 * nstep;
    par->parn = matrixalloc_1d(par->npar, sizeof (data_2a_step_xa_m1_param_name_T));
    par->parnstr = matrixalloc_1d(par->npar, sizeof (char *));
    par->onLn = matrixalloc_1d(par->npar, sizeof (bool));
    par->lb = matrixalloc_1d(par->npar, sizeof (double));
    par->ub = matrixalloc_1d(par->npar, sizeof (double));
    par->xNoTest = matrixalloc_1d(par->npar, sizeof (double));  
    par->onLnNoTest = matrixalloc_1d(par->npar, sizeof (bool)); 
    {// the full model
        /* theta_x and theta_a */
        int nTheta = 4;
        int indTheta[4] = { 0, 1, 3, 4 };
        const char *thstr[4];
        thstr[0] = "theta_01_x";
        thstr[1] = "theta_10_x";
        thstr[2] = "theta_01_a";
        thstr[3] = "theta_10_a";
        for (int i = 0; i < nTheta; i++) {
            new_par(par, indTheta[i], data_2a_step_xa_m1_param_name_THETA, thstr[i], thetaOnLn, initThetaRange[0], initThetaRange[1]);
        }
        /* gamma_x and gamma_a */
        int nGamma = 2;
        int indGamma[2] = {2, 5};
        const char *gastr[2];
        gastr[0] = "gamma_x";
        gastr[1] = "gamma_a";
        for (int i = 0; i < nGamma; i++) {
            new_par(par, indGamma[i], data_2a_step_xa_m1_param_name_GAMMA, gastr[i], gammaOnLn, initGammaRange[0], initGammaRange[1]);
        }
        if (nstep > 0) {
            new_par(par, 6, data_2a_step_xa_m1_param_name_LAMBDA, "lambda", lambdaOnLn, initLambdaRange[0], initLambdaRange[1]); //lambda
            char rhostr[5 + 1 + nstep / 10];
            char taustr[7 + 1 + nstep / 10];
            for (int i = 0, ind = 7; i < nstep; i++) {//rho and maxTA
                sprintf(rhostr, "rho_%d", (i + 1));
                new_par(par, ind, data_2a_step_xa_m1_param_name_RHO, rhostr, rhoOnLn, initRhoRange[2 * i], initRhoRange[2 * i + 1]);
                ind++;
                sprintf(taustr, "tau_a_%d", (i + 1));
                new_par(par, ind, data_2a_step_xa_m1_param_name_TAU, taustr, taOnLn, initTARange[2 * i], initTARange[2 * i + 1]);
                ind++;
            }
        }
    }
    if (test == data_2a_step_xa_m1_test_NO_TEST) {
        par->lnlike = lnlike_NO_TEST;
    } else if (test == data_2a_step_xa_m1_test_GAMMA_X_EQ_LAMBDA_GAMMA_A) {
        GET_NPAR_CHECK_NSTEP(nstep);
        rm_par(par, 2);//remove gamma_x
        par->lnlike = lnlike_GAMMA_X_EQ_LAMBDA_GAMMA_A;
    } else if (test == data_2a_step_xa_m1_test_GAMMA_X_EQ_3OVER4_GAMMA_A) {
        rm_par(par, 2);//remove gamma_x
        if (nstep > 0)
            rm_par(par, 5);//remove lambda
        par->lnlike = lnlike_GAMMA_X_EQ_3OVER4_GAMMA_A;
    } else if (test == data_2a_step_xa_m1_test_THETA_01_X_EQ_LAMBDA_THETA_01_A) {
        GET_NPAR_CHECK_NSTEP(nstep);
        rm_par(par, 0);//remove theta_01_x
        par->lnlike = lnlike_THETA_01_X_EQ_LAMBDA_THETA_01_A;
    } else if (test == data_2a_step_xa_m1_test_THETA_10_X_EQ_LAMBDA_THETA_10_A) {
        GET_NPAR_CHECK_NSTEP(nstep);
        rm_par(par, 1);//remove theta_10_x
        par->lnlike = lnlike_THETA_10_X_EQ_LAMBDA_THETA_10_A;
    } else if (test == data_2a_step_xa_m1_test_THETA_01_X_EQ_THETA_10_X) {
        rm_par(par, 0);//remove theta_01_x
        par->lnlike = lnlike_THETA_01_X_EQ_THETA_10_X;
    } else if (test == data_2a_step_xa_m1_test_THETA_01_A_EQ_THETA_10_A) {
        rm_par(par, 3);//remove theta_01_a
        par->lnlike = lnlike_THETA_01_A_EQ_THETA_10_A;    
    } else if (test == data_2a_step_xa_m1_test_GAMMA_X_EQ_C) {
        rm_par(par, 2);//remove gamma_x
        par->lnlike = lnlike_GAMMA_X_EQ_C;            
    } else if (test == data_2a_step_xa_m1_test_GAMMA_A_EQ_C) {
        rm_par(par, 5);//remove gamma_a
        par->lnlike = lnlike_GAMMA_A_EQ_C;                  
    } else if (test == data_2a_step_xa_m1_test_LAMBDA_EQ_C) {
        GET_NPAR_CHECK_NSTEP(nstep);
        rm_par(par, 6);//remove lambda
        par->lnlike = lnlike_LAMBDA_EQ_C;
    } else {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort(); 
    }
}

/**
 * @since 2013.09.26, 2013.09.28 (added onLnNoTest)
 */
static void free_test(data_2a_step_xa_m1_param_T *par) {
    matrixalloc_1d_free(par->onLnNoTest);
    matrixalloc_1d_free(par->xNoTest);
    matrixalloc_1d_free(par->ub);
    matrixalloc_1d_free(par->lb);
    matrixalloc_1d_free(par->onLn);
    matrixalloc_1d_free(par->parn);
    for (int i = 0; i < par->npar; i++)
        matrixalloc_1d_free(par->parnstr[i]);
    matrixalloc_1d_free(par->parnstr);
}

/**
 * @since 2013.09.26, 2014.04.09
 */
void *data_2a_step_xa_m1_new(const char *ctlFile, const int f_ind) {
#ifdef USE_MKL
    if (sizeof (MKL_INT) != sizeof (int)) {//Make sure MKL_INT = int
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        exit(EXIT_FAILURE);
    }
    while (true) {
        MKL_INT a = 0;
        int b = 0;
        if ((long double) (~a) != (long double) (~b)) {
            fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
            exit(EXIT_FAILURE);
        }
        break;
    }
#endif
    
    data_util_check_inf();
    
    const int buffer_size = 50000;
    /* control parameters */
    int nCtlPar = 23;
    int parN = 0;
    const char *ctlPar[nCtlPar];
    ctlPar[parN++] = "outputFile:";
    ctlPar[parN++] = "dataFile:";
    ctlPar[parN++] = "K:";
    ctlPar[parN++] = "nstep:";
    ctlPar[parN++] = "tau:";
    ctlPar[parN++] = "test:";
    ctlPar[parN++] = "useNrSimplex:";
    ctlPar[parN++] = "nlopt_alg:";
    ctlPar[parN++] = "initPoint:";
    ctlPar[parN++] = "initThetaRange:";
    ctlPar[parN++] = "initGammaRange:";
    ctlPar[parN++] = "initLambdaRange:";
    ctlPar[parN++] = "initRhoRange:";
    ctlPar[parN++] = "initTARange:"; 
    ctlPar[parN++] = "thetaOnLn:";
    ctlPar[parN++] = "lambdaOnLn:";
    ctlPar[parN++] = "rhoOnLn:";
    ctlPar[parN++] = "rftol:";
    ctlPar[parN++] = "maxeval:";
    ctlPar[parN++] = "maxtime:";
    ctlPar[parN++] = "imprftol:";
    ctlPar[parN++] = "nnoimp:";
    ctlPar[parN++] = "maximp:";
        
    if (f_ind == -1) {
        for (int i = 0; i < nCtlPar; i++)
            fprintf(stdout, "%s\n", ctlPar[i]);
        exit(1);
    } else if (f_ind <= 0) {
        fprintf(stderr, "Error: f_ind <= 0!\n");
        abort();
    }
        
    char ctlParVal[nCtlPar][buffer_size];
    data_io_control_param_get(ctlFile, buffer_size, nCtlPar, ctlPar, ctlParVal);
        
    parN = 0;
    
    FILE *outF = data_io_control_get_outF(ctlParVal[parN], f_ind);
    fprintf(outF, "Control file contents:\n");
    fprintf(outF, "%s %s\n", ctlPar[parN], data_io_trim(ctlParVal[parN]));
    parN++;    
    
    char *dataFile = data_io_trim(ctlParVal[parN]);
    if (dataFile == NULL) {
        fprintf(stderr, "Error: no data file was provided.\n");
        abort();
    }
    fprintf(outF, "%s %s\n", ctlPar[parN], dataFile);
    parN++;
    
    int K = data_io_control_get_int(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    if (K < 10)
        data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "Error: K < 10");
    parN++;    
    
    int nstep = data_io_control_get_int(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    if (nstep < 0)
        data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "Error: nstep < 0");
    parN++;
    
    double tau;
    if (nstep == 0) {
        tau = 0;
        if (data_io_all_space(ctlParVal[parN]) == false)
            data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "tau: should not be set when nstep: is 0.");      
        fprintf(outF, "%s\n", ctlPar[parN]); 
    } else {
        tau = data_io_control_get_double(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
        if (tau <= 0 || tau >= 0.1)
            data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "Error: tau <= 0 or tau >= 0.1");      
    }
    parN++;
           
    /* test */
    data_2a_step_xa_m1_test_T test;
    double testC;
    data_2a_step_xa_io_m1_get_test(&test, &testC, ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    if (test == data_2a_step_xa_m1_test_GAMMA_X_EQ_LAMBDA_GAMMA_A || 
            test == data_2a_step_xa_m1_test_THETA_01_X_EQ_LAMBDA_THETA_01_A || 
            test == data_2a_step_xa_m1_test_THETA_10_X_EQ_LAMBDA_THETA_10_A || 
            test == data_2a_step_xa_m1_test_LAMBDA_EQ_C) {
        if (nstep < 1) {
            fprintf(stderr, "Error: to carry out tests involving lambda, nstep must be greater than zero.");
            abort();
        }
    }
    if (test == data_2a_step_xa_m1_test_LAMBDA_EQ_C) {
        if (testC <= 0)
            data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "Lambda must be strictly positive.");
    }
    parN++;    
    
    bool useNrSimplex = data_io_control_get_bool(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    parN++;
    
    nlopt_algorithm nlopt_alg;
    if (useNrSimplex == true) {
        if (data_io_all_space(ctlParVal[parN]) == false) {
            data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "nlopt_alg: should not be set when useNrSimplex: is 1.");
        }
        fprintf(outF, "%s\n", ctlPar[parN]);
    } else {
        nlopt_alg = data_io_control_get_nlopt_alg(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    }
    parN++;
    
    bool withInitPoint;
    char *initPointStr;
    if (data_io_all_space(ctlParVal[parN]) == true) {
        withInitPoint = false;
        fprintf(outF, "%s\n", ctlPar[parN]);
    } else {
        withInitPoint = true;
        initPointStr = data_io_trim(ctlParVal[parN]);
        fprintf(outF, "%s %s\n", ctlPar[parN], initPointStr);
    }
    parN++;
    
    const bool setBound = true;

    double initThetaRange[2];
    data_io_control_get_range(ctlParVal[parN], 2, initThetaRange, DBL_MIN, DBL_MAX, setBound, ctlFile, parN, outF, ctlPar[parN]);
    parN++;

    double initGammaRange[2];
    data_io_control_get_range(ctlParVal[parN], 2, initGammaRange, -DBL_MAX, DBL_MAX, setBound, ctlFile, parN, outF, ctlPar[parN]);
    parN++;
    
    double initLambdaRange[2] = { DBL_MIN, DBL_MAX };
    if (! (nstep == 0 || test == data_2a_step_xa_m1_test_GAMMA_X_EQ_3OVER4_GAMMA_A || test == data_2a_step_xa_m1_test_LAMBDA_EQ_C)) {
        data_io_control_get_range(ctlParVal[parN], 2, initLambdaRange, DBL_MIN, DBL_MAX, setBound, ctlFile, parN, outF, ctlPar[parN]);
    } else {
        if (data_io_all_space(ctlParVal[parN]) == false) {
            fprintf(stderr, "initLambdaRange: should not be set when the test LAMBDA_EQ_C or GAMMA_X_EQ_3OVER4_GAMMA_A is set, or when nstep = 0.\n");
            abort();
        }
        fprintf(outF, "%s\n", ctlPar[parN]);
    }
    parN++;
    
    double *initRhoRange = NULL;
    if (nstep == 0) {
        if (data_io_all_space(ctlParVal[parN]) == false)
            data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "initRhoRange: should not be set when nstep: is 0.");      
        fprintf(outF, "%s\n", ctlPar[parN]);  
    } else {
        int nstep2 = nstep * 2;
        initRhoRange = matrixalloc_1d(nstep2, sizeof (double));
        data_io_control_get_range(ctlParVal[parN], nstep2, initRhoRange, DBL_MIN, DBL_MAX, setBound, ctlFile, parN, outF, ctlPar[parN]);
    }
    parN++;
    
    double *maxTX = NULL;
    double *maxTA = NULL;
    double *initTARange = NULL;
    if (nstep == 0) {
        if (data_io_all_space(ctlParVal[parN]) == false)
            data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "initTARange: should not be set when nstep: is 0.");      
        fprintf(outF, "%s\n", ctlPar[parN]);  
    } else {
        maxTX = matrixalloc_1d(nstep, sizeof (double));
        maxTA = matrixalloc_1d(nstep, sizeof (double));
        int nstep2 = nstep * 2;
        initTARange = matrixalloc_1d(nstep2, sizeof (double));
        data_io_control_get_range(ctlParVal[parN], nstep2, initTARange, DBL_MIN, DBL_MAX, setBound, ctlFile, parN, outF, ctlPar[parN]);
        for (int i = 0, j = 0; i < nstep2; i += 2, j++) {
            maxTX[j] = (INT_MAX - 1) * tau;
            maxTA[j] = initTARange[i + 1];
            if (maxTA[j] >= (INT_MAX - 1) * tau) {
                fprintf(stderr, "Error: initTARange should be strictly smaller than %.8e!\n", (INT_MAX - 1) * tau);
                abort();
            }
        }
    }
    parN++;
    
    bool thetaOnLn = data_io_control_get_bool(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    parN++;
    
    bool lambdaOnLn = false;
    if (! (nstep == 0 || test == data_2a_step_xa_m1_test_GAMMA_X_EQ_3OVER4_GAMMA_A || test == data_2a_step_xa_m1_test_LAMBDA_EQ_C)) {
        lambdaOnLn = data_io_control_get_bool(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    } else {
        if (data_io_all_space(ctlParVal[parN]) == false) {
            fprintf(stderr, "lambdaOnLn: should not be set when the test LAMBDA_EQ_C or GAMMA_X_EQ_3OVER4_GAMMA_A is set, or when nstep = 0.\n");
            abort();
        }
        fprintf(outF, "%s\n", ctlPar[parN]);
    }
    parN++;
    
    bool rhoOnLn;
    if (nstep == 0) {
        rhoOnLn = false;
        if (data_io_all_space(ctlParVal[parN]) == false)
            data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "rhoOnLn: should not be set when nstep: is 0.\n");      
        fprintf(outF, "%s\n", ctlPar[parN]);  
    } else {
        rhoOnLn = data_io_control_get_bool(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    }
    parN++;
           
    double rftol = data_io_control_get_double(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    if (rftol <= 0 || rftol >= 0.1)
        data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "Error: rftol <= 0 or rftol >= 0.1\n");
    parN++;
    
    int maxeval = data_io_control_get_int(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    if (maxeval < 1)
        data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "Error: maxeval < 1\n");
    parN++;
    
    double maxtime = data_io_control_get_double(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    if (maxtime <= 0)
        data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "Error: maxtime <= 0\n");
    parN++;
    
    double imprftol = data_io_control_get_double(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    if (imprftol < 0 || imprftol >= 0.1)
        data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "Error: imprftol < 0 || imprftol >= 0.1\n");
    parN++;
        
    int nnoimp = data_io_control_get_int(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    if (nnoimp < 1)
        data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "Error: nnoimp < 1\n");
    parN++;
    
    int maximp = data_io_control_get_int(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    if (maximp < 1)
        data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "Error: maximp < 1\n");
    parN++;
    
    fprintf(outF, "\n");
    
    /* data */    
    data_2a_step_xa_m1_param_T *params = matrixalloc_1d(1, sizeof (data_2a_step_xa_m1_param_T));
    params->K = K;
    params->nstep = nstep;
    params->test = test;
    params->testC = testC;
    get_test(params, initThetaRange, initGammaRange, initLambdaRange, initRhoRange, initTARange, thetaOnLn, false, lambdaOnLn, rhoOnLn, false);
    
    params->x_model = model_2a_step_new(K, nstep, maxTX, tau);
    model_2a_step_set_iteration_method(params->x_model, 1);
    params->x_param = matrixalloc_1d(4 + 2 * nstep, sizeof (double));
    params->a_model = model_2a_step_new(K, nstep, maxTA, tau);
    model_2a_step_set_iteration_method(params->a_model, 1);
    params->a_param = matrixalloc_1d(4 + 2 * nstep, sizeof (double));
    
    params->x_nl = 0; params->x_ns = NULL; params->x_data = NULL;
    params->a_nl = 0; params->a_ns = NULL; params->a_data = NULL;
    data_2a_step_xa_io_m1_get_data(dataFile, buffer_size,
        &(params->x_nl), &(params->x_ns), &(params->x_data),
        &(params->a_nl), &(params->a_ns), &(params->a_data));
    
    fprintf(outF, "\nData file contents:\n");
    data_2a_step_xa_io_m1_write_data(outF,
        params->x_nl, params->x_ns, params->x_data,
        params->a_nl, params->a_ns, params->a_data);
    fprintf(outF, "\n");
    
    params->x_bino = data_util_bino_new(params->x_nl, params->x_ns, K);
    params->a_bino = data_util_bino_new(params->a_nl, params->a_ns, K);    
        
    params->useNrSimplex = useNrSimplex;
    params->nlopt_alg = nlopt_alg;
    if (withInitPoint == true) {
        params->initPoint = matrixalloc_1d(params->npar, sizeof (double));
        data_io_control_get_double_array(params->npar, initPointStr, params->initPoint, ctlFile, parN, NULL, "Error in initPoint:!\n");
        for (int i = 0; i < params->npar; i++)
            params->initPoint[i] = par_to_ln(params->onLn[i], params->initPoint[i]);
    } else
        params->initPoint = NULL;
    
    gsl_rng *rng = gsl_rng_alloc(gsl_rng_mt19937);
    if (rng == NULL) {
        fprintf(stderr, "Error: failed to construct gsl_rng.\n");
        abort();
    }
    unsigned long seed = (unsigned long) time(NULL);
    gsl_rng_set(rng, seed);
    fprintf(outF, "\nRandom seed: %lu\n\n", seed);
    
    params->rng = rng;
    params->rftol = rftol;
    params->maxeval = maxeval;
    params->maxtime = maxtime;
    params->imprftol = imprftol;
    params->nnoimp = nnoimp;
    params->maximp = maximp;
    
    params->outF = outF;    
        
    matrixalloc_1d_free(initRhoRange);
    matrixalloc_1d_free(maxTX);    
    matrixalloc_1d_free(maxTA);
    matrixalloc_1d_free(initTARange);
    fflush(outF);        
    return params;
}

/**
 * @since 2013.09.26, 2013.09.28
 */
void data_2a_step_xa_m1_free(void *ptr) {
    data_2a_step_xa_m1_param_T *par = (data_2a_step_xa_m1_param_T *) ptr;
    fclose(par->outF);
    gsl_rng_free(par->rng);
    matrixalloc_1d_free(par->initPoint);
    data_util_bino_free(par->a_nl, par->a_ns, par->a_bino);
    data_util_bino_free(par->x_nl, par->x_ns, par->x_bino);
    data_2a_step_xa_io_m1_free_data(par->x_nl, par->x_ns, par->x_data, par->a_nl, par->a_ns, par->a_data);
    matrixalloc_1d_free(par->a_param);
    model_2a_step_free(par->a_model);
    matrixalloc_1d_free(par->x_param);
    model_2a_step_free(par->x_model);
    free_test(par);
    free(par);
}


/**
 * @since 2014.04.08, 2014.04.09
 */
static void compareSpectra(data_2a_step_xa_m1_param_T *par, const double *p, bool isX) {
    FILE *outF = par->outF;
    const int Kp1 = par->K + 1;
    int nl;
    int *ns;
    double **data;
    double ***bino;
    if (isX) {
        nl = par->x_nl;
        ns = par->x_ns;
        data = par->x_data;
        bino = par->x_bino;        
    } else {
        nl = par->a_nl;
        ns = par->a_ns;
        data = par->a_data;
        bino = par->a_bino;
    }
    
    if (isX == true) {
        fprintf(outF, "\nX:\n");
    } else
        fprintf(outF, "\nA:\n");
    
    for (int i = 0; i < nl; i++) {
        double sum = cblas_dasum(ns[i] + 1, data[i], 1);
        double predict[ns[i] + 1];
        fprintf(outF, "Observed:");
        for (int j = 0; j <= ns[i]; j++) {
            fprintf(outF, "\t%.8e", data[i][j]);
            double tmp = cblas_ddot(Kp1, p, 1, bino[i][j], 1);
            predict[j] = tmp * sum;
        }
        fprintf(outF, "\nPredicted:");
        for (int j = 0; j <= ns[i]; j++)
            fprintf(outF, "\t%.8e", predict[j]);
        fprintf(outF, "\n");
    }
    
}


/**
 * @since 2014.04.08, 2014.04.09 (fixed bug for maxTA and maxTX when nstep=0)
 */
void data_2a_step_xa_m1_sfs(const char *ctlFile, const int f_ind) {
#ifdef USE_MKL
    if (sizeof (MKL_INT) != sizeof (int)) {//Make sure MKL_INT = int
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        exit(EXIT_FAILURE);
    }
    while (true) {
        MKL_INT a = 0;
        int b = 0;
        if ((long double) (~a) != (long double) (~b)) {
            fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
            exit(EXIT_FAILURE);
        }
        break;
    }
#endif
    
    const int buffer_size = 50000;
    /* control parameters */
    int nCtlPar = 7;
    int parN = 0;
    const char *ctlPar[nCtlPar];
    ctlPar[parN++] = "outputFile:";
    ctlPar[parN++] = "dataFile:";
    ctlPar[parN++] = "K:";
    ctlPar[parN++] = "nstep:";  
    ctlPar[parN++] = "tau:";
    ctlPar[parN++] = "test:";
    ctlPar[parN++] = "MLEs:";
    
    if (f_ind == -1) {
        for (int i = 0; i < nCtlPar; i++)
            fprintf(stdout, "%s\n", ctlPar[i]);
        exit(1);
    } else if (f_ind <= 0) {
        fprintf(stderr, "Error: f_ind <= 0!\n");
        abort();
    }
            
    char ctlParVal[nCtlPar][buffer_size];
    data_io_control_param_get(ctlFile, buffer_size, nCtlPar, ctlPar, ctlParVal);
        
    parN = 0;
    
    FILE *outF = data_io_control_get_outF(ctlParVal[parN], f_ind);
    fprintf(outF, "Control file contents:\n");
    fprintf(outF, "%s %s\n", ctlPar[parN], data_io_trim(ctlParVal[parN]));
    parN++; 
    
    char *dataFile = data_io_trim(ctlParVal[parN]);
    if (dataFile == NULL) {
        fprintf(stderr, "Error: no data file was provided.\n");
        abort();
    }
    fprintf(outF, "%s %s\n", ctlPar[parN], dataFile);
    parN++;
    
    int K = data_io_control_get_int(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    if (K < 10)
        data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "Error: K < 10\n");
    parN++;    
    
    int nstep = data_io_control_get_int(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    if (nstep < 0)
        data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "Error: nstep < 0\n");
    parN++;
    
    double tau;
    if (nstep == 0) {
        tau = 0;
        if (data_io_all_space(ctlParVal[parN]) == false)
            data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "Error: tau should be 0 when nstep = 0\n.");      
    } else {
        tau = data_io_control_get_double(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
        if (tau <= 0 || tau >= 0.1)
            data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "Error: tau <= 0 or tau >= 0.1");      
    }
    parN++;
           
    data_2a_step_xa_m1_test_T test;
    double testC;
    data_2a_step_xa_io_m1_get_test(&test, &testC, ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    if (test == data_2a_step_xa_m1_test_GAMMA_X_EQ_LAMBDA_GAMMA_A || 
            test == data_2a_step_xa_m1_test_THETA_01_X_EQ_LAMBDA_THETA_01_A || 
            test == data_2a_step_xa_m1_test_THETA_10_X_EQ_LAMBDA_THETA_10_A || 
            test == data_2a_step_xa_m1_test_LAMBDA_EQ_C) {
        if (nstep < 1) {
            fprintf(stderr, "Error: to carry out tests involving lambda, nstep must be greater than zero.");
            abort();
        }
    }
    if (test == data_2a_step_xa_m1_test_LAMBDA_EQ_C) {
        if (testC <= 0)
            data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "Lambda must be strictly positive.");
    }
    parN++;    
               
    /* other model parameters */   
    double *maxTA = NULL;
    double *maxTX = NULL;
    if (nstep > 0) {
        maxTA = matrixalloc_1d(nstep, sizeof (double));
        maxTX = matrixalloc_1d(nstep, sizeof (double));
        for (int i = 0; i < nstep; i++) {
            maxTA[i] = (INT_MAX - 1) * tau;
            maxTX[i] = (INT_MAX - 1) * tau;
        }
    }
    double initThetaRange[2];
    initThetaRange[0] = DBL_MIN;
    initThetaRange[1] = DBL_MAX;
    double initGammaRange[2];
    initGammaRange[0] = -DBL_MAX;
    initGammaRange[1] = DBL_MAX;
    double initLambdaRange[2];
    initLambdaRange[0] = DBL_MIN;
    initLambdaRange[1] = DBL_MAX;
    double initRhoRange[2];
    initRhoRange[0] = DBL_MIN;
    initRhoRange[1] = DBL_MAX;
    double initTARange[2];
    initTARange[0] = DBL_MIN;
    initTARange[1] = DBL_MAX;
    bool thetaOnLn = false;
    bool lambdaOnLn = false;
    bool rhoOnLn = false;
        
    /* model */
    data_2a_step_xa_m1_param_T *params = matrixalloc_1d(1, sizeof (data_2a_step_xa_m1_param_T));
    params->K = K;
    params->nstep = nstep;
    params->test = test;
    params->testC = testC;
    
    get_test(params, initThetaRange, initGammaRange, initLambdaRange, initRhoRange, initTARange, thetaOnLn, false, lambdaOnLn, rhoOnLn, false);
    
    params->x_model = model_2a_step_new(K, nstep, maxTX, tau);
    model_2a_step_set_iteration_method(params->x_model, 1);
    params->x_param = matrixalloc_1d(4 + 2 * nstep, sizeof (double));
    params->a_model = model_2a_step_new(K, nstep, maxTA, tau);
    model_2a_step_set_iteration_method(params->a_model, 1);
    params->a_param = matrixalloc_1d(4 + 2 * nstep, sizeof (double));
    
    params->x_nl = 0; params->x_ns = NULL; params->x_data = NULL;
    params->a_nl = 0; params->a_ns = NULL; params->a_data = NULL;
    data_2a_step_xa_io_m1_get_data(dataFile, buffer_size,
        &(params->x_nl), &(params->x_ns), &(params->x_data),
        &(params->a_nl), &(params->a_ns), &(params->a_data));
    
    params->x_bino = data_util_bino_new(params->x_nl, params->x_ns, K);
    params->a_bino = data_util_bino_new(params->a_nl, params->a_ns, K);  
    
    params->initPoint = NULL;
    
    params->rng = NULL;
    
    params->outF = outF;
    
    /* get MLEs */
    double mle[params->npar + 1];
    data_io_control_get_double_array(params->npar + 1, ctlParVal[parN], mle, ctlFile, parN, outF, ctlPar[parN]);
    parN++;
    
    /* check ln-likelihood */
    double inputLnLike = mle[params->npar];
    double calculatedLnLike = params->lnlike(mle, params);
    fprintf(outF, "\nInput ln-likelihood:\n%.15e\n", inputLnLike);
    fprintf(outF, "Calculated ln-likelihood:\n%.15e\n\n", calculatedLnLike);
    
    /* get spectra */    
    const double *p_x = model_2a_step_spectrum(params->x_model);
    const double *p_a = model_2a_step_spectrum(params->a_model);
    
    /* print observed and predicted SFSs */
    compareSpectra(params, p_x, true);
    compareSpectra(params, p_a, false);    
            
    /* cleaning up */
    matrixalloc_1d_free(maxTX); 
    matrixalloc_1d_free(maxTA);   
    fflush(outF);        
    data_2a_step_xa_m1_free(params);
    return;
}