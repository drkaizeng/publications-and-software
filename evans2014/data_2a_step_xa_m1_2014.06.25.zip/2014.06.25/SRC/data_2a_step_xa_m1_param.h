/* 
 * File:   data_2a_xa_param.h
 * Author: Kai
 *
 * Created on 06 September 2013, 15:50
 */

#ifndef DATA_2A_STEP_XA_M1_PARAM_H
#    define	DATA_2A_STEP_XA_M1_PARAM_H

#include <stdbool.h>
#include <stdio.h>

#include "gsl/gsl_rng.h"
#include "nlopt.h"

#include "model_2a_step.h"

typedef enum {
    /* Tests that do not require additional input parameters */
    data_2a_step_xa_m1_test_NO_TEST,
    data_2a_step_xa_m1_test_GAMMA_X_EQ_LAMBDA_GAMMA_A, //gamma_x = lambda gamma_a (i.e., equal selection); nstep > 0
    data_2a_step_xa_m1_test_GAMMA_X_EQ_3OVER4_GAMMA_A, //gamma_x = 0.75 gamma_a       
    data_2a_step_xa_m1_test_THETA_01_X_EQ_LAMBDA_THETA_01_A, // theta_ij_x = lambda theta_ij_a (i.e., equal raw mutation rate); nstep > 0
    data_2a_step_xa_m1_test_THETA_10_X_EQ_LAMBDA_THETA_10_A, // theta_ij_x = lambda theta_ij_a (i.e., equal raw mutation rate); nstep > 0
    data_2a_step_xa_m1_test_THETA_01_X_EQ_THETA_10_X,
    data_2a_step_xa_m1_test_THETA_01_A_EQ_THETA_10_A,    
            
    /* Tests that require an additional double constant */        
    data_2a_step_xa_m1_test_GAMMA_X_EQ_C, //gamma_x = c
    data_2a_step_xa_m1_test_GAMMA_A_EQ_C, //gamma_a = c   
    data_2a_step_xa_m1_test_LAMBDA_EQ_C //lambda = c; nstep > 0
} data_2a_step_xa_m1_test_T;

typedef enum {
    data_2a_step_xa_m1_param_name_THETA,
    data_2a_step_xa_m1_param_name_GAMMA,
    data_2a_step_xa_m1_param_name_LAMBDA,
    data_2a_step_xa_m1_param_name_RHO,
    data_2a_step_xa_m1_param_name_TAU               
} data_2a_step_xa_m1_param_name_T;

typedef struct {
    int K;
    int nstep;
    
    data_2a_step_xa_m1_test_T test;
    double testC;//a const associated with the test; it is always on the natural scale
    int npar; //the number of free parameters in the final model after test is considered   
    data_2a_step_xa_m1_param_name_T *parn;
    char **parnstr;
    bool *onLn;
    double *lb;//The scale is determined by onLn
    double *ub;//The scale is determined by onLn
    double (*lnlike)(const double *x, void *params);
    double *xNoTest;//x when there is NO_TEST
    bool *onLnNoTest;
    
    model_2a_step_T *x_model;
    double *x_param;
    int x_nl;
    int *x_ns;
    double **x_data;//each row is created by a malloc call
    /*
     * x_bino[i][j][k]
     * 1. Population allele frequency is k/hapsize
     * 2. Sample size is x_ns[i]
     * 3. x_bino[i][j][k]: the probability that, in the sample, the allele concerned is observed j times, given 1 & 2.
     */
    double ***x_bino;
    
    model_2a_step_T *a_model;
    double *a_param;
    int a_nl;
    int *a_ns;
    double **a_data;
    double ***a_bino;
    
    bool useNrSimplex;
    nlopt_algorithm nlopt_alg;
    double *initPoint;//scale is determined by onLn
    
    gsl_rng *rng;    
    double rftol; 
    int maxeval;
    double maxtime;
    double imprftol; 
    int nnoimp;
    int maximp;
    
    FILE *outF;        
} data_2a_step_xa_m1_param_T;

#endif	/* DATA_2A_XA_PARAM_H */

