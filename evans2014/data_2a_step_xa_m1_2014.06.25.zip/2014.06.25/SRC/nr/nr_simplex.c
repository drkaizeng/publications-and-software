#include <stdio.h>
#include <math.h>
#include <float.h>
#include <stdlib.h>
#include <time.h>

#include "../util/matrixalloc.h"
#include "nr_simplex.h"


struct nr_simplex_TAG {
    int npar;//number of parameters
    double (*f)(double *x, void *f_data);
    void *param;
    double rftol;
    double aftol;
    int maxeval;
    double maxtime;
    
    double *psum;
    double *ptry;
    int numeval;
};

/**
 * @since 2013.08.11, 2013.09.11 (added maxtime)
 */
nr_simplex_T *nr_simplex_new(int npar, double (*f)(double *, void *), void *param, double rftol, double aftol, 
        int maxeval, double maxtime) {
    if (f == NULL || npar < 1) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort();  
    }
    if (rftol < 0 && aftol < 0 && maxeval < 0 && maxtime < 0) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        abort(); 
    }
    double tmp = HUGE_VAL;
    if (HUGE_VAL != tmp) {
        fprintf(stderr, "Error: HUGE_VAL != HUGE_VAL\n");
        abort();
    }
    tmp = -HUGE_VAL;
    if (-HUGE_VAL != tmp) {
        fprintf(stderr, "Error: -HUGE_VAL != -HUGE_VAL\n");
        abort();
    }
    tmp = DBL_MAX;
    if (tmp > HUGE_VAL) {
        fprintf(stderr, "Error: DBL_MAX > HUGE_VAL\n");
        abort();
    }
    if (tmp == HUGE_VAL) {
        fprintf(stderr, "Warning: DBL_MAX = HUGE_VAL\n");
    }
    tmp = -DBL_MAX;
    if (tmp < -HUGE_VAL) {
        fprintf(stderr, "Error: -DBL_MAX < -HUGE_VAL\n");
        abort();
    }
    if (maxtime >= 0 && (time(NULL) == (time_t) (-1))) {
        fprintf(stderr, "Error: calendar time is not available\n");
        abort();
    }
        
    nr_simplex_T *re = matrixalloc_1d(1, sizeof(nr_simplex_T));
    re->npar = npar;
    re->f = f;
    re->param = param;
    re->rftol = rftol;
    re->aftol = aftol;
    re->maxeval = maxeval;
    re->maxtime = maxtime;
    re->psum = matrixalloc_1d(npar, sizeof(double));
    re->ptry = matrixalloc_1d(npar, sizeof(double));
    return re;
}

/**
 * @since 2013.08.11, 2013.09.11
 */
void nr_simplex_free(nr_simplex_T *ptr) {
    matrixalloc_1d_free(ptr->psum);
    matrixalloc_1d_free(ptr->ptry);
    matrixalloc_1d_free(ptr);
}

/**
 * @since 2013.08.10, 2013.09.11
 */
static double amotry(double **p, double *y, int ndim,
        double (*funk)(double *, void *), void *param, double *psum, double *ptry, int ihi, double fac) {
    int j;
    double fac1, fac2, ytry;
    
    fac1 = (1.0 - fac) / ndim;
    fac2 = fac1 - fac;
    for (j = 0; j < ndim; j++) ptry[j] = psum[j] * fac1 - p[ihi][j] * fac2;
    ytry = funk(ptry, param);
    if (ytry < y[ihi]) {
        y[ihi] = ytry;
        for (j = 0; j < ndim; j++) {
            psum[j] += ptry[j] - p[ihi][j];
            p[ihi][j] = ptry[j];
        }
    }
    return ytry;
}

/**
 * @since 2013.08.10, 2013.09.11
 */
static inline void get_psum(const int ndim, double **p, double *psum) {
    double sum;
    for (int j = 0; j < ndim; j++) {
        sum = 0;
        for (int i = 0; i <= ndim; i++)
            sum += p[i][j];
        psum[j] = sum;
    }
}

/**
 * @since 2013.08.10, 2013.09.11 (added maxtime)
 */
nr_simplex_result nr_simplex_search(double **p, double *y, nr_simplex_T *ptr) {
    int i, ihi, ilo, inhi, j;
    double swap, ysave, ytry;

    const int ndim = ptr->npar;
    double (*funk)(double *, void *) = ptr->f;
    void *param = ptr->param;
    double *psum = ptr->psum;
    double *ptry = ptr->ptry;
    double rftol = ptr->rftol;
    double aftol = ptr->aftol;
    int maxeval = ptr->maxeval;
    ptr->numeval = 0;
    
    const time_t starttime = time(NULL);

    get_psum(ndim, p, psum);
    for (;;) {
        ilo = 0;
        ihi = y[0] > y[1] ? (inhi = 1, 0) : (inhi = 0, 1); //c99 6.5.17
        for (i = 0; i <= ndim; i++) {
            if (isnan(y[i]))
                return NR_SIMPLEX_ERR_FVAL_IS_NAN;
            if (y[i] <= y[ilo]) ilo = i;
            if (y[i] > y[ihi]) {
                inhi = ihi;
                ihi = i;
            } else if (y[i] > y[inhi] && i != ihi) inhi = i;
        }

        /* NLopt/util/stop.c relstop() */
        bool stop = false;
        nr_simplex_result re = -1;
        if (y[ilo] == HUGE_VAL || (isinf(y[ilo]) && signbit(y[ilo]) == 0)) {//c99, 7.12.1
            stop = true;
            re = NR_SIMPLEX_ERR_MIN_IS_POSINF;
        } else if (ptr->maxtime >= 0 && difftime(time(NULL), starttime) > ptr->maxtime) {
            stop = true;
            re = NR_SIMPLEX_MAXTIME_REACHED;
        } else {
            
            /*
             * 1. If y[ihi] is HUGE_VAL or positive infinity, carry on searching
             * 2. It is impossible for y[ihi] to be -HUGE_VAL here
             */
            double tmp = fabs(y[ihi] - y[ilo]);
            if (rftol >= 0 && tmp <= rftol * 0.5 * (fabs(y[ihi]) + fabs(y[ilo]))) {
                stop = true;
                re = NR_SIMPLEX_RFTOL_REACHED;
            } else if (aftol >= 0 && tmp <= aftol) {
                stop = true;
                re = NR_SIMPLEX_AFTOL_REACHED;
            } else if (maxeval >= 0 && ptr->numeval >= maxeval) {
                stop = true;
                re = NR_SIMPLEX_MAXEVAL_REACHED;
            }
        }
        if (stop == true) {
            //SWAP(y[1],y[ilo])
            swap = y[0];
            y[0] = y[ilo];
            y[ilo] = swap;
            for (i = 0; i < ndim; i++) {
                //SWAP(p[0][i],p[ilo][i])
                swap = p[0][i];
                p[0][i] = p[ilo][i];
                p[ilo][i] = swap;
            }
            return re;
        } else {
            ptr->numeval += 2;
            ytry = amotry(p, y, ndim, funk, param, psum, ptry, ihi, -1.0);
            if (ytry <= y[ilo])
                ytry = amotry(p, y, ndim, funk, param, psum, ptry, ihi, 2.0);
            else if (ytry >= y[inhi]) {
                ysave = y[ihi];
                ytry = amotry(p, y, ndim, funk, param, psum, ptry, ihi, 0.5);
                if (ytry >= ysave) {
                    for (i = 0; i <= ndim; i++) {
                        if (i != ilo) {
                            for (j = 0; j < ndim; j++)
                                p[i][j] = psum[j] = 0.5 * (p[i][j] + p[ilo][j]);
                            y[i] = (*funk)(psum, param);
                        }
                    }
                    ptr->numeval += ndim;
                    get_psum(ndim, p, psum);
                }
            } else --(ptr->numeval);
        }
    }
    fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
    abort();
}
