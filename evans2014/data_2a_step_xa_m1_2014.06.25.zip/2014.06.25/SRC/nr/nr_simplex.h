/* 
 * File:   nr_simplex.h
 * Author: Kai
 *
 * Created on 06 August 2013, 15:34
 */

#ifndef NR_SIMPLEX_H
#define	NR_SIMPLEX_H

struct nr_simplex_TAG;
typedef struct nr_simplex_TAG nr_simplex_T;

typedef enum {
    NR_SIMPLEX_RFTOL_REACHED = 1,
    NR_SIMPLEX_AFTOL_REACHED = 2,
    NR_SIMPLEX_MAXEVAL_REACHED = 3,
    NR_SIMPLEX_MAXTIME_REACHED = 4,
    NR_SIMPLEX_ERR_MIN_IS_POSINF = -1,
    NR_SIMPLEX_ERR_FVAL_IS_NAN = -2
} nr_simplex_result;

/**
 * @param npar The number of parameters
 * @param f The function to be minimised; infinity is assumed to be represented by HUGE_VAL.
 * @param param The parameters required to obtain the function value
 * @param rftol The relative tolerance on function value; set negative values to disable it.
 * @param aftol The absolute tolerance on function value; set negative values to disable it.
 * @param maxeval The maximum number of function evaluation before stopping the search; set negative values to disable it.
 * @param maxtime The maximum length of time (in seconds) that the search algorithm is allowed to run; set negative values to disable it.
 * @return 
 */
nr_simplex_T *nr_simplex_new(int npar, double (*f)(double *, void *), void *param, double rftol, double aftol, int maxeval, double maxtime);
void nr_simplex_free(nr_simplex_T *ptr);

/**
 * 1. p[i][j]
 *    1.1 i = 0..(npar)
 *    1.2 j = 0..(npar-1)
 *    1.3 y[i] = f(p[i], param)
 * 2. On return, y[0] = f(p[0]) is the best result obtained.
 */
nr_simplex_result nr_simplex_search(double **p, double *y, nr_simplex_T *ptr);

#endif	/* NR_SIMPLEX_H */

