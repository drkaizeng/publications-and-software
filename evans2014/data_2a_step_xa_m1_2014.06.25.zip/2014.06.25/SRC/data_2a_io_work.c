#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "util/matrixalloc.h"
#include "data_io.h"
#include "data_2a_io_work.h"


/**
 * @since 2013.08.01, 2013.08.11, 2013.09.10, 2013.09.26
 */
void data_2a_io_work_get_data(FILE *in, const int buffer_size, char buffer[buffer_size], const char *fileName, int * const lineNoPtr,
        int *nlPtr, int **nsPtr, double ***dataPtr) {    
    if (in == NULL) {
        fprintf (stderr, "No data file!\n");
        exit(EXIT_FAILURE);
    }
    if (buffer_size <= 0) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        exit(EXIT_FAILURE);
    }
    if (nlPtr[0] != 0) {
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        exit(EXIT_FAILURE);
    }
    if (nsPtr[0] != NULL) {
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        exit(EXIT_FAILURE);
    }
    if (dataPtr[0] != NULL) {
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        exit(EXIT_FAILURE);
    }
    /* get number of data lines */
    char *st = fgets(buffer, buffer_size, in);
    (*lineNoPtr)++;
    if (st == NULL)
        data_io_print_file_error(fileName, *lineNoPtr, buffer, NULL);
    char *endPtr;
    int info = data_io_next_int(st, &endPtr, nlPtr);
    if ((*nlPtr) <= 0 || info != 0)
        data_io_print_file_error(fileName, *lineNoPtr, buffer, NULL);
    if (data_io_all_space(endPtr) != true)
        data_io_print_file_error(fileName, *lineNoPtr, buffer, NULL);
    
    int *ns = matrixalloc_1d((*nlPtr), sizeof (int));
    double **data = matrixalloc_1d((*nlPtr), sizeof (double *));
    for (int i = 0; i < (*nlPtr); i++) {
        st = fgets(buffer, buffer_size, in);
        (*lineNoPtr)++;
        if (st == NULL)
            data_io_print_file_error(fileName, *lineNoPtr, buffer, NULL);
        if (data_io_check_line_width(in, st) == false)
            data_io_print_file_error(fileName, *lineNoPtr, buffer, NULL);
        info = data_io_next_int(st, &endPtr, ns + i);
        if (ns[i] <= 0 || info != 0)
            data_io_print_file_error(fileName, *lineNoPtr, buffer, NULL);
        if (i > 0 && ns[i] <= ns[i - 1])
            data_io_print_file_error(fileName, *lineNoPtr, buffer, NULL);
        data[i] = matrixalloc_1d(ns[i] + 1, sizeof(double));        
        for (int j = 0; j <= ns[i]; j++) {
            st = endPtr;
            double d;
            info = data_io_next_double(st, &endPtr, &d);
            if (d < 0 || info != 0)
                data_io_print_file_error(fileName, *lineNoPtr, buffer, NULL);
            data[i][j] = d;
        }
        if (data_io_all_space(endPtr) != true)
            data_io_print_file_error(fileName, *lineNoPtr, buffer, NULL);
    }
    nsPtr[0] = ns;
    dataPtr[0] = data;
}

/**
 * @since 2013.08.11, 2013.09.10, 2013.12.29
 */
void data_2a_io_work_free_data(int nl, int *ns, double **data) {
    matrixalloc_1d_free(ns);
    for (int i = 0; i < nl; i++)
        matrixalloc_1d_free(data[i]);
    matrixalloc_1d_free(data);
}

/**
 * @since 2013.09.10, 2013.09.13, 2013.09.26
 */
void data_2a_io_work_write_data(FILE *outF, const char *chr, int nl, int *ns, double **data) {
    fprintf(outF, "%s\n", chr);
    fprintf(outF, "%d\n", nl);
    for (int i = 0; i < nl; i++) {
        fprintf(outF, "%d", ns[i]);
        for (int j = 0; j <= ns[i]; j++)
            fprintf(outF, "\t%g", data[i][j]);
        fprintf(outF, "\n");
    }
}


