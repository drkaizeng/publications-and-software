/*
 * File:   data_2a_step_xa_m1_sfs.c
 * Author: kzeng
 *
 * Created on 07-Apr-2014, 17:32:52
 */

#include <stdio.h>
#include <stdlib.h>

#include "../data_2a_step_xa.h"


int main(int argc, char** argv) {
    if (argc != 3) {
        fprintf(stderr, "Usage: data_2a_step_xa_m1_sfs control_file f_index\n");
        abort();
    }
    data_2a_step_xa_m1_sfs(argv[1], atoi(argv[2]));

    return (EXIT_SUCCESS);
}
