#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>
#include <float.h>
#include <math.h>
#include <stdbool.h>

#if defined (USE_MKL)
    #include "mkl.h"
#elif defined (USE_ATLAS)
    #include "lapacke.h"
    #include "cblas.h"    
#else
    #error Either USE_ATLAS OR USE_MKL must be set
#endif

#include "model_2a_step.h"
#include "util/matrixalloc.h"

struct model_2a_step_TAG {
    int K;
    int nstep;
    double *maxT;
    double tau;
    int method;
    
    int Kp1;// size of matrix    
    int Km1;
    int Km2;
    double ep;//1/K
    double alpha;
    double *dl;
    double *d;
    double *du; 
    double *dlf;
    double *df;
    double *duf;
    double *du2;
    lapack_int *ipiv;
    double *b;
    double *p0;
    double *pcurrent;
    double *pnext;
    double *work;
    lapack_int *iwork;
    size_t Km1size;
    size_t Ksize;
    size_t Kp1size;
    
    double *freq;// i/K
    double *freq_c;// (1 - i/K)
    double *bx;//b(xi) = xi (1 - xi)
    double *nbx2;//-2 * b(xi)
    double *bxfreq;// b(xi) * xi, where xi = i/hapsize
    double *bxfreq_2c; // b(xi) * (1 - 2i/hapsize)
    double *epax;//epsilon * a(xi)
    double *U;
    double *V;
    double *Up1;
    double *Vp1;
    double *UmV;
    double *UmVp1;
    double *aR; //(alpha*Rn)
    double *aRp1;    
    double *iv;//identity vector of length K+1
    double *zv;//zero vector with rank (K+1) elements
};

/**
 * @since 2013.09.09, 2013.09.17, 2014.01.23
 */
static void getUVstat(const int bxleng, const size_t bxsize, const double *bx, const double *epax, 
        const double rho, double *U, double *V) {
    /* U */
    memcpy(U, bx, bxsize);
    cblas_dscal(bxleng, -1.0, U, 1);
    cblas_daxpy(bxleng, rho, epax, 1, U, 1);
    /* V */
    memcpy(V, bx, bxsize);
    cblas_daxpy(bxleng, rho, epax, 1, V, 1);    
}

/**
 * @since 2013.09.09, 2013.09.17, 2014.01.23
 */
static void getUVtrans(const int bxleng, const size_t bxsize, const double *bx, const double *epax, 
        const double rho1, const double rho2, double *U, double *V) {
    /* U */
    memcpy(U, bx, bxsize);
    cblas_dscal(bxleng, -rho2 / rho1, U, 1);
    cblas_daxpy(bxleng, rho2, epax, 1, U, 1);
    /* V */
    memcpy(V, bx, bxsize);
    cblas_dscal(bxleng, rho2 / rho1, V, 1);
    cblas_daxpy(bxleng, rho2, epax, 1, V, 1);    
}

/**
 * @since 2013.09.09, 2013.09.17, 2014.01.23
 */
static void getUmVtrans(const int rank, const size_t dsize, const double *nbx2, 
        const double rho1, const double rho2, double *UmV) {
    memcpy(UmV, nbx2, dsize);
    cblas_dscal(rank, rho2 / rho1, UmV, 1);
}

/**
 * @since 2013.09.07, 2013.09.09, 2013.09.17, 2014.01.23
 */
static void getAR(const int K, const double alpha, const double *U, const double *V, const double *UmV, double *aR) {
    const int K3 = K * 3;
    const int Km1 = K - 1;
    const double alphad2 = alpha / 2;
    /* the upper diagonal*/
    double *ptr = aR;
    ptr += 3;
    cblas_dcopy(K, U + 1, 1, ptr, 3);
    cblas_dscal(K, alphad2, ptr, 3);
    *(aR + K3) *= 2;
//    for (int i = 1; i <= K; i++) {
//        ptr += 3;
//        *(ptr) = alphad2 * U[i];
//    }
//    *(ptr) *= 2;
    
    /* the diagonal*/
    ptr = aR + 1;
    *(ptr) = alpha * V[0];
    ptr += 3;
    cblas_dcopy(Km1, UmV + 1, 1, ptr, 3);
    cblas_dscal(Km1, -alphad2, ptr, 3);
    *(aR + 1 + K3) = -alpha * U[K];
//    for (int i = 1; i < K; i++) {
//        ptr += 3;
//        *(ptr) = -alphad2 * (UmV[i]);
//    }
//    *(ptr + 3) = -alpha * U[K];
    
    /* the lower diagonal*/
    ptr = aR + 2;
    *(ptr) = -alpha * V[0];
    ptr += 3;
    cblas_dcopy(Km1, V + 1, 1, ptr, 3);
    cblas_dscal(Km1, -alphad2, ptr, 3);
//    for (int i = 1; i < K; i++) {
//        ptr += 3;
//        *(ptr) = -alphad2 * V[i];
//    }
}

/**
 * 1 + aRn1
 * @since 2013.09.04, 2013.09.05, 2013.09.07, 2013.09.17, 2014.01.23
 */
static void getCM(const int K, const int Kp1, const size_t Kp1size, const double *aR, const double *iv, double *dl, double *d, double *du) {
    /* coefficient matrix */
    const double *ptr = aR + 2;
    cblas_dcopy(K, ptr, 3, dl, 1);

    ptr = aR + 1;
    memcpy(d, iv, Kp1size);
    cblas_daxpy(Kp1, 1.0, ptr, 3, d, 1);

    ptr = aR + 3;
    cblas_dcopy(K, ptr, 3, du, 1);
}

/**
 * @since 2013.09.17, 2014.01.23
 */
static void getCMstat(const int K, const int Kp1, const double *aR, double *dl, double *d, double *du) {
    /* coefficient matrix */
    const double *ptr = aR + 2;
    cblas_dcopy(K, ptr, 3, dl, 1);

    ptr = aR + 1;
    cblas_dcopy(Kp1, ptr, 3, d, 1);

    ptr = aR + 3;
    cblas_dcopy(K, ptr, 3, du, 1);
}

/**
 * @since 2013.09.17, 2014.01.23
 */
static int solve(const lapack_int rank, const double *dl, const double *d, const double *du, const double *b,
        const size_t dlsize, const size_t dsize, model_2a_step_T *stp, double *x) {
    double *dlf = stp->dlf;
    double *df = stp->df;
    double *duf = stp->duf;
    double *du2 = stp->du2;
    lapack_int *ipiv = stp->ipiv;
    double *work = stp->work;
    lapack_int *iwork = stp->iwork;
    double ferr, berr;
    
    /* backup */
    memcpy(dlf, dl, dlsize);
    memcpy(df, d, dsize);
    memcpy(duf, du, dlsize);
    memcpy(x, b, dsize);    
    
    /* solve */
#ifdef USE_ATLAS
    lapack_int info = LAPACKE_dgttrf_work(rank, dlf, df, duf, du2, ipiv);
    if (info != 0)
        return 1;
    info = LAPACKE_dgttrs_work(LAPACK_COL_MAJOR, 'N', rank, 1, dlf, df, duf, du2, ipiv, x, rank);
    if (info != 0)
        return 1;
    info = LAPACKE_dgtrfs_work(LAPACK_COL_MAJOR, 'N', rank, 1, dl, d, du, dlf, df, duf, du2, ipiv, b, rank, x, rank, &ferr, &berr, work, iwork);
    if (info != 0)
        return 1;
#elif defined (USE_MKL)
    lapack_int info;
    dgttrf(&rank, dlf, df, duf, du2, ipiv, &info);
    if (info != 0)
        return 1;
    const char trans = 'N';
    lapack_int nrhs = 1;
    dgttrs(&trans, &rank, &nrhs, dlf, df, duf, du2, ipiv, x, &rank, &info);
    if (info != 0)
        return 1;
    dgtrfs(&trans, &rank, &nrhs, dl, d, du, dlf, df, duf, du2, ipiv, b, &rank, x, &rank, &ferr, &berr, work, iwork, &info);
    if (info != 0)
        return 1;
#else
    #error Either USE_ATLAS OR USE_MKL must be set 
#endif
    
    return 0;
}

/**
 * Iterate one step using pn as initial condition. The results are stored in pnext.
 * p and aR are the right-hand side components; dl, d, du and pnext are left-hand site components.
 * @since 2013.09.09, 2013.09.17 (added solve), 2014.01.23
 */
static int iterate(const double *p, const double *aR, const double *dl, const double *d, const double *du, 
        model_2a_step_T *stp, double *pnext) {
    const lapack_int Kp1 = stp->Kp1;
    double *b = stp->b;
    const size_t Ksize = stp->Ksize;
    const size_t Kp1size = stp->Kp1size;
    
    /* store right-hand side in b */
    memcpy(b, p, Kp1size);
    cblas_dgbmv(CblasColMajor, CblasNoTrans, Kp1, Kp1, 1, 1, -1.0, aR, 3, p, 1, 1.0, b, 1); 
    
    int info = solve(Kp1, dl, d, du, b, Ksize, Kp1size, stp, pnext);
    if (info != 0)
        return 1;
    
    double ss = cblas_dasum(Kp1, pnext, 1);
    for (int i = 0; i < Kp1; i++) {
        if (pnext[i] < 0)
            return 1;
        pnext[i] /= ss;
    }
    return 0;
}

/**
 * @since 2013.09.17, 2014.01.23
 */
static int solve_equi(bool isForward, const double *dl, const double *d, const double *du, const double C,
        model_2a_step_T *stp) {
    const int K = stp->K;
    double *b = stp->b;
    double *p0 = stp->p0;
    const size_t Ksize = stp->Ksize;
    const size_t Km1size = stp->Km1size;
    
    const double *ndl;
    const double *nd;
    const double *ndu;
    
    /* right-hand side; K elements */
    double *rhs;
    memcpy(b, stp->zv, Ksize);
    if (isForward == true) {
        p0[0] = C;
        rhs = p0 + 1;
        b[0] = d[0] * C;//alpha * V[0] * C or aR[0, 0] * C
        ndl = dl + 1;
        nd = d + 1;
        ndu = du + 1;
    } else {
        p0[K] = C;
        rhs = p0;
        b[K - 1] = d[K] * C;//alpha U[K] C or aR[K, K] * C
        ndl = dl;
        nd = d;
        ndu = du;
    }
    
    int info = solve(K, ndl, nd, ndu, b, Km1size, Ksize, stp, rhs);
    if (info != 0)
        return 1;
    
    double ss = cblas_dasum(stp->Kp1, p0, 1);
    if (isfinite(ss) == 0 || ss >= HUGE_VAL)
        return 1;
    for (int i = 0; i <= K; i++) {
        if (p0[i] < 0)
            return 1;
        p0[i] /= ss;
    }
    return 0;
}

#define PCON 100
#define SWAP_DBL_PTR(X, Y, TMP) { (TMP) = (X); (X) = (Y); (Y) = (TMP); }
#define PRINT_P(K, P) { for (int i = K; i <= K; i++) { printf("p[%i] = %.8e\n", i, P[i]); } printf("\n"); }

/**
 * @since 2014.05.31 (most subroutines were visually inspected)
 */
int model_2a_step_iterate(const double *par, model_2a_step_T *stp) {
    const int K = stp->K;
    
    const double theta01 = par[0];
    const double theta10 = par[1];
    const double gamma = par[2];
    const double h = par[3];    
    
    if (theta01 <= 0)
        return 1;
    if (theta10 <= 0)
        return 1;
    
    const int nstep = stp->nstep;
    if (nstep > 0) {
        const double *maxT = stp->maxT;
        for (int i = 0, ptr = 4; i < nstep; i++) {
            double rho = par[ptr];
            ptr++;
            if (rho <= 0)
                return 1;
            double t = par[ptr];
            ptr++;
            if (t <= 0 || t > maxT[i])
                return 1;
        }
    }
    
    const double ep = stp->ep;
    double *epax = stp->epax;
    const double *bx = stp->bx;
    const lapack_int Kp1 = stp->Kp1;
    const size_t Kp1size = stp->Kp1size;
    {
        const double *bxfreq = stp->bxfreq;
        const double *bxfreq_2c = stp->bxfreq_2c;
        const double *freq = stp->freq;
        const double *freq_c = stp->freq_c;
        const double epga = ep * gamma;
        const double epgah = epga * h;
        const double epth01d2 = ep * theta01 / 2;
        const double epth10d2 = ep * theta10 / 2;
        memcpy(epax, stp->zv, Kp1size);
        cblas_daxpy(Kp1, epth10d2, freq_c, 1, epax, 1);
        cblas_daxpy(Kp1, -epth01d2, freq, 1, epax, 1);
        cblas_daxpy(Kp1, epgah, bxfreq_2c, 1, epax, 1);
        cblas_daxpy(Kp1, epga, bxfreq, 1, epax, 1);
    }

    double *dl = stp->dl;
    double *d = stp->d;
    double *du = stp->du;
    double *U = stp->U;
    double *V = stp->V;
    double *aR = stp->aR;
    const double *UmV = stp->UmV;
    const double *iv = stp->iv;
    
    /* equilibrium */
    getUVstat(Kp1, Kp1size, bx, epax, 1.0, U, V);
    getAR(K, -2.0, U, V, UmV, aR);
    getCMstat(K, Kp1, aR, dl, d, du);
    if (gamma >= 0) {
        int info = solve_equi(true, dl, d, du, PCON, stp);
        if (info != 0) {
            info = solve_equi(false, dl, d, du, PCON, stp);
            if (info != 0)
                return 2;
        }
    } else {
        int info = solve_equi(false, dl, d, du, PCON, stp);
        if (info != 0) {
            info = solve_equi(true, dl, d, du, PCON, stp);
            if (info != 0)
                return 2;
        }
    }

    if (nstep > 0) {
        const double tau = stp->tau;
        double *Up1 = stp->Up1;
        double *Vp1 = stp->Vp1;
        double *UmVp1 = stp->UmVp1;
        double *aRp1 = stp->aRp1;
        double *tmpptr;
        int info;
        double rho1, rho2;
        rho1 = 1;
        memcpy(stp->pcurrent, stp->p0, Kp1size);
        for (int ii = 0, ptr = 4; ii < nstep; ii++) {
            rho2 = par[ptr];
            ptr++;
            getUVstat(Kp1, Kp1size, bx, epax, rho2, U, V);
            double t = par[ptr];
            ptr++;
            int niter = (int) (t / tau);//c99, 6.3.1.4
            double tau2 = t - niter * tau;
            if (niter == 0) {
                if (tau2 <= 0 || tau2 >= tau) {
                    fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
                    exit(EXIT_FAILURE);
                }
                double alpha2 = exp(log(tau2) - log(2) - 2 * log(ep));
                getAR(K, alpha2, U, V, UmV, aR);//left-hand side
                getCM(K, Kp1, Kp1size, aR, iv, dl, d, du);//left-hand side
                if (stp->method == 1) {
                    getUVtrans(Kp1, Kp1size, bx, epax, rho1, rho2, Up1, Vp1); //right-hand side
                    getUmVtrans(Kp1, Kp1size, UmV, rho1, rho2, UmVp1);
                    getAR(K, alpha2, Up1, Vp1, UmVp1, aRp1);
                    info = iterate(stp->pcurrent, aRp1, dl, d, du, stp, stp->pnext);
                } else {
                    info = iterate(stp->pcurrent, aR, dl, d, du, stp, stp->pnext);
                }
                if (info != 0)
                    return 2;
                SWAP_DBL_PTR(stp->pcurrent, stp->pnext, tmpptr);
            } else {
                double alpha = stp->alpha;
                /* first step */
                getAR(K, alpha, U, V, UmV, aR);//left-hand side
                getCM(K, Kp1, Kp1size, aR, iv, dl, d, du);//left-hand side
                if (stp->method == 1) {
                    getUVtrans(Kp1, Kp1size, bx, epax, rho1, rho2, Up1, Vp1); //right-hand side
                    getUmVtrans(Kp1, Kp1size, UmV, rho1, rho2, UmVp1);
                    getAR(K, alpha, Up1, Vp1, UmVp1, aRp1);
                    info = iterate(stp->pcurrent, aRp1, dl, d, du, stp, stp->pnext);
                } else {
                    info = iterate(stp->pcurrent, aR, dl, d, du, stp, stp->pnext);
                }
                if (info != 0)
                    return 2;
                SWAP_DBL_PTR(stp->pcurrent, stp->pnext, tmpptr);
//                PRINT_P(K, stp->pcurrent);
                for (int jj = 1; jj < niter; jj++) {
                    info = iterate(stp->pcurrent, aR, dl, d, du, stp, stp->pnext);
                    if (info != 0)
                        return 2;
                    SWAP_DBL_PTR(stp->pcurrent, stp->pnext, tmpptr);
//                    PRINT_P(K, stp->pcurrent);
                }
                /* last step */
                if (tau2 > 0) {
                    double alpha2 = exp(log(tau2) - log(2) - 2 * log(ep));
                    getAR(K, alpha2, U, V, UmV, aR);
                    getCM(K, Kp1, Kp1size, aR, iv, dl, d, du);
                    info = iterate(stp->pcurrent, aR, dl, d, du, stp, stp->pnext);
                    if (info != 0)
                        return 2;
                    SWAP_DBL_PTR(stp->pcurrent, stp->pnext, tmpptr);
//                    PRINT_P(K, stp->pcurrent);
                }
            }
            rho1 = rho2;
        }
    }

    return 0;
}

/**
 * @since 2013.09.10
 */
const double *model_2a_step_spectrum(model_2a_step_T *stp) {
    if (stp->nstep == 0)
        return stp->p0;
    else
        return stp->pcurrent;
}

/**
 * @since 2013.09.10, 2013.09.28, 2014.04.08
 */
int model_2a_step_lnlike(const double *par, model_2a_step_T *stp, const int nl, const int *ns, double **data, double ***bino, double *lnlikePtr) {
    int info = model_2a_step_iterate(par, stp);
    if (info != 0) {
        *lnlikePtr = -HUGE_VAL;
        return info;
    }
    const double *p = model_2a_step_spectrum(stp);
    double re = 0;
    for (int i = 0; i < nl; i++) {
        for (int j = 0; j <= ns[i]; j++) {
            if (data[i][j] == 0)
                continue;
            double tmp = cblas_ddot(stp->Kp1, p, 1, bino[i][j], 1);
            re += data[i][j] * log(tmp);
        }
    }
    if (isnan(re)) {
        *lnlikePtr = -HUGE_VAL;
        return 2;
    }
    *lnlikePtr = re;
    return 0;
}

/**
 * @since 2013.09.07, 2013.09.17 (rank -> Kp1), 2014.01.22
 */
model_2a_step_T *model_2a_step_new(const int K, const int nstep, const double *maxT, const double tau) {
    if (K < 2 || K >= INT_MAX) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        exit(EXIT_FAILURE);
    }
    if (nstep < 0) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        exit(EXIT_FAILURE);
    }
    if (nstep == 0 && (maxT != NULL || tau != 0)) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        exit(EXIT_FAILURE);
    }
    if (nstep > 0 && tau <= 0) {
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        exit(EXIT_FAILURE);
    }
    if (sizeof (lapack_int) < sizeof (int)) {//Make sure K+1 can be represented by lapack_int
        fprintf (stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        exit(EXIT_FAILURE);
    }
#ifdef USE_MKL
    if (sizeof (MKL_INT) != sizeof (lapack_int)) {//Make sure MKL_INT = lapack_int
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        exit(EXIT_FAILURE);
    }
    while (true) {
        MKL_INT a = 0;
        lapack_int b = 0;
        if ((long double) (~a) != (long double) (~b)) {
            fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
            exit(EXIT_FAILURE);
        }
        break;
    }
#endif
    
    model_2a_step_T *re = matrixalloc_1d(1, sizeof (model_2a_step_T));
    re->K = K;
    re->nstep = nstep;
    if (nstep == 0) {
        re->maxT = NULL;
        re->tau = 0;
    } else {
        re->maxT = matrixalloc_1d(nstep, sizeof (double));
        double min = maxT[0];
        double max = maxT[0];
        for (int i = 0; i < nstep; i++) {
            re->maxT[i] = maxT[i];
            if (maxT[i] < min) 
                min = maxT[i];
            if (maxT[i] > max)
                max = maxT[i];
            if (maxT[i] <= 0) {
                fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
                exit(EXIT_FAILURE);
            }
        }
        if (tau >= min) {
            fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
            exit(EXIT_FAILURE);
        }
        if ((max / tau) >= INT_MAX) {//c99 6.5.8.3 and 6.3.1.8
            fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
            exit(EXIT_FAILURE);
        }
        re->tau = tau;
    }
    
    re->method = 1;
    
    re->Kp1 = K + 1;
    re->Km1 = K - 1;
    re->Km2 = K - 2;
    re->ep = 1.0 / K;
    re->alpha = exp(log(tau) - log(2) - 2 * log(re->ep));
    if (re->Kp1 >= INT_MAX / 3) {
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        exit(EXIT_FAILURE);
    }
    re->dl = matrixalloc_1d(re->K, sizeof(double));
    re->d = matrixalloc_1d(re->Kp1, sizeof(double));
    re->du = matrixalloc_1d(re->K, sizeof(double));
    re->dlf = matrixalloc_1d(re->K, sizeof(double));
    re->df = matrixalloc_1d(re->Kp1, sizeof(double));
    re->duf = matrixalloc_1d(re->K, sizeof(double));
    re->du2 = matrixalloc_1d(re->Km1, sizeof(double));
    re->ipiv = matrixalloc_1d(re->Kp1, sizeof(lapack_int));
    re->b = matrixalloc_1d(re->Kp1, sizeof(double));
    re->p0 = matrixalloc_1d(re->Kp1, sizeof(double));
    re->pcurrent = matrixalloc_1d(re->Kp1, sizeof(double));
    re->pnext = matrixalloc_1d(re->Kp1, sizeof(double));
    re->work = matrixalloc_1d(re->Kp1 * 3, sizeof(double));
    re->iwork = matrixalloc_1d(re->Kp1, sizeof(lapack_int));
    
    re->Km1size = (size_t) (re->Km1) * sizeof(double);
    re->Ksize = (size_t) (re->K) * sizeof(double);
    re->Kp1size = (size_t) re->Kp1 * sizeof(double);
        
    re->freq = matrixalloc_1d(re->Kp1, sizeof(double));
    re->freq_c = matrixalloc_1d(re->Kp1, sizeof(double));
    re->bx = matrixalloc_1d(re->Kp1, sizeof(double));
    re->nbx2 = matrixalloc_1d(re->Kp1, sizeof(double));
    re->bxfreq = matrixalloc_1d(re->Kp1, sizeof(double));
    re->bxfreq_2c = matrixalloc_1d(re->Kp1, sizeof(double));
    {
        for (int i = 0; i <= K; i++) {
            re->freq[i] = (double) i / K;
        }
        for (int i = 0; i <= K; i++) {
            re->freq_c[i] = re->freq[K - i];
            re->bx[i] = re->freq[i] * re->freq_c[i];
            re->nbx2[i] = -2 * re->bx[i];
            re->bxfreq[i] = re->bx[i] * re->freq[i];
            re->bxfreq_2c[i] = re->bx[i] * (1.0 - 2.0 * re->freq[i]);
        }
    }
    re->epax = matrixalloc_1d(re->Kp1, sizeof(double));
    re->U = matrixalloc_1d(re->Kp1, sizeof(double));
    re->V = matrixalloc_1d(re->Kp1, sizeof(double));
    re->Up1 = matrixalloc_1d(re->Kp1, sizeof(double));
    re->Vp1 = matrixalloc_1d(re->Kp1, sizeof(double));
    re->UmV = matrixalloc_1d(re->Kp1, sizeof(double));
    memcpy(re->UmV, re->nbx2, re->Kp1size);
    re->UmVp1 = matrixalloc_1d(re->Kp1, sizeof(double));
    
    int leng = 3 * re->Kp1;
    re->aR = matrixalloc_1d(leng, sizeof(double));
    re->aRp1 = matrixalloc_1d(leng, sizeof(double));
    re->iv = matrixalloc_1d(re->Kp1, sizeof(double));
    re->zv = matrixalloc_1d(re->Kp1, sizeof(double));
    for (int i = 0; i < re->Kp1; i++) {
        re->iv[i] = 1;
        re->zv[i] = 0;
    }
    
    return re;
}

/**
 * @since 2014.05.31
 */
void model_2a_step_set_iteration_method(model_2a_step_T *stp, int method) {
    if (method != 1 && method != 2) {
        fprintf(stderr, "Error: %s:%d\n", __FILE__, __LINE__);
        exit(EXIT_FAILURE);
    }
    stp->method = method;
}

/**
 * @since 2013.09.07
 */
void model_2a_step_free(model_2a_step_T *stp) {
    matrixalloc_1d_free(stp->zv);
    matrixalloc_1d_free(stp->iv);
    matrixalloc_1d_free(stp->aRp1);
    matrixalloc_1d_free(stp->aR);
    matrixalloc_1d_free(stp->UmVp1);
    matrixalloc_1d_free(stp->UmV);
    matrixalloc_1d_free(stp->Vp1);
    matrixalloc_1d_free(stp->Up1);
    matrixalloc_1d_free(stp->V);
    matrixalloc_1d_free(stp->U);
    matrixalloc_1d_free(stp->epax);
    matrixalloc_1d_free(stp->bxfreq_2c);
    matrixalloc_1d_free(stp->bxfreq);
    matrixalloc_1d_free(stp->nbx2);
    matrixalloc_1d_free(stp->bx);
    matrixalloc_1d_free(stp->freq_c);
    matrixalloc_1d_free(stp->freq);
    matrixalloc_1d_free(stp->iwork);
    matrixalloc_1d_free(stp->work);
    matrixalloc_1d_free(stp->pnext);
    matrixalloc_1d_free(stp->pcurrent);
    matrixalloc_1d_free(stp->p0);
    matrixalloc_1d_free(stp->b);
    matrixalloc_1d_free(stp->ipiv);
    matrixalloc_1d_free(stp->du2);
    matrixalloc_1d_free(stp->duf);
    matrixalloc_1d_free(stp->df);
    matrixalloc_1d_free(stp->dlf);
    matrixalloc_1d_free(stp->du);
    matrixalloc_1d_free(stp->d);
    matrixalloc_1d_free(stp->dl);
    matrixalloc_1d_free(stp->maxT);
    matrixalloc_1d_free(stp);
}




///**
// * @since 2013.09.07, 2013.09.09
// */
//static void get_err(const int K, const double *U, const double *V, const double *UmV, 
//        const double *p, double *err, double *aR) {
//    getAR(K, -2, U, V, UmV, aR);
//    int rank = K + 1;
//    cblas_dgbmv(CblasColMajor, CblasNoTrans, rank, rank, 1, 1, 1.0, aR, 3, p, 1, 0.0, err, 1);
//    err[0] = -err[0];
////    err[0] = 2 * V[0] * p[0] + U[1] * p[1];
////    err[1] = 2 * V[0] * p[0] + UmV[1] * p[1] - U[2] * p[2];
////    for (int i = 2, im1 = 1, ip1 = 3; i <= Km2; i++, im1++, ip1++) {
////        err[i] = V[im1] * p[im1] + UmV[i] * p[i] - U[ip1] * p[ip1];
////    }
////    err[Km1] = V[Km2] * p[Km2] + UmV[Km1] * p[Km1] - 2 * U[K] * p[K];
//}
//
//#define IS_FAILED(X, END_STATEMENT)  { if ((X) < 0 || isnan(X) || isinf(X)) goto END_STATEMENT; }    
//
///**
// * @since 2013.09.05, 2013.09.07
// */
//static int solve_equi_forward(const int K, const int Km1, const int Km2, 
//        const double *U, const double *V, const double *UmV, const double C,
//        double *p, double *pdel, double *err, double *aR) {            
//    bool success = false;
//    while (true) {
//        p[0] = C;
//        p[1] = -2 * V[0] * C / U[1];
//        IS_FAILED(p[1], FORWARD_FAILED);
//        p[2] = (2 * V[0] * p[0] + UmV[1] * p[1]) / U[2];
//        IS_FAILED(p[2], FORWARD_FAILED);
//        for (int i = 2, im1 = 1, ip1 = 3; i <= Km2; i++, im1++, ip1++) {
//            p[ip1] = (V[im1] * p[im1] + UmV[i] * p[i]) / U[ip1];
//            IS_FAILED(p[ip1], FORWARD_FAILED);
//        }
//        p[K] = (V[Km2] * p[Km2] + UmV[Km1] * p[Km1]) / (2 * U[K]);
//        IS_FAILED(p[K], FORWARD_FAILED);
//        
//        /* improve */
//        get_err(K, U, V, UmV, p, err, aR);
//        pdel[1] = err[0] / U[1];
//        pdel[2] = - (err[1] - UmV[1] * pdel[1]) / U[2];
//        for (int i = 2, im1 = 1, ip1 = 3; i <= Km2; i++, im1++, ip1++) {
//            pdel[ip1] = -(err[i] - V[im1] * pdel[im1] - UmV[i] * pdel[i]) / U[ip1];
//        }
//        pdel[K] = -(err[Km1] - V[Km2] * pdel[Km2] - UmV[Km1] * pdel[Km1]) / (2 * U[K]);
//        
//        double sum = C;
//        for (int i = 1; i <= K; i++) {
//            p[i] -= pdel[i];
//            sum += p[i];
//            IS_FAILED(p[i], FORWARD_FAILED);
//        }        
//        IS_FAILED(sum, FORWARD_FAILED);
//        cblas_dscal(K + 1, 1.0 / sum, p, 1);
//                            
//        success = true;
//        break;
//    }
//    if (success == true) {
//        return 0;        
//    } else {
//        FORWARD_FAILED:
//        return 1;
//    }
//}
//
///**
// * @since 2013.09.03, 2013.09.09
// */
//static int solve_equi_backward(const int K, const int Km1, const int Km2, 
//        const double *U, const double *V, const double *UmV, const double C, 
//        double *p, double *pdel, double *err, double *aR) {
//    bool success = false;
//    while (true) {
//        p[K] = C;
//        p[Km1] = -2 * U[K] * C / V[Km1];
//        IS_FAILED(p[Km1], BACKWARD_FAILED);
//        p[Km2] = (-UmV[Km1] * p[Km1] + 2 * U[K] * p[K]) / V[Km2];
//        IS_FAILED(p[Km2], BACKWARD_FAILED);
//        for (int i = Km2, im1 = Km2 - 1, ip1 = Km1; i >= 2; i--, im1--, ip1--) {
//            p[im1] = (-UmV[i] * p[i] + U[ip1] * p[ip1]) / V[im1];
//            IS_FAILED(p[im1], BACKWARD_FAILED);
//        }
//        p[0] = (-UmV[1] * p[1] + U[2] * p[2]) / (2 * V[0]);
//        IS_FAILED(p[0], BACKWARD_FAILED);
//        
//        /* improve */
//        get_err(K, U, V, UmV, p, err, aR);
//        pdel[Km1] = err[K] / V[Km1];
//        pdel[Km2] = (err[Km1] - UmV[Km1] * pdel[Km1]) / V[Km2];
//        for (int i = Km2, im1 = Km2 - 1, ip1 = Km1; i >= 2; i--, im1--, ip1--) {
//            pdel[im1] = (err[i] - UmV[i] * pdel[i] + U[ip1] * pdel[ip1]) / V[im1];
//        }
//        pdel[0] = (err[1] - UmV[1] * pdel[1] + U[2] * pdel[2]) / (2 * V[0]);
//                  
//        double sum = C;
//        for (int i = Km1; i >= 0; i--) {
//            p[i] -= pdel[i];
//            sum += p[i];
//            IS_FAILED(p[i], BACKWARD_FAILED);
//        }        
//        IS_FAILED(sum, BACKWARD_FAILED);
//        cblas_dscal(K + 1, 1.0 / sum, p, 1);
//        
//        success = true;
//        break;
//    }
//    if (success == true) {
//        return 0;        
//    } else {
//        BACKWARD_FAILED:
//        return 1;
//    }
//}