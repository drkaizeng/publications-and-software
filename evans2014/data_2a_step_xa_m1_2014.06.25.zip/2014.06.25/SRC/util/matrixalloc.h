/* 
 * File:   matrixalloc.h
 * Author: Kai
 *
 * Created on 28 February 2013, 17:11
 */

#ifndef MATRIXALLOC_H
#define	MATRIXALLOC_H

#include <stdbool.h>
#include <stddef.h>

/**
 * Use to construct arrays of given length.
 * @param n The number of elements
 * @param s The size of each element
 */
void *matrixalloc_1d(const int n, const size_t styp);
void *matrixalloc_1d_init(const int n, const size_t styp);
void  matrixalloc_1d_free(void *);


/**
 * Use malloc to construct a 2D matrix for double-precision numbers.
 * @param nrow number of rows
 * @param ncol number of columns
 */
double **matrixalloc_2d_d(const int nrow, const int ncol);
double **matrixalloc_2d_d_init(const int nrow, const int ncol);
double **matrixalloc_2d_d_clone(double **src, const int nrow, const int ncol);
void     matrixalloc_2d_d_free(double **);

long double **matrixalloc_2d_ld(const int nrow, const int ncol);
long double **matrixalloc_2d_ld_init(const int nrow, const int ncol);
long double **matrixalloc_2d_ld_clone(long double **src, const int nrow, const int ncol);
void     matrixalloc_2d_ld_free(long double **);

int **matrixalloc_2d_i(const int nrow, const int ncol);
int **matrixalloc_2d_i_init(const int nrow, const int ncol);
int **matrixalloc_2d_i_clone(int **src, const int nrow, const int ncol);
void     matrixalloc_2d_i_free(int **);

bool **matrixalloc_2d_b(const int nrow, const int ncol);
bool **matrixalloc_2d_b_init(const int nrow, const int ncol);
bool **matrixalloc_2d_b_clone(bool **src, const int nrow, const int ncol);
void     matrixalloc_2d_b_free(bool **);

#endif	/* MATRIXALLOC_H */

