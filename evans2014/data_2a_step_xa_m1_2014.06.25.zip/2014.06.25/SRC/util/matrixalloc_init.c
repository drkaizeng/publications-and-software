#include "matrixalloc.h"

#define MATRIXALLOC_2D_DOUBLE
#include "matrixalloc_template_on.h"
#include "matrixalloc_2d.c"
#include "matrixalloc_template_off.h"
#undef  MATRIXALLOC_2D_DOUBLE

#define MATRIXALLOC_2D_LONG_DOUBLE
#include "matrixalloc_template_on.h"
#include "matrixalloc_2d.c"
#include "matrixalloc_template_off.h"
#undef  MATRIXALLOC_2D_LONG_DOUBLE

#define MATRIXALLOC_2D_INT
#include "matrixalloc_template_on.h"
#include "matrixalloc_2d.c"
#include "matrixalloc_template_off.h"
#undef  MATRIXALLOC_2D_INT

#define MATRIXALLOC_2D_BOOL
#include "matrixalloc_template_on.h"
#include "matrixalloc_2d.c"
#include "matrixalloc_template_off.h"
#undef  MATRIXALLOC_2D_BOOL