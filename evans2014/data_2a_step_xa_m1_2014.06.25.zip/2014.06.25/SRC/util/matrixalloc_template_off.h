/* 
 * File:   matrixalloc_template_off.h
 * Author: Kai
 *
 * Created on 29 July 2013, 19:51
 */

#undef MATRIXALLOC_TYPE
#undef MATRIXALLOC_TYPE_ABBR

#undef MATRIXALLOC_CONCAT2x
#undef MATRIXALLOC_CONCAT2
#undef MATRIXALLOC_CONCAT3x
#undef MATRIXALLOC_CONCAT3

#undef MATRIXALLOC_2D
#undef MATRIXALLOC_2D_INIT
#undef MATRIXALLOC_2D_CLONE
#undef MATRIXALLOC_2D_FREE

