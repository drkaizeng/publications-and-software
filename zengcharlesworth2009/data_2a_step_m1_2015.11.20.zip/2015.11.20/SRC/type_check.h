/* 
 * File:   mkl_check.h
 * Author: kai
 *
 * Created on 12 September 2014, 14:29
 */

#ifndef MKL_CHECK_H
#define	MKL_CHECK_H

#if defined (USE_MKL)
/**
 * MKL_INT and lapack_int are defined in mkl.h
 * @return the maximum value smaller than which non-negative values of int and MKL_INT and lapack_int can be used interchangeably.
 */
int type_check_mkl_int_max(void);
#endif

/**
 * lapack_int is defined in lapacke.h
 * @return the maximum value smaller than which non-negative values of int and lapack_int can be used interchangeably.
 */
int type_check_lapacke_int_max(void);

#endif	/* MKL_CHECK_H */

