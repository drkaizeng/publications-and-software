/* 
 * File:   matrix_util.h
 * Author: kai
 *
 * Created on 14 September 2014, 21:46
 */

#ifndef MATRIX_UTIL_H
#define	MATRIX_UTIL_H

#if defined (USE_MKL)
    #include "mkl.h"
#elif defined (USE_ATLAS)
    #include "lapacke.h" 
#else
    #error Either USE_ATLAS or USE_MKL must be set
#endif



#if defined (USE_MKL)
    #define MATRIX_UTIL_INT MKL_INT
#elif defined (USE_ATLAS)
    #define MATRIX_UTIL_INT lapack_int
#endif

/**
 * Ax=b
 * 
 * Note:
 * Only one right-hand side is allowed.
 * 
 * @param K the dimention of the coefficient matrix A (i.e., A is a K*K matrix)
 * @param A column_major storage; this is unchanged by the algorithm
 * @param AF column_major storage; on entry, this has the same values as A; on exit, this stores the result from dgetrf
 * @param b a K-element vector in continuous memory; the right-hand side
 * @param x a K-element vector in continuous memory; on entry, this has the same values as b; on exit, this stores
 *          the solution, as produced by dgetrs and refined by dgerfs
 * @param ipiv a K-element vector in continuous memory
 * @param work a 3K-element vector in continuous memory
 * @param iwork a K-element vector in continuous memory
 * @return 0 if successful, 1 if numerical problem is encountered
 */
int matrix_util_solve_equi(MATRIX_UTIL_INT K, const double *A, double *AF, const double *b, double *x, 
        MATRIX_UTIL_INT *ipiv, double *work, MATRIX_UTIL_INT *iwork);

/**
 * bino[i][j][k] <br>
 * 1. Population allele frequency is k/hapsize <br>
 * 2. Sample size is ns[i] <br>
 * 3. bino[i][j][k] = the probability that, in the sample, the allele concerned is observed j times, given 1 & 2. <br>
 * <br>
 * It is guaranteed that the array of size hapsize pointed by bino[i][j] is allocated as a continuous memory block.
 */
double ***matrix_util_bino_new(const int nl, const int *ns, const int hapsize);
void matrix_util_bino_free(const int nl, const int *ns, double ***bino);


#endif	/* MATRIX_UTIL_H */

