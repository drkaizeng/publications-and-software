/*
 * File:   test_data_2a_step_m1.c
 * Author: kzeng
 *
 * Created on 24-Apr-2014, 17:39:56
 */

#include <stdio.h>
#include <stdlib.h>

#include "data_2a_step.h"

/*
 * Simple C Test Suite
 */

static void test1(const char *controlFile, const int f_ind) {
    void *re = data_2a_step_m1_new(controlFile, f_ind);
    data_2a_step_m1_ml(re);
    data_2a_step_m1_free(re);
}

int main(int argc, char** argv) {
    if (argc != 3) {
        fprintf(stderr, "Usage: data_2a_step_m1 control_file f_index\n");
        abort();
    }
    test1(argv[1], atoi(argv[2]));

    return (EXIT_SUCCESS);
}
