/* 
 * File:   data_io.h
 * Author: Kai
 *
 * Created on 06 September 2013, 16:51
 */

#ifndef DATA_IO_H
#    define	DATA_IO_H

#include <stdio.h>

#include "nlopt.h"


/**
 * @lineNo Starting from 1.
 * @param buffer This should contain the contents of the lineNo-th line in the file.
 * @param msg Additional message to be printed.
 */
void data_io_print_file_error(const char *fileName, const int lineNo, const char *buffer, const char *msg);

/**
 * Return The index of the first non-space character [0, strlen-1].
 *        -1 if all characters are spaces (defined by isspace()).
 */
int data_io_first_nonspace(const char * const ptr);

/**
 * Return The index of the first space character [0, strlen-1].
 *        -1 if all characters are non-space (defined by isspace()).
 */
int data_io_first_space(const char * const ptr);

/**
 * @param file
 * @param ptr This should contain the contents of the line concerned.
 * @Return true if the line terminations with '\n' or EOF. Otherwise, the line is wider than the size of ptr.
 */
bool data_io_check_line_width(FILE *file, const char * const ptr);

/**
 * @param ptr see strtold()
 * @param endPtr see strtold()
 * @param re The value of the double value extracted; zero, if the extraction fails (see strtold()).
 * @return 0, if successful;
 *          1, if ptr = endPtr[0] (no relevant data)
 *          2, if errno is set (see strtold()).
 *          3, if the value is larger than DBL_MAX, or smaller than -DBL_MAX.
 * 
 */
int data_io_next_double(const char *ptr, char **endPtr, double *re);

/**
 * @param ptr see strtoll()
 * @param endPtr see strtoll()
 * @param re The value of the int value extracted; zero, if the extraction fails (see strtoll()).
 * @return 0, if successful;
 *          1, if ptr = endPtr[0] (no relevant data)
 *          2, if errno is set (see strtoll()).
 *          3, if the value is larger than INT_MAX, or smaller than INT_MIN.
 */
int data_io_next_int(const char *ptr, char **endPtr, int *re);

/**
 * @param ptr The string must be null terminated.
 * @return true if all characters the precede the null character test true by isspace().
 */
bool data_io_all_space(const char * ptr);

/**
 * Remove leading and terminating space characters as determined by isspace().
 * 1. The returned pointer points to the first non-space character; NULL is returned if there is no non-space character.
 * 2. All terminating space are removed by setting them to the null character.
 */
char *data_io_trim(char *ptr);


/* The following are for processing control files */
/**
 * @param ctlFile The name of the control file
 * @param buffer_size The maximum length of a line in ctlFile
 * @param n The number of parameters
 * @param ctlPar[n] An array containing the names of the parameters
 * @param ctlParV[n][buffer_size] An array for storing the values of the parameters
 */
void data_io_control_param_get(const char *ctlFile, const int buffer_size, const int n, const char *ctlPar[n], char ctlParV[n][buffer_size]);
/**
 * @param n The number of elements to be read
 * @param stptr The string to be processed
 * @param arr The array where the data will be stored
 * @param ctlFile The name of the control file
 * @param parN The ID of the parameter being dealt with; the line number.
 * @param outF The output file where the data will be written
 * @param parName The name of the parameter
 */
void data_io_control_get_double_array(int n, char *stptr, double arr[n], const char *ctlFile, int parN, FILE *outF, const char *parName);
double data_io_control_get_double(char *stptr, const char *ctlFile, int parN, FILE *outF, const char *parName);
int data_io_control_get_int(char *stptr, const char *ctlFile, int parN, FILE *outF, const char *parName);
bool data_io_control_get_bool(char *stptr, const char *ctlFile, int parN, FILE *outF, const char *parName);

/**
 * Creates an output file. The program stops if the output file exists.
 * @param stptr The path and name of the output file
 * @param f_ind Index to be appended to the output file's name
 */
FILE *data_io_control_get_outF(char *stptr, const int f_ind);

nlopt_algorithm data_io_control_get_nlopt_alg(char *str, const char *ctlFile, int parN, FILE *outF, const char *parName);

typedef enum {
    data_io_df_alg_NONE,
    data_io_df_alg_NR,
    data_io_df_alg_GSL        
} data_io_df_alg_T;

/**
 * Get details of the numerical differentiation algorithm
 * @param nAlgPar The number of parameters needed to run the algorithm is stored in nAlgPar[0].
 * @param algPar The array storing the parameters is algPar[0], which has to be freed using either free() or matrixalloc_1d_free()
 * @param stptr The string to be processed
 */
void data_io_control_get_df_alg(data_io_df_alg_T *algPtr, int *nAlgPar, double **algPar, char *stptr, const char *ctlFile, int parN, FILE *outF, const char *parName);

/**
 * This routine gets the minimum and maximum values from the string pointed to by stptr.
 * @param stptr Input data; two values separated by space
 * @param n size of range; must be a multiple of 2; range[i*2]=min; range[i*2+1]=max
 * @param range 
 * @param min User supplied minimum must be greater than min
 * @param max User supplied maximum must be greater than max
 * @param setBound If true, user supplied values are read; if false stptr should point to space characters only
 */
void data_io_control_get_range(char *stptr, int n, double range[n], double min, double max, bool setBound, 
        const char *ctlFile, int parN, FILE *outF, const char *parName);

#endif	/* DATA_IO_H */

