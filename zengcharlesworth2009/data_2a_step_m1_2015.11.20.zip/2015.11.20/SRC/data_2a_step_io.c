#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#include "data_2a_step_io.h"
#include "data_io_work.h"
#include "data_io.h"

/** 
 * @since 2013.12.29, 2014.04.25, 2015.11.22
 */
void data_2a_step_io_m1_get_data(char *dataFile, int buffer_size, int *nlPtr, int **nsPtr, double ***dataPtr) {
    if (dataFile == NULL) {
        fprintf (stderr, "No data file!\n");
        exit(EXIT_FAILURE);
    }

    FILE *in;
    {
        char *df = data_io_trim(dataFile);
        in = fopen(df, "r");
        if (in == NULL) {
            fprintf(stderr, "Error: failed to open data file, %s\n", dataFile);
            exit(EXIT_FAILURE);
        }
    }
    
    int lineNo = 0;
    char buffer[buffer_size];
    char *st; 
    bool read = false;
    
    while ((st = fgets(buffer, buffer_size, in)) != NULL) {
        lineNo++;
        if (data_io_check_line_width(in, st) == false)
            data_io_print_file_error(dataFile, lineNo, buffer, NULL);
        int ind = data_io_first_nonspace(st);
        if (ind < 0)
            continue;
        else if (st[ind] == '#')
            continue;
        else if (st[ind] == 'D') {
            if (read == true) {
                fprintf(stderr, "Error: Bad data file format!\n");
                exit(EXIT_FAILURE);
            }
            if (data_io_all_space(st + ind + 1) == false)
                data_io_print_file_error(dataFile, lineNo, buffer, NULL);
            data_io_work_2a_get_data(in, buffer_size, buffer, dataFile, &lineNo, nlPtr, nsPtr, dataPtr);
            read = true;
        } else {
            data_io_print_file_error(dataFile, lineNo, buffer, NULL);
        }
    }
    if (nlPtr[0] == 0) {
        fprintf(stderr, "Error: no data was read!\n");
        abort();
    }
    fclose(in);
}

/**
 * @since [2013.09.10], 2013.12.29
 */
void data_2a_step_io_m1_free_data(int nl, int *ns, double **data) {
    data_io_work_2a_free_data(nl, ns, data);
}

/**
 * @since 2013.12.29, 2014.04.25, 2015.11.22
 */
void data_2a_step_io_m1_write_data(FILE *outF, int nl, int *ns, double **data) {
    data_io_work_2a_write_data(outF, "D", nl, ns, data);
    fprintf(outF, "\n");
}


#define GET_TEST(test, status, instr, teststr, testPtr) \
            if (status == NOT_FOUND && strstr(#test, instr) != NULL) { \
                status = FOUND_TEST; \
                teststr = #test; \
                testPtr[0] = test; \
            }

/**
 * @since 2014.05.12, 2014.06.01, 2014.06.15, 2015.11.22
 */
void data_2a_step_io_m1_get_test(data_2a_step_m1_test_t *testPtr, 
        const char *stptr, const char *ctlFile, const int parN, FILE *outF, const char *parName) {
    enum { NOT_FOUND, FOUND_TEST } status;
    status = NOT_FOUND;
    {// Tests that do not require additional input parameters
        char stptr2[strlen(stptr) + 1];
        strcpy(stptr2, stptr);
        char *instr = data_io_trim(stptr2);
        if (instr == NULL || strlen(instr) == 0) {
            data_io_print_file_error(ctlFile, parN, stptr, NULL);
        }
        const char *teststr;
        GET_TEST(data_2a_step_m1_test_NO_TEST, status, instr, teststr, testPtr);
        GET_TEST(data_2a_step_m1_test_THETA_01_EQ_THETA_10, status, instr, teststr, testPtr);
        GET_TEST(data_2a_step_m1_test_GAMMA_EQ_0, status, instr, teststr, testPtr);
        if (status == FOUND_TEST) {
            fprintf(outF, "%s %s\n", parName, teststr);
            return;
        }
    } 
//    if (status == NOT_FOUND)  {// Tests that require an additional double constant
//        char stptr2[strlen(stptr) + 1];
//        strcpy(stptr2, stptr);
//        char *instr = data_io_trim(stptr2);
//        if (instr == NULL || strlen(instr) == 0) {
//            data_io_print_file_error(ctlFile, parN, stptr, NULL);
//        }
//        int ind = data_io_first_space(instr);
//        if (ind > 0) {
//            instr[ind] = '\0'; //split the string
//            if (strlen(instr) == 0) {
//                data_io_print_file_error(ctlFile, parN, stptr, NULL);
//            }
//            const char *teststr;
//            GET_TEST(data_2a_step_m1_test_GAMMA_EQ_0, status, instr, teststr, testPtr);
//            if (status == FOUND_TEST) {
//                testCPtr[0] = data_io_control_get_double(instr + ind + 1, ctlFile, parN, NULL, parName);
//                fprintf(outF, "%s %s %g\n", parName, teststr, testCPtr[0]);
//                return;
//            }
//        } else {
//            data_io_print_file_error(ctlFile, parN, stptr, NULL);    
//        }
//    }
    data_io_print_file_error(ctlFile, parN, stptr, "Unknown test!");    
}
