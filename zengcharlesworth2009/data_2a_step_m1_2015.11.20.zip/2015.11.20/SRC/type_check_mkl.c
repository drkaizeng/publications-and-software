#if defined (USE_MKL)

#include <limits.h>
#include "mkl.h"
#include "type_check.h"

/**
 * @since 2014.09.14
 */
int type_check_mkl_int_max(void) {
    size_t is = sizeof (int);
    size_t ms = sizeof (MKL_INT);
    size_t ls = sizeof (lapack_int);
    
    is = is < ms ? is : ms;
    is = is < ls ? is : ls;
    
    is = is * CHAR_BIT;//6.2.6.1.4, 6.5.3.4
    is--;//remove the sign bit
    
    unsigned int max = 1;    
    for (size_t i = 1; i < is; i++) {
        max = (max << 1) + 1;
    }
    return (int) max;
}

#endif