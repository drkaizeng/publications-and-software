/* 
 * File:   data_2a_step.h
 * Author: Kai
 *
 * Created on 12 September 2013, 14:13
 */

#ifndef DATA_2A_STEP_H
#    define	DATA_2A_STEP_H

/**
 * Model m1: 
 * 1. Parameters (all scaled by Ne, the effective population size before any change):
 *    1.1 theta_01, theta_10, gamma
 *    1.2 rho_i, t_i, where i = [1..steps], rho_i = Ne_i/Ne and t_i = T / (2 Ne_i), 
 *                        where T is the number of generation after the change, 
 *                        and Ne_i is the population size of the current step.
 * 2. Equilibrium:
 *    2.1 Let Ne be the effective population sizes at equilibrium
 *                theta_ij = 4 Ne u_ij
 *                gamma = 4 Ne s
 *            where genic selection is assumed (A0A0: 1+2s, A0A1: 1+s, A1A1: 1)
 * 3. Non-equilibrium
 *    3.1 In the diffusion algorithm, tau (the time step) is defined wrt the Ne_i of the i-th time step 
 *            for the type of chromosome concerned.
 * 
 * 
 * Data file format:
 * D
 * nl (this is the number of data lines below; nl must be an integer)
 * ns a[0] a[1] ... a[ns] (ns is the sample size; 
 *                         ns in different rows must be in strictly ascending order;
 *                         a[i] is the number of sites where the A0 allele is represented i times; 
 *                         a[i] is a nonnegative double value)
 * 
 */
void *data_2a_step_m1_new(const char *ctlFile, const int f_ind);
void data_2a_step_m1_free(void *);
void data_2a_step_m1_ml(void *);



#endif	/* DATA_2A_STEP_H */

