#include <float.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <stdbool.h>

#include "gsl/gsl_sf.h"
#include "nlopt.h"

#include "util/matrixalloc.h"

#include "data_util.h"
#include "matrix_util.h"

/**
 * @since 2013.08.01, 2013.12.29
 */
void data_util_check_inf(void) {    
    double test = DBL_MAX + DBL_MAX;
    if (test != HUGE_VAL) {
        fprintf(stderr, "Warning: DBL_MAX + DBL_MAX != HUGE_VAL\n");
    }
    test = DBL_MAX;
    if (test >= HUGE_VAL) {
        fprintf(stderr, "Warning: DBL_MAX >= HUGE_VAL\n");
    }
}

/**
 * @since 2014.09.20 (moved implementation to matrix_util)
 */
double ***data_util_bino_new(const int nl, const int *ns, const int hapsize) {
    return matrix_util_bino_new(nl, ns, hapsize);
}

/**
 * @since 2014.09.20 (moved implementation to matrix_util)
 */
void data_util_bino_free(const int nl, const int *ns, double ***bino) {
    matrix_util_bino_free(nl, ns, bino);
}

/**
 * @since 2013.08.11, 2013.08.15, 2013.09.10
 */
double data_util_get_unif(gsl_rng *rng, double min, double max) {
    if (min >= max) {
        fprintf(stderr, "%s\n%i\n", __FILE__, __LINE__);
        abort();
    }
    double x = gsl_rng_uniform(rng);
    x = x * (max - min) + min;
    return x;
}

/**
 * @since 2013.08.15 (onLn=T), 2013.09.10 (min<1 and max>1), 2013.09.30
 */
double data_util_get_rho_lam_unif(gsl_rng *rng, double min, double max, bool onLn) {
    double tmp;
    if (onLn) {
        tmp = data_util_get_unif(rng, min, max);
    } else {
        if (min >= 1)
            tmp = data_util_get_unif(rng, min, max);
        else if (max > 1) {
            double r1 = max;
            double r2 = 1 / min;
            tmp = gsl_rng_uniform(rng);
            if (tmp < r1 / (r1 + r2)) {
                tmp = data_util_get_unif(rng, 1, max);
            } else {
                tmp = 1 / data_util_get_unif(rng, 1, r2);
            }
        } else {
            tmp = 1 / data_util_get_unif(rng, 1 / max, 1 / min);
        }
    }
    return tmp;
}


/**
 * @since 2014.04.25
 */
bool data_util_nlopt_is_ld(nlopt_algorithm alg) {
    //check that this routine as the same set of algorithms as in data_io_control_get_nlopt_alg()
    if (alg == NLOPT_LD_LBFGS || alg == NLOPT_LD_MMA)
        return true;
    return false;
}
