/* 
 * File:   data_2a_step_io.h
 * Author: Kai
 *
 * Created on 12 September 2013, 16:34
 */

#ifndef DATA_2A_STEP_IO_H
#    define	DATA_2A_STEP_IO_H

#include "data_2a_step_m1_param.h"

void data_2a_step_io_m1_get_data(char *dataFile, int buffer_size,
        int *nlPtr, int **nsPtr, double ***dataPtr);
void data_2a_step_io_m1_free_data(int nl, int *ns, double **data);
void data_2a_step_io_m1_write_data(FILE *outF, int nl, int *ns, double **data);
/**
 * @param testPtr On return, testPtr[0] stores the name of the test
 * @param testCPtr On return, testCPtr[0] stores the constant needed to carry out the test; 
                       if the test does not require a constant, then the value is undefined
 */
void data_2a_step_io_m1_get_test(data_2a_step_m1_test_t *testPtr, 
        const char *stptr, const char *ctlFile, const int parN, FILE *outF, const char *parName);

#endif	/* DATA_2A_STEP_IO_H */

