/* 
 * File:   data_2a_step_param.h
 * Author: Kai
 *
 * Created on 12 September 2013, 14:50
 */

#ifndef DATA_2A_STEP_M1_PARAM_H
#    define	DATA_2A_STEP_M1_PARAM_H

#include <stdbool.h>
#include <stdio.h>

#include "gsl/gsl_rng.h"
#include "nlopt.h"

#include "model_2a_step.h"

typedef enum {
    data_2a_step_m1_test_NO_TEST,
    data_2a_step_m1_test_THETA_01_EQ_THETA_10,
    data_2a_step_m1_test_GAMMA_EQ_0
} data_2a_step_m1_test_t;

typedef enum {
    data_2a_step_m1_param_name_THETA,
    data_2a_step_m1_param_name_GAMMA,
    data_2a_step_m1_param_name_RHO,
    data_2a_step_m1_param_name_TAU               
} data_2a_step_m1_param_name_t;

typedef struct {
    int K;
    int nstep;
    
    data_2a_step_m1_test_t test;
    int npar;    
    data_2a_step_m1_param_name_t *parn;
    char **parnstr;
    bool *onLn;
    double *lb;//The scale is determined by onLn
    double *ub;//The scale is determined by onLn
    double (*lnlike)(const double *x, void *params);
    double *xNoTest;//x when there is NO_TEST
    bool *onLnNoTest;
    
    model_2a_step_t *model;
    double *param;
    int nl;//number of data lines
    int *ns;//number of samples in increasing order for the given number of data lines
    double **data;//each row is created by a malloc call; each row contains the data read from a data line
    /*
     * bino[i][j][k]
     * 1. Population allele frequency is k/hapsize
     * 2. Sample size is ns[i]
     * 3. bino[i][j][k]: the probability that, in the sample, the allele concerned is observed j times, given 1 & 2.
     */
    double ***bino;
    
    bool useNrSimplex;
    nlopt_algorithm nlopt_alg;
    double *initPoint;//scale is determined by onLn
    
    gsl_rng *rng;    
    double rftol; 
    int maxeval;
    double maxtime;
    double imprftol; 
    int nnoimp;
    int maximp;
    
    FILE *outF;        
} data_2a_step_m1_param_t;


#endif	/* DATA_2A_STEP_PARAM_H */

