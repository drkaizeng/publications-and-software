#include <limits.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <float.h>

#if defined (USE_MKL)
    #include "mkl.h"
#elif defined (USE_ATLAS)
    #include "cblas.h"    
#else
    #error Either USE_ATLAS OR USE_MKL must be set
#endif
    
#include "util/matrixalloc.h"
#include "nr/nr_simplex.h"

#include "data_2a_step.h"
#include "data_2a_step_m1_param.h"
#include "data_2a_step_io.h"
#include "data_util.h"
#include "data_io.h"


/**
 * @since 2013.12.29
 */
static void header(FILE *outF, data_2a_step_m1_param_t *par) {     
    fprintf(outF, "\nResults by %s:\n", __FILE__);
    fprintf(outF, "nimp\texit_code");
    for (int i = 0; i < par->npar; i++)
        fprintf(outF, "\t%s", par->parnstr[i]);
    fprintf(outF, "\tlnLike\n");
}

/**
 * Transform x to the original scale depending on onLn. If onLn is true, then x has previously been ln-transformed;
 * otherwise, x is on the natural scale.
 * @since [2013.09.25, 2013.09.30], 2013.12.29, 2014.06.15
 */
static inline double par_to_nat(const bool onLn, const double x) {
    return onLn ? exp(x) : x;
}

/**
 * @since 2013.12.29, 2014.04.25, 2014.04.30
 */
static double lnlike_NO_TEST(const double *x, void *params) {    
    data_2a_step_m1_param_t *par = (data_2a_step_m1_param_t *) params;
    
    double *param = par->param;
//    param[3] = 0.5;
    
    int ptr = 0; 
    param[0] = par_to_nat(par->onLnNoTest[ptr], x[ptr]);
    ptr++;
    param[1] = par_to_nat(par->onLnNoTest[ptr], x[ptr]);
    ptr++;
    param[2] = par_to_nat(par->onLnNoTest[ptr], x[ptr]);
    ptr++;
    param[3] = 0.5;
    
    if (par->nstep > 0) {
        for (int i = 0, pp = 4; i < par->nstep; i++) {
            double rho = par_to_nat(par->onLnNoTest[ptr], x[ptr]);
            ptr++;
            double t = par_to_nat(par->onLnNoTest[ptr], x[ptr]);
            ptr++;
            param[pp] = rho;
            pp++;
            param[pp] = t;
            pp++;
        }
    }
        
    double lnl;
    int info = model_2a_step_lnlike(param, par->model, par->nl, par->ns, par->data, par->bino, &lnl);
    if (info != 0)
        return -DBL_MAX;
    
    return lnl;
}

/**
 * x should be on the natural scale
 * @since [2013.09.28, 2013.09.30], 2013.12.29
 */
static inline double par_to_ln(const bool onLn, double x) {
    return onLn ? log(x) : x;
}

/**
 * @since 2013.12.29, 2014.04.30, 2014.06.01, 2015.11.22
 */
static double lnlike_THETA_01_EQ_THETA_10(const double *x, void *params) {    
    data_2a_step_m1_param_t *par = (data_2a_step_m1_param_t *) params;
    par->xNoTest[0] = x[0];//both theta must be on the same scale
    memcpy(par->xNoTest + 1, x, (size_t) (par->npar) * sizeof (double));
    return lnlike_NO_TEST(par->xNoTest, params);
}

/**
 * @since 2013.12.29, 2014.04.30, 2014.06.01, 2015.11.22
 */
static double lnlike_GAMMA_EQ_0(const double *x, void *params) {    
    data_2a_step_m1_param_t *par = (data_2a_step_m1_param_t *) params;
    static size_t s1 = 2 * sizeof (double);
    memcpy(par->xNoTest, x, s1);
    memcpy(par->xNoTest + 3, x + 2, (size_t) (par->npar - 2) * sizeof (double));
    par->xNoTest[2] = par_to_ln(par->onLnNoTest[2], 0);
    return lnlike_NO_TEST(par->xNoTest, params);
}

/**
 * i_min and i_max (both inclusive) are the range in p and y that are to be updated.
 * @since 2014.06.01, 2014.06.15
 */
static void init_point(double **p, double *y, int i_min, int i_max, data_2a_step_m1_param_t *par) {
    for (int i = i_min; i <= i_max; i++) {
        while (true) {
            for (int j = 0; j < par->npar; j++) {
                if (par->parn[j] == data_2a_step_m1_param_name_THETA) {
                    if (par->onLn[j] == true)
                        p[i][j] = data_util_get_unif(par->rng, par->lb[j], par->ub[j]);
                    else
                        p[i][j] = exp(data_util_get_unif(par->rng, log(par->lb[j]), log(par->ub[j])));
                } else if (par->parn[j] == data_2a_step_m1_param_name_RHO) {
                    p[i][j] = data_util_get_rho_lam_unif(par->rng, par->lb[j], par->ub[j], par->onLn[j]);
                } else {//gamma and tau
                    p[i][j] = data_util_get_unif(par->rng, par->lb[j], par->ub[j]);
                }
            }
            y[i] = par->lnlike(p[i], par);
            if (! (isnan(y[i]) || isinf(y[i]) || y[i] <= -HUGE_VAL || y[i] >= HUGE_VAL || fabs(y[i]) >= DBL_MAX)) 
                break;
        }
    }
}

/**
 * @since [2013.09.26, 2013.09.28], 2013.12.29
 */
static void write_result(FILE *outF, double *x, double y, data_2a_step_m1_param_t *par) {
    for (int j = 0; j < par->npar; j++) {
        fprintf(outF, "\t%.8e", par->onLn[j] ? exp(x[j]) : x[j]);
    }
    fprintf(outF, "\t%.15e\n", y);
}

/**
 * @since 2014.04.28, 2014.04.30, 2014.05.05, 2014.05.12, 2014.06.01
 */
static double nlopt_f(unsigned n, const double *x, double *grad, void *f_data) {
    data_2a_step_m1_param_t *par = (data_2a_step_m1_param_t *) f_data;
    if (grad != NULL) {//setBound is always true; see new()
        abort();
    }
    return par->lnlike(x, f_data);
}

/**
 * @since 2014.05.12, 2015.11.22
 */
static void nlopt_set_bound(nlopt_opt opt, data_2a_step_m1_param_t *par) {
    if (nlopt_set_lower_bounds(opt, par->lb) != NLOPT_SUCCESS) {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
    if (nlopt_set_upper_bounds(opt, par->ub) != NLOPT_SUCCESS) {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
}

/**
 * @since 2014.05.08, 2014.05.12, 2014.06.01, 2015.11.22
 */
static nlopt_opt nlopt_get_opt_work(nlopt_algorithm alg, data_2a_step_m1_param_t *par) {
    nlopt_opt opt = nlopt_create(alg, (unsigned) par->npar);
    if (opt == NULL) {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
    if (nlopt_set_ftol_rel(opt, par->rftol) != NLOPT_SUCCESS) {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
    if (nlopt_set_maxeval(opt, par->maxeval) != NLOPT_SUCCESS) {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
    if (nlopt_set_maxtime(opt, par->maxtime) != NLOPT_SUCCESS) {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
    return opt;
}

/**
 * @since 2014.06.01
 */
static nlopt_opt nlopt_get_opt(data_2a_step_m1_param_t *par) {
    nlopt_opt opt = nlopt_get_opt_work(par->nlopt_alg, par);
    if (par->nlopt_alg == NLOPT_G_MLSL || par->nlopt_alg == NLOPT_G_MLSL_LDS) {
        nlopt_opt local = nlopt_get_opt_work(NLOPT_LN_NELDERMEAD, par);
        if (nlopt_set_local_optimizer(opt, local) != NLOPT_SUCCESS) {
            fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
            abort();
        }
    }
    if (nlopt_set_max_objective(opt, nlopt_f, par) != NLOPT_SUCCESS) {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
    nlopt_set_bound(opt, par);
    return opt;
}

/**
 * @since 2014.06.01
 */
static void nlopt_run(data_2a_step_m1_param_t *par) {
    nlopt_opt opt = nlopt_get_opt(par);
    double *x = matrixalloc_1d(par->npar, sizeof (double));
    if (par->initPoint != NULL) {
        memcpy(x, par->initPoint, (size_t) par->npar * sizeof (double));
    } else {
        double tmp;
        init_point(&x, &tmp, 0, 0, par);
    }
    FILE *outF = par->outF;
    int nnoimp = 1;
    double fold;
    clock_t rt = clock();
    for (int i = 1; i <= par->maximp; i++) {
        double opt_f;
        nlopt_result info = nlopt_optimize(opt, x, &opt_f);      
        fprintf(outF, "%d\t%d", i, info);
        write_result(outF, x, opt_f, par);
        fflush(outF);
        if (i > 1) {
            double tmp = fabs(opt_f - fold);
            if (tmp <= par->imprftol * 0.5 * (fabs(opt_f) + fabs(fold)))
                nnoimp++;
            else
                nnoimp = 1;
        }
        fold = opt_f;
        if (nnoimp >= par->nnoimp)
            break;
    }
    rt = clock() - rt;
    clock_t rt_1 = rt / CLOCKS_PER_SEC;
    clock_t rt_2 = rt - (rt_1 * CLOCKS_PER_SEC);
    long double rt_d = (long double) rt_1 + (long double) rt_2 / CLOCKS_PER_SEC;
    fprintf(outF, "Done!\n");
    fprintf(outF, "Time used (in seconds) = %.3Lf\n\n", rt_d);
    fflush(outF);
    nlopt_destroy(opt);
    matrixalloc_1d_free(x);
}

/**
 * @since [2013.09.26], 2013.12.29
 */
static double nrsimplex_f(double *x, void *f_data) {
    data_2a_step_m1_param_t *par = (data_2a_step_m1_param_t *) f_data;
    for (int i = 0; i < par->npar; i++) {
        if (x[i] < par->lb[i] || x[i] > par->ub[i])
            return DBL_MAX;
    }
    return -par->lnlike(x, f_data);
}

/**
 * @since 2014.06.01
 */
static void nrsimplex_run(data_2a_step_m1_param_t *par) {
    nr_simplex_t *sim = nr_simplex_new(par->npar, nrsimplex_f, par, par->rftol, -1, par->maxeval, par->maxtime);
    int nparp1 = par->npar + 1;
    double **p = matrixalloc_2d_d(nparp1, par->npar);
    double *y = matrixalloc_1d(nparp1, sizeof (double));
    if (par->initPoint != NULL) {
        memcpy(p[0], par->initPoint, (size_t) par->npar * sizeof (double));
        y[0] = par->lnlike(p[0], par);
        init_point(p, y, 1, par->npar, par);
    } else {
        init_point(p, y, 0, par->npar, par);
    }
    cblas_dscal(nparp1, -1, y, 1);
    FILE *outF = par->outF;
    int nnoimp = 1;
    double fold, opt_f;
    clock_t rt = clock();
    for (int i = 1; i <= par->maximp; i++) {
        nr_simplex_result_t info = nr_simplex_search(p, y, sim);
        opt_f = -y[0];
        fprintf(outF, "%d\t%d", i, info);
        write_result(outF, p[0], opt_f, par);
        fflush(outF);
        if (i > 1) {
            double tmp = fabs(opt_f - fold);
            if (tmp <= par->imprftol * 0.5 * (fabs(opt_f) + fabs(fold)))
                nnoimp++;
            else
                nnoimp = 1;
        }
        fold = opt_f;
        if (nnoimp >= par->nnoimp)
            break;
        if (i < par->maximp) {
            init_point(p, y, 1, par->npar, par);
            cblas_dscal(par->npar, -1, y + 1, 1);
        }
    }
    rt = clock() - rt;
    clock_t rt_1 = rt / CLOCKS_PER_SEC;
    clock_t rt_2 = rt - (rt_1 * CLOCKS_PER_SEC);
    long double rt_d = (long double) rt_1 + (long double) rt_2 / CLOCKS_PER_SEC;
    fprintf(outF, "Done!\n");
    fprintf(outF, "Time used (in seconds) = %.3Lf\n\n", rt_d);
    fflush(outF);
    matrixalloc_1d_free(y);
    matrixalloc_2d_d_free(p);
    nr_simplex_free(sim);
}

/**
 * @since [2013.09.13, 2013.09.26], 2013.12.29
 */
void data_2a_step_m1_ml(void *ptr) {     
    data_2a_step_m1_param_t *par = (data_2a_step_m1_param_t *) ptr;
    header(par->outF, par);
    if (par->useNrSimplex == true) {
        nrsimplex_run(par);
    } else {
        nlopt_run(par);
    }
}


/**
 * This functions inserts the parameter to the ind-th element of
 * parn
 * parnstr
 * onLn
 * lb
 * ub
 * onLnNoTest
 * 
 * @since 2013.12.29, 2014.04.25, 2014.04.30, 2014.06.01, 2014.06.15, 2015.11.22
 */
static void new_par(data_2a_step_m1_param_t *par, const int ind, 
        const data_2a_step_m1_param_name_t name, const char *namestr, const bool onLn, const double initL, const double initU) {
    par->parn[ind] = name;
    par->parnstr[ind] = matrixalloc_1d((int) (strlen(namestr) + 1), sizeof (char));
    strcpy(par->parnstr[ind], namestr);
    par->onLn[ind] = onLn;
    if (onLn == true) {
        par->lb[ind] = log(initL);
        par->ub[ind] = log(initU);
    } else {
        par->lb[ind] = initL;
        par->ub[ind] = initU;
    }
    par->onLnNoTest[ind] = onLn;
}

/**
 * Remove the ind-th element in 
 * parn
 * parnstr
 * onLn
 * lb
 * ub
 * 
 * On return, par->npar is one smaller than that before calling this function.
 * 
 * @since 2013.12.29, 2014.04.30, 2014.06.01, 2015.11.22
 */
static void rm_par(data_2a_step_m1_param_t *par, const int ind) {
    matrixalloc_1d_free(par->parnstr[ind]);
    for (int i = ind + 1; i < par->npar; i++) {
        par->parn[i - 1] = par->parn[i];
        par->parnstr[i - 1] = par->parnstr[i];
        par->onLn[i - 1] = par->onLn[i];
        par->lb[i - 1] = par->lb[i];
        par->ub[i - 1] = par->ub[i];
    }
    par->npar--;
}

/**
 * @since 2014.06.15, 2015.11.22
 * 
 */
static void get_test(data_2a_step_m1_param_t *par,
        double *initThetaRange, double *initGammaRange, double *initRhoRange, double *initTRange, 
        bool thetaOnLn, bool gammaOnLn, bool rhoOnLn, bool tOnLn) {
    const int nstep = par->nstep;
    const data_2a_step_m1_test_t test = par->test;    
    par->npar = 3;//the number of parameters when there is NO_TEST
    if (nstep != 0)
        par->npar += 2 * nstep;
    par->parn = matrixalloc_1d(par->npar, sizeof (data_2a_step_m1_param_name_t));
    par->parnstr = matrixalloc_1d(par->npar, sizeof (char *));
    par->onLn = matrixalloc_1d(par->npar, sizeof (bool));
    par->lb = matrixalloc_1d(par->npar, sizeof (double));
    par->ub = matrixalloc_1d(par->npar, sizeof (double));
    par->xNoTest = matrixalloc_1d(par->npar, sizeof (double));  
    par->onLnNoTest = matrixalloc_1d(par->npar, sizeof (bool)); 
    {// the full model
        /* theta */
        int nTheta = 2;
        int indTheta[2] = { 0, 1 };
        const char *thstr[2];
        thstr[0] = "theta_01";
        thstr[1] = "theta_10";
        for (int i = 0; i < nTheta; i++) {
            new_par(par, indTheta[i], data_2a_step_m1_param_name_THETA, thstr[i], thetaOnLn, initThetaRange[0], initThetaRange[1]);
        }
        /* gamma */
        int nGamma = 1;
        int indGamma[1] = {2};
        const char *gastr[1];
        gastr[0] = "gamma";
        for (int i = 0; i < nGamma; i++) {
            new_par(par, indGamma[i], data_2a_step_m1_param_name_GAMMA, gastr[i], gammaOnLn, initGammaRange[0], initGammaRange[1]);
        }
        if (nstep > 0) {
            char rhostr[5 + 1 + nstep / 10];
            char taustr[5 + 1 + nstep / 10];
            for (int i = 0, ind = 3; i < nstep; i++) {//rho and maxT
                sprintf(rhostr, "rho_%d", (i + 1));
                new_par(par, ind, data_2a_step_m1_param_name_RHO, rhostr, rhoOnLn, initRhoRange[i * 2], initRhoRange[i * 2 + 1]);
                ind++;
                sprintf(taustr, "tau_%d", (i + 1));
                new_par(par, ind, data_2a_step_m1_param_name_TAU, taustr, tOnLn, initTRange[i * 2], initTRange[i * 2 + 1]);
                ind++;
            }
        }
    }
    if (test == data_2a_step_m1_test_NO_TEST) {
        par->lnlike = lnlike_NO_TEST;
    } else if (test == data_2a_step_m1_test_THETA_01_EQ_THETA_10) {
        rm_par(par, 0);//remove theta_01
        par->lnlike = lnlike_THETA_01_EQ_THETA_10;
    } else if (test == data_2a_step_m1_test_GAMMA_EQ_0) {
        rm_par(par, 2);//remove gamma
        par->lnlike = lnlike_GAMMA_EQ_0;
    } else {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort(); 
    }    
}

/**
 * @since 2014.06.15
 */
static void free_test(data_2a_step_m1_param_t *par) {
    matrixalloc_1d_free(par->onLnNoTest);
    matrixalloc_1d_free(par->xNoTest);
    matrixalloc_1d_free(par->ub);
    matrixalloc_1d_free(par->lb);
    matrixalloc_1d_free(par->onLn);
    matrixalloc_1d_free(par->parn);
    for (int i = 0; i < par->npar; i++)
        matrixalloc_1d_free(par->parnstr[i]);
    matrixalloc_1d_free(par->parnstr);
    
}


/**
 * @since 2014.06.01, 2014.06.15
 * 
 */
void *data_2a_step_m1_new(const char *ctlFile, const int f_ind) {   
    const int buffer_size = 32767;
    /* control parameters */
    const int nCtlPar = 21;
    int parN = 0;
    const char *ctlPar[nCtlPar];
    ctlPar[parN++] = "outputFile:";
    ctlPar[parN++] = "dataFile:";
    ctlPar[parN++] = "K:";
    ctlPar[parN++] = "nstep:";   
    ctlPar[parN++] = "tau:";
    ctlPar[parN++] = "test:";
    ctlPar[parN++] = "useNrSimplex:";
    ctlPar[parN++] = "nlopt_alg:";
    ctlPar[parN++] = "initPoint:";
    ctlPar[parN++] = "initThetaRange:";
    ctlPar[parN++] = "initGammaRange:";
    ctlPar[parN++] = "initRhoRange:";
    ctlPar[parN++] = "initTRange:"; 
    ctlPar[parN++] = "thetaOnLn:";
    ctlPar[parN++] = "rhoOnLn:";
    ctlPar[parN++] = "rftol:";
    ctlPar[parN++] = "maxeval:";
    ctlPar[parN++] = "maxtime:";
    ctlPar[parN++] = "imprftol:";
    ctlPar[parN++] = "nnoimp:";
    ctlPar[parN++] = "maximp:";
        
    if (f_ind == -1) {
        for (int i = 0; i < nCtlPar; i++)
            fprintf(stdout, "%s\n", ctlPar[i]);
        exit(1);
    } else if (f_ind <= 0) {
        fprintf(stderr, "Error: f_ind <= 0!\n");
        abort();
    }
        
    char ctlParVal[nCtlPar][buffer_size];
    data_io_control_param_get(ctlFile, buffer_size, nCtlPar, ctlPar, ctlParVal);
        
    parN = 0;
    
    FILE *outF = data_io_control_get_outF(ctlParVal[parN], f_ind);
    fprintf(outF, "Control file contents:\n");
    fprintf(outF, "%s %s\n", ctlPar[parN], data_io_trim(ctlParVal[parN]));    
    parN++;    
    
    char *dataFile = data_io_trim(ctlParVal[parN]);
    if (dataFile == NULL) {
        fprintf(stderr, "Error: no data file was provided.\n");
        abort();
    }
    fprintf(outF, "%s %s\n", ctlPar[parN], dataFile);
    parN++;
    
    int K = data_io_control_get_int(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    if (K < 10)
        data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "Error: K < 10");
    parN++;    
    
    int nstep = data_io_control_get_int(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    if (nstep < 0) {
        fprintf(stderr, "Error: nstep < 0\n");
        data_io_print_file_error(ctlFile, parN, ctlParVal[parN], NULL);
    }
    parN++;
    
    double tau;
    if (nstep == 0) {
        tau = 0;
        if (data_io_all_space(ctlParVal[parN]) == false)
            data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "tau: should not be set when nstep: is 0.");      
        fprintf(outF, "%s\n", ctlPar[parN]); 
    } else {
        tau = data_io_control_get_double(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
        if (tau <= 0 || tau >= 0.1)
            data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "Error: tau <= 0 or tau >= 0.1");      
    }
    parN++;
    
    /* test */
    data_2a_step_m1_test_t test;
    data_2a_step_io_m1_get_test(&test, ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    parN++;
    
    bool useNrSimplex = data_io_control_get_bool(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    parN++;

    nlopt_algorithm nlopt_alg;
    if (useNrSimplex == true) {
        if (data_io_all_space(ctlParVal[parN]) == false) {
            data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "nlopt_alg: should not be set when useNrSimplex: is 1.");
        }
        fprintf(outF, "%s\n", ctlPar[parN]);
    } else {
        nlopt_alg = data_io_control_get_nlopt_alg(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    }
    parN++;
    
    bool withInitPoint;
    char *initPointStr;
    if (data_io_all_space(ctlParVal[parN]) == true) {
        withInitPoint = false;
        fprintf(outF, "%s\n", ctlPar[parN]);
    } else {
        withInitPoint = true;
        initPointStr = data_io_trim(ctlParVal[parN]);
        fprintf(outF, "%s %s\n", ctlPar[parN], initPointStr);
    }
    parN++;
    
    const bool setBound = true;

    double initThetaRange[2];
    data_io_control_get_range(ctlParVal[parN], 2, initThetaRange, DBL_MIN, 1, setBound, ctlFile, parN, outF, ctlPar[parN]);
    parN++;

    double initGammaRange[2] = { -DBL_MAX, DBL_MAX };
    if (test != data_2a_step_m1_test_GAMMA_EQ_0)
        data_io_control_get_range(ctlParVal[parN], 2, initGammaRange, -DBL_MAX, DBL_MAX, setBound, ctlFile, parN, outF, ctlPar[parN]);
    else {
        if (data_io_all_space(ctlParVal[parN]) == false) {
            fprintf(stderr, "initGammaRange: should not be set when the test GAMMA_EQ_0 is set.\n");
            abort();
        }
        fprintf(outF, "%s\n", ctlPar[parN]);
    }
    parN++;
       
    double *initRhoRange = NULL;
    if (nstep == 0) {
        if (data_io_all_space(ctlParVal[parN]) == false)
            data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "initRhoRange: should not be set when nstep: is 0.");      
        fprintf(outF, "%s\n", ctlPar[parN]);  
    } else {
        int nstep2 = nstep * 2;
        initRhoRange = matrixalloc_1d(nstep2, sizeof (double));
        data_io_control_get_range(ctlParVal[parN], nstep2, initRhoRange, DBL_MIN, DBL_MAX, setBound, ctlFile, parN, outF, ctlPar[parN]);
    }
    parN++;
    
    double *maxT = NULL;
    double *initTRange = NULL;//avoid zero-length array c99 6.7.5.2
    if (nstep == 0) {
        if (data_io_all_space(ctlParVal[parN]) == false)
            data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "initTRange: should not be set when nstep: is 0.");      
        fprintf(outF, "%s\n", ctlPar[parN]);  
    } else {
        maxT = matrixalloc_1d(nstep, sizeof (double));
        int nstep2 = nstep * 2;
        initTRange = matrixalloc_1d(nstep2, sizeof (double));
        data_io_control_get_range(ctlParVal[parN], nstep2, initTRange, DBL_MIN, DBL_MAX, setBound, ctlFile, parN, outF, ctlPar[parN]);
        for (int i = 0, j = 0; i < nstep2; i += 2, j++) {
            maxT[j] = initTRange[i + 1];
            if (maxT[j] >= (INT_MAX - 1) * tau) {
                fprintf(stderr, "Error: initTRange should be strictly smaller than %.8e!\n", (INT_MAX - 1) * tau);
                abort();
            }
        }
    }
    parN++;
    
    bool thetaOnLn = data_io_control_get_bool(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    parN++;
    
    bool rhoOnLn;
    if (nstep == 0) {
        rhoOnLn = false;
        if (data_io_all_space(ctlParVal[parN]) == false)
            data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "rhoOnLn: should not be set when nstep: is 0.\n");      
        fprintf(outF, "%s\n", ctlPar[parN]);  
    } else {
        rhoOnLn = data_io_control_get_bool(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    }
    parN++;
        
    double rftol = data_io_control_get_double(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    if (rftol <= 0 || rftol >= 0.1)
        data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "Error: rftol <= 0 or rftol >= 0.1\n");
    parN++;
    
    int maxeval = data_io_control_get_int(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    if (maxeval < 1)
        data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "Error: maxeval < 1\n");
    parN++;
    
    double maxtime = data_io_control_get_double(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    if (maxtime <= 0)
        data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "Error: maxtime <= 0\n");
    parN++;
    
    double imprftol = data_io_control_get_double(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    if (imprftol < 0 || imprftol >= 0.1)
        data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "Error: imprftol < 0 || imprftol >= 0.1\n");
    parN++;
        
    int nnoimp = data_io_control_get_int(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    if (nnoimp < 1)
        data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "Error: nnoimp < 1\n");
    parN++;
    
    int maximp = data_io_control_get_int(ctlParVal[parN], ctlFile, parN, outF, ctlPar[parN]);
    if (maximp < 1)
        data_io_print_file_error(ctlFile, parN, ctlParVal[parN], "Error: maximp < 1\n");
    parN++;
    
    fprintf(outF, "\n");
       
    /* data */    
    data_2a_step_m1_param_t *params = matrixalloc_1d(1, sizeof (data_2a_step_m1_param_t));
    params->K = K;
    params->nstep = nstep;
    params->test = test;
    get_test(params, initThetaRange, initGammaRange, initRhoRange, initTRange, thetaOnLn, false, rhoOnLn, false);
        
    params->model = model_2a_step_new(K, nstep, maxT, tau);
    model_2a_step_set_iteration_method(params->model, 2);
    params->param = matrixalloc_1d(4 + 2 * nstep, sizeof (double));
    
    params->nl = 0; params->ns = NULL; params->data = NULL;
    data_2a_step_io_m1_get_data(dataFile, buffer_size, &(params->nl), &(params->ns), &(params->data));
    
    fprintf(outF, "\nData file contents:\n");
    data_2a_step_io_m1_write_data(outF, params->nl, params->ns, params->data);
    fprintf(outF, "\n");
    
    params->bino = data_util_bino_new(params->nl, params->ns, K);
        
    params->useNrSimplex = useNrSimplex;
    params->nlopt_alg = nlopt_alg;
    if (withInitPoint == true) {
        params->initPoint = matrixalloc_1d(params->npar, sizeof (double));
        data_io_control_get_double_array(params->npar, initPointStr, params->initPoint, ctlFile, parN, NULL, "Error in initPoint:!\n");
        for (int i = 0; i < params->npar; i++)
            params->initPoint[i] = par_to_ln(params->onLn[i], params->initPoint[i]);
    } else
        params->initPoint = NULL;
    
    gsl_rng *rng = gsl_rng_alloc(gsl_rng_mt19937);
    if (rng == NULL) {
        fprintf(stderr, "Error: failed to construct gsl_rng.\n");
        abort();
    }
    unsigned long seed = (unsigned long) time(NULL);
    gsl_rng_set(rng, seed);
    fprintf(outF, "\nRandom seed: %lu\n\n", seed);
    
    params->rng = rng;
    params->rftol = rftol;
    params->maxeval = maxeval;
    params->maxtime = maxtime;
    params->imprftol = imprftol;
    params->nnoimp = nnoimp;
    params->maximp = maximp;
    
    params->outF = outF;    
    
    if (params->initPoint != NULL) {
        double tmp = nrsimplex_f(params->initPoint, params);
        if (isnan(tmp) || isinf(tmp)) {
            fprintf(stderr, "Error: ln-likelihood calculated using initPoint is nan/inf!\n");
            abort();
        }
    }
          
    fflush(outF); 
    matrixalloc_1d_free(initRhoRange);
    matrixalloc_1d_free(maxT);
    matrixalloc_1d_free(initTRange);
    return params;
}

/**
 * @since 2014.05.12, 2014.06.15
 */
void data_2a_step_m1_free(void *ptr) {
    data_2a_step_m1_param_t *par = (data_2a_step_m1_param_t *) ptr;
    fclose(par->outF);
    gsl_rng_free(par->rng);
    matrixalloc_1d_free(par->initPoint);
    data_util_bino_free(par->nl, par->ns, par->bino);
    data_2a_step_io_m1_free_data(par->nl, par->ns, par->data);
    matrixalloc_1d_free(par->param);
    model_2a_step_free(par->model);
    free_test(par);
    free(par);
}