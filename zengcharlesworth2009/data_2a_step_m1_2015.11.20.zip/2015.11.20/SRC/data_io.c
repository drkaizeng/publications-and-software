#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <float.h>
#include <limits.h>
#include <ctype.h>
#include <string.h>
#include <errno.h>

#include "data_io.h"
#include "util/matrixalloc.h"


/**
 * @since 2013.07.31, 2013.09.09 (by eye)
 */
void data_io_print_file_error(const char *fileName, const int lineNo, const char *buffer, const char *msg) {
    fprintf(stderr, "Error: illegal file format, %s\n", fileName);
    fprintf(stderr, "Line = %i\n", lineNo);
    fprintf(stderr, "Content = \"%s\"\n", buffer);
    if (msg != NULL)
        fprintf(stderr, "%s", msg);
    exit(EXIT_FAILURE);
}

/**
 * @since 2013.07.31, 2013.08.11, 2013.09.09, 2013.09.26
 */
int data_io_first_nonspace(const char * const ptr) {
    size_t len = strlen(ptr);
    if (len >= INT_MAX) {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
    int length = (int) len;
    for (int i = 0; i < length; i++) {
        if (! isspace(ptr[i]))
            return i;
    }
    return -1;
}

/**
 * @since 2013.09.29
 */
int data_io_first_space(const char * const ptr) {
    size_t length = strlen(ptr);
    if (length >= INT_MAX) {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
    int len = (int) length;
    int i = 0;
    for (; i < len; i++) {
        if (isspace(ptr[i]))
            return i;
    }
    return -1;
}

/**
 * @since 2013.08.11, 2013.09.09, 2013.09.26, 2015.11.22
 */
bool data_io_check_line_width(FILE *file, const char * const ptr) {
    size_t length = strlen(ptr);
    if (length == 0) {
        return true;
    } else {
        if (ptr[length - 1] == '\n')
            return true;
        if (ptr[length - 1] != '\n') {
            if (fgetc(file) == EOF)
                return true;
        }
    }
    return false;
}

/**
 * @since 2013.07.31, 2013.08.01, 2013.08.11, 2013.09.09 (night), 2013.09.26
 */
int data_io_next_double(const char *ptr, char **endPtr, double *re) {
    errno = 0;
    long double tmp = strtold(ptr, endPtr);
    if (ptr == endPtr[0])
        return 1;
    if (errno != 0)
        return 2;
    if (tmp >= DBL_MAX || tmp <= -DBL_MAX)
        return 3;
    *re = (double) tmp;
    return 0;
}

/**
 * @since 2013.07.31, 2013.08.01, 2013.08.11, 2013.09.09 (night), 2013.09.26
 */
int data_io_next_int(const char *ptr, char **endPtr, int *re) {
    errno = 0;
    long long tmp = strtoll(ptr, endPtr, 10);
    if (ptr == endPtr[0])
        return 1;
    if (errno != 0)
        return 2;
    if (tmp >= INT_MAX || tmp <= INT_MIN)
        return 3;
    *re = (int) tmp;
    return 0;
}

/**
 * @since 2013.08.01, 2013.08.11, 2013.09.26
 */
bool data_io_all_space(const char * ptr) {
    while (*ptr != '\0') {
        if (!isspace(*ptr))
            return false;
        ptr++;
    }
    return true;
}

/**
 * @since 2013.08.11, 2013.08.15, 2013.09.09, 2013.09.26
 */
char *data_io_trim(char *ptr) {    
    size_t len = strlen(ptr);
    if (len >= INT_MAX) {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
    int cn = (int) len - 1;
    while (cn >= 0) {
        if (isspace(ptr[cn]) == 0)
            break;
        ptr[cn] = '\0';
        cn--;
    }
    len = strlen(ptr);
    if (len == 0) {
        return NULL;
    } else {
        cn = 0;
        while (cn < (int) len) {
            if (isspace(ptr[cn]))
                cn++;
            else
                return ptr + cn;
        }
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
}




/**
 * @since 2013.08.11, 2013.09.09, 2013.09.26, 2014.09.21, 2015.11.22
 */
void data_io_control_param_get(const char *ctlFile, const int buffer_size, const int n, const char *ctlPar[n], char ctlParVal[n][buffer_size]) {
    FILE *in = fopen(ctlFile, "r");
    if (in == NULL) {
        fprintf (stderr, "Error: failed to open file, %s\n", ctlFile);
        exit(EXIT_FAILURE);        
    }
    
    int lineNo = 0;
    char buffer[buffer_size];
    char *st;
    
    for (int i = 0; i < n; i++) {
        st = fgets(buffer, buffer_size, in);
        lineNo++;
        if (st == NULL) 
            data_io_print_file_error(ctlFile, lineNo, buffer, "Error encountered when reading the line.");
        if (data_io_check_line_width(in, st) == false)
            data_io_print_file_error(ctlFile, lineNo, buffer, "The line is too long.");
        char *tmp = strstr(st, ctlPar[i]);
        if (tmp == NULL) 
            data_io_print_file_error(ctlFile, lineNo, buffer, "The line must start with the specified parameter.");
        tmp = tmp + strlen(ctlPar[i]);
        strcpy(ctlParVal[i], tmp);
    }
    fclose(in);
}

/**
 * @since 2013.08.11, 2013.08.15, 2013.09.09, 2013.09.26 (added test of stptr = null)
 */
int data_io_control_get_int(char *stptr, const char *ctlFile, int parN, FILE *outF, const char *name) {
    stptr = data_io_trim(stptr);
    if (stptr == NULL) {
        data_io_print_file_error(ctlFile, parN, "", NULL);       
    }
    char *endPtr;
    int re;
    int info = data_io_next_int(stptr, &endPtr, &re);
    if (info != 0 || (*endPtr) != '\0')
        data_io_print_file_error(ctlFile, parN, stptr, NULL);    
    if (outF != NULL)
        fprintf(outF, "%s %d\n", name, re);
    return re;
}

/**
 * @since 2013.09.26 (added test of stptr = null)
 */
double data_io_control_get_double(char *stptr, const char *ctlFile, int parN, FILE *outF, const char *name) {
    stptr = data_io_trim(stptr);
    if (stptr == NULL) {
        data_io_print_file_error(ctlFile, parN, "", NULL);    
    }
    char *endPtr;
    double re;
    int info = data_io_next_double(stptr, &endPtr, &re);
    if (info != 0)
        data_io_print_file_error(ctlFile, parN, stptr, NULL);
    if (outF != NULL)
        fprintf(outF, "%s %g\n", name, re);
    return re;
}
/**
 * @since 2013.08.11, 2013.08.15, 2013.09.09, 2013.09.26 (added test of stptr = null)
 */
void data_io_control_get_double_array(int n, char *stptr, double arr[n], const char *ctlFile, int parN, FILE *outF, const char *name) {
    if (n <= 0) {
        fprintf(stderr, "Non-positive array length in %s %i\n", __FILE__, __LINE__);
        abort();
    }
    stptr = data_io_trim(stptr);
    if (stptr == NULL) {
        data_io_print_file_error(ctlFile, parN, "", NULL);        
    }
    char *endPtr;
    if (outF != NULL) {
        fprintf(outF, "%s", name);
    }
    for (int i = 0; i < n; i++) {
        double d;
        int info = data_io_next_double(stptr, &endPtr, &d);
        if (info != 0)
            data_io_print_file_error(ctlFile, parN, stptr, NULL);
        arr[i] = d;
        stptr = endPtr;
        if (outF != NULL) {
            fprintf(outF, "\t%g", d);
        }
    }
    if (outF != NULL) {
        fprintf(outF, "\n");
    }
    if (endPtr[0] != '\0')
        data_io_print_file_error(ctlFile, parN, stptr, NULL);
}

/**
 * @since 2013.08.15, 2013.09.09, 2013.09.26 (added test of stptr = null), 2015.11.22
 */
bool data_io_control_get_bool(char *stptr, const char *ctlFile, int parN, FILE *outF, const char *parName) {
    stptr = data_io_trim(stptr);
    if (stptr == NULL) {
        data_io_print_file_error(ctlFile, parN, "", NULL);    
    }
    int tmp = data_io_control_get_int(stptr, ctlFile, parN, outF, parName);
    if (tmp < 0 || tmp > 1)
        data_io_print_file_error(ctlFile, parN, stptr, NULL);
    return (tmp == 0 ? false : true);
}

/**
 * @since 2013.08.15, 2013.09.09, 2013.09.26 (removed, parName), 2013.12.29, 2014.09.21 (added test for snprintf), 2015.11.22
 */
FILE *data_io_control_get_outF(char *stptr, const int f_ind) {
    FILE *outF;
    char *outputFile = data_io_trim(stptr);
    if (outputFile == NULL) {
        fprintf(stderr, "Error: output file name not found!\n");
        abort();
    }
    size_t add = (size_t) f_ind / 10 + 7;
    char tmp[strlen(outputFile) + add];
    strcpy(tmp, outputFile);
    int n = snprintf(tmp + strlen(outputFile), add, ".%i.out", f_ind);
    if (! (n >= 0 && (size_t) n < add)) {
        fprintf(stderr, "Error: generating output file name!\n");
        abort();
    }
    outputFile = tmp;
    outF = fopen(outputFile, "r");
    if (outF != NULL) {
        fprintf(stderr, "Error: output file exists!\n");
        abort();
    }
    outF = fopen(outputFile, "w");
    if (outF == NULL) {
        fprintf(stderr, "Error: cannot open output file!\n");
        abort();
    }
    return outF;
}

#define GET_NLOPT_ALG(alg, status, name, nlopt_alg) \
            if (status == NOT_FOUND && strcmp(name, #alg) == 0) { \
                status = FOUND_ALG; \
                nlopt_alg = alg; \
            }

/**
 * @since 2014.06.15 (removed LD algorithms), 2014.09.21, 2015.11.22
 */
nlopt_algorithm data_io_control_get_nlopt_alg(char *str, const char *ctlFile, int parN, FILE *outF, const char *parName) {
    nlopt_algorithm nlopt_alg;
    const char *name = data_io_trim(str);
    if (name == NULL) {
        data_io_print_file_error(ctlFile, parN, str, NULL);    
    }
    enum { NOT_FOUND, FOUND_ALG } status;
    status = NOT_FOUND;
    //GET_NLOPT_ALG(alg, status, name, nlopt_alg)
    GET_NLOPT_ALG(NLOPT_LN_COBYLA, status, name, nlopt_alg);
    GET_NLOPT_ALG(NLOPT_LN_BOBYQA, status, name, nlopt_alg);
    GET_NLOPT_ALG(NLOPT_LN_NEWUOA_BOUND, status, name, nlopt_alg);
    GET_NLOPT_ALG(NLOPT_LN_NEWUOA, status, name, nlopt_alg);
    GET_NLOPT_ALG(NLOPT_LN_PRAXIS, status, name, nlopt_alg);
    GET_NLOPT_ALG(NLOPT_LN_NELDERMEAD, status, name, nlopt_alg);
    GET_NLOPT_ALG(NLOPT_LN_SBPLX, status, name, nlopt_alg);
    
    GET_NLOPT_ALG(NLOPT_GN_DIRECT, status, name, nlopt_alg);
    GET_NLOPT_ALG(NLOPT_GN_DIRECT_L, status, name, nlopt_alg);
    GET_NLOPT_ALG(NLOPT_GN_DIRECT_L_RAND, status, name, nlopt_alg);
    GET_NLOPT_ALG(NLOPT_GN_CRS2_LM, status, name, nlopt_alg);
    GET_NLOPT_ALG(NLOPT_G_MLSL_LDS, status, name, nlopt_alg);
    GET_NLOPT_ALG(NLOPT_G_MLSL, status, name, nlopt_alg);
    GET_NLOPT_ALG(NLOPT_GN_ISRES, status, name, nlopt_alg);
    GET_NLOPT_ALG(NLOPT_GN_ESCH, status, name, nlopt_alg);
    
    if (status == NOT_FOUND) {
        data_io_print_file_error(ctlFile, parN, str, NULL);
    }
    fprintf(outF, "%s %s\n", parName, name);
    return nlopt_alg;
}

#define GET_DF_ALG(alg, status, instr, algstr, algPtr) \
            if (status == NOT_FOUND && strstr(#alg, instr) != NULL) { \
                status = FOUND_ALG; \
                algstr = #alg; \
                algPtr[0] = alg; \
            }


/**
 * @since 2014.04.30, 2014.05.02, 2014.05.05, 2014.06.01
 */
void data_io_control_get_df_alg(data_io_df_alg_T *algPtr, int *nAlgPar, double **algPar, char *stptr, const char *ctlFile, int parN, FILE *outF, const char *parName) {
    enum { NOT_FOUND, FOUND_ALG } status;
    status = NOT_FOUND;

    char stptr2[strlen(stptr) + 1];
    strcpy(stptr2, stptr);
    char *instr = data_io_trim(stptr2);
    if (instr == NULL || strlen(instr) == 0) {
        data_io_print_file_error(ctlFile, parN, stptr, NULL);
    }
    int ind = data_io_first_space(instr);
    if (ind > 0) {
        instr[ind] = '\0'; //split the string
        if (strlen(instr) == 0) {
            data_io_print_file_error(ctlFile, parN, stptr, NULL);
        }
        const char *algstr;
        GET_DF_ALG(data_io_df_alg_NR, status, instr, algstr, algPtr);  
        GET_DF_ALG(data_io_df_alg_GSL, status, instr, algstr, algPtr);
        if (status == FOUND_ALG) {
            if (algPtr[0] == data_io_df_alg_NR)
                nAlgPar[0] = 2;
            else if (algPtr[0] == data_io_df_alg_GSL)
                nAlgPar[0] = 1;
            else {
                abort();
            }
            algPar[0] = matrixalloc_1d(nAlgPar[0], sizeof (double));
            data_io_control_get_double_array(nAlgPar[0], instr + ind + 1, algPar[0], ctlFile, parN, NULL, parName);
            fprintf(outF, "%s %s", parName, algstr);
            for (int i = 0; i < nAlgPar[0]; i++)
                fprintf(outF, " %g", algPar[0][i]);
            fprintf(outF, "\n");
        } else {
            data_io_print_file_error(ctlFile, parN, stptr, NULL);
        }
    } else {
        data_io_print_file_error(ctlFile, parN, stptr, NULL);
    }
}

/**
 * @since 2014.05.12, 2014.06.01, 2014.06.15, 2014.09.21
 */
void data_io_control_get_range(char *stptr, int n, double range[n], double min, double max, bool setBound, 
        const char *ctlFile, int parN, FILE *outF, const char *parName) {
    if (min >= max) {
        fprintf(stderr, "%s MIN_VALUE >= MAX_VALUE\n", parName);
        abort();
    }
    if (n % 2 != 0) {
        fprintf(stderr, "Error: %s %i\n", __FILE__, __LINE__);
        abort();
    }
    for (int i = 0; i < n;) {
        range[i++] = min;
        range[i++] = max;
    }
    if (setBound == true) {
        data_io_control_get_double_array(n, stptr, range, ctlFile, parN, outF, parName);
        for (int i = 0; i < n; i += 2) {
            if (range[i] >= range[i + 1] || range[i] <= min || range[i + 1] >= max) {
                fprintf(stderr, "%s beyond the permitted range [%g, %g]: %s\n", parName, min, max, stptr);
                abort();
            }
        }
    } else {
        if (data_io_all_space(stptr) == false) {
            fprintf(stderr, "%s should not be set when setBound: is false\n", parName);
            abort();
        }
        fprintf(outF, "%s\n", parName);
    }
}