#include <math.h>

#if defined (USE_MKL)
    #define INT_TYPE MKL_INT
#elif defined (USE_ATLAS) 
    #define INT_TYPE lapack_int
#endif
    
#include "gsl/gsl_sf.h"

#include "util/matrixalloc.h"

#include "matrix_util.h"


/**
 * @since 2014.09.14 (MKL, ALTLAS for matrix_is_step), 2014.09.17 (MKL & ATLAS for matrix_2a_step), 2014.09.25 (night), 2015.10.25 (ATLAS, matrix_is_step)
 */
int matrix_util_solve_equi(MATRIX_UTIL_INT K, const double *A, double *AF, const double *b, double *x, 
        MATRIX_UTIL_INT *ipiv, double *work, MATRIX_UTIL_INT *iwork) {
#if defined(USE_MKL)
    MATRIX_UTIL_INT *Kadd = &K;
    MATRIX_UTIL_INT info;
    dgetrf(Kadd, Kadd, AF, Kadd, ipiv, &info);//void dgetrf(const MKL_INT* m, const MKL_INT* n, double* a, const MKL_INT* lda, MKL_INT* ipiv, MKL_INT* info );
    if (info != 0)
        return 1;
    
    const char trans = 'N';
    MATRIX_UTIL_INT nrhs = 1;
    /*
     * void dgetrs( const char* trans, const MKL_INT* n, const MKL_INT* nrhs, 
             const double* a, const MKL_INT* lda, const MKL_INT* ipiv,
             double* b, const MKL_INT* ldb, MKL_INT* info );
     */
    dgetrs(&trans, Kadd, &nrhs, AF, Kadd, ipiv, x, Kadd, &info);
    if (info != 0)
        return 1;
    
    double ferr, berr;
    /*
     * void dgerfs( const char* trans, const MKL_INT* n, const MKL_INT* nrhs, 
             const double* a, const MKL_INT* lda, const double* af,
             const MKL_INT* ldaf, const MKL_INT* ipiv, const double* b,
             const MKL_INT* ldb, double* x, const MKL_INT* ldx, double* ferr,
             double* berr, double* work, MKL_INT* iwork, MKL_INT* info );
     */
    dgerfs(&trans, Kadd, &nrhs, A, Kadd, AF, Kadd, ipiv, b, Kadd, x, Kadd, &ferr, &berr, work, iwork, &info);
    if (info != 0)
        return 1;
    
    return 0;
#elif defined(USE_ATLAS)
    MATRIX_UTIL_INT info = LAPACKE_dgetrf_work(LAPACK_COL_MAJOR, K, K, AF, K, ipiv);//lapack_int LAPACKE_dgetrf_work( int matrix_order, lapack_int m, lapack_int n, double* a, lapack_int lda, lapack_int* ipiv );
    if (info != 0)
        return 1;
    
    /*
     * lapack_int LAPACKE_dgetrs_work( int matrix_order, char trans, lapack_int n,
                                lapack_int nrhs, const double* a,
                                lapack_int lda, const lapack_int* ipiv,
                                double* b, lapack_int ldb );
     */
    info = LAPACKE_dgetrs_work(LAPACK_COL_MAJOR, 'N', K, 1, AF, K, ipiv, x, K);
    if (info != 0)
        return 1;
    
    /*
     * lapack_int LAPACKE_dgerfs_work( int matrix_order, char trans, lapack_int n,
                                lapack_int nrhs, const double* a,
                                lapack_int lda, const double* af,
                                lapack_int ldaf, const lapack_int* ipiv,
                                const double* b, lapack_int ldb, double* x,
                                lapack_int ldx, double* ferr, double* berr,
                                double* work, lapack_int* iwork );
     */
    double ferr, berr;
    info = LAPACKE_dgerfs_work(LAPACK_COL_MAJOR, 'N', K, 1, A, K, AF, K, ipiv, b, K, x, K, &ferr, &berr, work, iwork);
    if (info != 0)
        return 1;
    
    return 0;
#endif    
}



/**
 * @since 2013.08.01, 2013.08.11, 2013.09.10, 2013.09.26
 */
double ***matrix_util_bino_new(const int nl, const int *ns, const int hapsize) {
    double ***bino = matrixalloc_1d(nl, sizeof (double **));
    for (int i = 0; i < nl; i++) {
        int n = ns[i];
        bino[i] = matrixalloc_1d(n + 1, sizeof (double *));
        for (int j = 0; j <= n; j++) {
            bino[i][j] = matrixalloc_1d(hapsize + 1, sizeof (double));
            for (int k = 0; k <= hapsize; k++) {
                if (k == 0) {
                    if (j == 0)
                        bino[i][j][k] = 1;
                    else
                        bino[i][j][k] = 0;
                } else if (k == hapsize) {
                    if (j == n) 
                        bino[i][j][k] = 1;
                    else
                        bino[i][j][k] = 0;
                } else {
                    double p = (double) k / hapsize;
                    bino[i][j][k] = gsl_sf_lnchoose((unsigned) n, (unsigned) j)
                            + j * log(p) + (n - j) * log(1 - p);
                    bino[i][j][k] = exp(bino[i][j][k]);
                }
            }
        }
    }
    return bino;
}

/**
 * @since 2013.08.11, 2013.09.10, 2013.12.29
 */
void matrix_util_bino_free(const int nl, const int *ns, double ***bino) {
    for (int i = 0; i < nl; i++) {
        for (int j = 0; j <= ns[i]; j++)
            matrixalloc_1d_free(bino[i][j]);
        matrixalloc_1d_free(bino[i]);
    }
    matrixalloc_1d_free(bino);
}
