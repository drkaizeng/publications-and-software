/* 
 * File:   data_2a_step_io.h
 * Author: Kai
 *
 * Created on 12 September 2013, 15:26
 */

#ifndef DATA_2A_IO_WORK_H
#    define	DATA_2A_IO_WORK_H

#include <stdio.h>


/**
 * On entry
 * nlPtr[0] = 0
 * nsPtr[0] = NULL
 * dataPtr[0] = NULL
 * 
 * The data should be in the following format
 * nl (this is the number of data lines below; nl must be an integer)
 * ns a[0] a[1] ... a[ns] (ns is the sample size; 
 *                         ns in different rows must be in strictly ascending order;
 *                         a[i] is the number of sites where the A0 allele is represented i times; 
 *                         a[i] is a nonnegative double value)
 * 
 * @param in A pointer to the file from which the data will be read. 
 * @param buffer
 * @param buffer_size
 * @param fileName name of the data file
 * @param lineNoPtr The index of the number of lines that have been read so far.
 * @param nlPtr On return, nlPtr[0] 
 * @param nsPtr On return, nsPtr[0] points to an integer array
 * @param dataPtr On return dataPtr[0] points to the data
 */
void data_io_work_2a_get_data(FILE *in, const int buffer_size, char buffer[buffer_size], const char *fileName, int * const lineNoPtr,
        int *nlPtr, int **nsPtr, double ***dataPtr);
void data_io_work_2a_free_data(int nl, int *ns, double **data);
/**
 * @param chr A single character that signifies the beginning of a data set in the data file.
 */
void data_io_work_2a_write_data(FILE *outF, const char *chr, int nl, int *ns, double **data);

/**
 * On entry
 * nlPtr[0] = 0
 * nsPtr[0] = NULL
 * dataPtr[0] = NULL
 * 
 * The data should be in the following format
 * nl (this is the number of data lines below; nl must be an integer)
 * ns a[1] ... a[ns-1] (ns is the sample size; 
 *                         ns in different rows must be in strictly ascending order;
 *                         a[i] is the number of sites where the derived allele is represented i times; 
 *                         a[i] is a nonnegative double value)
 * 
 * @param in A pointer to the file from which the data will be read. 
 * @param buffer
 * @param buffer_size
 * @param fileName name of the data file
 * @param lineNoPtr The index of the number of lines that have been read so far.
 * @param nlPtr On return, nlPtr[0] 
 * @param nsPtr On return, nsPtr[0] points to an integer array
 * @param dataPtr On return dataPtr[0] points to the data
 */
void data_io_work_is_get_data(FILE *in, const int buffer_size, char buffer[buffer_size], const char *fileName, int * const lineNoPtr,
        int *nlPtr, int **nsPtr, double ***dataPtr);
void data_io_work_is_free_data(int nl, int *ns, double **data);
/**
 * @param chr A single character that signifies the beginning of a data set in the data file.
 */
void data_io_work_is_write_data(FILE *outF, const char *chr, int nl, int *ns, double **data);

#endif	/* DATA_2A_IO_WORK_H */

